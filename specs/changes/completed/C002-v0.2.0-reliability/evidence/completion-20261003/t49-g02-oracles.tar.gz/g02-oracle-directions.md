G02 只读 Spec 与处分方向审查。47 个精确旧ID→当前ID均采用已独立核验的映射；按8组真实消费者/独立判据组织，不为每个mutant复制实现。本报告不编写生产oracle、不改仓库、不执行这47个突变，也不给它们动态PASS。确切ID、diff SHA、当前源码SHA与分组见 `g02-oracle-direction-index.json`。

最先补 O1 的历史快照资格、O2 的同身份新旧生命周期、O5 的真实发布完成清理race。它们可共享同一套合法fixture、完整原响应、SQL行及原件oracle。原G02的不存在binary(request_id)导致0变异执行，停止原文必须保留；修正filter后的非零baseline另记，不能把两次运行合并。使用实际nextest JSON列出的 `workbook_txn`、`effect_contracts`、`service`、`reliability_crash` 等消费者；不凭文件名相似猜binary存在。

**共同产物与停止条件。** 正例由真实CLI/Repo/WorkService形成Work/Workbook与requests/audit/effects。期望取首次完整响应、手写合同值、独立SQL `SELECT *` 原SQLite类型/内容、全树原bytes/mode与必要dev/ino。拒绝例只改一个逻辑条件；若维护合法身份闭包必须同步附属字段，明确列出每项改动及保持一致的原因，不把多处无关修改称单字段反例。本人已提交错误须committed=true/request_id=A；旧A阻新B须committed=false/request_id=B/pending_request_id=A；坏快照资格不得original/pending_original，已核资格的坏效果仍保留原响应。任何控制例不绿、baseline为零、源hash漂移、未到目标窗口、超时或产物原字节漂移即停止，原Missed/Timeout/0-run不改caught。

| 组 | ID数 | 真实入口与共享判据 |
| --- | ---: | --- |
| O1 快照shape/身份 | 4 | WorkbookRepo::load_checked_request经同rid add重放，及旧pending add/remove阻断新正常写。flows空/重复/非法FlowId与requires单侧空kind/name；非法id/version要在成功original前拒。 |
| O2 最新生命周期选择 | 8 | Repo add A→remove R→add B；load/list/verify及旧A/R重放。相同id/version、相同秒、可相同digest时仍只能由B证明当前final，坏B不得借A。 |
| O3 当前row/请求/effect/索引闭包 | 15 | Repo.load/list/verify；workbook-row与最新add完整请求、audit、PublishDir和捕获索引必须一致。单独核原响应资格与文件动作前停止，不只is_err。 |
| O4 Work Start发布定位 | 6 | WorkService::stats/list及写重放中的load，真实work_start_effect_rows→PendingReferenceIndex→workbook_publication。Start只能指自己的works/W与规范pending；错final不能被同owner/相同Workbook digest放行。 |
| O5 完成清理fallback | 8 | readonly Repo.load与WorkService.stats/list；先捕获published=false，再在owner读取窗口由真实writer发布/标记/清理，reader只能接受同metadata的published=true。 |
| O6 实体manifest身份 | 2 | work start复制最终副本与Repo.load当前目录，核id/version与登记身份，即使摘要检查另有保护也不凭猜测记等价。 |
| O7 缺文件与rename重读 | 3 | WorkService::load_row_at→read_publish_dir。已发布缺声明文件为StoreCorrupt；合法pending→final竞态允许有界整份重读；永久缺失必须停止。 |
| O8 完整Workbook效果形状 | 1 | load_checked_request→check_workbook_effects。整组形状/归属在任何效果动作前严格核，坏效果保留已核original。 |

**O1：用一次快照资格表覆盖多个条件。** 首次add与同rid重放完整响应一致（只有replayed变化），源可消失。依次只把历史data.flows变成 `[]`、重复同一合法id、一个非法id；requires用 `:named` 与 `skill:`，分别只空kind或name，不同时空两者。预期EFFECT_PENDING/STORE_CORRUPT、无成功original、完整row/files不变。这些shape在completed历史重放不会重读当前Workbook，不能靠删除源或改当前安装目录来挡住它。

`validate_workbook_identity→Ok`需专门核**资格**。只改add.data.id通常会更早在PublishDir目标绑定被拒，不能说明身份语法guard被测到。可保持原意图/请求、构造id或version本身非法但data与PublishDir final/owner相互一致的历史载荷，独立记录改动闭包：原实现应在original前拒；突变可能在之后受管路径或效果对象验证才失败，却已经附错误original。remove的同ridCLI先拒非法selector，宜把旧pending A的audit target/data/hash/effect身份同步到同一个非法身份，再由合法新B触发恢复；不能用REQUEST_CONFLICT当检测。效果失败类型、original/pending_original有无与原件不变才是辨别力。

**O2：同秒同digest仍必须保最新请求。** 实际add A、remove R、add B；一组B内容不变，一组B有独立新bytes/digest。把requests.at、audit.at与当前row.added_at固定到同秒合法值，核正常load选择B。只坏最新B的audit种类/target、snapshot.data.id或version、request关联时，必须StoreCorrupt，不回退A；现有 `current_workbook_never_uses_an_old_same_second_publisher_when_latest_audit_is_corrupt` 可作具体入口，但新增条件的完整原件/SQL oracle需要补足。旧A/R重放必须返回它们自己的历史快照，B的row/digest/dev/ino/bytes不变，不能重封存、误删B或重新发布A。

`lifecycle_references_for_workbook→vec![]`与两个==→!=不是“健康路径也能从audit找到”的等价：publisher_ids是发现伪装/损坏最新请求的来源桥。A→R→B且同秒同digest时，将B的data身份或remove target改成另一合法身份；缺桥接可能漏掉坏B并误用A。删除latest-remove match arm也不能只核最终StoreCorrupt：原分支先完整验证R，再给“当前row声称removed生命周期仍存在”的诊断。保留残存row、只坏R的metadata/effect时必须准确报告R的损坏，不能把它伪装成“缺add”而绕过R验证；原字节与不执行效果一并核。普通非Workbook Work audit在同Store内必须被忽略，给publication_for_row的skip条件一个真实合法对照。

**O3：重复检查的对象是否相同必须逐项核。** 最新请求的checked结果与当前row不同权威：row.digest/added_at、request.at、audit.at/Work归属、当前manifest分别有独立锚点；跨连接读取不天然同快照。先用静态坏row/坏snapshot/effect合法类型漂移做单条件拒绝；若旧层已经挡住，要明确前层检测，不记当前guard被执行。

索引校验可用现有 `pending_after_reference_index`：reader取得原索引后暂停，再更改后续读取的requests/effects，恢复后应拒绝索引/当前请求不一致。特别是借另一个same-owner生命周期的internal-id：捕获索引中那个id属于A，当前B.effect.pending改成A的规范pending，其它身份/digest相同。原实现必须因reference.request_id≠B拒；pending字符串本身相等，||→&&的优先级可能吞掉前一request-id不等。不能先在所有记录里造成重复internal-id，那会被索引producer拒绝而摸不到后续guard。

审计也有两次读取：checked_effects_for内部已经捕获audit，publication_for_row随后重新audit_rows。若测试最新audit归属/时间的后层check，用owner读取的既有窗口捕获旧合法audit，再改独立SQLite事实给第二次读取；拒绝必须发生在业务文件读取前。请求行的raw字符串在CheckedRequest里是不可变局部值，别把重复反序列化当新的Store查询。确实由同一不可变值证明的冗余可给精确限定静态处分，不要求重复执行。

**O4：先区分producer严格拒绝与后续漂移。** `load_work_start` SQL只选requests.work_id=W、audit.revision=1；from_rows核Work owner与requests.work_id、owner/final/digest_root及规范pending。静态只改owner/pending常被producer提前拒绝，这不能给workbook_publication后层mutant记caught。对于final/pending后层guard，用 `pending_after_reference_index` 捕获旧合法索引，再单改将要读取的Start effects；stats/list是真实仍走workbook_publication的只读caller，status/result现在走bundle，不能互相代替。

目标final可以借另一个同Workbook版本/同digest的真实Work V的冻结目录，同时保持Start owner为W，State/Command/Reply仍是W。原实现必须在读取V之前拒绝，不以“摘要相同”认为归属成立。严格pending例核prefix/leaf/UUID；已有正确owner侧车或已发布final不能豁免持久路径结构。多个publish或错误kind也应在任何定位/业务读取前拒绝，不人为构造private未校验Index直接调用helper。

**O5：一个正race捕获8个错误拒绝变体。** 已有 `workbook_reader_accepts_publication_and_cleanup_after_its_reference_index` 的pause在request重新读取之前；writer先完成时reader可能直接看到published=true，完全不走owner_error fallback。必须在reader已捕获false、owner sidecar开始读取时暂停。可用现有 `regular_open_after_stat`，scope为精确owner侧车绝对路径。等待reached后disarm，随后真实writer同rid恢复并cleanup移除owner，最后release reader；其owner open得到原对象已消失，fallback重读请求必须接受published=true且所有metadata逐字相同。用未发布真实请求/原文件，不在fake中直接写成功。writer也会读owner，必须先disarm避免两参与者卡同一屏障。RAII保证release/join。

Repo.load可覆盖load_checked_request三项；WorkService.stats/list覆盖workbook_publication五项。正常published转换只改flag，原响应/source/intent/effects/work/at不变。负对照：published仍false或任一metadata漂移，必须保留准确owner_error，不能凭flag接受新载荷；Store/业务原件除已允许的真实publication变化外不动。不能用sleep概率或反复跑到绿替代确定性握手。

**O6/O7：不要为了杀mutant改变产品错误合同。** 目录manifest只改id或version且相关SHA已由独立帧算法更新到实际bytes时，当前row/请求/effect仍明确要求旧身份，Repo.load必须StoreCorrupt；digest相等与身份一致是两个条件。Work start的identity ||→&&后仍有copied.digest检查，若只观察“最终失败”，该mutant可能只是换诊断路径。没有可达正反例或精确静态证明时保留open，不用被测digest helper造自己的expected，不要求计算SHA碰撞。

load_row_at三个NotFound变体要覆盖真实已发布目录内缺某一声明文件、合法publication rename发生于冻结编译期间、永久缺失三种条件。`pending_read_after_locate`太早可能在“冻结目录不存在”分支提前返回，未触compile_frozen_workbook的NotFound映射；必须核命中实际分支再报告辨别力。原外层也把部分NotFound转StoreCorrupt，因此错误文本不同与拒绝集合变化要分开。若只能证明同类错误/无I/O差异，可给合同范围内的静态处分并保留诊断差异，不能写全可观察等价。

**目前有两条完整producer约束的静态候选证明，可减少无收益执行。**

1. pending.rs:173 `publish_references_for_work`的&&→||：唯一caller传Work W，producer是load_work_start。SQL限定r.work_id=W；from_rows对每个PublishDir核requests.work_id=owner里的W，对DeleteDir拒任何Work归属，对Workbook Publish同样拒Work归属。Index只保存publish/delete目录refs。因此能返回的reference全部operation=publish且owner=work:W；两个谓词恒真，&&/||返回集合相同。涉及parse/验证仍在producer先执行。仅此完整调用闭包候选可作静态对应，不扩大到一般未校验Index。
2. pending.rs:185 `lifecycle_references_for_workbook`的&&→||：唯一caller的row先经validate_workbook_row，owner=`workbook:id@version`、final=`workbooks/id/version`。所有Workbook ref的producer validate_publish_reference/validate_delete_reference严格绑定这两个字段；Work ref的命名域与之互斥。对每个能进入Index的ref，owner相等当且仅当final相等，&&/||过滤集合逐项相同。其它两个==→!=与vec![]变体没有此等价，不套用本证明。

此外publication_for_row的snapshot request-id/replayed重复核、checked effects对owner/final/digest_root的后层核可能受同一不可变CheckedRequest/CheckedEffects支配；必须逐ID证明返回值构造、metadata fallback与所有caller后再处置。audit/index的再次查询可漂移，不能套同一证明。check_workbook_effects开头效果数量guard之后还有完整shape检查：若静态证明拒绝集合/无效果I/O相同，仍须保留具体诊断差异，不能称原响应全字节等价。

||→&&改变Rust优先级：它可能把“前一条件 OR 当前条件”变成“前一条件 AND 当前条件”，并非单纯删除当前字段check。每组的独立期望来自合同事实，不以mutant行号命名规则，不逐个镜像实现。完成实际baseline/样本后再扩大47项，每个最终处分保留其精确ID、候选/consumer/raw结果与静态边界。
