//! 任务书与状态卡的渲染。格式见 `specs/contracts/protocol.md` §4、§6。
//! 快照测试的期望文件在 `snapshots/` 下，由 T01 手写，是标准答案。

use std::collections::{BTreeMap, BTreeSet};

use serde::Serialize;

use super::next::{NextOp, legal_next};
use super::state::{
    ArtifactRef, Attempt, AttemptStatus, BlockedReason, Timestamp, WorkState, WorkStatus,
};
use crate::flow::{Graph, InputSource};
use crate::ids::WorkId;
use crate::path::AbsPath;

/// 渲染一份 Attempt 的任务书（协议 §4）。快照 `snapshots/*brief*.snap` 是逐字节的标准答案。
///
/// 逐行格式（`\n` 分隔，末尾一个换行）：
///
/// ```text
/// # 任务书：<node.title>
/// <空行>
/// Work: <work_id>（<name>）
/// 节点: <node>#<n>，第 <number> 次尝试
/// 来自: <occ>（<kind> 边）            入口为「来自: 入口」
/// 执行者: agent（<tier>）             human 为「执行者: human」
/// <空行>
/// ## 输入
/// <空行>
/// | 名称 | 路径 | sha256 |
/// | --- | --- | --- |
/// | <name> | <绝对路径> | <64 位摘要> |        按节点 inputs[] 声明顺序
/// | <name> | 尚无（上游 <node> 还没有产出） | |   可选且未绑定
/// <空行>
/// ## 需要的宿主资源                           节点 requires 非空时才有此节
/// <空行>
/// | 类型 | 名称 | 版本 | 说明 |
/// | --- | --- | --- | --- |
/// | <kind> | <name> | <version 或 -> | 请确认你的宿主已装此 <kind>；未装请停下并告知用户 |   「此 <kind>」随类型变成「此 skill」「此 agent」「此 mcp」
/// <空行>
/// ## 说明
/// <空行>
/// <instruction_text 原文，去掉末尾换行后再补一个换行>
/// <空行>
/// ## 输出要求
/// <空行>
/// | 名称 | 写到 | 必需 | 上限 |
/// | --- | --- | --- | --- |
/// | <name> | <attempt_dir>/<path> | 是/否 | <human_size(max_bytes)> |
/// <空行>
/// 完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
/// ```
///
/// human 执行者时最后一段换成：
///
/// ```text
/// 写完输出文件后，在终端运行：
/// <空行>
///     sheltie attempt submit <work_id> --attempt <attempt_id> --summary "<一句话结论>"
/// ```
///
/// 没有输入时「## 输入」节只有表头两行。`human_size`：字节数是 1 MiB 的整数倍写 `N MiB`，是 1 KiB 的整数倍写 `N KiB`，否则 `N B`。
pub fn render_brief(
    state: &WorkState,
    graph: &Graph,
    attempt: &Attempt,
    instruction_text: &str,
) -> String {
    let Some(node) = graph.node(&attempt.id.node) else {
        return String::new();
    };
    let mut out = String::new();
    out.push_str(&format!("# 任务书：{}\n\n", node.title));
    out.push_str(&format!("Work: {}（{}）\n", state.work_id, state.name));
    out.push_str(&format!(
        "节点: {}，第 {} 次尝试\n",
        attempt.occurrence(),
        attempt.id.number
    ));
    match &attempt.entered_from {
        None => out.push_str("来自: 入口\n"),
        Some((occ, kind)) => {
            out.push_str(&format!("来自: {occ}（{} 边）\n", kind.as_str()));
        }
    }
    match node.executor {
        crate::flow::Executor::Agent => {
            let tier = node.tier.unwrap_or_default();
            out.push_str(&format!("执行者: agent（{}）\n", tier.as_str()));
        }
        crate::flow::Executor::Human => out.push_str("执行者: human\n"),
    }
    out.push('\n');

    out.push_str("## 输入\n\n");
    out.push_str("| 名称 | 路径 | sha256 |\n");
    out.push_str("| --- | --- | --- |\n");
    for decl in &node.inputs {
        match attempt.inputs.get(&decl.name).and_then(|o| o.as_ref()) {
            Some(r) => out.push_str(&format!(
                "| {} | {} | {} |\n",
                decl.name,
                r.path,
                r.sha256.as_str()
            )),
            // 合同 §4 模板：未绑定的可选输入写「尚无（上游 <node> 还没有产出）」。
            // required = false 只允许来自 <node>.<output>（编译规则 5），其余来源 begin 时必已绑定。
            None => match &decl.from {
                InputSource::Node { node, .. } => out.push_str(&format!(
                    "| {} | 尚无（上游 {} 还没有产出） | |\n",
                    decl.name, node
                )),
                _ => out.push_str(&format!("| {} | 尚无 | |\n", decl.name)),
            },
        }
    }

    if !node.requires.is_empty() {
        out.push_str("\n## 需要的宿主资源\n\n");
        out.push_str("| 类型 | 名称 | 版本 | 说明 |\n");
        out.push_str("| --- | --- | --- | --- |\n");
        for (kind, name) in &node.requires {
            // 版本从 Workbook 的 requires 声明里查（合同 §4 模板）；没声明版本就写 `-`。
            let version = graph
                .requires()
                .iter()
                .find(|r| r.kind == *kind && r.name == *name)
                .and_then(|r| r.version.as_deref())
                .unwrap_or("-");
            // 说明里的「此 <kind>」随类型变：此 skill / 此 agent / 此 mcp（协议 §4）。
            out.push_str(&format!(
                "| {} | {} | {} | 请确认你的宿主已装此 {}；未装请停下并告知用户 |\n",
                kind.as_str(),
                name,
                version,
                kind.as_str()
            ));
        }
    }

    out.push_str("\n## 说明\n\n");
    out.push_str(instruction_text.trim_end_matches('\n'));
    out.push('\n');

    let attempt_dir = state.attempt_dir(&attempt.id);
    out.push_str("\n## 输出要求\n\n");
    out.push_str("| 名称 | 写到 | 必需 | 上限 |\n");
    out.push_str("| --- | --- | --- | --- |\n");
    for decl in &node.outputs {
        out.push_str(&format!(
            "| {} | {} | {} | {} |\n",
            decl.name,
            crate::work::layout::output_path(&attempt_dir, &decl.path),
            if decl.required { "是" } else { "否" },
            human_size(decl.max_bytes)
        ));
    }

    out.push('\n');
    match node.executor {
        crate::flow::Executor::Agent => {
            out.push_str("完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。\n");
        }
        crate::flow::Executor::Human => {
            out.push_str("写完输出文件后，在终端运行：\n\n");
            out.push_str(&format!(
                "    sheltie attempt submit {} --attempt {} --summary \"<一句话结论>\"\n",
                state.work_id, attempt.id
            ));
        }
    }
    out
}

/// `N MiB` / `N KiB` / `N B`。0 写 `0 B`。
fn human_size(bytes: u64) -> String {
    const MIB: u64 = 1024 * 1024;
    const KIB: u64 = 1024;
    if bytes == 0 {
        "0 B".to_string()
    } else if bytes % MIB == 0 {
        format!("{} MiB", bytes / MIB)
    } else if bytes % KIB == 0 {
        format!("{} KiB", bytes / KIB)
    } else {
        format!("{bytes} B")
    }
}

/// 渲染状态卡（协议 §6）。快照 `snapshots/*status_card*.snap` 是标准答案。
///
/// ```text
/// # Work <work_id>（<name>）
/// <空行>
/// workbook: <id>@<version>   flow: <flow>   status: <status>     status 用 WorkStatus 的 Display，如 blocked(gate)
/// current: <occ>
/// done: <occ>, <occ>                                              全部 Succeeded 的 Occurrence，按提交先后；没有写「无」
/// pending: <node>, <node>                                         从未到达的节点，按图声明顺序；没有写「无」
/// visits: draft 2/3, review 1/3, publish 0/1                      按图声明顺序，visits/max_visits
/// blocked: <reason>: <说明>                                       只在 Blocked 时有；说明见协议 §6
/// <空行>
/// ## 最近一次尝试
/// <空行>
/// <attempt_id> <status>                                           attempts.last()；没有任何 Attempt 写「无」
/// summary: <summary>                                              仅 Succeeded 且有摘要
/// reason: <fail_reason>                                           仅 Failed 且有原因
/// outputs:                                                        仅 Succeeded 且有输出；每个输出一行，缩进两格
///   <name> → <path> (sha256 <64 位>, <human_size(bytes)>)
/// <空行>
/// ## 合法下一步
/// <空行>
/// - <to_command_line>                                             每项一行；终态时写「- 无」
/// ```
///
/// `blocked` 行的说明：`gate: <occ> 需要 gate approve`；`retries_exhausted: <occ>`；
/// `no_legal_edge: <occ> 的全部出边目标已达 max_visits`。
pub fn render_status_card(state: &WorkState, graph: &Graph) -> String {
    let view = status_view(state, graph);
    let mut out = String::new();
    out.push_str(&format!("# Work {}（{}）\n\n", view.work_id, view.name));
    out.push_str(&format!(
        "workbook: {}   flow: {}   status: {}\n",
        view.workbook, view.flow, view.status
    ));
    out.push_str(&format!("current: {}\n", view.current));

    out.push_str(&format!(
        "done: {}\n",
        if view.done.is_empty() {
            "无".to_string()
        } else {
            view.done.join(", ")
        }
    ));
    out.push_str(&format!(
        "pending: {}\n",
        if view.pending.is_empty() {
            "无".to_string()
        } else {
            view.pending.join(", ")
        }
    ));
    let visits = view
        .visits
        .iter()
        .map(|(n, m)| format!("{n} {m}"))
        .collect::<Vec<_>>()
        .join(", ");
    out.push_str(&format!("visits: {visits}\n"));
    if let Some(line) = &view.blocked {
        out.push_str(&format!("blocked: {line}\n"));
    }

    out.push_str("\n## 当前任务\n\n");
    match &view.resume {
        None => out.push_str("无\n"),
        Some(resume) => {
            out.push_str(&format!(
                "attempt: {}\nbrief_path: {}\n",
                resume.attempt, resume.brief_path
            ));
            out.push_str("inputs:\n");
            for (name, reference) in &resume.inputs {
                match reference {
                    Some(reference) => out.push_str(&format!(
                        "  {} → {} (sha256 {}, {} B)\n",
                        name, reference.path, reference.sha256, reference.bytes,
                    )),
                    None => out.push_str(&format!("  {name} → 尚无\n")),
                }
            }
            if !resume.draft_outputs.is_empty() {
                out.push_str("draft_outputs:\n");
                for (name, path) in &resume.draft_outputs {
                    out.push_str(&format!("  {name} → {path}\n"));
                }
            }
        }
    }

    out.push_str("\n## 最近一次尝试\n\n");
    match &view.last_attempt {
        None => out.push_str("无\n"),
        Some(a) => {
            out.push_str(&format!("{} {}\n", a.attempt, a.status.as_str()));
            match a.status {
                AttemptStatus::Succeeded => {
                    if let Some(s) = &a.summary {
                        out.push_str(&format!("summary: {s}\n"));
                    }
                    if !a.outputs.is_empty() {
                        out.push_str("outputs:\n");
                        for (name, r) in &a.outputs {
                            out.push_str(&format!(
                                "  {} → {} (sha256 {}, {})\n",
                                name,
                                r.path,
                                r.sha256.as_str(),
                                human_size(r.bytes)
                            ));
                        }
                    }
                }
                AttemptStatus::Failed => {
                    if let Some(s) = &a.reason {
                        out.push_str(&format!("reason: {s}\n"));
                    }
                }
                AttemptStatus::Superseded => {
                    if let Some(s) = &a.reason {
                        out.push_str(&format!("reason: {s}\n"));
                    }
                }
                AttemptStatus::Running => {}
            }
        }
    }

    out.push_str("\n## 合法下一步\n\n");
    if view.next.is_empty() {
        out.push_str("- 无\n");
    } else {
        for op in &view.next {
            out.push_str(&format!("- {}\n", op.to_command_line(&view.work_id)));
        }
    }
    out
}

/// 事实视图（GF-10/GF-29）：文本卡与 JSON 是**同一份事实**的两种渲染，失败原因、
/// 完整产物引用（路径、摘要、字节数）与 `next` 只在这里装配一次。
/// T06 交付纯实现与独立测试；持久 caller 与响应封装在 T07 统一接入。
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StatusView {
    pub work_id: WorkId,
    pub name: String,
    pub workbook: String,
    pub flow: String,
    pub status: WorkStatus,
    pub current: String,
    pub done: Vec<String>,
    pub pending: Vec<String>,
    pub visits: Vec<(String, String)>,
    /// 与文本卡相同的说明串（如 `gate: review#2 需要 gate approve`），无则 `None`。
    pub blocked: Option<String>,
    pub last_attempt: Option<LastAttemptView>,
    pub resume: Option<ResumeView>,
    pub next: Vec<NextOp>,
}

/// 最近一次尝试的事实：失败原因与完整产物引用都在。
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LastAttemptView {
    pub attempt: String,
    pub status: AttemptStatus,
    pub summary: Option<String>,
    pub reason: Option<String>,
    pub outputs: BTreeMap<String, ArtifactRef>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ResumeView {
    pub attempt: String,
    pub brief_path: AbsPath,
    pub inputs: BTreeMap<String, Option<ArtifactRef>>,
    pub draft_outputs: BTreeMap<String, AbsPath>,
}

/// 从状态与图装配事实视图。
pub fn status_view(state: &WorkState, graph: &Graph) -> StatusView {
    StatusView {
        work_id: state.work_id.clone(),
        name: state.name.to_string(),
        workbook: format!("{}@{}", state.workbook.id, state.workbook.version),
        flow: state.flow.to_string(),
        status: state.status,
        current: state.current.to_string(),
        done: done_occurrences(state),
        pending: pending_nodes(state, graph),
        visits: visit_items(state, graph),
        blocked: blocked_line(state),
        last_attempt: state.attempts.last().map(|a| LastAttemptView {
            attempt: a.id.to_string(),
            status: a.status,
            summary: a.summary.as_ref().map(|s| s.as_str().to_string()),
            reason: a
                .fail_reason
                .as_ref()
                .or(a.replacement_reason.as_ref())
                .map(|s| s.as_str().to_string()),
            outputs: a.outputs.clone(),
        }),
        resume: state.latest_attempt_of_current().map(|attempt| {
            let attempt_dir = state.attempt_dir(&attempt.id);
            let mut draft_outputs = BTreeMap::new();
            if attempt.status == AttemptStatus::Running {
                if let Some(node) = graph.node(&attempt.id.node) {
                    for output in &node.outputs {
                        draft_outputs.insert(
                            output.name.clone(),
                            crate::work::layout::output_path(&attempt_dir, &output.path),
                        );
                    }
                }
            }
            ResumeView {
                attempt: attempt.id.to_string(),
                brief_path: crate::work::layout::brief_path(&attempt_dir),
                inputs: attempt.inputs.clone(),
                draft_outputs,
            }
        }),
        next: legal_next(state, graph),
    }
}

/// `--json` 用的状态卡：`StatusView` 的结构化渲染。`last_attempt.outputs` 是完整
/// 产物引用（路径、摘要、字节数），失败时 `reason` 与文本卡同一来源；`next` 与协议
/// §5 的响应封装完全同形（O13）。
#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct StatusCardJson {
    pub work_id: WorkId,
    pub name: String,
    pub workbook: String,
    pub flow: String,
    pub status: WorkStatus,
    pub current: String,
    pub done: Vec<String>,
    pub pending: Vec<String>,
    pub visits: BTreeMap<String, String>,
    pub blocked: Option<String>,
    pub last_attempt: Option<LastAttemptJson>,
    pub resume: Option<ResumeView>,
    pub next: Vec<serde_json::Value>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct LastAttemptJson {
    pub attempt: String,
    pub status: String,
    pub summary: Option<String>,
    pub reason: Option<String>,
    pub outputs: BTreeMap<String, ArtifactRefJson>,
}

/// 完整产物引用（协议 §6）：与文本卡同样的路径、摘要与大小。
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ArtifactRefJson {
    pub path: String,
    pub sha256: String,
    pub bytes: u64,
}

/// 状态卡的结构化形式。字段与文本卡一致。
pub fn status_card_json(state: &WorkState, graph: &Graph) -> StatusCardJson {
    let view = status_view(state, graph);
    StatusCardJson {
        work_id: view.work_id,
        name: view.name,
        workbook: view.workbook,
        flow: view.flow,
        status: view.status,
        current: view.current,
        done: view.done,
        pending: view.pending,
        visits: view.visits.into_iter().collect(),
        blocked: view.blocked,
        last_attempt: view.last_attempt.map(|a| LastAttemptJson {
            attempt: a.attempt,
            status: a.status.as_str().to_string(),
            summary: a.summary,
            reason: a.reason,
            outputs: a
                .outputs
                .iter()
                .map(|(name, r)| {
                    (
                        name.clone(),
                        ArtifactRefJson {
                            path: r.path.to_string(),
                            sha256: r.sha256.as_str().to_string(),
                            bytes: r.bytes,
                        },
                    )
                })
                .collect(),
        }),
        resume: view.resume,
        next: view
            .next
            .iter()
            .map(|op| next_item_json(&state.work_id, op))
            .collect(),
    }
}

/// 协议 §5 的 `next` 项：`op`、`args`（含 `work`），以及仅 `attempt begin` 项上的
/// `edge`、`executor`、`tier`。全协议只有这一种形状（O13）。
pub fn next_item_json(work_id: &WorkId, op: &NextOp) -> serde_json::Value {
    match op {
        NextOp::BeginAttempt {
            node,
            edge,
            executor,
            tier,
        } => {
            let mut v = serde_json::json!({
                "op": "attempt begin",
                "args": { "work": work_id.as_str(), "node": node.as_str() },
            });
            if let Some(kind) = edge {
                v["edge"] = serde_json::json!(kind.as_str());
            }
            v["executor"] = serde_json::json!(executor.as_str());
            if let Some(t) = tier {
                v["tier"] = serde_json::json!(t.as_str());
            }
            v
        }
        NextOp::SubmitAttempt { attempt } => serde_json::json!({
            "op": "attempt submit",
            "args": { "work": work_id.as_str(), "attempt": attempt.to_string() },
        }),
        NextOp::FailAttempt { attempt } => serde_json::json!({
            "op": "attempt fail",
            "args": { "work": work_id.as_str(), "attempt": attempt.to_string() },
        }),
        NextOp::ReplaceAttempt { attempt } => serde_json::json!({
            "op": "attempt replace",
            "args": { "work": work_id.as_str(), "attempt": attempt.to_string() },
        }),
        NextOp::ApproveGate { node } => serde_json::json!({
            "op": "gate approve",
            "args": { "work": work_id.as_str(), "node": node.as_str() },
        }),
        NextOp::Cancel => serde_json::json!({
            "op": "work cancel",
            "args": { "work": work_id.as_str() },
        }),
    }
}

/// 全部 Succeeded 的 Occurrence，按提交先后。
fn done_occurrences(state: &WorkState) -> Vec<String> {
    let mut seen = BTreeSet::new();
    let mut out = Vec::new();
    for a in &state.attempts {
        if a.status == AttemptStatus::Succeeded {
            let occ = a.occurrence();
            if seen.insert(occ.clone()) {
                out.push(occ.to_string());
            }
        }
    }
    out
}

/// 从未到达的节点 id，按图声明顺序。
fn pending_nodes(state: &WorkState, graph: &Graph) -> Vec<String> {
    graph
        .nodes()
        .filter(|d| state.visits_of(&d.id) == 0)
        .map(|d| d.id.as_str().to_string())
        .collect()
}

/// `(node, "n/m")`，按图声明顺序。
fn visit_items(state: &WorkState, graph: &Graph) -> Vec<(String, String)> {
    graph
        .nodes()
        .map(|d| {
            (
                d.id.as_str().to_string(),
                format!("{}/{}", state.visits_of(&d.id), d.max_visits),
            )
        })
        .collect()
}

/// `blocked` 行；非 `Blocked` 为 `None`。
/// `blocked` 说明串（协议 §6：与文本行相同的串，不带 `blocked: ` 前缀）；
/// 非 `Blocked` 为 `None`。文本卡自行加前缀。
fn blocked_line(state: &WorkState) -> Option<String> {
    let occ = state.current.to_string();
    match state.status {
        WorkStatus::Blocked(BlockedReason::Gate) => Some(format!("gate: {occ} 需要 gate approve")),
        WorkStatus::Blocked(BlockedReason::RetriesExhausted) => {
            Some(format!("retries_exhausted: {occ}"))
        }
        WorkStatus::Blocked(BlockedReason::NoLegalEdge) => Some(format!(
            "no_legal_edge: {occ} 的全部出边目标已达 max_visits"
        )),
        _ => None,
    }
}

/// 事实视图（协议 `work stats`）：每个节点到达、尝试、失败几次，平均耗时、从哪些节点经哪种边进来。
/// 只是对 `WorkState` 的计数，不含任何判断。
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct StatsJson {
    pub work_id: WorkId,
    pub status: WorkStatus,
    /// 从 `created_at` 到 `updated_at` 的秒数。
    pub total_seconds: u64,
    pub blocked_count: u32,
    pub approvals: u32,
    /// 按图声明顺序。
    pub nodes: Vec<NodeStatsJson>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct NodeStatsJson {
    pub node: String,
    pub visits: u32,
    pub max_visits: u32,
    pub attempts: u32,
    pub failed: u32,
    pub superseded: u32,
    /// 已结束 Attempt 的平均秒数；没有则 0。
    pub avg_seconds: u64,
    /// `"<from>(<edge>)×<n>"` 或 `"entry×<n>"`，按首次出现顺序。
    pub entered_via: Vec<String>,
    /// 结构化同源数据：`{from, edge, count}`（`from`/`edge` 为 `null` 表示入口）。
    pub entered_via_json: Vec<EnteredViaJson>,
}

/// 单条进入来源事实（协议 `work stats` 的 JSON 形状）。
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct EnteredViaJson {
    pub from: Option<String>,
    pub edge: Option<String>,
    pub count: u32,
}

/// 事实视图的结构化形式。`total_seconds` 与 `avg_seconds` 由 `Timestamp::unix_secs` 相减得到。
pub fn render_stats_json(state: &WorkState, graph: &Graph) -> StatsJson {
    let mut nodes = Vec::new();
    for def in graph.nodes() {
        let attempts: Vec<&Attempt> = state
            .attempts
            .iter()
            .filter(|a| a.id.node == def.id)
            .collect();
        let failed = attempts
            .iter()
            .filter(|a| a.status == AttemptStatus::Failed)
            .count() as u32;
        let superseded = attempts
            .iter()
            .filter(|attempt| attempt.status == AttemptStatus::Superseded)
            .count() as u32;

        // entered_via 按 Occurrence 计（重试沿用同一来源），来源是「节点 + 边类型」
        // 二元组（N07：只记节点会把 main/back 混在一起），按首次出现顺序。
        let mut order: Vec<(Option<String>, Option<String>)> = Vec::new();
        let mut counts: BTreeMap<(Option<String>, Option<String>), u32> = BTreeMap::new();
        let mut seen_occ = BTreeSet::new();
        for a in &attempts {
            if !seen_occ.insert(a.id.occurrence) {
                continue;
            }
            let key = match &a.entered_from {
                Some((occ, kind)) => (
                    Some(occ.node.as_str().to_string()),
                    Some(kind.as_str().to_string()),
                ),
                None => (None, None),
            };
            if !counts.contains_key(&key) {
                order.push(key.clone());
            }
            *counts.entry(key).or_insert(0) += 1;
        }
        let entered_via = order
            .iter()
            .map(|key| {
                let n = counts.get(key).copied().unwrap_or(0);
                match key {
                    (Some(f), Some(e)) => format!("{f}({e})×{n}"),
                    _ => format!("entry×{n}"),
                }
            })
            .collect();
        let entered_via_json = order
            .iter()
            .map(|(from, edge)| EnteredViaJson {
                from: from.clone(),
                edge: edge.clone(),
                count: counts
                    .get(&(from.clone(), edge.clone()))
                    .copied()
                    .unwrap_or(0),
            })
            .collect();

        let mut ended_secs = 0u64;
        let mut ended_n = 0u64;
        for a in &attempts {
            if let Some(end) = &a.ended_at {
                ended_secs += secs_between(&a.started_at, end);
                ended_n += 1;
            }
        }
        nodes.push(NodeStatsJson {
            node: def.id.as_str().to_string(),
            visits: state.visits_of(&def.id),
            max_visits: def.max_visits,
            attempts: attempts.len() as u32,
            failed,
            superseded,
            avg_seconds: ended_secs.checked_div(ended_n).unwrap_or(0),
            entered_via,
            entered_via_json,
        });
    }
    StatsJson {
        work_id: state.work_id.clone(),
        status: state.status,
        total_seconds: secs_between(&state.created_at, &state.updated_at),
        // 累计受阻是状态转换记录的事实（GF-29/N07）：取消后不减少，不从当前
        // status 重推历史。
        blocked_count: state.blocked_count,
        approvals: state.approvals.len() as u32,
        nodes,
    }
}

/// 时间差，秒，负差算 0。`Timestamp` 构造时已校验格式，这里没有失败路径。
fn secs_between(a: &Timestamp, b: &Timestamp) -> u64 {
    (b.unix_secs() - a.unix_secs()).max(0) as u64
}

/// 事实视图的文本表（协议 `work stats`）。快照 `*stats_table*.snap` 是标准答案。
///
/// ```text
/// # Stats <work_id>
///
/// status: <status>   total: <Ns>   blocked: <n>   approvals: <n>
///
/// | node | visits | attempts | failed | avg | entered_via |
/// | --- | --- | --- | --- | --- | --- |
/// | draft | 2/3 | 2 | 0 | 0s | entry×1, review×1 |
/// ```
pub fn render_stats(state: &WorkState, graph: &Graph) -> String {
    let s = render_stats_json(state, graph);
    let mut out = String::new();
    out.push_str(&format!("# Stats {}\n\n", s.work_id));
    out.push_str(&format!(
        "status: {}   total: {}s   blocked: {}   approvals: {}\n\n",
        s.status, s.total_seconds, s.blocked_count, s.approvals
    ));
    out.push_str("| node | visits | attempts | failed | superseded | avg | entered_via |\n");
    out.push_str("| --- | --- | --- | --- | --- | --- | --- |\n");
    for n in &s.nodes {
        out.push_str(&format!(
            "| {} | {}/{} | {} | {} | {} | {}s | {} |\n",
            n.node,
            n.visits,
            n.max_visits,
            n.attempts,
            n.failed,
            n.superseded,
            n.avg_seconds,
            n.entered_via.join(", ")
        ));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testkit::Fixture;
    use crate::work::next::NextOp;

    // Task: C004-T01
    #[test]
    fn resume_without_current_attempt_is_null_in_text_and_json() {
        let fixture = Fixture::article_review().started();
        assert!(
            status_view(fixture.state(), &fixture.graph)
                .resume
                .is_none()
        );
        assert_eq!(
            serde_json::to_value(status_card_json(fixture.state(), &fixture.graph)).unwrap()["resume"],
            serde_json::Value::Null
        );
        assert!(
            render_status_card(fixture.state(), &fixture.graph).contains("## 当前任务\n\n无\n")
        );
    }

    // Task: C004-T01
    #[test]
    fn resume_running_attempt_has_frozen_inputs_and_declared_draft_paths() {
        let mut fixture = Fixture::article_review().started();
        fixture.begin("draft").unwrap();
        let card = status_card_json(fixture.state(), &fixture.graph);
        let resume = card.resume.unwrap();
        assert_eq!(resume.attempt, "draft#1.0");
        assert_eq!(
            resume.brief_path.as_str(),
            "/tmp/sheltie-test/works/2026-09-24-001-t/attempts/draft/occurrence-001/attempt-000/brief.md"
        );
        assert_eq!(resume.inputs["review"], None);
        let topic = resume.inputs["topic"].as_ref().unwrap();
        assert_eq!(
            topic.path.as_str(),
            "/tmp/sheltie-test/works/2026-09-24-001-t/start-inputs/topic"
        );
        assert_eq!(
            topic.sha256.as_str(),
            "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"
        );
        assert_eq!(topic.bytes, 5);
        assert_eq!(
            resume.draft_outputs["article"].as_str(),
            "/tmp/sheltie-test/works/2026-09-24-001-t/attempts/draft/occurrence-001/attempt-000/outputs/article.md"
        );
        let text = render_status_card(fixture.state(), &fixture.graph);
        assert!(text.contains("attempt: draft#1.0"));
        assert!(text.contains(resume.brief_path.as_str()));
        assert!(text.contains("review → 尚无"));
        assert!(text.contains(&format!("{} (sha256 {}, 5 B)", topic.path, topic.sha256)));
        assert!(text.contains("draft_outputs:"));
        assert!(text.contains(resume.draft_outputs["article"].as_str()));
    }

    // Task: C004-T01
    #[test]
    fn resume_current_attempt_keeps_brief_and_inputs_after_end_but_removes_drafts() {
        let mut fixture = Fixture::article_review().started();
        fixture.begin("draft").unwrap();
        fixture.fail("draft#1.0", "Interrupted").unwrap();
        let failed = status_card_json(fixture.state(), &fixture.graph)
            .resume
            .unwrap();
        assert_eq!(failed.attempt, "draft#1.0");
        assert!(failed.draft_outputs.is_empty());
        fixture.begin("draft").unwrap();
        let running = status_card_json(fixture.state(), &fixture.graph)
            .resume
            .unwrap();
        assert_eq!(running.attempt, "draft#1.1");
        assert!(running.brief_path.as_str().contains("attempt-001/brief.md"));
        fixture.submit_ok("draft#1.1", "Finished").unwrap();
        let succeeded = status_card_json(fixture.state(), &fixture.graph)
            .resume
            .unwrap();
        assert_eq!(succeeded.inputs, running.inputs);
        assert_eq!(succeeded.brief_path, running.brief_path);
        assert!(succeeded.draft_outputs.is_empty());
        assert!(!render_status_card(fixture.state(), &fixture.graph).contains("draft_outputs:"));
    }

    // Task: T10
    #[test]
    fn brief_for_review_node() {
        let mut fx = Fixture::article_review().started();
        fx.begin("draft").unwrap();
        fx.submit_ok("draft#1.0", "ok").unwrap();
        fx.begin("review").unwrap();
        let a = fx.state().latest_attempt_of_current().unwrap();
        insta::assert_snapshot!(
            "brief_for_review_node",
            render_brief(fx.state(), &fx.graph, a, "审查这篇文章。")
        );
    }

    // Task: T10
    #[test]
    fn brief_for_node_with_requires() {
        let mut fx = Fixture::with_requires();
        fx.begin("only").unwrap();
        let a = fx.state().latest_attempt_of_current().unwrap();
        insta::assert_snapshot!(
            "brief_for_node_with_requires",
            render_brief(fx.state(), &fx.graph, a, "用公司 API 做点事。")
        );
    }

    // Task: T10
    #[test]
    fn brief_for_node_without_requires_omits_section() {
        let mut fx = Fixture::article_review().started();
        fx.begin("draft").unwrap();
        let a = fx.state().latest_attempt_of_current().unwrap();
        let text = render_brief(fx.state(), &fx.graph, a, "写初稿。");
        assert!(!text.contains("需要的宿主资源"));
    }

    // ── M1 复核 O3：版本列来自 Workbook 的 requires 声明，没声明版本写 `-` ─────

    // Task: T10
    #[test]
    fn brief_require_row_takes_version_from_manifest_and_names_kind() {
        let mut fx = Fixture::from_texts(
            "schema = \"workbook/v1\"\nid = \"single\"\nversion = \"1.0.0\"\nname = \"单节点\"\nflows = [\"flows/default.toml\"]\n[[requires]]\nkind = \"skill\"\nname = \"company-api\"\nversion = \"^1\"\n[[requires]]\nkind = \"mcp\"\nname = \"db\"\n",
            "schema = \"flow/v1\"\nid = \"default\"\nentry = \"only\"\n\n[[nodes]]\nid = \"only\"\ntitle = \"唯一\"\nexecutor = \"agent\"\ninstruction = { text = \"用公司 API 做点事。\" }\nrequires = [\"skill:company-api\", \"mcp:db\"]\n",
            &[],
        )
        .started_with(&[]);
        fx.begin("only").unwrap();
        let a = fx.state().latest_attempt_of_current().unwrap();
        let text = render_brief(fx.state(), &fx.graph, a, "用公司 API 做点事。");
        // 版本取自 manifest，没写时填 `-`；说明里的「此 <kind>」随类型变（protocol.md §4）。
        assert!(text.contains(
            "| skill | company-api | ^1 | 请确认你的宿主已装此 skill；未装请停下并告知用户 |\n\
             | mcp | db | - | 请确认你的宿主已装此 mcp；未装请停下并告知用户 |\n"
        ));
    }

    // ── M1 复审：manifest 里 kind 与 name 交叉的声明不得串行 ─────

    // Task: T10
    #[test]
    fn brief_require_version_ignores_crossed_kind_name_pairs() {
        // skill:db 与 mcp:db 同 name 不同 kind；mcp:db 才是节点引用的那条。
        // 版本查找若把 && 写成 ||，会先命中 skill:db 的 1.0。
        let mut fx = Fixture::from_texts(
            "schema = \"workbook/v1\"\nid = \"single\"\nversion = \"1.0.0\"\nname = \"单节点\"\nflows = [\"flows/default.toml\"]\n[[requires]]\nkind = \"skill\"\nname = \"db\"\nversion = \"1.0\"\n[[requires]]\nkind = \"mcp\"\nname = \"db\"\nversion = \"3.0\"\n",
            "schema = \"flow/v1\"\nid = \"default\"\nentry = \"only\"\n\n[[nodes]]\nid = \"only\"\ntitle = \"唯一\"\nexecutor = \"agent\"\ninstruction = { text = \"做这一件事。\" }\nrequires = [\"mcp:db\"]\n",
            &[],
        )
        .started_with(&[]);
        fx.begin("only").unwrap();
        let a = fx.state().latest_attempt_of_current().unwrap();
        let text = render_brief(fx.state(), &fx.graph, a, "做这一件事。");
        assert!(
            text.contains("| mcp | db | 3.0 |"),
            "版本必须来自 mcp:db 那条声明：\n{text}"
        );
    }

    // Task: T10
    #[test]
    fn brief_marks_unbound_optional_input_as_absent() {
        let mut fx = Fixture::spec_dev().started_with(&[("request", "r"), ("project", "/p")]);
        fx.begin("spec").unwrap();
        let a = fx.state().latest_attempt_of_current().unwrap();
        let text = render_brief(fx.state(), &fx.graph, a, "写规格。");
        assert!(text.contains("| decision | 尚无（上游 plan-review 还没有产出） | |"));
    }

    // Task: T10
    #[test]
    fn brief_for_human_executor_ends_with_submit_command() {
        let mut fx = Fixture::article_review().started();
        fx.begin("draft").unwrap();
        fx.submit_ok("draft#1.0", "ok").unwrap();
        fx.begin("review").unwrap();
        fx.submit_ok("review#1.0", "通过").unwrap();
        fx.begin("publish").unwrap();
        let a = fx.state().latest_attempt_of_current().unwrap();
        insta::assert_snapshot!(
            "brief_for_human_executor_ends_with_submit_command",
            render_brief(fx.state(), &fx.graph, a, "确认可以发布。")
        );
    }

    // Task: T10
    #[test]
    fn brief_shows_entered_from_line_or_entry() {
        let mut fx = Fixture::article_review().started();
        fx.begin("draft").unwrap();
        let entry = render_brief(
            fx.state(),
            &fx.graph,
            fx.state().latest_attempt_of_current().unwrap(),
            "x",
        );
        assert!(entry.contains("来自: 入口"));
    }

    // Task: C005-T02
    #[test]
    fn status_card_active_mid_flow() {
        let mut fx = Fixture::article_review().started();
        fx.run_to_review_done_not_passing();
        fx.begin("draft").unwrap();
        insta::assert_snapshot!(
            "status_card_active_mid_flow",
            render_status_card(fx.state(), &fx.graph)
        );
    }

    // Task: T10
    #[test]
    fn status_card_blocked_on_gate() {
        let mut fx = Fixture::gated_release().started_with(&[("version", "1.0")]);
        fx.begin("notes").unwrap();
        fx.submit_ok("notes#1.0", "写好了").unwrap();
        insta::assert_snapshot!(
            "status_card_blocked_on_gate",
            render_status_card(fx.state(), &fx.graph)
        );
    }

    // Task: T10
    #[test]
    fn status_card_succeeded() {
        let mut fx = Fixture::two_step().started_with(&[("topic", "t")]);
        fx.begin("outline").unwrap();
        fx.submit_ok("outline#1.0", "提纲好了").unwrap();
        fx.begin("summary").unwrap();
        fx.submit_ok("summary#1.0", "摘要好了").unwrap();
        insta::assert_snapshot!(
            "status_card_succeeded",
            render_status_card(fx.state(), &fx.graph)
        );
    }

    // Task: T10
    #[test]
    fn next_op_renders_begin_with_node_flag() {
        let fx = Fixture::article_review().started();
        let next = legal_next(fx.state(), &fx.graph);
        assert_eq!(
            next[0].to_command_line(&fx.state().work_id),
            format!("sheltie attempt begin {} --node draft", fx.state().work_id)
        );
        assert_eq!(
            NextOp::Cancel.to_command_line(&fx.state().work_id),
            format!("sheltie work cancel {}", fx.state().work_id)
        );
    }

    // Task: T10
    #[test]
    fn next_op_begin_carries_executor_and_tier() {
        let fx = Fixture::article_review().started();
        let json = serde_json::to_value(&legal_next(fx.state(), &fx.graph)[0]).unwrap();
        assert_eq!(json["op"], "attempt begin");
        assert_eq!(json["executor"], "agent");
        assert_eq!(json["tier"], "standard");
    }

    // Task: T10
    #[test]
    fn stats_table_mid_flow() {
        let mut fx = Fixture::article_review().started();
        fx.run_to_review_done_not_passing();
        fx.begin("draft").unwrap();
        insta::assert_snapshot!("stats_table_mid_flow", render_stats(fx.state(), &fx.graph));
    }

    // Task: T10
    #[test]
    fn stats_json_counts_visits_failures_and_entered_via() {
        let mut fx = Fixture::article_review().started();
        fx.begin("draft").unwrap();
        fx.fail("draft#1.0", "崩").unwrap();
        fx.begin("draft").unwrap();
        fx.submit_ok("draft#1.1", "ok").unwrap();
        fx.begin("review").unwrap();
        fx.submit_ok("review#1.0", "不通过").unwrap();
        fx.begin("draft").unwrap();
        let s = render_stats_json(fx.state(), &fx.graph);
        let draft = &s.nodes[0];
        assert_eq!(
            (
                draft.node.as_str(),
                draft.visits,
                draft.attempts,
                draft.failed
            ),
            ("draft", 2, 3, 1)
        );
        // 合同（协议 work stats）要求保留边类型：draft(back)×1。
        assert_eq!(draft.entered_via, vec!["entry×1", "review(back)×1"]);
        assert_eq!(s.nodes[1].entered_via, vec!["draft(main)×1"]);
        assert_eq!(s.nodes[2].attempts, 0);
        assert_eq!(s.blocked_count, 0);
    }

    // Task: T10
    #[test]
    fn status_card_lists_done_occurrences_in_order() {
        let mut fx = Fixture::article_review().started();
        fx.run_to_review_done_not_passing();
        fx.begin("draft").unwrap();
        fx.submit_ok("draft#2.0", "改了").unwrap();
        let card = status_card_json(fx.state(), &fx.graph);
        assert_eq!(card.done, vec!["draft#1", "review#1", "draft#2"]);
        assert_eq!(card.pending, vec!["publish"]);
        assert_eq!(card.current, "draft#2");
    }

    // ── M1 补测（阻断行、阻断计数、时间换算；夹具时钟固定，快照里全是 0s） ─────

    fn exhausted_draft() -> Fixture {
        let mut fx = Fixture::article_review().started();
        fx.begin("draft").unwrap();
        fx.fail("draft#1.0", "一").unwrap();
        fx.begin("draft").unwrap();
        fx.fail("draft#1.1", "二").unwrap();
        fx
    }

    fn no_legal_edge() -> Fixture {
        let mut fx = Fixture::article_review_with_review_max_visits_1().started();
        fx.begin("draft").unwrap();
        fx.submit_ok("draft#1.0", "ok").unwrap();
        fx.begin("review").unwrap();
        fx.submit_ok("review#1.0", "不通过").unwrap();
        fx.begin("draft").unwrap();
        fx.submit_ok("draft#2.0", "改了").unwrap();
        fx
    }

    // Task: T10
    #[test]
    fn status_card_names_retries_exhausted_occurrence() {
        let fx = exhausted_draft();
        let card = render_status_card(fx.state(), &fx.graph);
        assert!(
            card.contains("blocked: retries_exhausted: draft#1\n"),
            "{card}"
        );
    }

    // Task: T10
    #[test]
    fn status_card_explains_no_legal_edge() {
        let fx = no_legal_edge();
        let card = render_status_card(fx.state(), &fx.graph);
        assert!(
            card.contains("blocked: no_legal_edge: draft#2 的全部出边目标已达 max_visits"),
            "{card}"
        );
    }

    // Task: T10
    #[test]
    fn stats_blocked_count_by_reason() {
        // 普通成功与可重试的失败都不算阻断。
        let mut fx = Fixture::article_review().started();
        fx.begin("draft").unwrap();
        fx.fail("draft#1.0", "一").unwrap();
        assert_eq!(fx.state().blocked_count, 0);
        assert_eq!(render_stats_json(fx.state(), &fx.graph).blocked_count, 0);
        fx.begin("draft").unwrap();
        fx.submit_ok("draft#1.1", "ok").unwrap();
        assert_eq!(render_stats_json(fx.state(), &fx.graph).blocked_count, 0);

        let fx = exhausted_draft();
        assert_eq!(fx.state().blocked_count, 1);
        assert_eq!(render_stats_json(fx.state(), &fx.graph).blocked_count, 1);

        let fx = no_legal_edge();
        assert_eq!(render_stats_json(fx.state(), &fx.graph).blocked_count, 1);

        // 门槛成功算一次，批准之后仍算。
        let mut fx = Fixture::gated_release().started_with(&[("version", "1.0")]);
        fx.begin("notes").unwrap();
        fx.submit_ok("notes#1.0", "写好了").unwrap();
        assert_eq!(fx.state().blocked_count, 1);
        assert_eq!(render_stats_json(fx.state(), &fx.graph).blocked_count, 1);
        fx.approve("notes").unwrap();
        assert_eq!(fx.state().blocked_count, 1, "批准不清除已发生的受阻事实");
        assert_eq!(render_stats_json(fx.state(), &fx.graph).blocked_count, 1);
    }

    // Task: T10
    #[test]
    fn secs_between_matches_independent_calendar_math() {
        // 期望值由 Python datetime 独立算出。
        let cases = [
            ("2026-02-28T23:59:30Z", "2026-03-01T00:00:30Z", 60),
            ("2024-02-28T00:00:00Z", "2024-03-01T00:00:00Z", 172_800),
            ("1999-12-31T23:59:59Z", "2000-03-01T00:00:00Z", 5_184_001),
            (
                "1970-01-01T00:00:00Z",
                "2026-09-24T03:04:05Z",
                1_790_219_045,
            ),
            ("1900-02-28T00:00:00Z", "1900-03-01T00:00:00Z", 86_400),
            ("2025-12-31T23:59:59Z", "2026-01-01T00:00:09Z", 10),
            (
                "1600-01-01T00:00:00Z",
                "2400-12-31T23:59:59Z",
                25_277_183_999,
            ),
        ];
        let ts = |s: &str| Timestamp::parse(s).unwrap();
        for (a, b, want) in cases {
            assert_eq!(secs_between(&ts(a), &ts(b)), want, "{a} → {b}");
        }
        // 倒序夹到 0。格式不合法的时间串在 `Timestamp::parse` 就被拒绝，到不了这里。
        assert_eq!(
            secs_between(&ts("2026-01-01T00:00:09Z"), &ts("2026-01-01T00:00:00Z")),
            0
        );
    }

    // ── C002-T06：事实视图与累计受阻（O13/N07） ───────────────────

    // Task: C002-T06
    #[test]
    fn blocked_count_survives_cancel_after_no_legal_edge() {
        // NoLegalEdge 发生记 1；取消是状态转换，不回退已发生的事实（GF-29/N07）。
        let mut fx = no_legal_edge();
        assert_eq!(fx.state().blocked_count, 1);
        fx.cancel().unwrap();
        assert_eq!(fx.state().blocked_count, 1, "取消不得减少累计受阻");
        let stats = render_stats_json(fx.state(), &fx.graph);
        assert_eq!(stats.blocked_count, 1);
    }

    // Task: C002-T06
    #[test]
    fn status_json_carries_reason_and_full_artifact_refs() {
        // 失败原因进 JSON（O13）：字段缺失或值错都会让本测试失败。
        let mut fx = Fixture::article_review().started();
        fx.begin("draft").unwrap();
        fx.fail("draft#1.0", "worker 崩了").unwrap();
        let card = status_card_json(fx.state(), &fx.graph);
        let last = card.last_attempt.as_ref().unwrap();
        assert_eq!(last.reason.as_deref(), Some("worker 崩了"));
        assert_eq!(last.status, "failed");

        // 成功提交后 outputs 是完整产物引用：路径、sha256、字节数逐一有值。
        let mut fx = Fixture::article_review().started();
        fx.begin("draft").unwrap();
        let d = fx.submit_ok("draft#1.0", "完成").unwrap();
        let sealed = d.state.attempts[0].outputs["article"].clone();
        let card = status_card_json(&d.state, &fx.graph);
        let out = &card.last_attempt.as_ref().unwrap().outputs["article"];
        assert_eq!(out.path, sealed.path.to_string());
        assert_eq!(out.sha256, sealed.sha256.as_str());
        assert_eq!(out.bytes, sealed.bytes);
        // 手写期望值字段必须真实存在（删除 digest/bytes 字段会让上面的相等失败）。
        assert_eq!(out.sha256.len(), 64);
        assert!(out.bytes > 0);

        // 受阻说明串两格式同源。
        let mut fx = Fixture::gated_release().started_with(&[("version", "1.0")]);
        fx.begin("notes").unwrap();
        fx.submit_ok("notes#1.0", "写好了").unwrap();
        let card = status_card_json(fx.state(), &fx.graph);
        assert_eq!(
            card.blocked.as_deref(),
            Some("gate: notes#1 需要 gate approve")
        );
    }

    // Task: C002-T06
    #[test]
    fn next_items_use_single_protocol_shape() {
        // 状态卡 data.next 与协议 §5 的顶层 next 同形：op/args/work，begin 项带
        // edge/executor/tier（O13 的「不同形状」修复）。
        let mut fx = Fixture::article_review().started();
        fx.run_to_review_done_not_passing();
        let card = status_card_json(fx.state(), &fx.graph);
        let next = &card.next;
        assert!(next.len() >= 2);
        for item in next {
            assert!(item["op"].is_string(), "{item}");
            assert!(item["args"]["work"].is_string(), "{item}");
        }
        let begin = next
            .iter()
            .find(|i| i["op"] == "attempt begin" && i["args"]["node"] == "draft")
            .unwrap();
        assert_eq!(begin["edge"], "back");
        assert_eq!(begin["executor"], "agent");
        assert_eq!(begin["tier"], "standard");
        // 与文本卡的命令行一致（同一份事实）。
        let text = render_status_card(fx.state(), &fx.graph);
        assert!(text.contains("sheltie attempt begin"), "{text}");
    }

    // Task: C002-T06
    #[test]
    fn entered_via_distinguishes_edges_and_entry() {
        let mut fx = Fixture::article_review().started();
        fx.run_to_review_done_not_passing();
        // 打回后再次进入 draft：来自 review#1 的 back 边。
        fx.begin("draft").unwrap();
        let stats = render_stats_json(fx.state(), &fx.graph);
        let draft = &stats.nodes[0];
        // 文本与结构化同源：entry 无 from/edge，back 有边类型。
        assert_eq!(draft.entered_via, vec!["entry×1", "review(back)×1"]);
        assert_eq!(
            draft.entered_via_json,
            vec![
                EnteredViaJson {
                    from: None,
                    edge: None,
                    count: 1
                },
                EnteredViaJson {
                    from: Some("review".to_string()),
                    edge: Some("back".to_string()),
                    count: 1,
                },
            ]
        );
        assert_eq!(
            stats.nodes[1].entered_via,
            vec!["draft(main)×1"],
            "review 经 main 进入，边类型必须保留"
        );
    }

    // Task: C002-T06
    #[test]
    fn text_and_json_agree_on_hand_written_state() {
        // 独立手写状态：非零时间、失败原因、多个输出，逐字段断言两种渲染一致。
        let mut fx = Fixture::article_review().started();
        fx.begin("draft").unwrap();
        let mut state = fx.state().clone();
        let ts = |s: &str| Timestamp::parse(s).unwrap();
        state.created_at = ts("2026-09-24T01:00:00Z");
        state.updated_at = ts("2026-09-24T02:30:00Z");
        state.attempts[0].started_at = ts("2026-09-24T01:10:00Z");
        state.attempts[0].fail_reason =
            Some(crate::text::Summary::new("超时退出", "reason").unwrap());
        state.attempts[0].status = AttemptStatus::Failed;
        state.attempts[0].ended_at = Some(ts("2026-09-24T01:25:00Z"));
        state.blocked_count = 2;

        let text = render_status_card(&state, &fx.graph);
        assert!(text.contains("reason: 超时退出"), "{text}");
        let stats = render_stats_json(&state, &fx.graph);
        assert_eq!(stats.total_seconds, 5400);
        assert_eq!(stats.nodes[0].avg_seconds, 900);
        assert_eq!(stats.blocked_count, 2);
        assert!(render_stats(&state, &fx.graph).contains("total: 5400s"));
        assert!(render_stats(&state, &fx.graph).contains("blocked: 2"));
    }

    // Task: T10
    #[test]
    fn stats_total_and_avg_use_timestamps() {
        let mut fx = Fixture::article_review().started();
        fx.begin("draft").unwrap();
        fx.fail("draft#1.0", "一").unwrap();
        fx.begin("draft").unwrap();
        fx.submit_ok("draft#1.1", "ok").unwrap();
        fx.begin("review").unwrap();
        let mut state = fx.state().clone();
        let ts = |s: &str| Timestamp::parse(s).unwrap();
        state.created_at = ts("2026-09-24T03:00:00Z");
        state.updated_at = ts("2026-09-24T04:00:00Z");
        state.attempts[0].started_at = ts("2026-09-24T03:00:00Z");
        state.attempts[0].ended_at = Some(ts("2026-09-24T03:00:10Z"));
        state.attempts[1].started_at = ts("2026-09-24T03:01:00Z");
        state.attempts[1].ended_at = Some(ts("2026-09-24T03:01:30Z"));
        // review#1.0 仍在运行：不计入 avg。
        state.attempts[2].started_at = ts("2026-09-24T03:02:00Z");
        let stats = render_stats_json(&state, &fx.graph);
        assert_eq!(stats.total_seconds, 3600);
        assert_eq!(stats.nodes[0].avg_seconds, 20);
        assert_eq!(stats.nodes[1].avg_seconds, 0);
        assert!(render_stats(&state, &fx.graph).contains("total: 3600s"));
    }
}
