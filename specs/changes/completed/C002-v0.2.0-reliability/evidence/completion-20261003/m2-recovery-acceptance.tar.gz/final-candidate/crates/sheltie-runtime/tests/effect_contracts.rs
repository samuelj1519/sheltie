//! C002-T31：真实重放入口拒绝不完整或互相矛盾的效果登记。
#![allow(clippy::unwrap_used, clippy::expect_used)]
mod common;
use common::*;
use rusqlite::Connection;
use serde_json::{Value, json};
use sheltie_core::ids::{AttemptId, NodeId};
use sheltie_runtime::request::InputValue;
use std::collections::BTreeMap;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

fn effects(conn: &Connection, rid: &str) -> Value {
    let raw: String = conn
        .query_row(
            "SELECT effects_json FROM requests WHERE request_id=?1",
            [rid],
            |r| r.get(0),
        )
        .unwrap();
    serde_json::from_str(&raw).unwrap()
}
fn set_effects(conn: &Connection, rid: &str, effects: &Value, published: i64) {
    conn.execute(
        "UPDATE requests SET effects_json=?1,published=?2 WHERE request_id=?3",
        rusqlite::params![effects.to_string(), published, rid],
    )
    .unwrap();
}
type BusinessFiles = BTreeMap<PathBuf, (u32, Vec<u8>)>;
fn files(root: &Path) -> BusinessFiles {
    fn walk(base: &Path, dir: &Path, out: &mut BusinessFiles) {
        if !dir.exists() {
            return;
        }
        let meta = std::fs::symlink_metadata(dir).unwrap();
        let bytes = if meta.is_file() {
            std::fs::read(dir).unwrap()
        } else {
            Vec::new()
        };
        out.insert(
            dir.strip_prefix(base).unwrap().to_path_buf(),
            (meta.permissions().mode(), bytes),
        );
        if meta.is_dir() {
            for e in std::fs::read_dir(dir).unwrap() {
                walk(base, &e.unwrap().path(), out);
            }
        }
    }
    let mut out = BTreeMap::new();
    for name in ["works", "workbooks", "pending"] {
        walk(root, &root.join(name), &mut out);
    }
    out
}
fn assert_unchanged(
    home: &sheltie_runtime::Home,
    conn: &Connection,
    before_rows: StoreRows,
    before_files: BusinessFiles,
) {
    assert_eq!(
        store_rows(conn),
        before_rows,
        "拒绝前不得提交或改变完成标记"
    );
    assert_eq!(
        files(home.root().as_path().as_std_path()),
        before_files,
        "整批登记校验失败不得写文件、封存或清理元数据"
    );
}

fn assert_original_data(snapshot: &Value, expected: &Value) {
    let mut data = snapshot["data"].clone();
    assert_eq!(
        data.as_object_mut().unwrap().remove("replayed"),
        Some(json!(false))
    );
    assert_eq!(&data, expected);
}

// Task: C002-T31
#[test]
fn begin_replay_checks_content_and_hash_even_when_the_existing_brief_matches() {
    for missing in [false, true] {
        let (_dir, home, svc) = home_with_example("two-step");
        let work = work_id_of(&start_two_step(&svc));
        let node = NodeId::new("outline").unwrap();
        let rid = "brief-content";
        let original = svc.begin(&work, &node, Some(rid.into())).unwrap();
        assert!(svc.begin(&work, &node, Some(rid.into())).unwrap().replayed);
        let conn = Connection::open(home.store_path().as_str()).unwrap();
        let mut changed = effects(&conn, rid);
        let brief = changed
            .as_array_mut()
            .unwrap()
            .iter_mut()
            .find(|op| {
                op["kind"] == "write_file" && op["path"].as_str().unwrap().ends_with("/brief.md")
            })
            .unwrap();
        brief["content"] = json!("changed persisted content without its matching hash");
        if missing {
            std::fs::remove_file(original.data["brief_path"].as_str().unwrap()).unwrap();
        }
        set_effects(&conn, rid, &changed, i64::from(!missing));
        let before_rows = store_rows(&conn);
        let before_files = files(home.root().as_path().as_std_path());
        assert_effect_pending(
            svc.begin(&work, &node, Some(rid.into())).unwrap_err(),
            true,
            Some(rid),
            None,
        );
        assert_unchanged(&home, &conn, before_rows, before_files);
    }
}

// Task: C002-T31
#[test]
fn submit_replay_requires_exactly_the_committed_output_references_and_seal() {
    for corruption in ["missing_ref", "duplicate_ref", "missing_seal"] {
        let (_dir, home, svc) = home_with_example("two-step");
        let work = work_id_of(&start_two_step(&svc));
        let begun = svc
            .begin(&work, &NodeId::new("outline").unwrap(), None)
            .unwrap();
        let output = PathBuf::from(output_dir_of(&begun).as_str()).join("outline.md");
        std::fs::write(&output, b"# independent committed output\n").unwrap();
        let attempt = AttemptId::parse("outline#1.0").unwrap();
        let summary = InputValue::Literal {
            text: "done".into(),
        };
        let rid = "seal-shape";
        svc.submit(&work, &attempt, &summary, Some(rid.into()))
            .unwrap();
        assert!(
            svc.submit(&work, &attempt, &summary, Some(rid.into()))
                .unwrap()
                .replayed
        );
        std::fs::set_permissions(&output, std::fs::Permissions::from_mode(0o644)).unwrap();
        let conn = Connection::open(home.store_path().as_str()).unwrap();
        let mut changed = effects(&conn, rid);
        let ops = changed.as_array_mut().unwrap();
        if corruption == "missing_seal" {
            ops.retain(|op| op["kind"] != "seal_outputs");
        } else {
            let refs = ops
                .iter_mut()
                .find(|op| op["kind"] == "seal_outputs")
                .unwrap()["refs"]
                .as_array_mut()
                .unwrap();
            assert_eq!(refs.len(), 1);
            if corruption == "missing_ref" {
                refs.clear();
            } else {
                refs.push(refs[0].clone());
            }
        }
        set_effects(&conn, rid, &changed, 0);
        let before_rows = store_rows(&conn);
        let before_files = files(home.root().as_path().as_std_path());
        assert_effect_pending(
            svc.submit(&work, &attempt, &summary, Some(rid.into()))
                .unwrap_err(),
            true,
            Some(rid),
            None,
        );
        assert_unchanged(&home, &conn, before_rows, before_files);
    }
}

// 原任务 C002-T31；T34收紧原响应资格断言。
// Task: C002-T34
#[test]
fn completed_workbook_replay_checks_effect_shape_identity_and_pending_path() {
    for remove in [false, true] {
        let (_dir, home) = temp_home();
        let repo = repo(&home);
        let source = abs(&example_dir("two-step"));
        let rid = if remove { "remove-shape" } else { "add-shape" };
        let added = repo
            .add(&source, Some(if remove { "setup-add" } else { rid }.into()))
            .unwrap();
        let expected_data = if remove {
            repo.remove("two-step", "1.0.0", Some(rid.into()))
                .unwrap()
                .data
        } else {
            added.data
        };
        if remove {
            assert!(
                repo.remove("two-step", "1.0.0", Some(rid.into()))
                    .unwrap()
                    .replayed
            );
        } else {
            assert!(repo.add(&source, Some(rid.into())).unwrap().replayed);
        }
        let conn = Connection::open(home.store_path().as_str()).unwrap();
        let pristine = effects(&conn, rid);
        let pristine_reply: String = conn
            .query_row(
                "SELECT reply_json FROM requests WHERE request_id=?1",
                [rid],
                |r| r.get(0),
            )
            .unwrap();
        for corruption in [
            "empty_batch",
            "final",
            "owner",
            "digest",
            "digest_format",
            "digest_root",
            "pending_prefix",
            "pending_leaf",
            "pending_uuid",
            "shared_bad_digest",
        ] {
            if remove && matches!(corruption, "digest_root" | "digest" | "shared_bad_digest") {
                continue;
            }
            let mut changed = pristine.clone();
            if corruption == "empty_batch" {
                changed = json!([]);
            } else {
                let op = &mut changed[0];
                assert!(op.get("final").is_some() && op.get("final_path").is_none());
                match corruption {
                    "final" => op["final"] = json!("workbooks/other/1.0.0"),
                    "owner" => op["owner"] = json!("workbook:other@1.0.0"),
                    "digest" => {
                        assert_ne!(op["digest"], json!("0".repeat(64)));
                        op["digest"] = json!("0".repeat(64));
                    }
                    "digest_format" => op["digest"] = json!("invalid-digest"),
                    "shared_bad_digest" => {
                        // 两份相等的摘要仍必须满足SHA-256格式；此事实已损坏，不能返回可信original。
                        op["digest"] = json!("invalid-digest");
                        let mut reply: Value = serde_json::from_str(&pristine_reply).unwrap();
                        reply["data"]["digest"] = json!("invalid-digest");
                        conn.execute(
                            "UPDATE requests SET reply_json=?1 WHERE request_id=?2",
                            rusqlite::params![reply.to_string(), rid],
                        )
                        .unwrap();
                    }
                    "digest_root" => op["digest_root"] = json!("workbook"),
                    "pending_prefix" => {
                        op["pending"] = json!(
                            op["pending"]
                                .as_str()
                                .unwrap()
                                .replacen("pending/", "other/", 1)
                        )
                    }
                    "pending_leaf" => {
                        op["pending"] = json!(
                            op["pending"]
                                .as_str()
                                .unwrap()
                                .replace("/payload", "/other")
                        )
                    }
                    "pending_uuid" => op["pending"] = json!("pending/invalid/payload"),
                    _ => unreachable!(),
                }
            }
            set_effects(&conn, rid, &changed, 1);
            let before_rows = store_rows(&conn);
            let before_files = files(home.root().as_path().as_std_path());
            let error = if remove {
                repo.remove("two-step", "1.0.0", Some(rid.into()))
                    .unwrap_err()
            } else {
                repo.add(&source, Some(rid.into())).unwrap_err()
            };
            // add的唯一业务身份锚点损坏时，不能把仅形状合法的快照当可信原响应。
            // remove仍由audit target独立绑定；pending等后效果错误也保留已核原响应。
            if corruption == "shared_bad_digest"
                || !remove
                    && matches!(
                        corruption,
                        "empty_batch" | "final" | "owner" | "digest" | "digest_format"
                    )
            {
                assert_effect_pending_without_original(error, true, rid, None);
            } else {
                let snapshot = assert_effect_pending(error, true, Some(rid), None);
                assert_eq!(snapshot["request_id"], rid);
                assert_original_data(&snapshot, &expected_data);
            }
            assert_unchanged(&home, &conn, before_rows, before_files);
            set_effects(&conn, rid, &pristine, 1);
            conn.execute(
                "UPDATE requests SET reply_json=?1 WHERE request_id=?2",
                rusqlite::params![pristine_reply, rid],
            )
            .unwrap();
        }
    }
}

// Task: C002-T31
#[test]
fn unpublished_workbook_publish_checks_registered_digest_and_audit_time() {
    let (_dir, home) = temp_home();
    let repo = repo(&home);
    let source = abs(&example_dir("two-step"));
    let rid = "registered-publisher";
    let original = repo.add(&source, Some(rid.into())).unwrap();
    let conn = Connection::open(home.store_path().as_str()).unwrap();
    let original_effects = effects(&conn, rid);
    set_effects(&conn, rid, &original_effects, 0);
    assert!(repo.add(&source, Some(rid.into())).unwrap().replayed);
    for field in ["digest", "added_at"] {
        set_effects(&conn, rid, &original_effects, 0);
        let pristine: String = conn
            .query_row(&format!("SELECT {field} FROM workbooks"), [], |row| {
                row.get(0)
            })
            .unwrap();
        let value = if field == "digest" {
            "0".repeat(64)
        } else {
            "2000-01-01T00:00:00Z".into()
        };
        assert_ne!(value, pristine);
        conn.execute(&format!("UPDATE workbooks SET {field}=?1"), [value])
            .unwrap();
        let before_rows = store_rows(&conn);
        let before_files = files(home.root().as_path().as_std_path());
        let snapshot = assert_effect_pending(
            repo.add(&source, Some(rid.into())).unwrap_err(),
            true,
            Some(rid),
            None,
        );
        assert_eq!(snapshot["request_id"], rid);
        assert_original_data(&snapshot, &original.data);
        assert_unchanged(&home, &conn, before_rows, before_files);
        conn.execute(&format!("UPDATE workbooks SET {field}=?1"), [pristine])
            .unwrap();
    }
}

// Task: C002-T31
#[test]
fn cleanup_preserves_unreferenced_objects_claiming_a_committed_request() {
    let (_dir, home) = temp_home();
    let repo = repo(&home);
    repo.add(
        &abs(&example_dir("two-step")),
        Some("existing-request".into()),
    )
    .unwrap();
    assert!(repo.cleanup_pending().unwrap().is_empty());
    let id = "0198f01a7f00700080000000000000ff";
    let pending_dir = home.pending_dir();
    let pending = pending_dir.as_path();
    std::fs::create_dir_all(pending.join(id).join("payload")).unwrap();
    std::fs::write(
        pending.join(id).join("payload/private"),
        b"retain unrelated original",
    )
    .unwrap();
    std::fs::write(pending.join(format!("{id}.owner")),json!({"format":"pending/v1","internal_id":id,"request_id":"existing-request","op":"add_workbook"}).to_string()+"\n").unwrap();
    let conn = Connection::open(home.store_path().as_str()).unwrap();
    let before_rows = store_rows(&conn);
    let before_files = files(home.root().as_path().as_std_path());
    let warnings = repo.cleanup_pending().unwrap();
    assert!(
        warnings
            .iter()
            .any(|w| w.contains(id) && w.contains("existing-request"))
    );
    assert_unchanged(&home, &conn, before_rows, before_files);
}

// Task: C002-T31
#[test]
fn cleanup_validates_completed_remove_metadata_before_any_deletion_and_is_repeatable() {
    for corruption in ["none", "marker", "request", "op"] {
        let (_dir, home) = temp_home();
        let repo = repo(&home);
        let rid = "completed-remove";
        repo.add(&abs(&example_dir("two-step")), None).unwrap();
        assert!(repo.cleanup_pending().unwrap().is_empty());
        repo.remove("two-step", "1.0.0", Some(rid.into())).unwrap();
        let conn = Connection::open(home.store_path().as_str()).unwrap();
        let original = effects(&conn, rid);
        let id = original[0]["pending"]
            .as_str()
            .unwrap()
            .split('/')
            .nth(1)
            .unwrap();
        let container = home.pending_dir().as_path().join(id);
        let owner = home.pending_dir().as_path().join(format!("{id}.owner"));
        let marker = home.pending_dir().as_path().join(format!("{id}.deleted"));
        assert!(container.is_dir() && owner.is_file() && marker.is_file());
        if corruption == "marker" {
            std::fs::write(&marker, b"corrupt deletion proof\n").unwrap();
        } else if corruption != "none" {
            let mut json: Value = serde_json::from_slice(&std::fs::read(&owner).unwrap()).unwrap();
            let field = if corruption == "request" {
                "request_id"
            } else {
                "op"
            };
            json[field] = json!(if corruption == "request" {
                "other-request"
            } else {
                "add_workbook"
            });
            std::fs::write(&owner, json.to_string() + "\n").unwrap();
        }
        let before_rows = store_rows(&conn);
        let before_files = files(home.root().as_path().as_std_path());
        let warnings = repo.cleanup_pending().unwrap();
        if corruption == "none" {
            assert!(warnings.is_empty(), "{warnings:?}");
            assert!(!container.exists() && !owner.exists() && !marker.exists());
            assert!(repo.cleanup_pending().unwrap().is_empty());
            assert_eq!(store_rows(&conn), before_rows);
        } else {
            assert!(warnings.iter().any(|w| w.contains(id)));
            assert_unchanged(&home, &conn, before_rows, before_files);
        }
    }
}

// Task: C002-T31
#[test]
fn begin_recovery_checks_required_prepare_and_history_effects_before_io() {
    let (_dir, home, svc) = home_with_example("two-step");
    let work = work_id_of(&start_two_step(&svc));
    let node = NodeId::new("outline").unwrap();
    let rid = "begin-required-effects";
    let original = svc.begin(&work, &node, Some(rid.into())).unwrap();
    let conn = Connection::open(home.store_path().as_str()).unwrap();
    let pristine = effects(&conn, rid);
    std::fs::remove_file(original.data["brief_path"].as_str().unwrap()).unwrap();
    for missing in ["prepare_attempt", "write_file"] {
        let mut changed = pristine.clone();
        changed
            .as_array_mut()
            .unwrap()
            .retain(|op| op["kind"] != missing);
        assert!(
            changed
                .as_array()
                .unwrap()
                .iter()
                .all(|op| op["kind"] != missing)
        );
        set_effects(&conn, rid, &changed, 0);
        let before_rows = store_rows(&conn);
        let before_files = files(home.root().as_path().as_std_path());
        let snapshot = assert_effect_pending(
            svc.begin(&work, &node, Some(rid.into())).unwrap_err(),
            true,
            Some(rid),
            None,
        );
        assert_eq!(snapshot["request_id"], rid);
        assert_eq!(snapshot["revision"], original.revision);
        assert_original_data(&snapshot, &original.data);
        assert_unchanged(&home, &conn, before_rows, before_files);
    }
}

// Task: C002-T31
#[test]
fn cleanup_warns_about_unpublished_reference_even_when_all_metadata_is_missing() {
    let (_dir, home) = temp_home();
    let repo = repo(&home);
    let rid = "missing-pending-metadata";
    repo.add(&abs(&example_dir("two-step")), Some(rid.into()))
        .unwrap();
    let conn = Connection::open(home.store_path().as_str()).unwrap();
    let pristine = effects(&conn, rid);
    let id = pristine[0]["pending"]
        .as_str()
        .unwrap()
        .split('/')
        .nth(1)
        .unwrap();
    assert!(repo.cleanup_pending().unwrap().is_empty());
    set_effects(&conn, rid, &pristine, 0);
    let before_rows = store_rows(&conn);
    let before_files = files(home.root().as_path().as_std_path());
    let warnings = repo.cleanup_pending().unwrap();
    assert!(warnings.iter().any(|w| w.contains(rid) && w.contains(id)));
    assert_unchanged(&home, &conn, before_rows, before_files);
}

// Task: C002-T31
#[test]
fn cleanup_checks_the_entire_request_index_before_removing_a_legitimate_orphan() {
    let (_dir, home) = temp_home();
    let repo = repo(&home);
    let rid = "index-publisher";
    repo.add(&abs(&example_dir("two-step")), Some(rid.into()))
        .unwrap();
    let svc = service(&home);
    let started = start_two_step(&svc);
    let work = work_id_of(&started);
    let begun = svc
        .begin(
            &work,
            &NodeId::new("outline").unwrap(),
            Some("index-begin".into()),
        )
        .unwrap();
    let original_brief = std::fs::read(begun.data["brief_path"].as_str().unwrap()).unwrap();
    std::fs::write(
        output_dir_of(&begun).as_path().join("outline.md"),
        b"index output",
    )
    .unwrap();
    svc.submit(
        &work,
        &AttemptId::parse("outline#1.0").unwrap(),
        &InputValue::Literal {
            text: "done".into(),
        },
        Some("index-submit".into()),
    )
    .unwrap();
    let conn = Connection::open(home.store_path().as_str()).unwrap();
    let pristine_publish = effects(&conn, rid);
    let pristine_begin = effects(&conn, "index-begin");
    let pristine_start = effects(&conn, &started.request_id);
    let pristine_submit = effects(&conn, "index-submit");
    let id = "0198f01a7f00700080000000000000fa";
    let pending = home.pending_dir();
    let private = pending.as_path().join(id).join("payload/private");
    std::fs::create_dir_all(private.parent().unwrap()).unwrap();
    std::fs::write(&private, b"legitimate orphan original").unwrap();
    std::fs::write(pending.as_path().join(format!("{id}.owner")),json!({"format":"pending/v1","internal_id":id,"request_id":"uncommitted-index-neighbor","op":"add_workbook"}).to_string()+"\n").unwrap();
    for corruption in [
        "publish_final",
        "publish_owner",
        "publish_digest",
        "publish_root",
        "publish_version",
        "workbook_work_id",
        "history_ancestor",
        "work_publish_root",
        "seal_digest",
    ] {
        let (changed_request, pristine) = match corruption {
            "history_ancestor" => ("index-begin", &pristine_begin),
            "work_publish_root" => (started.request_id.as_str(), &pristine_start),
            "seal_digest" => ("index-submit", &pristine_submit),
            _ => (rid, &pristine_publish),
        };
        let mut changed = pristine.clone();
        match corruption {
            "publish_final" => changed[0]["final"] = json!("workbooks/other/1.0.0"),
            "publish_owner" => changed[0]["owner"] = json!("workbook:other@1.0.0"),
            "publish_digest" => changed[0]["digest"] = json!("invalid-digest"),
            "publish_root" => changed[0]["digest_root"] = json!("workbook"),
            "publish_version" => {
                // 一个Workbook版本事实在owner与final中的两份表示保持一致，只破坏其格式。
                changed[0]["owner"] = json!("workbook:two-step@bad_");
                changed[0]["final"] = json!("workbooks/two-step/bad_");
            }
            "work_publish_root" => changed[0]["digest_root"] = json!(""),
            "seal_digest" => {
                changed
                    .as_array_mut()
                    .unwrap()
                    .iter_mut()
                    .find(|op| op["kind"] == "seal_outputs")
                    .unwrap()["refs"][0]["sha256"] = json!("invalid-digest")
            }
            "workbook_work_id" => {
                conn.execute(
                    "UPDATE requests SET work_id=?1 WHERE request_id=?2",
                    rusqlite::params![work.as_str(), rid],
                )
                .unwrap();
            }
            "history_ancestor" => {
                changed
                    .as_array_mut()
                    .unwrap()
                    .iter_mut()
                    .find(|op| op["kind"] == "write_file")
                    .unwrap()["path"] = json!("works")
            }
            _ => unreachable!(),
        }
        set_effects(&conn, changed_request, &changed, 1);
        let before_rows = store_rows(&conn);
        let before_files = files(home.root().as_path().as_std_path());
        let error = repo.cleanup_pending().unwrap_err();
        assert_eq!(
            error.code(),
            sheltie_core::ErrorCode::StoreCorrupt,
            "{corruption}: {error:?}"
        );
        assert_unchanged(&home, &conn, before_rows, before_files);
        set_effects(&conn, rid, &pristine_publish, 1);
        set_effects(&conn, "index-begin", &pristine_begin, 1);
        set_effects(&conn, &started.request_id, &pristine_start, 1);
        set_effects(&conn, "index-submit", &pristine_submit, 1);
        conn.execute(
            "UPDATE requests SET work_id=NULL WHERE request_id=?1",
            [rid],
        )
        .unwrap();
    }
    assert!(repo.cleanup_pending().unwrap().is_empty());
    assert!(!private.exists());
    assert_eq!(
        std::fs::read(begun.data["brief_path"].as_str().unwrap()).unwrap(),
        original_brief
    );
}

// Task: C002-T31
#[test]
fn submit_snapshot_data_must_match_the_committed_reply_output_references() {
    let (_dir, home, svc) = home_with_example("two-step");
    let work = work_id_of(&start_two_step(&svc));
    let begun = svc
        .begin(&work, &NodeId::new("outline").unwrap(), None)
        .unwrap();
    write_output(&output_dir_of(&begun), "outline.md", "# committed output\n");
    let attempt = AttemptId::parse("outline#1.0").unwrap();
    let summary = InputValue::Literal {
        text: "done".into(),
    };
    let rid = "submit-data-ref";
    let original = svc
        .submit(&work, &attempt, &summary, Some(rid.into()))
        .unwrap();
    assert!(
        svc.submit(&work, &attempt, &summary, Some(rid.into()))
            .unwrap()
            .replayed
    );
    let conn = Connection::open(home.store_path().as_str()).unwrap();
    let raw: String = conn
        .query_row(
            "SELECT reply_json FROM requests WHERE request_id=?1",
            [rid],
            |r| r.get(0),
        )
        .unwrap();
    let pristine: Value = serde_json::from_str(&raw).unwrap();
    for field in ["bytes", "sha256", "path"] {
        let mut changed = pristine.clone();
        let reference = &mut changed["data"]["outputs"]["outline"];
        match field {
            "bytes" => reference[field] = json!(reference[field].as_u64().unwrap() + 1),
            "sha256" => reference[field] = json!("0".repeat(64)),
            "path" => {
                reference[field] = json!(format!("{}/another.md", output_dir_of(&begun).as_str()))
            }
            _ => unreachable!(),
        }
        assert_ne!(changed["data"], original.data);
        assert_eq!(changed["reply"], pristine["reply"]);
        conn.execute(
            "UPDATE requests SET reply_json=?1 WHERE request_id=?2",
            rusqlite::params![changed.to_string(), rid],
        )
        .unwrap();
        let before_rows = store_rows(&conn);
        let before_files = files(home.root().as_path().as_std_path());
        assert_effect_pending_without_original(
            svc.submit(&work, &attempt, &summary, Some(rid.into()))
                .unwrap_err(),
            true,
            rid,
            None,
        );
        assert_unchanged(&home, &conn, before_rows, before_files);
    }
}

// Task: C002-T31
#[test]
fn approval_snapshot_data_must_match_the_approved_node_and_occurrence() {
    let (_dir, home, svc) = home_with_example("gated-release");
    let started = svc
        .start(
            sheltie_runtime::StartArgs {
                workbook_id: "gated-release".into(),
                version: None,
                flow: "default".into(),
                name: None,
                inputs: [(
                    "version".into(),
                    InputValue::Literal {
                        text: "1.0.0".into(),
                    },
                )]
                .into_iter()
                .collect(),
            },
            None,
        )
        .unwrap();
    let work = work_id_of(&started);
    let node = NodeId::new("notes").unwrap();
    let begun = svc.begin(&work, &node, None).unwrap();
    write_output(&output_dir_of(&begun), "notes.md", "# notes\n");
    svc.submit(
        &work,
        &AttemptId::parse("notes#1.0").unwrap(),
        &InputValue::Literal {
            text: "done".into(),
        },
        None,
    )
    .unwrap();
    let rid = "approval-data-identity";
    svc.approve(&work, &node, Some(rid.into())).unwrap();
    assert!(
        svc.approve(&work, &node, Some(rid.into()))
            .unwrap()
            .replayed
    );
    let conn = Connection::open(home.store_path().as_str()).unwrap();
    let raw: String = conn
        .query_row(
            "SELECT reply_json FROM requests WHERE request_id=?1",
            [rid],
            |r| r.get(0),
        )
        .unwrap();
    let pristine: Value = serde_json::from_str(&raw).unwrap();
    for field in ["node", "occurrence", "by"] {
        let mut changed = pristine.clone();
        changed["data"][field] = match field {
            "node" => json!("archive"),
            "occurrence" => json!(2),
            "by" => json!(format!(
                "{}-other",
                pristine["data"]["by"].as_str().unwrap()
            )),
            _ => unreachable!(),
        };
        assert_ne!(changed["data"], pristine["data"]);
        assert_eq!(changed["reply"], pristine["reply"]);
        conn.execute(
            "UPDATE requests SET reply_json=?1 WHERE request_id=?2",
            rusqlite::params![changed.to_string(), rid],
        )
        .unwrap();
        let before_rows = store_rows(&conn);
        let before_files = files(home.root().as_path().as_std_path());
        let error = svc.approve(&work, &node, Some(rid.into())).unwrap_err();
        if field == "by" {
            let sheltie_runtime::Error::EffectPending {
                committed,
                request_id,
                cause,
                ..
            } = error
            else {
                panic!("{error:?}");
            };
            assert!(committed);
            assert_eq!(request_id, rid);
            assert_eq!(cause, sheltie_core::ErrorCode::StoreCorrupt);
        } else {
            assert_effect_pending_without_original(error, true, rid, None);
        }
        assert_unchanged(&home, &conn, before_rows, before_files);
    }
}

// Task: C002-T31
#[test]
fn persisted_start_command_cannot_claim_a_different_flow_than_the_frozen_work() {
    let (_dir, home, svc) = home_with_example("two-step");
    let original = start_two_step(&svc);
    let work = work_id_of(&original);
    let rid = original.request_id.as_str();
    assert!(svc.status(&work).is_ok());
    let conn = Connection::open(home.store_path().as_str()).unwrap();
    let (command, reply): (String,String) = conn.query_row("SELECT a.command_json,r.reply_json FROM audit a JOIN requests r USING(request_id) WHERE a.request_id=?1", [rid], |row| Ok((row.get(0)?,row.get(1)?))).unwrap();
    for snapshot in [false, true] {
        let mut changed: Value =
            serde_json::from_str(if snapshot { &reply } else { &command }).unwrap();
        let flow = if snapshot {
            &mut changed["data"]["flow"]
        } else {
            &mut changed["flow"]
        };
        assert_eq!(*flow, json!("default"));
        *flow = json!("another-flow");
        if snapshot {
            conn.execute(
                "UPDATE requests SET reply_json=?1 WHERE request_id=?2",
                rusqlite::params![changed.to_string(), rid],
            )
            .unwrap();
        } else {
            conn.execute(
                "UPDATE audit SET command_json=?1 WHERE request_id=?2",
                rusqlite::params![changed.to_string(), rid],
            )
            .unwrap();
        }
        let before_rows = store_rows(&conn);
        let before_files = files(home.root().as_path().as_std_path());
        for error in [
            svc.status(&work).unwrap_err(),
            svc.stats(&work).unwrap_err(),
            svc.list().unwrap_err(),
        ] {
            assert_eq!(
                error.code(),
                sheltie_core::ErrorCode::StoreCorrupt,
                "{error:?}"
            );
        }
        assert_unchanged(&home, &conn, before_rows, before_files);
        conn.execute(
            "UPDATE requests SET reply_json=?1 WHERE request_id=?2",
            rusqlite::params![reply, rid],
        )
        .unwrap();
        conn.execute(
            "UPDATE audit SET command_json=?1 WHERE request_id=?2",
            rusqlite::params![command, rid],
        )
        .unwrap();
    }
}

// Task: C002-T31
#[test]
fn readonly_work_loading_checks_the_start_effect_shape_and_digest() {
    let (_dir, home, svc) = home_with_example("two-step");
    let original = start_two_step(&svc);
    let work = work_id_of(&original);
    let rid = original.request_id.as_str();
    let conn = Connection::open(home.store_path().as_str()).unwrap();
    let pristine = effects(&conn, rid);
    for corruption in ["extra_history", "missing_card", "digest"] {
        let mut changed = pristine.clone();
        let extra = json!({"kind":"write_file","path":format!("works/{work}/extra.md"),"sha256":"0".repeat(64),"content":"extra"});
        match corruption {
            "extra_history" => changed.as_array_mut().unwrap().push(extra),
            "missing_card" => {
                changed
                    .as_array_mut()
                    .unwrap()
                    .retain(|op| op["kind"] != "refresh_status_card");
                changed.as_array_mut().unwrap().push(extra);
            }
            "digest" => {
                assert_ne!(changed[0]["digest"], json!("0".repeat(64)));
                changed[0]["digest"] = json!("0".repeat(64));
            }
            _ => unreachable!(),
        }
        set_effects(&conn, rid, &changed, 1);
        let before_rows = store_rows(&conn);
        let before_files = files(home.root().as_path().as_std_path());
        for error in [
            svc.status(&work).unwrap_err(),
            svc.stats(&work).unwrap_err(),
            svc.list().unwrap_err(),
        ] {
            assert_eq!(
                error.code(),
                sheltie_core::ErrorCode::StoreCorrupt,
                "{corruption}: {error:?}"
            );
        }
        assert_unchanged(&home, &conn, before_rows, before_files);
    }
}

// Task: C002-T31
#[test]
fn unpublished_work_cannot_use_the_completed_owner_cleanup_fallback() {
    let (_dir, home, svc) = home_with_example("two-step");
    let original = start_two_step(&svc);
    let work = work_id_of(&original);
    let rid = original.request_id.as_str();
    let conn = Connection::open(home.store_path().as_str()).unwrap();
    let pristine = effects(&conn, rid);
    assert!(repo(&home).cleanup_pending().unwrap().is_empty());
    set_effects(&conn, rid, &pristine, 0);
    let before_rows = store_rows(&conn);
    let before_files = files(home.root().as_path().as_std_path());
    for error in [
        svc.status(&work).unwrap_err(),
        svc.stats(&work).unwrap_err(),
        svc.list().unwrap_err(),
    ] {
        assert_eq!(
            error.code(),
            sheltie_core::ErrorCode::StoreCorrupt,
            "{error:?}"
        );
    }
    assert_unchanged(&home, &conn, before_rows, before_files);
}

// Task: C002-T31
#[test]
fn begin_replay_rejects_audit_and_snapshot_metadata_drift_without_business_changes() {
    let (_dir, home, svc) = home_with_example("two-step");
    let work = work_id_of(&start_two_step(&svc));
    let node = NodeId::new("outline").unwrap();
    let rid = "begin-metadata";
    let original = svc.begin(&work, &node, Some(rid.into())).unwrap();
    assert!(svc.begin(&work, &node, Some(rid.into())).unwrap().replayed);
    let conn = Connection::open(home.store_path().as_str()).unwrap();
    let (reply, audit_work, audit_at, command): (String, String, String, String) = conn.query_row(
        "SELECT r.reply_json,a.work_id,a.at,a.command_json FROM requests r JOIN audit a USING(request_id) WHERE r.request_id=?1", [rid], |row| Ok((row.get(0)?,row.get(1)?,row.get(2)?,row.get(3)?))
    ).unwrap();
    let pristine: Value = serde_json::from_str(&reply).unwrap();
    for corruption in [
        "audit_work",
        "audit_at",
        "audit_node",
        "request_id",
        "revision",
        "replayed",
        "zero_revision",
        "future_revision",
    ] {
        let mut changed = pristine.clone();
        match corruption {
            "audit_work" => {
                conn.execute(
                    "UPDATE audit SET work_id='w20260930-001-other' WHERE request_id=?1",
                    [rid],
                )
                .unwrap();
            }
            "audit_at" => {
                conn.execute(
                    "UPDATE audit SET at='2000-01-01T00:00:00Z' WHERE request_id=?1",
                    [rid],
                )
                .unwrap();
            }
            "audit_node" => {
                let mut changed_command: Value = serde_json::from_str(&command).unwrap();
                assert_eq!(changed_command["node"], "outline");
                changed_command["node"] = json!("summary");
                conn.execute(
                    "UPDATE audit SET command_json=?1 WHERE request_id=?2",
                    rusqlite::params![changed_command.to_string(), rid],
                )
                .unwrap();
            }
            "request_id" => changed["request_id"] = json!("other-request"),
            "revision" => changed["revision"] = json!(original.revision + 1),
            "replayed" => changed["replayed"] = json!(true),
            "zero_revision" | "future_revision" => {
                let revision = if corruption == "zero_revision" {
                    0
                } else {
                    original.revision + 1
                };
                changed["revision"] = json!(revision);
                conn.execute(
                    "UPDATE audit SET revision=?1 WHERE request_id=?2",
                    rusqlite::params![revision, rid],
                )
                .unwrap();
            }
            _ => unreachable!(),
        }
        conn.execute(
            "UPDATE requests SET reply_json=?1 WHERE request_id=?2",
            rusqlite::params![changed.to_string(), rid],
        )
        .unwrap();
        let before_rows = store_rows(&conn);
        let before_files = files(home.root().as_path().as_std_path());
        let error = svc.begin(&work, &node, Some(rid.into())).unwrap_err();
        let sheltie_runtime::Error::EffectPending {
            committed,
            request_id,
            pending_request_id,
            cause,
            ..
        } = error
        else {
            panic!("{corruption}: {error:?}");
        };
        assert!(committed);
        assert_eq!(request_id, rid);
        assert!(pending_request_id.is_none());
        assert_eq!(cause, sheltie_core::ErrorCode::StoreCorrupt);
        assert_unchanged(&home, &conn, before_rows, before_files);
        conn.execute(
            "UPDATE requests SET reply_json=?1 WHERE request_id=?2",
            rusqlite::params![reply, rid],
        )
        .unwrap();
        conn.execute(
            "UPDATE audit SET work_id=?1,at=?2,command_json=?3,revision=?4 WHERE request_id=?5",
            rusqlite::params![audit_work, audit_at, command, original.revision, rid],
        )
        .unwrap();
    }
}

// Task: C002-T32
#[test]
fn cleanup_rejects_each_invalid_delete_reference_before_removing_an_orphan() {
    let (_directory, home) = temp_home();
    let repository = repo(&home);
    repository
        .add(&abs(&example_dir("two-step")), Some("delete-source".into()))
        .unwrap();
    repository
        .remove("two-step", "1.0.0", Some("delete-reference".into()))
        .unwrap();
    let connection = Connection::open(home.store_path().as_str()).unwrap();
    let pristine = effects(&connection, "delete-reference");
    let id = "0198f01a7f00700080000000000000fb";
    let pending = home.pending_dir();
    let payload = pending.as_path().join(id).join("payload");
    std::fs::create_dir_all(&payload).unwrap();
    std::fs::write(payload.join("private"), b"orphan original").unwrap();
    std::fs::write(pending.as_path().join(format!("{id}.owner")), json!({"format":"pending/v1","internal_id":id,"request_id":"uncommitted-delete-neighbor","op":"add_workbook"}).to_string()+"\n").unwrap();
    for field in ["final", "digest", "version"] {
        let mut changed = pristine.clone();
        let deletion = changed
            .as_array_mut()
            .unwrap()
            .iter_mut()
            .find(|effect| effect["kind"] == "delete_dir")
            .unwrap();
        match field {
            "final" => deletion["final"] = json!("workbooks/other/1.0.0"),
            "digest" => deletion["digest"] = json!("not-a-digest"),
            "version" => {
                deletion["owner"] = json!("workbook:two-step@bad_");
                deletion["final"] = json!("workbooks/two-step/bad_");
            }
            _ => unreachable!(),
        }
        set_effects(&connection, "delete-reference", &changed, 1);
        let before_rows = store_rows(&connection);
        let before_files = files(home.root().as_path().as_std_path());
        assert_eq!(
            repository.cleanup_pending().unwrap_err().code(),
            sheltie_core::ErrorCode::StoreCorrupt,
            "{field}"
        );
        assert_unchanged(&home, &connection, before_rows, before_files);
    }
    set_effects(&connection, "delete-reference", &pristine, 1);
    assert!(repository.cleanup_pending().unwrap().is_empty());
    assert!(!payload.exists());
}

// Task: C002-T33
#[test]
fn workbook_replay_rejects_audit_and_snapshot_single_field_drift() {
    for remove in [false, true] {
        let (_directory, home) = temp_home();
        let repository = repo(&home);
        let source = abs(&example_dir("two-step"));
        let rid = "snapshot-drift";
        repository
            .add(
                &source,
                Some(if remove { "drift-setup" } else { rid }.into()),
            )
            .unwrap();
        if remove {
            repository
                .remove("two-step", "1.0.0", Some(rid.into()))
                .unwrap();
        }
        let connection = Connection::open(home.store_path().as_str()).unwrap();
        let reply: String = connection
            .query_row(
                "SELECT reply_json FROM requests WHERE request_id=?1",
                [rid],
                |row| row.get(0),
            )
            .unwrap();
        let audit: String = connection
            .query_row(
                "SELECT command_json FROM audit WHERE request_id=?1",
                [rid],
                |row| row.get(0),
            )
            .unwrap();
        let hash: String = connection
            .query_row(
                "SELECT intent_hash FROM requests WHERE request_id=?1",
                [rid],
                |row| row.get(0),
            )
            .unwrap();
        for corruption in ["rid", "replayed", "source", "requires", "id", "version"] {
            if remove && matches!(corruption, "source" | "requires")
                || !remove && matches!(corruption, "id" | "version")
            {
                continue;
            }
            let mut snapshot: Value = serde_json::from_str(&reply).unwrap();
            match corruption {
                "rid" => snapshot["request_id"] = json!("another-request"),
                "replayed" => snapshot["replayed"] = json!(true),
                "requires" => snapshot["data"]["requires"] = json!(["invalid-without-colon"]),
                "id" => snapshot["data"]["id"] = json!("other-step"),
                "version" => snapshot["data"]["version"] = json!("2.0.0"),
                "source" => {
                    let replacement = if hash == "0".repeat(64) {
                        "1".repeat(64)
                    } else {
                        "0".repeat(64)
                    };
                    let mut command: Value = serde_json::from_str(&audit).unwrap();
                    command["source"] = json!(replacement);
                    connection
                        .execute(
                            "UPDATE audit SET command_json=?1 WHERE request_id=?2",
                            rusqlite::params![command.to_string(), rid],
                        )
                        .unwrap();
                }
                _ => unreachable!(),
            }
            connection
                .execute(
                    "UPDATE requests SET reply_json=?1 WHERE request_id=?2",
                    rusqlite::params![snapshot.to_string(), rid],
                )
                .unwrap();
            let before_rows = store_rows(&connection);
            let before_files = files(home.root().as_path().as_std_path());
            let error = if remove {
                repository
                    .remove("two-step", "1.0.0", Some(rid.into()))
                    .unwrap_err()
            } else {
                repository.add(&source, Some(rid.into())).unwrap_err()
            };
            assert_eq!(
                error.code(),
                sheltie_core::ErrorCode::EffectPending,
                "{corruption}: {error}"
            );
            assert_unchanged(&home, &connection, before_rows, before_files);
            connection
                .execute(
                    "UPDATE requests SET reply_json=?1 WHERE request_id=?2",
                    rusqlite::params![reply, rid],
                )
                .unwrap();
            connection
                .execute(
                    "UPDATE audit SET command_json=?1 WHERE request_id=?2",
                    rusqlite::params![audit, rid],
                )
                .unwrap();
        }
        assert!(if remove {
            repository
                .remove("two-step", "1.0.0", Some(rid.into()))
                .unwrap()
                .replayed
        } else {
            repository.add(&source, Some(rid.into())).unwrap().replayed
        });
    }
}

// Task: C002-T55
#[cfg(feature = "failpoint")]
#[test]
fn a_repaired_history_collision_reports_corruption_and_preserves_the_competing_original() {
    use std::os::unix::fs::MetadataExt as _;
    let (_directory, home, service) = home_with_example("two-step");
    let work = work_id_of(&start_two_step(&service));
    let node = NodeId::new("outline").unwrap();
    let rid = "collision-begin";
    let original = service.begin(&work, &node, Some(rid.into())).unwrap();
    let replay = service.begin(&work, &node, Some(rid.into())).unwrap();
    assert_eq!(replay.data, original.data);
    let connection = Connection::open(home.store_path().as_str()).unwrap();
    let registered = effects(&connection, rid);
    let path = registered
        .as_array()
        .unwrap()
        .iter()
        .find(|effect| {
            effect["kind"] == "write_file"
                && effect["path"].as_str().unwrap().ends_with("/brief.md")
        })
        .unwrap()["path"]
        .as_str()
        .unwrap();
    let target = home.rel(path).unwrap();
    std::fs::remove_file(target.as_path()).unwrap();
    let sync = tempfile::tempdir().unwrap();
    sheltie_runtime::failpoint::arm_rendezvous(
        "atomic_write_after_file_sync",
        target.as_str(),
        sync.path(),
    )
    .unwrap();
    let writer = service.clone();
    let writer_work = work.clone();
    let writer_node = node.clone();
    let worker = std::thread::spawn(move || {
        writer.begin(&writer_work, &writer_node, Some("collision-begin".into()))
    });
    let mut worker = RendezvousWorker::single(worker, sync.path());
    worker.wait("history repair did not reach its actual post-sync temporary write");
    std::fs::write(target.as_path(), b"competing historical original").unwrap();
    let competitor = std::fs::metadata(target.as_path()).unwrap();
    let before = store_rows(&connection);
    let error = worker.finish().unwrap().unwrap_err();
    let snapshot = assert_effect_pending(error, true, Some(rid), None);
    assert_original_data(&snapshot, &original.data);
    assert_eq!(store_rows(&connection), before);
    assert_eq!(
        std::fs::read(target.as_path()).unwrap(),
        b"competing historical original"
    );
    let after = std::fs::metadata(target.as_path()).unwrap();
    assert_eq!(
        (after.dev(), after.ino(), after.mode(), after.nlink()),
        (
            competitor.dev(),
            competitor.ino(),
            competitor.mode(),
            competitor.nlink()
        )
    );
}

// Task: C002-T55
#[test]
fn workbook_listing_rejects_a_global_work_publication_bound_to_another_legal_final_path() {
    let (_directory, home, service) = home_with_example("two-step");
    let started = start_two_step(&service);
    let work = work_id_of(&started);
    let connection = Connection::open(home.store_path().as_str()).unwrap();
    let rid: String = connection
        .query_row(
            "SELECT request_id FROM audit WHERE work_id=?1 AND revision=1",
            [work.as_str()],
            |row| row.get(0),
        )
        .unwrap();
    let mut registered = effects(&connection, &rid);
    let publish = registered
        .as_array_mut()
        .unwrap()
        .iter_mut()
        .find(|effect| effect["kind"] == "publish_dir")
        .unwrap();
    publish["final"] = json!("works/2026-10-03-999-other");
    set_effects(&connection, &rid, &registered, 1);
    let before = store_rows(&connection);
    let before_files = files(home.root().as_path().as_std_path());
    let error = repo(&home).list().unwrap_err();
    assert_eq!(error.code(), sheltie_core::ErrorCode::StoreCorrupt);
    assert_unchanged(&home, &connection, before, before_files);
}
