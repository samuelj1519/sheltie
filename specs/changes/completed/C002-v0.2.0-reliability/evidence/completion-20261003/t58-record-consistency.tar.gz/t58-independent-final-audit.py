from pathlib import Path
import json,hashlib,re,subprocess,sqlite3
R=Path.cwd();T=Path('/private/tmp/sheltie-completion-20261003');E=R/'specs/changes/active/C002-v0.2.0-reliability/evidence/completion-20261003'
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def J(p):return json.loads(p.read_text())
g=J(E/'t58-final-gates.json');p=T/'mutation-t58-shared-audit-checks-final';sel=J(p/'selection.json');out=J(p/'mutants.out/outcomes.json');res=J(p/'result.json');source=sel['source_sha256']
assert len(source)==190 and len(g['inputs'])==134 and g['source_unchanged'] and all(H(R/k)==v for k,v in source.items()) and all(source[k]==v for k,v in g['inputs'].items())
for x in g['results']:assert x['exit_code']==0 and H(E/('t58-final-'+x['name']+'.txt'))==x['output_sha256']
raw=(E/'t58-final-nextest.txt').read_text();assert '424c53bc-4a8a-4bf1-8c26-f4b600335a83' in raw and '951 tests run: 951 passed (2 slow), 0 skipped' in raw and not any(z in raw for z in ['LEAK','FAIL','SKIP'])
doc=(E/'t58-final-doctest.txt').read_text();assert doc.count('(line ')==5 and '5 passed; 0 failed' in doc
art=J(E/'t58-frozen-binaries.json');assert art['artifacts']==g['frozen_binaries'];build=[json.loads(x) for x in (E/'t58-binary-build.jsonl').read_text().splitlines() if x.startswith('{')];built={x['target']['name']:x['executable'] for x in build if x.get('reason')=='compiler-artifact' and x.get('executable')}
for key,x in art['artifacts'].items():assert built[key]==x['original'] and x['cargo_reported_executable'] and H(Path(x['frozen']))==x['sha256']
assert g['env']['RUSTC_WRAPPER']=='' and g['env']['SHELTIE_TEST_ENGINE_BINARY']==art['artifacts']['sheltie']['frozen'] and g['env']['SHELTIE_TEST_EXPORT_BINARY']==art['artifacts']['sheltie-export']['frozen']
affected=(E/'t58-final-affected-consumers.txt').read_text();assert '46 tests run: 46 passed' in affected
required=['committed_history_and_attempt_directory_type_changes_are_integrity_errors_with_original_snapshot','begin_replay_checks_content_and_hash_even_when_the_existing_brief_matches','submit_replay_requires_exactly_the_committed_output_references_and_seal','replay_of_a_completed_request_restores_earlier_pending_requests_instead_of_consuming_the_wrong_cache','corrupt_pending_remove_snapshot_cannot_be_projected_as_a_blockers_original','replay_decodes_command_and_data_before_reading_the_frozen_workbook']
for name in required:assert any('PASS' in x and name in x for x in affected.splitlines()),name
supp=J(E/'t58-supplemental-checks.json')
for x in supp['results']:
 path=E/('t58-msrv.txt' if x['name']=='msrv' else 't58-default-check.txt');assert x['exit_code']==0 and H(path)==x['output_sha256']
gov=J(E/'t58-candidate-governance.json')
for x in gov['results']:assert H(E/('t58-candidate-'+x['name']+'.txt'))==x['output_sha256']
assert next(x for x in gov['results'] if x['name']=='docs')['exit_code']==1 and all(x['exit_code']==0 for x in gov['results'] if x['name']!='docs')
assert 'check-docs: OK' in (E/'t58-corrected-docs.txt').read_text();assert '3 tests run: 3 passed' in (E/'t58-task-tests.txt').read_text()
assert res['exit_code']==0 and res['source_unchanged'] and out['caught']==2 and out['timeout']==out['missed']==out['unviable']==0
assert len(out['outcomes'])==3 and out['outcomes'][0]['scenario']=='Baseline' and out['outcomes'][0]['summary']=='Success'
base=(p/'mutants.out/log/baseline.log').read_text();assert '3 tests run: 3 passed' in base
assert len(J(p/'dispatch-env.json'))==6 and all(v is None for v in J(p/'dispatch-env.json').values())
ledger=J(E/'t58-shared-checks-detection.json');entries=[]
for o in out['outcomes'][1:]:
 m=o['scenario']['Mutant'];rec=next(x for x in ledger['items'] if x['current_id']==m['name']);ph=o['phase_results'];assert ph[0]['process_status']=='Success' and ph[1]['process_status']=={'Failure':100}
 log=p/'mutants.out'/o['log_path'];diff=p/'mutants.out'/o['diff_path'];assert H(log)==rec['log_sha256'] and H(diff)==rec['diff_sha256'];s=log.read_text()
 if 'validate_audit_snapshot' in m['name']:assert 'pure record eligibility must precede frozen IO' in s and '冻结副本' in s;kind='pure eligibility-before-frozenIO diagnostic/stage; later still refuses withoutoriginal'
 else:assert '命令意外成功' in s and 'record-cancel' in s;kind='wrong coupled event time actually accepted as successful historical Cancel replay'
 entries.append({'id':m['name'],'classification':kind,'log_sha256':H(log),'diff_sha256':H(diff),'phases':ph})
oldrun=J(T/'mutation-t58-shared-audit-checks/mutants.out/outcomes.json');assert len(oldrun['outcomes'])==1 and oldrun['outcomes'][0]['phase_results'][1]['process_status']=={'Failure':4}
nat=J(T/'t58-native-fixed-repro.json');assert nat['source_engine_sha256']==art['artifacts']['sheltie']['sha256'] and nat['current_service_sha256']==source['crates/sheltie-runtime/src/service.rs']
assert nat['replay_exit']==nat['status_exit']==1 and nat['replay_reply']['committed'] and nat['replay_reply']['request_id']=='audit-approve' and nat['replay_reply']['error']['code']=='EFFECT_PENDING' and nat['replay_reply']['error']['detail']['cause']=='STORE_CORRUPT' and 'original' not in nat['replay_reply'] and 'revision' not in nat['replay_reply'] and nat['status_reply']['error']['code']=='STORE_CORRUPT'
assert all(nat[k] for k in ['only_audit_principal_changed','five_tables_preserved_after_replay','five_tables_preserved_after_status','business_tree_preserved_after_replay','business_tree_preserved_after_status']) and nat['request_published_before']==1
old=nat['before_rows'];new=nat['changed_rows'];delta=[]
for table in old:
 assert len(old[table])==len(new[table])
 for i,(a,b) in enumerate(zip(old[table],new[table])):
  for col,(u,v) in enumerate(zip(a,b)):
   if u!=v:delta.append((table,i,col,u,v))
assert len(delta)==1 and delta[0][0]=='audit' and delta[0][2]==4
con=sqlite3.connect('file:'+nat['fixture_home_retained_for_readonly_review']+'/store.db?mode=ro',uri=True)
for table,rows in new.items():assert [list(x) for x in con.execute('SELECT * FROM '+table+' ORDER BY rowid')]==rows
con.close()
# Every old215-containing service target lives in untouched function regions.
s=(R/'crates/sheltie-runtime/src/service.rs').read_text();oldsrc=subprocess.check_output(['git','show','32c085f53955c5b63a2253eefa57e7504b2cec35:crates/sheltie-runtime/src/service.rs'],text=True)
regions=[('    pub fn start(', '    pub fn begin('),('    fn load_row_at(', '    /// 从Start请求'),('    fn workbook_publication(', '    /// Work 写操作'),('fn validate_command_owner_data(', 'fn materialize_inputs('),('fn observe_output(', 'fn audit_json(')]
for a,b in regions:assert s[s.index(a):s.index(b,s.index(a))]==oldsrc[oldsrc.index(a):oldsrc.index(b,oldsrc.index(a))],a
oldledger=J(T/'t43-215-ledger-draft.json');serviceold=[x['old_id'] for x in oldledger['items'] if '/service.rs:' in x['old_id']];assert len(serviceold)==19
report={'result':'PASS_scoped_final_T58','reviewer':'independent read-only; no Cargo/source/oracle modification','base':g['base'],'source_sha256':{'service':source['crates/sheltie-runtime/src/service.rs'],'new_test':source['crates/sheltie-cli/tests/snapshot_qualification.rs']},'inputs190_current':True,'gate134_subset':True,'source_unchanged':True,'full951':{'run':'424c53bc-4a8a-4bf1-8c26-f4b600335a83','passed':951,'skip':0,'leak':0,'compilefail5':True,'gate_results':g['results']},'affected46':{'run':re.search(r'Nextest run ID (\S+)',affected)[1],'all46_pass':True,'required_6_exception_or_strict_controls_actual':required},'Task3_actual':True,'MSRV_default_actual0':supp,'governance':{'original_docs1_preserved':True,'corrected_docs0_raw_OK':True,'other4exit0':True,'corrected_docs_sha256':H(E/'t58-corrected-docs.txt')},'new2_mutants':{'count':2,'seconds':res['elapsed_seconds'],'formal_actual_CLI_baseline3':True,'env6actualnull':True,'initial_baseline_0_exit4_no_mutants_preserved':True,'entries':entries,'old215_extra_count':0},'native_fixed_case':{'sha256':H(T/'t58-native-fixed-repro.json'),'onlysingle_auditprincipal_delta':delta,'before_published1':True,'replay_effectpending_nooriginal_revision':True,'status_storecorrupt':True,'all5_and_business_tree_kept':True,'readonly_live5rows_match':True,'original32c_needschanges_and_engine66aa_retained':True},'frozen_binaries':art,'old215_source_delta':{'19service_target_regions_byte_exact':serviceold,'other196_target_code_unchanged':True,'new_guards':'earlier pure audit snapshot and write/replay audit execution fact; can newly refuse inconsistent/invalid audit metadata before former targets, do not claim existing frozen catches current reruns','noteworthy_old_witnesses':'G01 service old1240/1241 submit-other-attempt and1251 fail-other-attempt: alternate real event endedAt may differ from originalaudit.at, newly refusing earlier; if same UTC second, existing owner-binding mutant discrimination remains. Candidate contract still rejects; no latest-Caught assertion','scope':'T43 185dynamic/21limitedStatic/9structural historical/frozen qualification kept; guards add necessary facts, unchanged producer/value premises remain; no additional required215 execution identified on validaudit witness domain','static21_structure9':'new fact guard strengthens eligible producer subset, no pure/wiring/root/row value change; oldscopes not enlarged'},'must_fix':[],'remaining_required_mutation_reexecution':[],'limits':['onlyT58 final task, not M2/product/release','no new auth/account/permissions/observer claims','all oldnative/physicalbadFF/unknownusage/stage1 labels preserved','oldpreSubmitWait951/42 separate source, never substituted for final']}
(T/'t58-final-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(report['result'],report['source_sha256'])
