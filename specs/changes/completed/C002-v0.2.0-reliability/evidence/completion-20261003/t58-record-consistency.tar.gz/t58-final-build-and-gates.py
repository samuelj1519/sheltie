from pathlib import Path
import subprocess,os,json,hashlib,shutil
r=Path('/private/tmp/sheltie-completion-20261003');ev=Path('specs/changes/active/C002-v0.2.0-reliability/evidence/completion-20261003');e=os.environ.copy();e['RUSTC_WRAPPER']='';e['CARGO_TARGET_DIR']='/private/tmp/sheltie-c006-binary-tests-target';cmd=['cargo','build','-p','sheltie-cli','-p','sheltie-export','--all-features','--locked','--message-format=json']
with (ev/'t58-binary-build.jsonl').open('wb') as out,(ev/'t58-binary-build-stderr.txt').open('wb') as err:q=subprocess.run(cmd,env=e,stdout=out,stderr=err,timeout=240)
assert q.returncode==0
folder=r/'t58-final-frozen-binaries';folder.mkdir();artifacts={}
for line in (ev/'t58-binary-build.jsonl').read_text().splitlines():
 x=json.loads(line)
 if x.get('reason')=='compiler-artifact' and x.get('executable') and x['target']['name'] in ['sheltie','sheltie-export']:
  n=x['target']['name'];src=Path(x['executable']);dst=folder/n;shutil.copy2(src,dst);artifacts[n]={'original':str(src),'frozen':str(dst),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'cargo_reported_executable':True}
assert set(artifacts)=={'sheltie','sheltie-export'}
record={'argv':cmd,'exit_code':0,'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'artifacts':artifacts}
for p in [r/'t58-frozen-binaries.json',ev/'t58-frozen-binaries.json']:p.write_text(json.dumps(record,indent=2)+'\n')
s=(r/'t51-frozen-gates.py').read_text().replace('t51','t58').replace('/t58-frozen-binaries/','/t58-final-frozen-binaries/').replace('b5226d07a8abca1c2a1b7eaee4de71eb19cf770d',record['base']);(r/'t58-frozen-gates.py').write_text(s);print('Frozen cargo-returned binary artifacts',artifacts,flush=True)
subprocess.run(['python3',str(r/'t58-frozen-gates.py')],check=True)
