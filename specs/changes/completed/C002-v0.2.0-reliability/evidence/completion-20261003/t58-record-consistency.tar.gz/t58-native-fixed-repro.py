from pathlib import Path
import subprocess,sqlite3,tempfile,json,hashlib,os,base64
r=Path('/private/tmp/sheltie-completion-20261003');binary=r/'t58-final-frozen-binaries/sheltie';directory=tempfile.mkdtemp(prefix='t58-record-consistency-',dir=str(r));home=Path(directory)/'home';calls=[]
def run(args):
 cmd=[str(binary),'--home',str(home),'--json',*args];p=subprocess.run(cmd,capture_output=True,timeout=30);reply=json.loads(p.stdout);calls.append({'argv':cmd,'exit_code':p.returncode,'reply':reply,'stderr':p.stderr.decode()});return p.returncode,reply
def ok(args):
 code,reply=run(args);assert code==0 and reply['ok'],reply;return reply
def rows():
 c=sqlite3.connect(home/'store.db');result={t:c.execute('SELECT * FROM '+t+' ORDER BY rowid').fetchall() for t in ['workbooks','works','work_sequence','requests','audit']};c.close();return result
def tree():
 result={}
 for name in ['workbooks','works','pending']:
  root=home/name
  if root.exists():
   for p in [root,*root.rglob('*')]:
    m=p.lstat();result[str(p.relative_to(home))]={'dev':m.st_dev,'ino':m.st_ino,'mode':m.st_mode,'links':m.st_nlink,'bytes_sha256':hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None}
 return result
ok(['--request-id','audit-book','workbook','add',str(Path('examples/gated-release').resolve())]);start=ok(['--request-id','audit-start','work','start','--workbook','gated-release','--flow','default','--input','version=0.3.0-rc.1']);work=start['data']['work_id'];begin=ok(['--request-id','audit-begin','attempt','begin',work,'--node','notes']);Path(begin['data']['outputs']['notes']).write_text('Technical approval audit binding probe\n');ok(['--request-id','audit-submit','attempt','submit',work,'--attempt',begin['data']['attempt'],'--summary','native approved artifact']);approve_args=['--request-id','audit-approve','gate','approve',work,'--node','notes'];original=ok(approve_args)
before_rows=rows();before_files=tree();c=sqlite3.connect(home/'store.db');principal=c.execute("SELECT principal FROM audit WHERE request_id='audit-approve'").fetchone()[0];assert principal and principal!='different-account';assert c.execute("UPDATE audit SET principal='different-account' WHERE request_id='audit-approve'").rowcount==1;c.commit();c.close();changed_rows=rows();changed_files=tree();assert changed_files==before_files
for table in ['workbooks','works','work_sequence','requests']:assert changed_rows[table]==before_rows[table]
replay_code,replay=run(approve_args);after_replay_rows=rows();after_replay_files=tree();status_code,status=run(['work','status',work]);after_status_rows=rows();after_status_files=tree();record={'candidate_base':'32c085f53955c5b63a2253eefa57e7504b2cec35','current_service_sha256':hashlib.sha256(Path('crates/sheltie-runtime/src/service.rs').read_bytes()).hexdigest(),'source_engine_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'fixture_home_retained_for_readonly_review':str(home),'request_published_before':sqlite3.connect(home/'store.db').execute("SELECT published FROM requests WHERE request_id='audit-approve'").fetchone()[0],'only_audit_principal_changed':True,'original_principal':principal,'original_approval_reply':original,'replay_exit':replay_code,'replay_reply':replay,'status_exit':status_code,'status_reply':status,'five_tables_preserved_after_replay':changed_rows==after_replay_rows,'five_tables_preserved_after_status':changed_rows==after_status_rows,'business_tree_preserved_after_replay':changed_files==after_replay_files,'business_tree_preserved_after_status':changed_files==after_status_files,'before_rows':before_rows,'changed_rows':changed_rows,'business_tree_after_single_change':changed_files,'calls':calls,'scope':'actual native CLI/SQL single column change, no source edits/neworacle yet; technical gate fixture not human approval claim'};(r/'t58-native-fixed-repro.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['replay_exit','replay_reply','status_exit','status_reply','five_tables_preserved_after_replay','five_tables_preserved_after_status','business_tree_preserved_after_replay','business_tree_preserved_after_status']},ensure_ascii=False))
