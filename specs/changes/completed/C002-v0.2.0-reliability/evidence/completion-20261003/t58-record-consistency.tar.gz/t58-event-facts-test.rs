
// Task: C002-T58
#[test]
fn historical_work_replay_refuses_empty_audit_subjects_and_self_consistent_wrong_event_times() {
    for field in ["start-principal", "start-time", "cancel-time"] {
        let env = Env::new();
        env.add_example("gated-release");
        let start_args = ["--request-id", "record-start", "work", "start", "--workbook", "gated-release", "--flow", "default", "--input", "version=event-time"];
        let start = env.ok(&start_args);
        let work = start["data"]["work_id"].as_str().unwrap();
        let cancel_args = ["--request-id", "record-cancel", "work", "cancel", work];
        env.ok(&cancel_args);
        let (rid, args) = if field == "cancel-time" { ("record-cancel", cancel_args.as_slice()) } else { ("record-start", start_args.as_slice()) };
        assert_eq!(env.ok(args)["data"]["replayed"], true);
        let connection = Connection::open(env.dir.path().join("store.db")).unwrap();
        if field == "start-principal" {
            assert_eq!(connection.execute("UPDATE audit SET principal='' WHERE request_id=?1", [rid]).unwrap(), 1);
        } else {
            let unrelated_time = "2000-01-01T00:00:00Z";
            assert_eq!(connection.execute("UPDATE audit SET at=?1 WHERE request_id=?2", rusqlite::params![unrelated_time, rid]).unwrap(), 1);
            assert_eq!(connection.execute("UPDATE requests SET at=?1 WHERE request_id=?2", rusqlite::params![unrelated_time, rid]).unwrap(), 1);
        }
        let before = store_rows(&env);
        let objects = audit_fixture_objects(&env);
        let (error, exit) = env.fail(args);
        assert_eq!(exit, 1);
        assert_eq!(error["error"]["code"], "EFFECT_PENDING");
        assert_eq!(error["error"]["detail"]["cause"], "STORE_CORRUPT");
        assert_eq!(error["committed"], true);
        assert_eq!(error["request_id"], rid);
        assert!(error.get("original").is_none(), "{field}: {error}");
        assert!(error.get("revision").is_none(), "{field}: {error}");
        assert_eq!(store_rows(&env), before);
        assert_eq!(audit_fixture_objects(&env), objects);
    }
}
