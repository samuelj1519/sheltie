
fn completed_approval_fixture() -> (Env, String, Vec<String>, Value) {
    let env = Env::new();
    env.add_example("gated-release");
    let work = env.start("gated-release", &[("version", "record-consistency")]);
    let begun = env.begin(&work, "notes");
    env.submit_all(&work, &begun, "actual notes for record consistency");
    let args = ["--request-id", "recorded-approval", "gate", "approve", &work, "--node", "notes"]
        .into_iter().map(str::to_owned).collect::<Vec<_>>();
    let original = env.ok(&args.iter().map(String::as_str).collect::<Vec<_>>());
    let archive = env.begin(&work, "archive");
    env.submit_all(&work, &archive, "later legitimate completion");
    assert_eq!(env.ok(&["work", "status", &work])["data"]["status"]["kind"], "succeeded");
    (env, work, args, original)
}

#[derive(Debug, PartialEq, Eq)]
struct AuditFixtureObject {
    device: u64,
    inode: u64,
    mode: u32,
    links: u64,
    bytes: Option<Vec<u8>>,
}

fn audit_fixture_objects(env: &Env) -> std::collections::BTreeMap<std::path::PathBuf, AuditFixtureObject> {
    use std::os::unix::fs::MetadataExt;
    fn visit(root: &std::path::Path, path: &std::path::Path, out: &mut std::collections::BTreeMap<std::path::PathBuf, AuditFixtureObject>) {
        let meta = std::fs::symlink_metadata(path).unwrap();
        assert!(meta.is_file() || meta.is_dir());
        out.insert(path.strip_prefix(root).unwrap().to_owned(), AuditFixtureObject {
            device: meta.dev(), inode: meta.ino(), mode: meta.mode(), links: meta.nlink(),
            bytes: meta.is_file().then(|| std::fs::read(path).unwrap()),
        });
        if meta.is_dir() {
            for child in std::fs::read_dir(path).unwrap() { visit(root, &child.unwrap().path(), out); }
        }
    }
    let mut out = std::collections::BTreeMap::new();
    for name in ["works", "workbooks", "pending", "retained-frozen"] {
        let path = env.dir.path().join(name);
        if path.exists() { visit(env.dir.path(), &path, &mut out); }
    }
    out
}

// Task: C002-T58
#[test]
fn historical_gate_replay_keeps_its_original_after_later_work_completion() {
    let (env, _work, args, mut expected) = completed_approval_fixture();
    assert_eq!(expected["data"]["work_status"]["kind"], "active");
    expected["data"]["replayed"] = json!(true);
    let before = store_rows(&env);
    let objects = audit_fixture_objects(&env);
    assert_eq!(env.ok(&args.iter().map(String::as_str).collect::<Vec<_>>()), expected);
    assert_eq!(store_rows(&env), before);
    assert_eq!(audit_fixture_objects(&env), objects);
}

// Task: C002-T58
#[test]
fn historical_gate_replay_refuses_an_inconsistent_audit_subject_before_reading_frozen_files() {
    for principal in ["record-check-other", ""] {
        for missing_frozen in [false, true] {
            let (env, work, args, original) = completed_approval_fixture();
            let before = store_rows(&env);
            let connection = Connection::open(env.dir.path().join("store.db")).unwrap();
            assert_ne!(original["data"]["by"], principal);
            assert_eq!(connection.execute("UPDATE audit SET principal=?1 WHERE request_id='recorded-approval'", [principal]).unwrap(), 1);
            let changed = store_rows(&env);
            let mut expected = before;
            let row = expected.get_mut("audit").unwrap().iter_mut().find(|row| row[3] == rusqlite::types::Value::Text("recorded-approval".into())).unwrap();
            row[4] = rusqlite::types::Value::Text(principal.into());
            assert_eq!(changed, expected, "only the named audit column changes");
            if missing_frozen {
                std::fs::rename(env.dir.path().join("works").join(&work).join("workbook"), env.dir.path().join("retained-frozen")).unwrap();
            }
            let objects = audit_fixture_objects(&env);
            let (error, exit) = env.fail(&args.iter().map(String::as_str).collect::<Vec<_>>());
            assert_eq!(exit, 1);
            assert_eq!(error["error"]["code"], "EFFECT_PENDING");
            assert_eq!(error["error"]["detail"]["cause"], "STORE_CORRUPT");
            assert_eq!(error["committed"], true);
            assert_eq!(error["request_id"], "recorded-approval");
            assert!(error.get("original").is_none(), "{error}");
            assert!(error.get("revision").is_none(), "{error}");
            assert!(error.to_string().contains("audit"), "pure record eligibility must precede frozen IO: {error}");
            assert_eq!(store_rows(&env), changed);
            assert_eq!(audit_fixture_objects(&env), objects);
            let (status, exit) = env.fail(&["work", "status", &work]);
            assert_eq!(exit, 1);
            assert_eq!(status["error"]["code"], "STORE_CORRUPT");
            assert_eq!(store_rows(&env), changed);
            assert_eq!(audit_fixture_objects(&env), objects);
        }
    }
}
