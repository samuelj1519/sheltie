from pathlib import Path
import os,subprocess,tempfile,shutil,json,hashlib,base64,stat
r=Path('/private/tmp/sheltie-completion-20261003');records={};candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();binary=r/'t57-frozen-binaries/sheltie'
for name,cmd in [('uname',['uname','-m']),('macos',['sw_vers']),('rust',['rustc','-Vv']),('nextest',[str(r/'tools/nextest/cargo-nextest'),'--version']),('binary_architecture',['file',str(binary)]),('binary_version',[str(binary),'--version'])]:
 p=subprocess.run(cmd,capture_output=True,timeout=30);records[name]={'argv':cmd,'exit_code':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}
assert records['uname']['stdout'].strip()=='arm64' and 'arm64' in records['binary_architecture']['stdout']
inputs=json.loads(Path('specs/changes/active/C002-v0.2.0-reliability/evidence/completion-20261003/t57-final-gates.json').read_text());assert inputs['source_unchanged'] and all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in inputs['inputs'].items())
def tree(root):return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
with tempfile.TemporaryDirectory(prefix='t45-native-',dir=str(r)) as directory:
 parent=Path(directory);source=parent/'合法源目录-中文';shutil.copytree('examples/two-step',source);before=tree(source);home=parent/'合法管理根-中文';cmd=[str(binary),'--home',str(home),'--json','--request-id','t45-native-unicode','workbook','add',str(source)];p=subprocess.run(cmd,capture_output=True,timeout=30);reply=json.loads(p.stdout);assert p.returncode==0 and reply['ok'] and reply['data']['id']=='two-step';assert tree(source)==before==tree(home/'workbooks/two-step/1.0.0')
 records['unicode_source']={'argv':cmd,'exit_code':p.returncode,'reply':reply,'source_files_sha256':before,'source_bytes_unchanged':True,'installed_bytes_match':True}
 records['physical_nonutf8']=[]
 for kind in ['file','directory']:
  path=os.fsencode(parent)+b'/bad-'+kind.encode()+b'-\xff'
  try:
   if kind=='directory':os.mkdir(path)
   else:
    fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.write(fd,b'native original');os.close(fd)
   item={'kind':kind,'created':True,'execution':'physical_created_requires_engine_traversal_followup'}
  except OSError as error:item={'kind':kind,'created':False,'errno':error.errno,'error':str(error),'engine_physical_traversal_fixture':'not_run/environment_blocked_by_carrier'}
  records['physical_nonutf8'].append(item)
 missing_home=parent/'invalid-argv-home';args=[os.fsencode(binary),b'--home',os.fsencode(missing_home),b'--json',b'workbook',b'add',os.fsencode(parent)+b'/invalid-\xff'];p=subprocess.run(args,capture_output=True,timeout=30);assert p.returncode==2 and not missing_home.exists()
 records['invalid_utf8_argv']={'argv_bytes_hex':[a.hex() for a in args],'exit_code':p.returncode,'stdout_base64':base64.b64encode(p.stdout).decode(),'stderr_base64':base64.b64encode(p.stderr).decode(),'stderr_text':p.stderr.decode(errors='replace'),'home_not_created':True,'scope':'actual native execve argv frontend refusal; not physical invalid-name tree traversal'}
 for path in [home/'workbooks/two-step/1.0.0']:
  for current,dirs,files in os.walk(path):
   os.chmod(current,0o700)
 records['owned_fixture_reclaimed_after_scope']=str(parent)
assert not parent.exists()
record={'candidate':candidate,'platform':'macOS aarch64 only','filesystem':json.loads((r/'t45-native-carrier-filesystem.json').read_text()),'binary':{'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},'native':records,'same_source_engineering_gate':'t57-final-gates.json run fca0838a-afa4-436c-af23-0403e735b3b9 948/948','same_engineering134_inputs_verified':True,'other_platforms':'excluded_by_user','usage':None,'scope':'actual verified APFS carrier and constructible native inputs; physical nonUTF8 engine traversal not_run retained'}
(r/'t45-native-current-probe.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print('Native probe complete:',[(x['kind'],x.get('errno'),x['created']) for x in records['physical_nonutf8']],'CLI raw UTF8 exit',records['invalid_utf8_argv']['exit_code'])
