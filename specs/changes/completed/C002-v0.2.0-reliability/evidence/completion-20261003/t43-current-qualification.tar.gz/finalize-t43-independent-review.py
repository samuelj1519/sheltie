from pathlib import Path
import json,hashlib,collections,subprocess
R=Path.cwd();T=Path('/private/tmp/sheltie-completion-20261003');E=R/'specs/changes/active/C002-v0.2.0-reliability/evidence/completion-20261003'
def J(p):return json.loads(p.read_text())
def H(b):return hashlib.sha256(b).hexdigest()
f=E/'t43-215-dispositions.json';ledger=J(f);draft=J(T/'t43-215-ledger-draft.json');old={x['old_id']:x for x in draft['items']};cur30=J(T/'t43-current30-independent-audit.json');new30={x['old_id']:x for x in cur30['entries']};src=cur30['source_sha256']
assert ledger['candidate']=='4487ac1eb20672b8136aba186e8392fafa38ebca' and ledger['counts']=={'dynamic':185,'static':21,'structural':9}
assert len(ledger['items'])==len({x['old_id'] for x in ledger['items']})==215 and set(old)=={x['old_id'] for x in ledger['items']}
assert not ledger['old_history_rewritten'] and not ledger['current_all215_native_execution'] and not ledger['full215_current_reexecution_claimed'] and not ledger['parent_M2_approval']
for row in ledger['items']:
 ident=row['old_id'];assert row['old_stage1_label']=='MissedMutant';assert row['category']==old[ident]['category'] and row['latest_mapping']==old[ident]['latest_mapping']
 if ident in new30:
  rec=row['current_execution_record'];expected=new30[ident]
  for k in ['current_id','log_sha256','phase_results']:assert rec[k]==expected[k]
  assert rec['source_closure_count']==190 and rec['result']=='CaughtMutant'
  assert row['historical_early_execution_record']==old[ident]['frozen_execution_record']
  assert (T/rec['log']).exists() and H((T/rec['log']).read_bytes())==rec['log_sha256']
 else:
  for k in ['frozen_execution_record','frozen_task_record']:
   if k in old[ident]:assert old[ident][k]==row[k]
# All existing task source190 closures' non-Rust external Cargo/config/fixture inputs unchanged currently.
closures=J(T/'t43-later-frozen-closure-audit.json')
for row in closures:
 assert row['source_count']==190 and row['missing_current']==[]
 assert all(p.endswith('.rs') for p in row['changed_current'])
# Current full engineering gate remains actual source134 subset of current190.
gates=J(E/'t57-final-gates.json');assert len(gates['inputs'])==134 and gates['source_unchanged']
assert all(src[k]==v for k,v in gates['inputs'].items())
for result in gates['results']:
 assert result['exit_code']==0
 raw=E/('t57-final-'+result['name']+'.txt');assert H(raw.read_bytes())==result['output_sha256']
for b in J(E/'t57-frozen-binaries.json')['artifacts'].values():
 assert b['cargo_reported_executable'] and H(Path(b['frozen']).read_bytes())==b['sha256']
# exact data layout varies; use independently checked report source and unchanged current190 rather than guess gate keys.
t57=J(T/'t57-final-review.json');assert t57['source_unchanged_verified'] and t57['input_count']==190 and t57['gate_input_count']==134
assert all(H((R/p).read_bytes())==sha for p,sha in src.items())
# Preserve actual classification of all30 new red snippets, with narrower pure/response/mechanism bounds.
class_counts=collections.Counter()
for row in cur30['entries']:
 ident=row['current_id'];snippet=row['actual_failure_excerpt']
 if '/effects.rs:' in ident:
  cls='pure Publication qualification over genuine real-producer context accepts malformed field';assert any(x in snippet for x in ['pending_leaf','pending_prefix','command_work','digest','owner','final'])
 elif '/load.rs:' in ident:cls='pure binding consumer over genuine two-commit state accepts invalid namespace or missing required';assert 'assertion failed' in snippet
 elif '/store/read.rs:' in ident:cls='pure narrow/full immutable metadata drift accepted';assert any(x in snippet for x in ['intent','reply','work'])
 elif '/snapshot.rs:' in ident:cls='wrong subsequent frozen-file refusal instead of prior Start data/Reply identity diagnostic';assert '冻结副本' in snippet
 elif '/service.rs:166' in ident:cls='unqualified submit original exposed although later effect still refused';assert 'original' in snippet and 'summary#1.0' in snippet
 elif '/service.rs:' in ident:cls='coherently forged Start or Fail replay actually succeeds';assert '命令意外成功' in snippet
 elif 'checked_asset_name' in ident:cls='pure asset-name accepts forbidden lexical segment';assert any(x in snippet for x in ['""','"."','dir'])
 elif 'wait_bounded_child' in ident:cls='actual child terminated before explicit release at legal closed-pipe byte limits';assert 'unix_wait_status(9)' in snippet
 elif 'validate_readonly' in ident:cls='bad schema still refused later but main SQLite bytes already changed';assert 'store/tests.rs:107:9' in snippet
 elif 'Store::validate' in ident:cls='write-session independent journal mode not configured before later Store getter';assert 'delete' in snippet and 'wal' in snippet
 elif '129:50' in ident:cls='zero persistent revision incorrectly reports CAS conflict instead of corruption';assert '实际 0' in snippet
 elif '183:24' in ident:cls='actual non-Constraint INSERT failure misclassified as WorkbookExists';assert '已装' in snippet
 else:raise AssertionError(ident)
 row['independent_actual_classification']=cls;class_counts[cls]+=1
# Avoid giant main-bytes dump in final JSON; original raw/log hashes remain complete in supplemental audit.
cur30['entries']=[{**r,'actual_failure_excerpt':r['actual_failure_excerpt'][:1900] if 'main SQLite' not in r['independent_actual_classification'] else 'store/tests.rs:107 main_before byte comparison failed; full byte arrays retained in immutable raw log'} for r in cur30['entries']]
cur30['final_independent_target_predicate_review']='PASS all30 exact intended predicate; diagnostic/pure/final-acceptance distinctions retained'
references=['t43-215-mechanical-audit.json','t43-static-current-delta-review.json','t43-later-frozen-closure-audit.json','t43-target-line-delta-audit.json','t43-schema-current-review.json','t57-final-review.json','t43-current-delta-qualification.md','t43-findings.json','t43-dispatch-environment-boundaries.json']
report={'result':'PASS_scoped_T43_current_adopted_215_dispositions','reviewer':'Codex /root/oracle_review; independent of oracle/implementation/preparation; no Cargo or source/plan edits','candidate':ledger['candidate'],'platform':'macOS aarch64 only','unique_old215_exact':True,'counts':ledger['counts'],'current_executions':{'count':37,'current30':30,'current_schema':2,'T57_current':5,'other148':'task-frozen full190 executions plus independent current producer/caller/delta qualification; not current reexecution'},'current_inventory':{'expressible206_unique':True,'removed_structural9':True,'exact_target_changed_lines204':True,'two_function_delete_deltas':'verify_tree_at directory pure replacement and sync_dir_locked modeled sync observation; T55/T56 genuine current consumer outcomes reviewed','function_renames9':'T48 validate_command_owner_data four; T49 load_row_at three; T57 rendezvous_payload two; exact operator/function/column/genre/replacement mapping independently checked'},'old_stage1_Missed_all215_preserved':True,'old_diff_source_original_immutable_git_verified':True,'current30':cur30,'current30_actual_classification_counts':dict(class_counts),'finding_F_T43_01':{'original':'preserved t43-findings.md/json','resolution':'resolved by new actual current full190 30 executions; historical126/127 omission retained, no retrospective closure/relabel or additional oldID count'},'static21':'all current complete producer/caller limitations independently rechecked; no dynamic/Caught or whole-observation equivalence expansion','structural9':'current private pure truth-table/wiring/native caller and pure-only9 mechanism qualification still valid; old native not_run/Caughtfalse remain','current_full_engineering_reference':{'run_id':'fca0838a-afa4-436c-af23-0403e735b3b9','nextest':'948/948,0skip,0LEAK','doctests_compilefail':5,'fmt_check_clippy_MSRV_default':'actual0 previously independently audited, current134/190 byte unchanged; not rerun by Reviewer','gates_json_sha256':H((E/'t57-final-gates.json').read_bytes())},'evidence_archives':J(T/'t43-215-mechanical-audit.json')['archives'],'final_new_T43_archive':'assembly after independent review not yet evaluated; owner must append current30/schema/review artifacts and verify memberSHA; no finalarchive PASS invented','reviewed_ledger_sha256':H(f.read_bytes()),'supporting_reference_sha256':{s:H((T/s).read_bytes()) for s in references},'must_fix':[],'required_more_mutation_execution':[],'does_not_approve':['M2','whole product C001-C008','old e3eea89/old95d78e candidate','215 old native executions','185 latest candidate reexecutions','platforms other than macOS aarch64','unobserved child status or whole-safety/resources/error-JSON equivalence']}
(T/'t43-final-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(report['result'],H(f.read_bytes()),dict(class_counts))
