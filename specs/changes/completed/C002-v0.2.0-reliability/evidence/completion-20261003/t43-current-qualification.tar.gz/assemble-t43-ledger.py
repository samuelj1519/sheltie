from pathlib import Path
import json,hashlib,collections,subprocess
r=Path('/private/tmp/sheltie-completion-20261003');ev=Path('specs/changes/active/C002-v0.2.0-reliability/evidence/completion-20261003');prep=json.loads((r/'t43-final-assembly-directions.json').read_text());latest={x['old_id']:x for x in json.loads((r/'t43-latest215-binding.json').read_text())['items']};schema=json.loads((r/'t43-schema-current-review.json').read_text());assert 'PASS' in schema['result'];rows=[]
for x in prep['restored32']:
 row={'old_id':x['old_id'],'category':'dynamic','group':x['group'],'evidence_origin':'restored early32','frozen_execution_record':x,'latest_mapping':latest[x['old_id']],'old_stage1_label':'MissedMutant','latest_execution_reuse_approved':False}
 if 'store/schema.rs:' in x['old_id']:row['scoped_independent_acceptance']='t43-schema-current-review.md/json current190 closure'
 else:row['scoped_independent_acceptance']='existing T47/T48 scoped acceptance; current caller/delta qualification pending independent T43 review'
 rows.append(row)
for x in prep['existing183']:
 p=Path(x['ledger_ref']);owner=json.loads(p.read_text());original=next(y for y in owner['items'] if y['old_id']==x['old_id']);category=x['category'];row={'old_id':x['old_id'],'category':category,'evidence_origin':p.name,'source_ledger_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'frozen_task_record':original,'latest_mapping':latest[x['old_id']],'old_stage1_label':'MissedMutant','latest_execution_reuse_approved':False,'scoped_independent_acceptance':x['task']+' final scoped review; current caller/delta qualification pending independent T43 review'}
 if category=='structural':row['current_qualification']='T55 current replacement contract verified (pure/wiring/native caller/shared mutation), old syntax removed; original native execution not_run/caught=false retained'
 if x['task']=='T57':row['scoped_independent_acceptance']='t57-final-review.md/json PASS scoped current5';row['preparation_status_boundary']='not_run in original preparation refers only to that earlier preparation stage; actual frozen execution5 separately reviewed'
 rows.append(row)
counts=dict(collections.Counter(x['category'] for x in rows));assert counts=={'dynamic':185,'static':21,'structural':9},counts
assert len(rows)==len({x['old_id'] for x in rows})==215 and set(latest)=={x['old_id'] for x in rows}
record={'candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'platform':'macOS aarch64 only','counts':counts,'unique_old215':True,'items':rows,'source_closure_boundaries':prep['run_closures'],'historical_schema_sample':prep['historical_schema_sample'],'assembly_approval':'pending independent current caller/delta review; counts do not confer215PASS','old_history_rewritten':False,'current_all215_native_execution':False,'full215_current_reexecution_claimed':False,'latest_mapping_alone_is_not_execution':True,'parent_M2_approval':False}
(r/'t43-215-ledger-draft.json').write_text(json.dumps(record,indent=2)+'\n');print(counts,len(rows))
