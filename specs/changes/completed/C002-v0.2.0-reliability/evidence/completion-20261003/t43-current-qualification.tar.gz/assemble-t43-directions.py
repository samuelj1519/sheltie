import hashlib,json,tarfile,subprocess,re,collections,io
from pathlib import Path
p=Path('/private/tmp/sheltie-completion-20261003');repo=Path.cwd();e=repo/'specs/changes/active/C002-v0.2.0-reliability/evidence/completion-20261003'
archive_ref='e54dcd41d8f1e186007b62b47583063cb19a4b66';oldbase='specs/changes/active/C002-v0.2.0-reliability/evidence/m1-2026-10-01/mutants/'
def sha(b):return hashlib.sha256(b).hexdigest()
def gitbytes(path):return subprocess.check_output(['git','show',archive_ref+':'+path])
ledgerpath=oldbase+'adaptive-validation-2026-10-02/final-ledger.json';mapath=oldbase+'adaptive-validation-2026-10-02/SK02-missing-execution-map.json'
ledgerraw=gitbytes(ledgerpath);led=json.loads(ledgerraw);missingraw=gitbytes(mapath);missing=json.loads(missingraw);oldmap={x['id']:x for x in missing['items']};oldledger={x['id']:x for x in led['items']}
assert len(oldmap)==215;assert set(oldmap)==set(json.loads((p/'sk02-map.json').read_text())['items'][i]['id'] for i in range(215))
corresp={x['old_id']:x for x in json.loads((p/'independent-sk02-mapping.json').read_text())['all_correspondences']}
early_inventory={x['name']:x for x in json.loads((p/'current-runtime-mutants.json').read_text())}
def changed_lines(b):return [l for l in b.decode().splitlines() if l[:1] in ['+','-'] and not l.startswith(('+++ ','--- '))]
archive_maps={};archive_audit={}
for prefix,an in [('t47','t47-oracles.tar.gz'),('t48','t48-g01-oracles.tar.gz')]:
 info=json.loads((e/(prefix+'-oracle-archive.json')).read_text());z=e/an;assert sha(z.read_bytes())==info['sha256']
 with tarfile.open(z) as tar:member={x.name:tar.extractfile(x).read() for x in tar.getmembers() if x.isfile()}
 assert all(sha(member[n])==h for n,h in info['members'].items())
 archive_maps[prefix]=member;archive_audit[prefix]=dict(path=str(z),sha256=info['sha256'],manifest=str(e/(prefix+'-oracle-archive.json')),member_hashes_verified=len(info['members']))
runs={};run_prefix={'mutation-groups/G10':'t47','mutation-oracle-check':'t47','mutation-cleanup-check':'t47','mutation-g01-final':'t48'}
for run,prefix in run_prefix.items():
 member=archive_maps[prefix];skey=run+'/selection.json';okey=run+'/mutants.out/outcomes.json';selection=json.loads(member[skey]);out=json.loads(member[okey]);assert member[skey]==(p/skey).read_bytes();assert member[okey]==(p/okey).read_bytes()
 resultkey=run+'/result.json';result=json.loads(member[resultkey]) if resultkey in member else next(x for x in json.loads(member['mutation-groups/results.json']) if x['group']=='G10')
 source=selection['source_sha256'];changed=[]
 for f,h in source.items():
  path=repo/f
  if not path.is_file():changed.append({'file':f,'frozen_sha256':h,'latest':'absent'})
  else:
   now=sha(path.read_bytes())
   if now!=h:changed.append({'file':f,'frozen_sha256':h,'latest_sha256':now})
 runs[run]=dict(base_commit=selection.get('candidate',selection.get('base')),selection_archive_member=skey,selection_sha256=sha(member[skey]),archive=archive_audit[prefix]['path'],archive_sha256=archive_audit[prefix]['sha256'],outcomes_archive_member=okey,outcomes_sha256=sha(member[okey]),outcomes_start=out['start_time'],outcomes_end=out['end_time'],result=result,source_manifest=source,source_manifest_count=len(source),filter=selection['filter'],baseline=out['outcomes'][0],latest_changed_inputs=changed,comparison_is_test_reuse_approval=False)
 runobj={o['scenario']['Mutant']['name']:o for o in out['outcomes'] if isinstance(o['scenario'],dict)};runs[run]['_outcomes']=runobj
schema_run='mutation-t43-schema-current';ss=json.loads((p/schema_run/'selection.json').read_text());so=json.loads((p/schema_run/'mutants.out/outcomes.json').read_text());sr=json.loads((p/schema_run/'result.json').read_text());smp=json.loads((p/'t43-schema-current-mapping.json').read_text())
assert len(ss['source_sha256'])==190 and sr['source_unchanged'] and sr['counts']['CaughtMutant']==2
runs[schema_run]=dict(base_commit=ss['base'],selection=str(p/schema_run/'selection.json'),selection_sha256=sha((p/schema_run/'selection.json').read_bytes()),outcomes=str(p/schema_run/'mutants.out/outcomes.json'),outcomes_sha256=sha((p/schema_run/'mutants.out/outcomes.json').read_bytes()),result=sr,source_manifest=ss['source_sha256'],source_manifest_count=190,filter=ss['filter'],baseline=so['outcomes'][0],outcomes_start=so['start_time'],outcomes_end=so['end_time'],archive=None,archive_status='Root to adopt raw archive and bind final independent review',independent_acceptance='pending',_outcomes={o['scenario']['Mutant']['name']:o for o in so['outcomes'] if isinstance(o['scenario'],dict)})
oldphase={}
def stage_record(id):
 x=oldledger[id];s=x['original_stage1'];phase=s['phase']
 if phase not in oldphase:
  meta_path=oldbase+phase+'/metadata.json';mb=gitbytes(meta_path);obpath=oldbase+phase+'/raw/outcomes.json';ob=gitbytes(obpath);meta=json.loads(mb);out=json.loads(ob);assert sha(ob)==s['outcomes_sha256']==meta['outcomes_sha256'];oldphase[phase]=dict(metadata_path=meta_path,metadata_sha256=sha(mb),metadata=meta,outcomes_path=obpath,outcomes_sha256=sha(ob),_index={o['scenario']['Mutant']['name']:o for o in out['outcomes'] if isinstance(o['scenario'],dict)})
  arpath=oldbase+phase+'/raw.tar.gz';ar=gitbytes(arpath);am=json.loads(gitbytes(oldbase+phase+'/archive-manifest.json'));rm=gitbytes(oldbase+phase+'/raw-manifest.json');assert sha(ar)==am['archive_sha256'] and sha(rm)==am['raw_manifest_sha256'];manifest=json.loads(rm)
  wanted={oldledger[k]['original_stage1']['log_path'] for k,v in oldmap.items() if v['group_id'] in ['G01','G10','G11','G12'] and oldledger[k]['original_stage1']['phase']==phase}
  with tarfile.open(fileobj=io.BytesIO(ar)) as tar:logs={n:tar.extractfile('raw/'+n).read() for n in wanted}
  assert all(sha(v)==manifest[n]['sha256'] for n,v in logs.items());oldphase[phase].update(raw_archive_path=arpath,raw_archive_sha256=sha(ar),raw_manifest_sha256=sha(rm),selected_original_logs_verified=len(logs),_logs=logs)
 pp=oldphase[phase];o=pp['_index'][id];assert o['summary']==s['result']=='MissedMutant';assert oldmap[id]['diff_sha256']==x['diff_sha256'];logpath=pp['raw_archive_path']+'#raw/'+s['log_path'];lb=pp['_logs'][s['log_path']]
 return dict(label='MissedMutant',candidate=pp['metadata']['candidate'],execution_closure_sha256=pp['metadata']['execution_closure_sha256'],source_sha256=x['source_sha256'],old_diff_sha256=x['diff_sha256'],phase=phase,archive_ref=archive_ref,metadata_path=pp['metadata_path'],outcomes_path=pp['outcomes_path'],outcomes_sha256=pp['outcomes_sha256'],log_path=logpath,log_sha256=sha(lb),original_phase_results=s['phase_results'])
def make_record(id,run):
 cm=corresp[id]['current_id'];rr=runs[run];o=rr['_outcomes'][cm];assert o['summary']=='CaughtMutant';mut=o['scenario']['Mutant'];ph=o['phase_results'];assert next(x for x in ph if x['phase']=='Build')['process_status']=='Success';test=next(x for x in ph if x['phase']=='Test');assert isinstance(test['process_status'],dict) and 'Failure' in test['process_status'];prefix=run_prefix.get(run)
 if prefix:
  member=archive_maps[prefix];lp=run+'/mutants.out/'+o['log_path'];dp=run+'/mutants.out/'+o['diff_path'];lb=member[lp];db=member[dp];arch=rr['archive']
 else:
  lp=str(p/run/'mutants.out'/o['log_path']);dp=str(p/run/'mutants.out'/o['diff_path']);lb=Path(lp).read_bytes();db=Path(dp).read_bytes();arch=None
 assert changed_lines(db)==changed_lines(early_inventory[cm]['diff'].encode()),id
 text=lb.decode(errors='replace');fails=[]
 for line in text.splitlines():
  if re.search(r'^\s*FAIL \[',line):
   name=line.rsplit(') ',1)[-1].strip()
   if name not in fails:fails.append(name)
 return dict(old_id=id,group=oldmap[id]['group_id'],current_id=cm,old_diff_sha256=oldmap[id]['diff_sha256'],current_diff_sha256=sha(db),early_correspondence_diff_sha256=corresp[id]['current_diff_sha256'],raw_diff_changed_lines_match_early_inventory=True,full_diff_matches_early_inventory=sha(db)==corresp[id]['current_diff_sha256'],old_stage1=stage_record(id),disposition='dynamic_caught',observed_summary=o['summary'],formal_build_success=True,formal_test_failure=True,phase_results=ph,failing_tests=fails,run_ref=run,archive=arch,log_member_or_path=lp,log_sha256=sha(lb),diff_member_or_path=dp,source_file_sha256=rr['source_manifest'][mut['file']],independent_acceptance='pending_current_schema' if run==schema_run else 'previous task scope only; final T43 aggregate review pending')
restored=[]
for id,x in oldmap.items():
 if x['group_id']=='G01':run='mutation-g01-final'
 elif x['group_id']=='G10':
  if '/store/schema.rs:' in id:run=schema_run
  elif 'validate_readonly' in id:run='mutation-groups/G10'
  else:run='mutation-oracle-check'
 elif x['group_id']=='G11':run='mutation-oracle-check'
 elif x['group_id']=='G12':run='mutation-cleanup-check'
 else:continue
 restored.append(make_record(id,run))
assert len(restored)==32 and collections.Counter(x['group'] for x in restored)=={'G01':19,'G10':6,'G11':3,'G12':4}
existing=[];files=[]
for t,g in [(49,'g02'),(50,'g03'),(51,'g04'),(52,'g05'),(53,'g06'),(54,'g07'),(55,'g08'),(56,'g09'),(57,'g13')]:
 file=e/f't{t}-{g}-dispositions.json';j=json.loads(file.read_text());files.append(dict(task='T'+str(t),group=g.upper(),path=str(file),sha256=sha(file.read_bytes()),count=len(j['items']),counts=j['counts']))
 for row in j['items']:
  oid=row['old_id'];assert oid in oldmap;assert row.get('old_stage1_formal_summary','MissedMutant')=='MissedMutant'
  if row.get('old_diff_sha256'):assert row['old_diff_sha256']==oldmap[oid]['diff_sha256']
  disposition=row['disposition'];category='dynamic' if disposition=='dynamic_caught' else 'structural' if 'structural_replacement' in disposition else 'static'
  existing.append(dict(old_id=oid,old_diff_sha256=oldmap[oid]['diff_sha256'],old_stage1_label='MissedMutant',current_disposition=disposition,category=category,ledger_ref=str(file),current_id=row.get('current_id'),current_diff_sha256=row.get('current_diff_sha256'),current_source_sha256=row.get('current_source_sha256'),log=row.get('log'),log_sha256=row.get('log_sha256'),proof=row.get('proof'),task='T'+str(t),independent_acceptance='pending_T57_final_review' if t==57 else 'existing scoped task review; final T43 cross-input assembly pending'))
assert len(existing)==183
allrecords=[dict(old_id=x['old_id'],category='dynamic',record_type='restored32',record_index=i,old_stage1_label='MissedMutant') for i,x in enumerate(restored)]+[dict(old_id=x['old_id'],category=x['category'],record_type='existing183',record_index=i,old_stage1_label='MissedMutant') for i,x in enumerate(existing)]
allids=[x['old_id'] for x in allrecords];assert len(allids)==len(set(allids))==215 and set(allids)==set(oldmap)
counts=dict(collections.Counter(x['category'] for x in allrecords));assert counts=={'dynamic':185,'static':21,'structural':9}
for rr in runs.values():rr.pop('_outcomes',None)
for rr in oldphase.values():rr.pop('_index',None);rr.pop('_logs',None)
legacy_schema=json.loads((p/'mutation-sample/mutants.out/outcomes.json').read_text());historical=[]
for o in legacy_schema['outcomes']:
 if isinstance(o['scenario'],dict) and o['scenario']['Mutant']['name'] in oldmap:
  lb=p/'mutation-sample/mutants.out'/o['log_path'];db=p/'mutation-sample/mutants.out'/o['diff_path'];historical.append(dict(old_id=o['scenario']['Mutant']['name'],summary=o['summary'],log=str(lb),log_sha256=sha(lb.read_bytes()),diff=str(db),diff_sha256=sha(db.read_bytes()),closure='incomplete; no selection/candidate/source manifest; do not infer from HEAD/time',counted_as_current_qualification=False))
assert len(historical)==2
report=dict(scope='T43 final assembly preparation only; no Cargo/oracle execution, tracked/state writes or PASS; oracle_review owns final independent acceptance',head_at_assembly=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),platform='aarch64-apple-darwin only',historical_inventory_count=2514,old_extra_set_count=215,exact_old_set_verified=True,duplicates=[],missing=[],unexpected=[],expected_current_categories=counts,restored32=restored,existing183=existing,unique215_index=allrecords,existing_ledgers=files,run_closures=runs,archive_readback=archive_audit,old_stage_closures=oldphase,old_accounting=dict(archive_ref=archive_ref,final_ledger_path=ledgerpath,final_ledger_sha256=sha(ledgerraw),missing_map_path=mapath,missing_map_sha256=sha(missingraw),candidate=led['candidate'],product_candidate=led['product_candidate'],source_manifest_sha256=led['source_manifest_sha256'],inventory_sha256=led['inventory_sha256'],old_disposition_complete=led['disposition_complete']),historical_schema_sample=historical,current_schema_recheck=dict(mapping_path=str(p/'t43-schema-current-mapping.json'),mapping_sha256=sha((p/'t43-schema-current-mapping.json').read_bytes()),run_ref=schema_run,actual_caught=2,source_closure_count=190,independent_acceptance='pending',adopted_archive='pending'),t57_acceptance='pending independent final approval per assigned scope; raw 5 actual catches alone do not authorize PASS',all_old_stage1_labels_preserved=True,approval=False)
report['assembly_followups']=[
 'Bind two schema fresh-current logs/result/selection190/raw archive and oracle_review decision; old sample remains separately closure-incomplete, extra String::new excluded.',
 'Bind T57 formal runtime2 baseline vs five mutated tests correctly, supplemental exactcontrol separate; final oracle_review decision required.',
 'Join all215 by original exact ID/diff hash; do not count duplicate early/corrected runs or replacement targets as extra old IDs.',
 'Preserve185 dynamic,21 limited static,9 structural categories;9 old native targets not_run/caught=false/removed, not equivalent or old Caught.',
 'For latest candidate compare each frozen input closure and actual producer/caller/test path. Commands/filter alone are insufficient; unchanged semantic subclosure can only support explicit scoped retention with reviewer proof.',
 'T47 first6 Store/asset use original oracle-check source hash, final4 child use cleanup-check source hash. Selfmgmt full-file hashes differ due test cleanup; same base06e is not one frozen source.',
 'T48 uses final all19 unchanged-source run; initial17 source-drift run is development only.',
 'Review current effects/fsx/pending changed by observer additions, T53 digest/UTF8 fix and T55 structural normalization; validate static caller closure and structural wiring against latest source.',
 'T55 ledger inherited text still says pending in some mapping/current_target fields while final proof/disposition says verified: final assembly should normalize current status with precise proof pointer, preserve old source records.',
 'T57 inherited preparation_status=not_run reflects preparation, execution field reflects later actual run; final ledger should avoid ambiguous execution status.',
 'Old stage1 actual candidate95d78 vs historical product e3eea89 and archived input closures remain distinct; new qualification never approves old input or revises old Missed.',
 'No product/M2/all-platform/security completion from aggregate counts; final current engineering gates and user-flow acceptance have their own frozen source/run.']
(p/'t43-final-assembly-directions.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=['# T43 最终汇总准备（不授 PASS）','','只读恢复精确证据，未运行Cargo/变异、未写tracked或任务状态。本报告作者只负责准备，最终由oracle_review独立验收。','', '已核归档SK02的215个旧ID：32项恢复+T49–T57既有183项恰好215，unique=215、无重/漏/外项，185动态记录、21限定静态、9结构验证。全部旧stage1标签仍为MissedMutant；不等于185个旧候选Caught或215旧原生全部执行。','', '## 32 项取证选择','', '| 来源 | 旧ID数 | 正式最后采用运行 | 冻结源依据 |','|---|---:|---|---|','| T48 G01 | 19 | mutation-g01-final | base d27816b + selection127 SHA；最终19/19源稳定 |','| T43 G10 readonly | 1 | mutation-groups/G10 | base06e5a91 + selection126；首次实际Caught |','| T47 Store/asset | 6 | mutation-oracle-check | base06e5a91 + 当时126项源；前6项保留，不冒充child修后重跑 |','| T47 child | 4 | mutation-cleanup-check | base06e5a91 + 另一126项源；RAII/scoped清理后4项重验 |','| G10 schema | 2 | mutation-t43-schema-current | 当前base4bf9f872 + 完整190源；2/2实际Caught，独审/正式归档待绑定 |','', '13=G10六项+G11三项+G12四项；19=G01。最早schema sample仅有raw/console，没有selection/candidate/source闭包，保留历史Caught但不承担当前资格。String::new是旧215外第三样本，排除。根agent已在同当前冻结190输入重验指定两项，本报告仅读取结果，不自批。','', 'T47档案t47-oracles.tar.gz及111成员、T48档案t48-g01-oracles.tar.gz及160成员已逐SHA回读；与tmp对应selection/outcomes一致。每项原stage1的metadata/outcomes/log在固定归档Git对象e54dcd41...核对，候选95d78e、execution closure及source/diff SHA详见JSON；历史产品候选e3eea89单列，不把两种身份混成新执行。','', '## 逐旧 ID 的实际日志入口','', '完整当前/旧ID、old/current diff SHA、oldstage1来源、实际build/test argv、失败测试、log SHA、selection/source与archive member都在JSON。以下给32项最小导航：','', '| 组 | 旧ID | 采用run | log member/path |','|---|---|---|---|']
for x in restored:lines.append('| '+x['group']+' | `'+x['old_id']+'` | '+x['run_ref']+' | `'+x['log_member_or_path']+'` |')
lines+=['','## 闭包差异与当前候选复核','','同base、命令或filter不能表示同输入。T47三个126源分别有旧测试、新增oracle、修后child RAII版本，selfmgmt整体SHA分别b259.../0113.../b79d...；只保留前6同目标/同oracle的原运行，4child用修后新运行。T48起始17source漂移记录不能升级，最终同19冻结运行才是证据。','', 'JSON的run_closures逐一保留完整源清单，并列latest_changed_inputs。这是字节差异清单，不是复用批准。Store/snapshot/service纯目标即使自身不变，真实consumer还经过Root/Store/当前恢复：最终review需要核改动的调用链是否改变拒绝前提、诊断/副作用、原件/原响应资格与测试窗口，不把整仓旧run套最新HEAD。','','重点回看T50–T57：fsx/pending/effects观察点与类型/身份接线；T53真实digest/UTF8缺陷修复；T55 directory_has_identity/sole_directory_exists结构归一；T56失败创建补偿/owner sync模型；T57故障生命周期与envfallback。21静态证明依赖当前完整producer/caller及不可变值支配，需最新源再次核成立。9结构验证是旧target已移除后的当前机制/wiring/caller闭包，旧native未执行/caught=false保持；9个新机制mutant不是9个旧native执行。','','## 待收尾边界','','T57五个raw Caught已有记录，但按本任务范围最终独审尚待绑定；正式baseline自动裁剪到runtime2，mutation阶段才加入CLI形成5，不得把补充非变异5/对照5重写成formal5。当前schema两项2/2也须archive+190 selection+独审绑定。185是证据分类预期，尚不授权T43 done/PASS。','','T55结构条目的mapping/current_target残留“pending”措辞与最终verified proof不同；最终账本应指向明确新状态/最终证明，源旧账本保留。T57继承preparation_status=not_run与后续execution动态Caught属于不同阶段，最终字段不要混淆。','','最终汇总应写 current input disposal_complete 的准确限定资格，不改变旧stage1/SK02暂停、不批准旧e3eea89、不称全原生215或旧M1/M2/全平台/全安全/产品完成。当前全工程/最终用户闭环必须绑定其自己的新候选及run，不能从这些分组计数推导。','','本准备不重做183项独审，也不替oracle_review批准这些范围；其真实log/archive/proof账本SHA入口统一保留在JSON。']
(p/'t43-final-assembly-directions.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'restored':len(restored),'existing':len(existing),'unique':len(set(allids)),'counts':counts,'archive_verified':archive_audit,'schema_current_caught':2,'schema_acceptance':'pending','T57_acceptance':'pending','approval':False,'outputs':[str(p/'t43-final-assembly-directions.md'),str(p/'t43-final-assembly-directions.json')]},ensure_ascii=False,indent=2))
