from pathlib import Path
import json,subprocess,difflib,hashlib,collections
r=Path('/private/tmp/sheltie-completion-20261003');prep=json.loads((r/'t43-final-assembly-directions.json').read_text());oldmap={x['old_id']:x for x in json.loads((r/'independent-sk02-mapping.json').read_text())['all_correspondences']};oldinv={x['name']:x for x in json.loads((r/'current-runtime-mutants.json').read_text())};cur=json.loads((r/'t57-current-mutants.json').read_text());structural={x['old_id'] for x in prep['existing183'] if x['category']=='structural'};sources={x['file']:Path(x['file']).read_bytes() for x in cur};line_maps={}
for f,b in sources.items():
 old=subprocess.check_output(['git','show','63b05ca:'+f],text=True).splitlines();new=b.decode().splitlines();line_maps[f]={}
 for a,c,count in difflib.SequenceMatcher(None,old,new,autojunk=False).get_matching_blocks():
  for k in range(count):line_maps[f][a+k+1]=c+k+1
rows=[];issues=[]
for record in prep['unique215_index']:
 oid=record['old_id'];x={'old_id':oid,'category':record['category'],'old_stage1':'MissedMutant'}
 if oid in structural:x.update(current_id=None,current_binding='removed old syntax; current T55 private pure mechanism/wiring/caller and actual new-mechanism execution verified; original native not_run preserved')
 else:
  o=oldinv[oldmap[oid]['current_id']];f=o['file'];sp=o['span']['start'];line=line_maps[f].get(sp['line']);fn=(o.get('function') or {}).get('function_name');expected='rendezvous_payload' if fn=='rendezvous' and f.endswith('/failpoint.rs') else fn
  choices=[c for c in cur if c['file']==f and c['genre']==o['genre'] and c['replacement']==o['replacement'] and c['span']['start']=={'line':line,'column':sp['column']} and (c.get('function') or {}).get('function_name')==expected]
  if len(choices)!=1:issues.append({'old_id':oid,'expected_line':line,'choice_count':len(choices)});continue
  c=choices[0];x.update(current_id=c['name'],latest_diff_sha256=hashlib.sha256(c['diff'].encode()).hexdigest(),latest_source_sha256=hashlib.sha256(sources[f]).hexdigest(),current_binding='exact expression/function/column/genre/replacement in latest inventory; mapping does not execute or reuse older candidate results')
 rows.append(x)
print('mapped',len(rows),'issues',issues);assert not issues and len(rows)==215 and len({x['current_id'] for x in rows if x['current_id']})==206
(r/'t43-latest215-binding.json').write_text(json.dumps({'candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'latest_inventory_sha256':hashlib.sha256((r/'t57-current-mutants.json').read_bytes()).hexdigest(),'items':rows,'mapping_only_no_new_PASS':True},indent=2)+'\n')
