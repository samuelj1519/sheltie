from pathlib import Path
import json,hashlib,re,collections
r=Path('/private/tmp/sheltie-completion-20261003');ev=Path('specs/changes/active/C002-v0.2.0-reliability/evidence/completion-20261003');x=json.loads((r/'t43-215-ledger-draft.json').read_text());by_latest={row['latest_mapping']['current_id']:row for row in x['items'] if row['latest_mapping']['current_id']};updates=[];baseline_counts={}
for batch,expected in [('g01-a',12),('g01-b',7),('early11',11)]:
 d=r/('mutation-t43-current-'+batch);result=json.loads((d/'result.json').read_text());assert result['exit_code']==0 and result['source_unchanged'] and result['counts']['CaughtMutant']==expected
 outs=json.loads((d/'mutants.out/outcomes.json').read_text())['outcomes']
 for o in outs:
  p=d/'mutants.out'/o['log_path'];txt=p.read_text()
  if not isinstance(o['scenario'],dict):
   assert o['summary']=='Success';m=re.search(r'Starting\s+(\d+) tests',txt);assert m;baseline_counts[batch]=int(m.group(1));continue
  cid=o['scenario']['Mutant']['name'];row=by_latest[cid];assert row['category']=='dynamic';fails=re.findall(r'^\s*FAIL \[.*?\] \(.*?\) (.+)$',txt,re.M);assert fails
  row['historical_early_execution_record']=row.pop('frozen_execution_record');row['current_execution_record']={'batch':batch,'current_id':cid,'result':'CaughtMutant','phase_results':o['phase_results'],'log':str(p.relative_to(r)),'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'failing_tests':sorted(set(fails)),'selection':str((d/'selection.json').relative_to(r)),'source_closure_count':190,'elapsed_batch_seconds':result['elapsed_seconds'],'dispatch_six_keys':'unknown/notrecorded' if batch=='g01-a' else json.loads((d/'dispatch-env.json').read_text())['six_relevant_keys']};row['scoped_independent_acceptance']='current30 raw reviewed; final T43 binding pending';updates.append(row['old_id'])
assert len(updates)==len(set(updates))==30
x['current30_rechecks']={'old_ids':updates,'baseline_counts':baseline_counts,'controls':'g01 filter exactCLI/runtime7 (both A/B); early filter exactCLI/runtime43; formal counts remain separate','unknown_early_environment_retained':True};x['assembly_approval']='pending final independent T43 review';x['qualification_boundaries']='185 dynamic records=37 current execution (30 rechecks+schema2+T57 five) plus148 group-frozen exact executions+currentcaller/delta review;21static and9structural separate;no185latestreexecution/no215oldnativeclaim'
(ev/'t43-215-dispositions.json').write_text(json.dumps(x,indent=2)+'\n');print('Current30 bound',baseline_counts,'unique215 categories',x['counts'])
