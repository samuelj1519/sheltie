# T43 最终汇总准备（不授 PASS）

只读恢复精确证据，未运行Cargo/变异、未写tracked或任务状态。本报告作者只负责准备，最终由oracle_review独立验收。

已核归档SK02的215个旧ID：32项恢复+T49–T57既有183项恰好215，unique=215、无重/漏/外项，185动态记录、21限定静态、9结构验证。全部旧stage1标签仍为MissedMutant；不等于185个旧候选Caught或215旧原生全部执行。

## 32 项取证选择

| 来源 | 旧ID数 | 正式最后采用运行 | 冻结源依据 |
|---|---:|---|---|
| T48 G01 | 19 | mutation-g01-final | base d27816b + selection127 SHA；最终19/19源稳定 |
| T43 G10 readonly | 1 | mutation-groups/G10 | base06e5a91 + selection126；首次实际Caught |
| T47 Store/asset | 6 | mutation-oracle-check | base06e5a91 + 当时126项源；前6项保留，不冒充child修后重跑 |
| T47 child | 4 | mutation-cleanup-check | base06e5a91 + 另一126项源；RAII/scoped清理后4项重验 |
| G10 schema | 2 | mutation-t43-schema-current | 当前base4bf9f872 + 完整190源；2/2实际Caught，独审/正式归档待绑定 |

13=G10六项+G11三项+G12四项；19=G01。最早schema sample仅有raw/console，没有selection/candidate/source闭包，保留历史Caught但不承担当前资格。String::new是旧215外第三样本，排除。根agent已在同当前冻结190输入重验指定两项，本报告仅读取结果，不自批。

T47档案t47-oracles.tar.gz及111成员、T48档案t48-g01-oracles.tar.gz及160成员已逐SHA回读；与tmp对应selection/outcomes一致。每项原stage1的metadata/outcomes/log在固定归档Git对象e54dcd41...核对，候选95d78e、execution closure及source/diff SHA详见JSON；历史产品候选e3eea89单列，不把两种身份混成新执行。

## 逐旧 ID 的实际日志入口

完整当前/旧ID、old/current diff SHA、oldstage1来源、实际build/test argv、失败测试、log SHA、selection/source与archive member都在JSON。以下给32项最小导航：

| 组 | 旧ID | 采用run | log member/path |
|---|---|---|---|
| G01 | `crates/sheltie-runtime/src/effects.rs:151:21: replace || with && in check_work_effects` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__effects.rs_line_153_col_21.log` |
| G01 | `crates/sheltie-runtime/src/effects.rs:150:21: replace || with && in check_work_effects` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__effects.rs_line_152_col_21.log` |
| G01 | `crates/sheltie-runtime/src/effects.rs:149:21: replace || with && in check_work_effects` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__effects.rs_line_151_col_21.log` |
| G01 | `crates/sheltie-runtime/src/effects.rs:159:21: replace || with && in check_work_effects` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__effects.rs_line_161_col_21.log` |
| G01 | `crates/sheltie-runtime/src/effects.rs:158:21: replace || with && in check_work_effects` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__effects.rs_line_160_col_21.log` |
| G01 | `crates/sheltie-runtime/src/effects.rs:157:21: replace || with && in check_work_effects` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__effects.rs_line_159_col_21.log` |
| G01 | `crates/sheltie-runtime/src/effects.rs:156:21: replace || with && in check_work_effects` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__effects.rs_line_158_col_21.log` |
| G01 | `crates/sheltie-runtime/src/load.rs:190:33: replace match guard !declaration.required() with true in validate_work_paths` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__load.rs_line_248_col_33.log` |
| G01 | `crates/sheltie-runtime/src/load.rs:294:5: replace require_path -> Result<()> with Ok(())` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__load.rs_line_352_col_5.log` |
| G11 | `crates/sheltie-runtime/src/selfmgmt.rs:493:9: replace || with && in checked_asset_name` | mutation-oracle-check | `mutation-oracle-check/mutants.out/log/crates__sheltie-runtime__src__selfmgmt.rs_line_493_col_9.log` |
| G11 | `crates/sheltie-runtime/src/selfmgmt.rs:490:9: replace || with && in checked_asset_name` | mutation-oracle-check | `mutation-oracle-check/mutants.out/log/crates__sheltie-runtime__src__selfmgmt.rs_line_490_col_9.log` |
| G11 | `crates/sheltie-runtime/src/selfmgmt.rs:489:9: replace || with && in checked_asset_name` | mutation-oracle-check | `mutation-oracle-check/mutants.out/log/crates__sheltie-runtime__src__selfmgmt.rs_line_489_col_9.log` |
| G12 | `crates/sheltie-runtime/src/selfmgmt.rs:838:24: replace > with < in wait_bounded_child` | mutation-cleanup-check | `mutation-cleanup-check/mutants.out/log/crates__sheltie-runtime__src__selfmgmt.rs_line_838_col_24.log` |
| G12 | `crates/sheltie-runtime/src/selfmgmt.rs:838:24: replace > with >= in wait_bounded_child` | mutation-cleanup-check | `mutation-cleanup-check/mutants.out/log/crates__sheltie-runtime__src__selfmgmt.rs_line_838_col_24_001.log` |
| G12 | `crates/sheltie-runtime/src/selfmgmt.rs:855:24: replace > with < in wait_bounded_child` | mutation-cleanup-check | `mutation-cleanup-check/mutants.out/log/crates__sheltie-runtime__src__selfmgmt.rs_line_855_col_24.log` |
| G12 | `crates/sheltie-runtime/src/selfmgmt.rs:855:24: replace > with >= in wait_bounded_child` | mutation-cleanup-check | `mutation-cleanup-check/mutants.out/log/crates__sheltie-runtime__src__selfmgmt.rs_line_855_col_24_001.log` |
| G01 | `crates/sheltie-runtime/src/service.rs:1191:17: replace && with || in validate_command_owner` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__service.rs_line_1533_col_17.log` |
| G01 | `crates/sheltie-runtime/src/service.rs:1241:17: replace && with || in validate_command_owner` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__service.rs_line_1663_col_17.log` |
| G01 | `crates/sheltie-runtime/src/service.rs:1240:17: replace && with || in validate_command_owner` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__service.rs_line_1662_col_17.log` |
| G01 | `crates/sheltie-runtime/src/service.rs:1251:17: replace && with || in validate_command_owner` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__service.rs_line_1673_col_17.log` |
| G01 | `crates/sheltie-runtime/src/snapshot.rs:142:17: replace && with || in check_data` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__snapshot.rs_line_160_col_17.log` |
| G01 | `crates/sheltie-runtime/src/snapshot.rs:141:17: replace && with || in check_data` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__snapshot.rs_line_159_col_17.log` |
| G10 | `crates/sheltie-runtime/src/store/mod.rs:32:5: replace validate_readonly -> Result<()> with Ok(())` | mutation-groups/G10 | `mutation-groups/G10/mutants.out/log/crates__sheltie-runtime__src__store__mod.rs_line_32_col_5.log` |
| G10 | `crates/sheltie-runtime/src/store/mod.rs:334:9: replace Store::validate -> Result<()> with Ok(())` | mutation-oracle-check | `mutation-oracle-check/mutants.out/log/crates__sheltie-runtime__src__store__mod.rs_line_334_col_9.log` |
| G10 | `crates/sheltie-runtime/src/store/commit.rs:129:50: replace > with >= in Store::commit` | mutation-oracle-check | `mutation-oracle-check/mutants.out/log/crates__sheltie-runtime__src__store__commit.rs_line_129_col_50.log` |
| G10 | `crates/sheltie-runtime/src/store/commit.rs:183:24: replace match guard code.code == rusqlite::ErrorCode::ConstraintViolation with true in Store::commit` | mutation-oracle-check | `mutation-oracle-check/mutants.out/log/crates__sheltie-runtime__src__store__commit.rs_line_183_col_24.log` |
| G01 | `crates/sheltie-runtime/src/store/read.rs:40:9: replace RequestMetadata::check_row -> Result<()> with Ok(())` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__store__read.rs_line_40_col_9.log` |
| G01 | `crates/sheltie-runtime/src/store/read.rs:43:13: replace || with && in RequestMetadata::check_row` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__store__read.rs_line_43_col_13.log` |
| G01 | `crates/sheltie-runtime/src/store/read.rs:42:13: replace || with && in RequestMetadata::check_row` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__store__read.rs_line_42_col_13.log` |
| G01 | `crates/sheltie-runtime/src/store/read.rs:41:13: replace || with && in RequestMetadata::check_row` | mutation-g01-final | `mutation-g01-final/mutants.out/log/crates__sheltie-runtime__src__store__read.rs_line_41_col_13.log` |
| G10 | `crates/sheltie-runtime/src/store/schema.rs:82:5: replace normalize_sql -> String with "xyzzy".into()` | mutation-t43-schema-current | `/private/tmp/sheltie-completion-20261003/mutation-t43-schema-current/mutants.out/log/crates__sheltie-runtime__src__store__schema.rs_line_82_col_5.log` |
| G10 | `crates/sheltie-runtime/src/store/schema.rs:82:28: delete ! in normalize_sql` | mutation-t43-schema-current | `/private/tmp/sheltie-completion-20261003/mutation-t43-schema-current/mutants.out/log/crates__sheltie-runtime__src__store__schema.rs_line_82_col_28.log` |

## 闭包差异与当前候选复核

额外精确差异：G01旧 `load.rs:294:5 require_path→Ok` 的最终raw diff SHA为 `c80fb47cb8a0b29d8469e7c2c4cf19eed796c52cc9c92a3ea0ec1afc3e026bc3`，早期对应库存SHA为 `40f17c738349f0ea351e69e6ec0e9281805293c2734eaea28b5cc6dcfacb28a8`。测试模块追加改变周围hunk上下文；两者完整删除/替换行逐字相同，JSON保留两个SHA，不用早期库存SHA冒充正式raw。

同base、命令或filter不能表示同输入。T47三个126源分别有旧测试、新增oracle、修后child RAII版本，selfmgmt整体SHA分别b259.../0113.../b79d...；只保留前6同目标/同oracle的原运行，4child用修后新运行。T48起始17source漂移记录不能升级，最终同19冻结运行才是证据。

JSON的run_closures逐一保留完整源清单，并列latest_changed_inputs。这是字节差异清单，不是复用批准。Store/snapshot/service纯目标即使自身不变，真实consumer还经过Root/Store/当前恢复：最终review需要核改动的调用链是否改变拒绝前提、诊断/副作用、原件/原响应资格与测试窗口，不把整仓旧run套最新HEAD。

重点回看T50–T57：fsx/pending/effects观察点与类型/身份接线；T53真实digest/UTF8缺陷修复；T55 directory_has_identity/sole_directory_exists结构归一；T56失败创建补偿/owner sync模型；T57故障生命周期与envfallback。21静态证明依赖当前完整producer/caller及不可变值支配，需最新源再次核成立。9结构验证是旧target已移除后的当前机制/wiring/caller闭包，旧native未执行/caught=false保持；9个新机制mutant不是9个旧native执行。

## 待收尾边界

T57五个raw Caught已有记录，但按本任务范围最终独审尚待绑定；正式baseline自动裁剪到runtime2，mutation阶段才加入CLI形成5，不得把补充非变异5/对照5重写成formal5。当前schema两项2/2也须archive+190 selection+独审绑定。185是证据分类预期，尚不授权T43 done/PASS。

T55结构条目的mapping/current_target残留“pending”措辞与最终verified proof不同；最终账本应指向明确新状态/最终证明，源旧账本保留。T57继承preparation_status=not_run与后续execution动态Caught属于不同阶段，最终字段不要混淆。

最终汇总应写 current input disposal_complete 的准确限定资格，不改变旧stage1/SK02暂停、不批准旧e3eea89、不称全原生215或旧M1/M2/全平台/全安全/产品完成。当前全工程/最终用户闭环必须绑定其自己的新候选及run，不能从这些分组计数推导。

本准备不重做183项独审，也不替oracle_review批准这些范围；其真实log/archive/proof账本SHA入口统一保留在JSON。
