
#[cfg(all(test, feature = "failpoint"))]
mod synchronization_origin_contract_tests {
    use super::*;

    // Task: C002-T54
    #[test]
    fn synchronizing_a_current_root_handle_preserves_its_original_and_all_names() {
        let directory = tempfile::tempdir().unwrap();
        let root = directory.path().join("home");
        let home = crate::Home::resolve(Some(root.to_str().unwrap())).unwrap();
        let lock = home.acquire_lock().unwrap();
        let fs = ManagedFs::open_existing(&home).unwrap();
        let rel = ManagedRelPath::new("original").unwrap();
        fs.write_new(&lock, &rel, b"legitimate original bytes").unwrap();
        let observed = fs.open_regular(&rel).unwrap();
        let path = home.rel("original").unwrap();
        let before = std::fs::metadata(path.as_path()).unwrap();
        fs.sync_regular_file_handle_locked(&lock, &rel, &observed).unwrap();
        let after = std::fs::metadata(path.as_path()).unwrap();
        assert_eq!(std::fs::read(path.as_path()).unwrap(), b"legitimate original bytes");
        assert_eq!((after.dev(), after.ino(), after.mode(), after.nlink()), (before.dev(), before.ino(), before.mode(), before.nlink()));
        assert!(!home.store_path().as_path().exists());
    }

    // Task: C002-T54
    #[test]
    fn an_old_root_epoch_cannot_authorize_synchronizing_the_same_transplanted_object() {
        let directory = tempfile::tempdir().unwrap();
        let root = directory.path().join("home");
        let home = crate::Home::resolve(Some(root.to_str().unwrap())).unwrap();
        let old_lock = home.acquire_lock().unwrap();
        let old_fs = ManagedFs::open_existing(&home).unwrap();
        let rel = ManagedRelPath::new("original").unwrap();
        old_fs.write_new(&old_lock, &rel, b"held original bytes").unwrap();
        let observed = old_fs.open_regular(&rel).unwrap();
        let path = home.rel("original").unwrap();
        let before = std::fs::metadata(path.as_path()).unwrap();
        let old_root = directory.path().join("retained-home");
        let old_root_metadata = std::fs::metadata(&root).unwrap();
        std::fs::rename(&root, &old_root).unwrap();
        let new_lock = home.acquire_lock().unwrap();
        let new_fs = ManagedFs::open_existing(&home).unwrap();
        let new_root_metadata = std::fs::metadata(&root).unwrap();
        assert_eq!(old_root_metadata.dev(), new_root_metadata.dev());
        assert_ne!(old_root_metadata.ino(), new_root_metadata.ino());
        std::fs::rename(old_root.join("original"), path.as_path()).unwrap();
        let Error::InvalidRequest { reason } = new_fs.sync_regular_file_handle_locked(&new_lock, &rel, &observed).unwrap_err() else {
            panic!("a stale managed origin must be refused before synchronizing")
        };
        assert!(reason.contains("文件句柄身份与同步路径不一致"), "{reason}");
        let after = std::fs::metadata(path.as_path()).unwrap();
        assert_eq!(std::fs::read(path.as_path()).unwrap(), b"held original bytes");
        assert_eq!((after.dev(), after.ino(), after.mode(), after.nlink()), (before.dev(), before.ino(), before.mode(), before.nlink()));
        assert!(old_root.join(".lock").is_file());
        assert!(!home.store_path().as_path().exists());
    }
}
