
fn limit_attempt_fixture() -> (OwnedTempDir, Home, WorkService, WorkId, PathBuf) {
    let (directory, home) = temp_home();
    let source = directory.path().join("limit-source");
    std::fs::create_dir_all(source.join("flows")).unwrap();
    std::fs::write(source.join("workbook.toml"), "schema='workbook/v1'\nid='limit-fixture'\nversion='1.0.0'\nname='Limit'\nflows=['flows/default.toml']\n").unwrap();
    std::fs::write(source.join("flows/default.toml"), "schema='flow/v1'\nid='default'\nentry='finish'\n[[nodes]]\nid='finish'\ntitle='Finish'\nexecutor='agent'\ninstruction={text='Write the output.'}\noutputs=[{name='payload',path='payload.bin',result=true,max_bytes=33554432}]\n").unwrap();
    repo(&home).add(&abs(&source), None).unwrap();
    let service = common::service(&home);
    let work = work_id_of(&service.start(StartArgs {
        workbook_id: "limit-fixture".into(), version: None, flow: "default".into(), name: None, inputs: inputs_lit(&[]),
    }, None).unwrap());
    let begun = service.begin(&work, &NodeId::new("finish").unwrap(), None).unwrap();
    let output = PathBuf::from(output_dir_of(&begun).join_segment("payload.bin").as_str());
    (directory, home, service, work, output)
}

// Task: C002-T54
#[test]
fn submission_accepts_the_actual_output_limit_and_refuses_one_more_byte_before_commit() {
    use std::os::unix::fs::MetadataExt as _;
    use sheltie_core::ErrorCode;
    for bytes in [33_554_432_u64, 33_554_433] {
        let (_directory, home, service, work, path) = limit_attempt_fixture();
        let file = std::fs::File::create(&path).unwrap();
        file.set_len(bytes).unwrap();
        let before_file = file.metadata().unwrap();
        let connection = rusqlite::Connection::open(home.store_path().as_str()).unwrap();
        let before_rows = store_rows(&connection);
        let result = service.submit(&work, &AttemptId::parse("finish#1.0").unwrap(), &lit("done"), Some("limit-submit".into()));
        let after_file = std::fs::metadata(&path).unwrap();
        assert_eq!((after_file.dev(), after_file.ino(), after_file.nlink(), after_file.len()), (before_file.dev(), before_file.ino(), 1, bytes));
        if bytes == 33_554_432 {
            let response = result.unwrap();
            assert_eq!(response.revision, Some(3));
            assert!(!response.replayed);
            assert_eq!(after_file.mode() & 0o777, 0o444);
            let state: String = connection.query_row("SELECT state_json FROM works WHERE work_id=?1", [work.as_str()], |row| row.get(0)).unwrap();
            let state: serde_json::Value = serde_json::from_str(&state).unwrap();
            let reference = &state["attempts"][0]["outputs"]["payload"];
            assert_eq!(reference["bytes"], 33_554_432);
            assert_eq!(reference["sha256"], "83ee47245398adee79bd9c0a8bc57b821e92aba10f5f9ade8a5d1fae4d8c4302");
            assert_eq!(reference["path"], path.to_str().unwrap());
            assert_eq!(connection.query_row::<i64,_,_>("SELECT published FROM requests WHERE request_id='limit-submit'", [], |row| row.get(0)).unwrap(), 1);
            assert_eq!(connection.query_row::<i64,_,_>("SELECT count(*) FROM audit WHERE request_id='limit-submit' AND revision=3", [], |row| row.get(0)).unwrap(), 1);
        } else {
            let error = result.unwrap_err();
            assert_eq!(error.code(), ErrorCode::OutputTooLarge);
            assert!(matches!(error, sheltie_runtime::Error::Core(sheltie_core::Error::OutputTooLarge { max_bytes: 33_554_432, actual: 33_554_433, .. })));
            assert_eq!(store_rows(&connection), before_rows);
            assert_eq!(after_file.mode(), before_file.mode());
            assert_eq!(connection.query_row::<i64,_,_>("SELECT count(*) FROM requests WHERE request_id='limit-submit'", [], |row| row.get(0)).unwrap(), 0);
        }
    }
}

// Task: C002-T54
#[cfg(feature = "failpoint")]
#[test]
fn a_restored_output_cannot_erase_the_bad_length_already_observed_during_sealing() {
    use std::os::unix::fs::MetadataExt as _;
    use std::time::{Duration, Instant};
    let (_directory, home, service, work, path) = limit_attempt_fixture();
    std::fs::write(&path, b"data").unwrap();
    let original_file = std::fs::metadata(&path).unwrap();
    let before_seal = tempfile::tempdir().unwrap();
    let after_stat = tempfile::tempdir().unwrap();
    sheltie_runtime::failpoint::arm_rendezvous("submit_after_commit_before_seal", "seal-growth", before_seal.path()).unwrap();
    let writer = service.clone();
    let writer_work = work.clone();
    let worker = std::thread::spawn(move || writer.submit(&writer_work, &AttemptId::parse("finish#1.0").unwrap(), &lit("done"), Some("seal-growth".into())));
    let mut worker = RendezvousWorker::new(worker, before_seal.path(), after_stat.path());
    worker.wait("submit did not reach its actual committed pre-seal window");
    let connection = rusqlite::Connection::open(home.store_path().as_str()).unwrap();
    let before_rows = store_rows(&connection);
    let snapshot: String = connection.query_row("SELECT snapshot_json FROM requests WHERE request_id='seal-growth'", [], |row| row.get(0)).unwrap();
    let expected_snapshot: serde_json::Value = serde_json::from_str(&snapshot).unwrap();
    std::fs::OpenOptions::new().append(true).open(&path).unwrap().write_all(b"+").unwrap();
    assert_eq!(std::fs::metadata(&path).unwrap().len(), 5);
    sheltie_runtime::failpoint::arm_rendezvous("seal_reference_after_stat", path.to_str().unwrap(), after_stat.path()).unwrap();
    std::fs::write(before_seal.path().join("release"), b"release committed submit").unwrap();
    let deadline = Instant::now() + Duration::from_secs(10);
    while !after_stat.path().join("reached").exists() {
        assert!(Instant::now() < deadline, "seal did not capture the grown file before comparison");
        std::thread::sleep(Duration::from_millis(2));
    }
    std::fs::write(&path, b"data").unwrap();
    let error = worker.finish().unwrap().unwrap_err();
    let original = assert_effect_pending(error, true, Some("seal-growth"), None);
    assert_eq!(original, expected_snapshot);
    assert_eq!(store_rows(&connection), before_rows);
    assert_eq!(std::fs::read(&path).unwrap(), b"data");
    let after = std::fs::metadata(&path).unwrap();
    assert_eq!((after.dev(), after.ino(), after.mode(), after.nlink(), after.len()), (original_file.dev(), original_file.ino(), original_file.mode(), original_file.nlink(), 4));
    assert_eq!(connection.query_row::<i64,_,_>("SELECT published FROM requests WHERE request_id='seal-growth'", [], |row| row.get(0)).unwrap(), 0);
}
