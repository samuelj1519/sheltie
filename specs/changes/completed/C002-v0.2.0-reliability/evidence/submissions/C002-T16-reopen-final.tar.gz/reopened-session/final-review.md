# C002-T16 真实批准与最终宿主场景独立审查

Reviewer：`Codex /root/t16_reopen_review`。未参与本轮用户决定记录、CLI 操作、worker、项目实现或 package 文档修改；只读复核实际批准、四份新 CLI 原文、只读 Store/audit/request 及待批准档案。仅新写本文，保留 `independent-review.md` 的批准前结论，不修改仓库或 home，不调用写 CLI、审批、提交或完整测试。

结论：**通过，范围限定为 C002-T16 计划要求的本机真实宿主场景。** Work003 已经得到具体用户批准并通过实际 CLI gate 结束；上一报告的实际阻断项已消除。结合既有独立阶段审查与本轮 Work006 真实重开续接，未发现仍缺的必需场景或真实人工动作，可以更新 T16 完成状态并执行正式任务门禁。该结论不预判尚未运行的完成门禁或尚未生成的最终档案，也不构成提交或发布授权。

## 真实批准与 CLI 结果

- `work003-gate-approval.json` 保存实际问题与用户原话「批准 Work003 最终 retro gate」，来源为 `request_user_input_async`，questionItemId 为 `["request_user_input_async","call_9adT9sBMUpCj2TLfgsz6HIRz",0]`。问题明确是批准 Work003 的交付与反思、结束本地演练，保留 usage/完整变异/Linux 限制且不授权发布。批准发生在两份实际产物已展示后，不能扩大为所有 C002 或外部动作批准。
- `commands/reopened-work003-before-approve` 是收到批准后新的实际 CLI status，exit 0，仍 blocked(gate: retro)，next 只有 approve/cancel。协调者以该当前状态继续，没有从旧回复取 next。
- `reopened-work003-approve-retro` 实际调用本轮同一隔离 home 与原交付二进制，request-id `43e1101f-7a1b-4862-b776-2c505c9e15fb`；exit 0、revision 40、`replayed=false`、Work succeeded、next 空，时间 `2026-10-02T14:31:09Z`。四份命令的 argv、stdout/stderr、退出码、耗时齐全，实际 stdout/stderr SHA256 全部匹配 result.json。
- `reopened-work003-final-status` exit 0、succeeded、blocked=null、next 空；`reopened-work003-final-stats` exit 0、succeeded、approvals=1、blocked_count=1、total_seconds=8896。未走的 fix 分支仍列于 pending 是 Flow 访问事实，不是 next 或失败状态；不能因为该列表仍有 fix 判 Work 未结束。Work/Attempt 耗时包含真人等待，不是模型计量。
- 独立 SQLite 仅以只读 URI 交叉核证：works 为 revision 40/succeeded，audit 的该 request-id 为 `approve_gate/retro`、revision 40、principal shushu、同一时间；requests 已 published=1，原响应 revision/status/next 与 CLI 一致。这一核证没有作为协调者续接状态入口，OS principal 也不证明独立真人认证。

## 待批准历史档案

`C002-T16-reopen-pending.tar.gz` 实际 59043 bytes、SHA256 `f7dae68baa8ea8e1c9acc5ad003f8187e84b5c334f2ae7e14bccebec7f2bf72d`，与 README 一致。69 个普通文件全部与本机对应来源逐字相同，无缺失、逃逸路径或链接。档案实际含用户重开陈述、9 份 reopened 请求响应、Work006 brief/产物、ArtifactRef oracle、批准前独立报告及 docs/specs/diff/task 原文；task gate exit 1 与 T16 doing 是当时事实。

该档案没有本轮后来的批准、approve CLI 或本文，不能以批准后成功改写其历史完成边界。它不含完整管理根或二进制，只用于核证据，不作为运行 home。最终批准阶段应另封存原文和本文，再核实际 hash、内容与 package 引用。

## T16 必需场景与完成资格

按 plan §5，既有阶段加本轮已覆盖未指定/未安装 Workbook、缺输入的真实交互及已给信息不重复询问；真实 two-step、受控 article-review back、gated-release 与真人复制/批准；错误后恢复及真实关闭重开后只从新 CLI 查询继续；spec-dev 四任务、人工条件、实际改方案、原始基线与已验证前缀、最终完整原始需求；实际 Finder 与完整性、逐命令原文、产物摘要、绝对耗时及质量观察。F16-01 是已观察到的说明缺陷，源码 Workbook 0.2.1 修复、真实 brief producer 与修复后的完整 688/688、5/5 及工程门禁已分别核实；旧冻结 Work003 0.2.0 和历史 brief 保留。

本轮五类场景验收有限通过。完成状态和提交门禁仍需更新记录后实际运行，最终证据仍需封存核字节；若任一失败，保存真实 FAIL 并处理，不以本文预先记 PASS。正式 gate 及最终档案待后续独立补核，无需因本轮批准复跑没有变化的完整源码/测试输入。

## 必须保留的范围

回归对象是绑定源码 `82c6c55159592db5cdb485549e933960863de185` 的本机 0.1.0 身份二进制、T16 已记录的 Workbook 文案修复、独立 home 和当前 Codex。不能称为已发布 v0.2.0、具有新版本身份的 rc、四平台资产或所有 Host 资格。新 Workbook 0.2.1 不改变引擎版本，真实开发 Work 仍冻结 0.2.0。

用户直接陈述支持本轮真实重开，手动 skill 加载支持已执行其规则；二者不证明自动 skill 发现或独立窗口/进程认证。usage 明确缺失/null，允许按计划如实保留，不能写 0。没有同任务对照，不宣称成本、调用量或质量收益。

旧 M1/SK01/SK02、215 项额外变异、Linux及完整安全/变异验证缺失保持原记录；本轮没有补这些结论。T17 仍 not_run，实际四平台资产与同 SHA 质量、远端指定版本更新/rollback和对外发布均未由此次 gate 批准授权。管理根未清理，提交、推送、发布和宿主安装都需各自现有或新增的明确授权。
