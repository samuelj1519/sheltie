# v0.2.0 release record 草稿

状态：`candidate; not published`
版本：`0.2.0`
Git tag：未创建
Release commit：待候选提交固定
T16 验收闭包：`785552be4fddc8fbbbcbffef7bcf69e65588ff8f`

## 范围

纳入 C002 可靠性修复，版本采用 schema 2、workbook-digest/v2、cli-result/v2 和新的 Attempt 目录。spec-dev 0.2.1 修复反思目录说明。旧 schema 1 数据保持原样，旧 binary 配旧 home 读取；binary rollback 不等于 Store 降级。

## 当前验收

本机 v0.2.0 release binary 与隔离安装正在实际验证。四平台包、manifest/checksum 和同 SHA 质量尚待真实 CI，不用 dist plan 成功代替资产存在。指定版本远端 update/rollback 尚未运行。正式发布授权与实际发布均未取得，不登记 released 或迁移 completed。

## 已知限制

M1 已按实际授权的 SK01/SK02 范围完成；最终 Spec 批准、215 项额外执行及历史 Linux 原生运行缺失，不记完整变异或安全 PASS。T16 当前 Codex 本机场景通过，usage 缺失，手动 skill 不证明自动发现，真实重开来源为用户陈述，没有成本收益对照。

## 正式收尾要求

取得四平台实物与同 SHA 质量，独立核资产、候选和实际安装；展示材料后取得外部发布授权。真实 tag/release 成功，再验证指定远端更新与rollback，更新正式 record 与 C002 生命周期。固定源码 tag 和后续验收文档闭包分开记录，不引用自身尚不存在的commit。
