import pathlib,subprocess,sys,json,time,datetime,hashlib,os
base=pathlib.Path('/private/tmp/sheltie-c002-t17-785552b');label=sys.argv[1];args=sys.argv[2:]
assert label.replace('-','').replace('_','').isalnum();folder=base/'commands'/label;folder.mkdir(exist_ok=False)
env=os.environ.copy();env.update(RUSTC_WRAPPER='',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',NEXTEST_TEST_THREADS='2',CARGO_TARGET_DIR='/private/tmp/sheltie-simplify-t38-target')
(folder/'request.json').write_text(json.dumps({'argv':args,'cwd':os.getcwd(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{k:env[k] for k in ['RUSTC_WRAPPER','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','NEXTEST_TEST_THREADS','CARGO_TARGET_DIR']}},indent=2)+'\n')
start=time.monotonic();p=subprocess.run(args,capture_output=True,env=env)
(folder/'stdout').write_bytes(p.stdout);(folder/'stderr').write_bytes(p.stderr)
r={'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()};(folder/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(label,json.dumps(r));print(p.stderr.decode()[-1800:] if p.returncode else '');sys.exit(p.returncode)
