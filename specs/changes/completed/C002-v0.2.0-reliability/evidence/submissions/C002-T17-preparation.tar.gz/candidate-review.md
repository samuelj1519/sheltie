# C002-T17 候选准备独立审查

Reviewer：`Codex /root/t16_reopen_review`。未参与本轮 T17 修改；只读核相对 `785552b` 的 8 个文件 diff、C002 plan、spec/contracts/engineering、validation 模板及真实 caller。仅写本文，不修改仓库或 home、不提交或网络写、不发布，不复跑由 Owner 执行的完整门禁。中文记录沿用 `tech-doc-style-chinese` 的事实保真规则。

结论：**需修改（1 项治理缺口）；非发布 CI 路径可以验证，当前不是 T17 完成或发布批准。** 改动方向与已授权候选准备相符；PR 构建和发布条件分开，未观察到 PR 会创建 GitHub Release 的路径。完成最终治理修复需关闭下列 F17-01；Owner 的新完整门禁及实际 CI、四平台/远端证据仍待独立补核。

## F17-01：最终表的数据行仍可为空或多列

位置：`scripts/check-specs.sh:128-145`，对应 `release_governance.rs:598-662` 的最终表负例。

精确六列表头能识别，但数据行在 `rows++` 前没有校验 `NF == 8`（六列加两侧空字段）或 Requirement 非空。独立抽取当前脚本原样 awk 程序，喂入同一合法表头与分隔行，实际结果如下，均 exit 0、空 stdout/stderr：

```text
合法：| current | executed | closure | run | PASS | raw |
空要求：| | | | | PASS | |
多列：| current | executed | closure | run | PASS | raw | FAIL |
```

后两行也被计为非空最终验证表并放行，削弱此次「精确六列、非空最终证据、当前全部 PASS」的治理修复意图。现有 8 个新反例核无表、零行、header 漂移、另一表 FAIL/空表及历史隔离，未覆盖这两种行。

建议：separator 与数据行分别核精确列数；数据行至少拒绝空 Requirement，按模板要求保留具体输入/原文定位，补合法控制、空要求和多列的独立反例。保持历史表原样，不把历史 FAIL/SKIP 改写为当前 PASS；修复后仅按影响链重跑治理目标和完成工程门禁。本问题不要求新增 Markdown 框架或通用 parser。

## Standards

除 F17-01 外通过本轮范围审查。先修订 T17 白名单和任务依据，再改 workflow/checker/test；8 个实际改动都在白名单内。Cargo.lock 独立结构比较只有 sheltie-cli/core/runtime 的 0.1.0→0.2.0 版本变化，依赖来源/版本/校验值未变。CHANGELOG 使用 Unreleased 与候选说明，既有 release 历史未改。

治理测试保留原 10 个测试身份及原有断言目标，另增 8 个完成态正反例；原质量 SHA 判据因 PR 改为候选 SHA，但仍核 checkout 与预期相等、全历史、MSRV、quality needs/if 两处独立负控制。生命周期与 release record/tag 在独立临时 Git 自建，避免 live active 包归档后使测试失效；Git 环境隔离仍保留。未增生产 Rust、业务状态或 runtime 判断，三 crate 与引擎/宿主写入边界未变。

## Spec 与真实执行链

- workspace 0.2.0 和三个本地 lock 项准备新版候选；Cargo dist PR 模式由 plan 改 upload，使 local/global artifacts 可以在批准发布前实际生成。官方配置文档区分 plan 和 upload，后者构建并上传 PR artifacts；这只是模式能力，实际资产成功仍待 CI。见 [cargo-dist 配置](https://axodotdev.github.io/cargo-dist/book/reference/config.html#pr-run-mode)。
- workflow 六个 checkout：plan/quality 使用同一 `github.event.pull_request.head.sha || github.sha`，其余 local/global/host/announce 使用 plan 输出 candidate-sha，Release target 也来自该输出。quality 明确验证实际 HEAD；PR 默认 merge SHA 不再当待发布候选。此处是源码结构核证，不是已经取得同 SHA CI 成功证据。
- publishing、tag、tag-flag、plan host/create 均限定 push 且 refs/tags；PR 走 plan，host/announce 都要求 publishing=true，announce 另要求 plan、host、quality success。因此当前 PR upload 只走临时 workflow artifact 路径；没有观察到 PR 外部发布路径。tag push 是正式发布入口，不能在授权前推版本 tag。
- quality 记录候选/checkout SHA、event/run/attempt、commit、tracked 字节 hash、工具版本、逐门禁原文及结果，并 always 上传记录。所有新增 tee 管道明确 `shell: bash`；GitHub 的显式 bash 使用 `-eo pipefail`，不会因 tee 成功掩盖前一命令失败。见 [GitHub workflow shell 语义](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#jobsjob_idstepsshell)。上传记录成功不替代 quality job 成功。
- check-specs 将当前最终表与其他历史事实表分开，零 active 时不执行无匹配 glob 的 sed，符合 change 允许 completed/无 active 的生命周期。精确 header、每张表有数据和当前 Result PASS 的方向正确；F17-01 是仍需补齐的数据行边界。此门禁只核记录形状，不能判断 PASS 是否有真实证据。
- CHANGELOG 明确 schema2/新协议/目录、旧 schema1 保留、Workbook 修复、MIT，以及旧 M1 SK01/SK02、215 项额外执行与 Spec 批准缺失、usage/自动发现限制。没有把 T16 历史 0.1.0 本机构建当本轮 0.2.0 同 SHA quality，没有将历史豁免改成完整验证通过。

## 风险与后续验证

非发布 CI 可以用于取得本候选四平台实物和 quality 原文；它仍需固定实际提交与 run ID，逐平台 manifest/checksum/二进制身份/源码 SHA 以及 quality 成功对照，失败不可记 PASS。tag发布与 package completed 仍受 C002 plan §6 的独立批准门槛约束；不能以 PR upload 或本地构建完成 T17。

新版二进制、release identity 或治理输入改变后，T16 的 0.1.0 历史不能自动复用为新版同 SHA 执行证据。指定真实远端版本更新、rollback、clean home、旧 schema1 原字节、新 home 不被旧 binary 误写及正式 release record 仍按 T17 实际结果核。现有本地 mirror 只可列其有限 caller/失败窗口结果，不能冒充真实发布远端。

本轮未补 Linux Host、M1 最终 Spec 批准、215 项额外变异或完整安全/变异，usage 仍缺失，不写成 0/成本收益；未确认新的四平台实物或远端步骤已通过。候选内容审查与 Owner 的完整工程门禁分开，本报告没有预判正在运行的门禁。

## 初次被审字节

`.github/workflows/release.yml`：`cfdc92dbeff3cf2085f112cb4cf9d2ae30bfe23db8900f7eb1933d25d076e821`；`scripts/check-specs.sh`：`50e800479363f3cdcdae70bd2625301398ff37cc913bbb4827d12e4028169dc0`；`release_governance.rs`：`cb0a065cac36de918ee30a6ab3f060b1bfbe2da26b4d9ee9e6338e8cb8492b8d`。本段固定初次结论；F17-01 修复后另核新的输入，不覆盖本次复现。

## F17-01 修复后复核

**当前候选 Standards/Spec 结论：通过，限定候选准备与非发布 CI 路径。** 初次需修改和红例保留；F17-01 已关闭，没有观察到其他本轮内容阻断项。Owner 的完整门禁、实际 CI/资产及 T17 终态仍未由本报告预判。

修复实际共享 `six_columns()`，同时核 NF=8 与首尾字段为空，防止「多第七列但无尾 pipe，NF 恰为 8」绕过。header、separator、数据行使用同一六列边界；数据行逐字段 trim 后拒绝空字段，Result 必须字面 PASS。范围仍只从精确模板 header 开始，其他历史事实表不被重写或升级。

Reviewer 再次抽取当前精确 awk：合法行仍无诊断；原空要求、多列红例及无尾 pipe 的多列行均返回具体空字段/六列错误。这是运行原 parser 的独立补核，不仅阅读测试或调用被测 parser 生成预期。

治理 worker 的 `/private/tmp/sheltie-t17-governance-p2/red.stdout` 保留旧 checker 上新增四测试实际失败（8 个选定测试为 4 PASS/4 FAIL，14 filtered）；最终 green.stdout 实际 22/22、0 ignored、0 filtered，exit 0，保留原 10＋先前 8＋新增 4 入口。新增例逐列覆盖六个空字段及全空要求行，多/少列、带和不带尾 pipe 的额外列，以及多列 separator。header 额外尾字段也由现有精确 header 负例覆盖。Reviewer 独立核 green.json 的 argv/env、6 份输入 hash 与实际文件、stdout/stderr SHA 全一致，不冒充本轮全仓门禁。

本轮最终所核输入：checker `a5c6a5763e654640ad91ba19fd25de7901bad7e91230e3853191d087fe7364f6`；测试 `e3762627c329224e5bf6bce3bf20b0d0daf8bc89d59f3472527385e72ba4cdde`；workflow `3fc4f407dd607dd753bd61097da2857471262ac46b5aff23e4990a9cf6e3ef3c`。workflow 后续删减过时生成注释，PR/head/tag/quality 六 job 的实际语义未改变。可以在明确非发布 CI 授权内进行实际取证；仍不得推版本 tag、创建 Release、标 T17 done 或把四平台/远端 `not_run` 写成 PASS。
