from pathlib import Path
import json,hashlib,tarfile,stat
base=Path('/private/tmp/sheltie-c002-t16-82c6c55')
repo=Path('/Users/shushu/orca/workspaces/sheltie/codex')
output=repo/'specs/changes/active/C002-v0.2.0-reliability/evidence/submissions/C002-T16-reopen-pending.tar.gz'
assert not output.exists()
assert (base/'reopened-session/independent-review.md').is_file()
paths=[base/'candidate.json',base/'resume-checkpoint.json',base/'delivery/manifest.json',base/'delivery/sheltie/SKILL.md',base/'reopened-record-command.py']
paths+=list((base/'reopened-session').rglob('*'))
for folder in (base/'commands').glob('reopened-*'):paths+=list(folder.rglob('*'))
paths+=list((base/'home/works/2026-10-02-006-t16-续接').rglob('*'))
for node,filename in [('deliver','delivery.md'),('retro','lessons.md')]:paths.append(base/f'home/works/2026-10-02-003-t16-spec-dev/attempts/{node}/occurrence-001/attempt-000/outputs/{filename}')
files={}
for p in sorted(set(paths)):
 mode=p.lstat().st_mode
 if stat.S_ISDIR(mode):continue
 assert stat.S_ISREG(mode),str(p)
 assert '__pycache__' not in p.parts and p.suffix!='.pyc'
 b=p.read_bytes();files[p.relative_to(base).as_posix()]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(base/'reopen-pending-input-files.json').write_text(json.dumps(files,ensure_ascii=False,indent=2)+'\n')
with tarfile.open(output,'w:gz') as tar:
 for name in files:tar.add(base/name,arcname=name,recursive=False)
with tarfile.open(output,'r:gz') as tar:
 assert set(tar.getnames())==set(files)
 for item in tar:
  assert item.isfile();b=tar.extractfile(item).read();assert len(b)==files[item.name]['bytes'] and hashlib.sha256(b).hexdigest()==files[item.name]['sha256']
manifest={'archive':str(output.relative_to(repo)),'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'bytes':output.stat().st_size,'files':len(files),'byte_readback':True,'T16':'doing','T17':'not_run','Work006':'succeeded','Work003':'blocked(gate: retro), pending user approval','usage':None,'scope':'重开续接阶段快照；只用于证据恢复，不作为可运行home或第二套状态来源'}
(base/'reopen-pending-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(manifest,ensure_ascii=False))
