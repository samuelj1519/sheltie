# 反思：2026-10-02-003-t16-spec-dev

## 事实

- 任务清单为 T01—T04；来源是 `deliver#1.0/outputs/delivery.md` 第 20 行，不从引擎统计推算业务任务数。九份绑定输入的实际 SHA-256 均与 brief 相同。
- 以下运行数字均取自 `retro#1.0/engine/stats.json` 第 1 行：`implement` 到达 4 次、尝试 4 次，`verify` 到达 4 次、尝试 4 次；`fix` 到达 0 次，`escalate` 到达 1 次；所有节点 `failed` 均为 0，`blocked_count` 为 0，`approvals` 为 0，Work 跨度 6243 秒。这是 retro 开始时的绑定快照，不能解释为 token 成本、质量分或最终 Work 状态。
- 到达最多的节点是 `implement` 与 `verify`，各 4 次。以下位置均相对本 Work；`node#n.0` 对应 `attempts/<node>/occurrence-<NNN>/attempt-000/`。

| 报告位置 | 第一行 |
| --- | --- |
| `implement#1.0/outputs/change.md` 第 1 行 | 完成 T01 |
| `implement#2.0/outputs/change.md` 第 1 行 | 完成 T02 |
| `implement#3.0/outputs/change.md` 第 1 行 | 完成 T03 |
| `implement#4.0/outputs/change.md` 第 1 行 | 完成 T04 |
| `verify#1.0/outputs/report.md` 第 1 行 | 通过，下一任务 T02 |
| `verify#2.0/outputs/report.md` 第 1 行 | 通过，下一任务 T03 |
| `verify#3.0/outputs/report.md` 第 1 行 | 通过，下一任务 T04 |
| `verify#4.0/outputs/report.md` 第 1 行 | 通过，全部完成 |

- 人工决定：当前 `plan-review#2.0/outputs/decision.md` 第 1 行为「通过」，第 6—9 行保留「错误信息不得回显输入正文」和新版明确批准；`escalate#1.0/outputs/decision.md` 第 1 行为「改方案」，第 3—6 行明确只重排未验证的 T03/T04，保留 T01/T02、整体原始基线及审批条件，且这是 T16 重规划回归，不是验证失败。统计中的 `approvals=0` 不能代替这些人工决定文件。
- `plan`、`plan-review`、`scaffold` 均到达 2 次，统计入口说明第二轮由 `escalate(back)` 回到 `plan`。四份 verify 报告的「发现」均为「无」；整体 `review#1.0/outputs/report.md` 第 1 行为「通过」，第 61 行为「无。阻断项 0 条，建议 0 条」。
- 平均耗时最长的是 `deliver` 的 684 秒，其次是 `escalate` 的 472 秒，均来自绑定 stats。`deliver#1.0/outputs/delivery.md` 第 5—20、26—39 行记录交付证据、人工确认来源及提交清单；没有报告行将这两个耗时归因为流程缺陷，不能据此改档位或删门槛。
- 本 Work 冻结的是 spec-dev 0.2.0，见 `workbook/workbook.toml` 第 3 行。retro brief 第 34 行仍给出旧历史目录，实际本 Work 的报告位于 `attempts/<node>/occurrence-<NNN>/attempt-<NNN>/outputs/`，例如 verify 第 2 次到达的首次尝试为 `attempts/verify/occurrence-002/attempt-000/outputs/report.md`。本轮按协调者明确的定位更正读取，未改旧 brief 或冻结 Workbook。

## 建议

| # | 类别 | 证据 | 改哪 | 改成什么 |
| --- | --- | --- | --- | --- |
| L1 | 说明书歧义 | `retro#1.0/brief.md` 第 34 行指向 `attempts/<node>/<n>/<retry>/`；实际可打开的 `verify#2.0/outputs/report.md` 第 1 行位于 `attempts/verify/occurrence-002/attempt-000/outputs/report.md`。对应已发现的 F16-01。 | 本 Work 的冻结 Workbook `instructions/retro.md`「读什么」第 5 项，第 11 行；建议只作用于后续版本。 | 把历史定位路径改为 `attempts/<node>/occurrence-<NNN>/attempt-<NNN>/outputs/`，说明 Occurrence 与 Attempt 使用三位数字，并给出第二次到达、首次尝试的例子 `occurrence-002/attempt-000/outputs/`。 |

只提出 1 条有实际证据及 Workbook 落点的建议。brief 第 43 行要求三到八条，但第 41 行及绑定 rules 第 16—17 行要求每条都有证据和落点；剩余材料不足以支持另两条，未为满足数量补写推测。

协调者已告知源码的 spec-dev 0.2.1 修正了此路径；本 Work 仍使用 0.2.0，L1 记录的是旧冻结版本问题，不应再原地修改，也不表示新版本已在本 Work 生效。本轮没有另启 0.2.1 Work 验证，不能记新版回归通过。

## 不建议改的

- 不因两轮规划与一次升级改变任务拆分或取消人工审核。`escalate#1.0/outputs/decision.md` 第 6 行明确为真实重规划回归；`deliver#1.0/outputs/delivery.md` 第 20、45 行确认已验证前缀及原始基线保留，没有把演练当成原任务缺陷。
- 不凭 `failed=0`、各任务首行通过或平均耗时调整 `tier`、`max_visits`、`gate`。本次没有反复被打回、达到上限或人要求移动门槛的证据；绑定 stats 也没有模型 usage 数据。
- 不为 verify 的临时解析脚本错误新增固定产品机制。`verify#4.0/outputs/report.md` 第 62 行说明两处解析假设在首次业务测试前纠正，未改项目或测试期望；这是本轮核验脚本的一次性问题，不足以证明冻结报告协议需要修改。
- 不因突变工具缺失而要求 Workbook 安装工具。`deliver#1.0/outputs/delivery.md` 第 47 行保留突变测试 `not_run`；本轮无证据证明这一缺失应改变方法的安装或验收合同。
- 不把隔离项目通过写成父任务完成。`deliver#1.0/outputs/delivery.md` 第 48—49 行保留 usage 缺失、retro 与真人 gate 未完成，以及 C002、T16 和发布边界；新增 lessons 只是待审产物，没有推进或批准这些状态。

## 上一版建议的效果

- 无已采纳的 retro `Ln`。冻结 Workbook `README.md` 第 120—125 行仅记录 0.1.0 初版和 0.2.0 的 C002 修复，并明确 0.2.0 不是 retro 建议。
- 作为既有修复的本次证据：`plan#2.0/outputs/plan.md` 第 32 行继续保留整体原始基线；`deliver#1.0/outputs/delivery.md` 第 20、45 行记录重规划、新版批准及已验证前缀保留。该结果只覆盖本次隔离项目，不扩展到所有宿主或未来 Work。
