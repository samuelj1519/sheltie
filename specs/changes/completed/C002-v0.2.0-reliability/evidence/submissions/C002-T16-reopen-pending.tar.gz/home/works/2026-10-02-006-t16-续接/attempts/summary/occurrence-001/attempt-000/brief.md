# 任务书：按提纲写摘要

Work: 2026-10-02-006-t16-续接（t16-续接）
节点: summary#1，第 0 次尝试
来自: outline#1（main 边）
执行者: agent（standard）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| outline | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-006-t16-续接/attempts/outline/occurrence-001/attempt-000/outputs/outline.md | db1dd9ca5730f74dd2329e6afd6fc0ebb509c3e251c2fb48798d90c3a19c1ca1 |

## 说明

读 `outline`，按它写一篇 300 到 500 字的摘要。

- 顺序与提纲一致，每个一级要点一段。
- 不新增提纲里没有的观点。
- 用简体中文。

把摘要写到 `summary` 对应的路径。回复协调者时说一句：字数与是否覆盖了全部要点。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| summary | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-006-t16-续接/attempts/summary/occurrence-001/attempt-000/outputs/summary.md | 是 | 64 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
