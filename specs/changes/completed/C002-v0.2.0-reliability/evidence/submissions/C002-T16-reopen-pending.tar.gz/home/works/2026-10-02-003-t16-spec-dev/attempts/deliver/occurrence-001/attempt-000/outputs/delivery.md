本次完成隔离 Python 项目的标题规范化、Markdown 首个一级标题提取、UTF-8 只读文件读取及两个 CLI 子命令，整体独立审查通过。

## 验收标准逐条

项目根目录：`/private/tmp/sheltie-c002-t16-82c6c55/project`。整体原始基线：`2f88d59b0d214967b64b285e96d764f26bc71c30`；当前 HEAD：`0ff54fa35002477c033f306e46089cfda738e3d1`。本轮交付核对两者和 Git 状态；工作区干净，六份绑定输入的 SHA-256 均与任务书一致。

以下业务结果引用已完成的[整体独立审查报告](/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/review/occurrence-001/attempt-000/outputs/report.md)，本轮交付未重跑业务测试。报告结论为「通过」，覆盖原始基线到当前 HEAD 的全部改动，阻断项 0 条、建议 0 条。原始证据目录为 `/private/tmp/sheltie-c002-t16-82c6c55/task-runs/whole-review/`；下表证据文件名均相对此目录，命令的 `.json/.stdout/.stderr` 保留实际参数、退出状态和输出原字节。

| 项 | 验证命令或操作 | 结果与证据 |
| --- | --- | --- |
| 1. Unicode 空白与字符保留 | 运行完整 unittest；调用 `normalize_title`，输入含全角首尾空白、不换行空格、制表符和换行。 | 通过。返回 `AbC 你好，世界！`，中间为一个 ASCII 空格，汉字、标点与大小写不变。见 `gate-unittest.stderr`、`readme-functions.*`。 |
| 2. 空结果拒绝 | 分别以空字符串、ASCII 空格、全角空格和混合 Unicode 空白调用 `normalize_title`。 | 通过。四类输入均抛出 `ValueError`，没有返回空标题。见 `gate-unittest.stderr`。 |
| 3. 首个严格匹配标题 | 调用 `extract_title`，依次放入二级、缩进、缺空格、含连续制表符的有效一级标题及后续有效标题。 | 通过。忽略前三类行，返回首个有效标题 `AbC 你好，世界！`。仅认行首 `# `，不解析 Markdown 上下文。见 `gate-unittest.stderr`、`readme-functions.*`。 |
| 4. 无标题和首个空标题拒绝 | 分别传入无匹配行的文本，以及首个匹配标题仅有空白、后续存在有效标题的文本。 | 通过。两类均拒绝，首个空标题不回退。见 `gate-unittest.stderr`、两模式 `*-no-heading.*`、`*-empty-heading.*`。 |
| 5. normalize 成功协议 | 执行 `python3 -m title_tools normalize "  AbC   你好，世界！  "`，并以空 venv 的 Python 加 `-S` 验证同一成功用例。 | 通过。退出 0，stdout 恰为规范标题及一个换行，stderr 空。见 `normal-normalize-success.*`、`empty-venv-no-site-normalize-success.*`。 |
| 6. extract 明确文件、UTF-8 与只读 | 准备含多个标题、CRLF 和 Unicode 空白的 UTF-8 文件；执行 `python3 -m title_tools extract <文件名>`，比较前后完整字节。 | 通过。两种解释器模式均退出 0，stdout 仅为首个规范标题及一个换行，stderr 空；文件字节不变。见 `success.before.bytes`、两模式 `*-extract-success.*` 及对应 `*.after.bytes`。 |
| 7. 所有错误边界 | 实际执行空白标题、无标题、首个空标题、非法 UTF-8、不存在、不可读、缺必需参数和未知子命令用例；另核无子命令及额外私密参数。 | 通过。两种模式各执行 13 次 CLI 调用；所有失败退出 2，stdout 空，stderr 有安全原因，无 traceback、正文或其 repr 回显。已有文件字节不变，不存在文件未创建。真实 chmod(0) 文件先经独立子进程确认 `PermissionError`，之后验证 CLI，最后恢复权限；未 mock 或 skip。见两模式 CLI 原文及 `behavior-result.json`。 |
| 8. 标准库、无第三方和禁止联网环境 | 使用 `python3 -m venv --without-pip` 建立空 venv，核空 site-packages、`include-system-site-packages=false` 及 `-S` 的 sys.path；在同禁网执行上下文运行两个子命令的全部成功与失败用例，并核依赖声明及导入。 | 通过，仅限下述执行闭包。实现导入仅有 argparse/sys，没有第三方依赖声明或网络访问路径；实际记录 seatbelt 禁网标记及 IPv4 TCP connect(1.1.1.1:443) 的 PermissionError/EPERM。见 `execution-environment.*`、`venv-config.bytes`、`empty-site-packages.json`、两模式 CLI 原文。 |
| 9. README 完整门禁 | 在项目根执行 `python3 -m unittest discover -s tests -v` 和 `python3 -m compileall -q title_tools.py tests`。 | 通过。unittest 退出 0，26 项全部实际通过、无 skip；compileall 退出 0，无编译错误，stdout/stderr 空。见 `gate-unittest.*`、`gate-compileall.*`。 |
| 10. 任务拆分、提交和真实确认 | 比较原始需求、冻结规格及两版 plan/tasks；检查六个新增提交的 Task trailer，以及旧版批准、一次条件、真实重规划和新版批准的对应被审字节与执行顺序。 | 通过。两版均为 T01—T04 四项小任务；四个业务提交对应 T01—T04，两个骨架提交另标 scaffold，六个均有 Task trailer。用户确认依次为旧批准、同意重规划、新版批准；新版保留「错误信息不得回显输入正文」，实际错误正反例验证履行。原始基线未重设，T01/T02 证据前缀保留。见 `human-decisions.bytes`、`approval-T01..T04.bytes`、`replanning-decision.bytes`、`reviewed-*.bytes`、`history-*`、`git-message-T01..T04.*` 和 `closure.json`。 |

规格 8 的环境限定按整体审查报告原文保留：

> 规格 8 的环境结论仅覆盖本次明确记录的 Python 执行闭包。单次 EPERM 直接证明所测连接被权限拒绝；`-S` 直接证明不加载 site-packages。这里结合明确禁网执行上下文、实际空环境及同闭包业务成功/失败，接受这一具体执行环境的验收；未取得任意 Host、所有协议、任意攻击代码或整机信任资格，没有用私有 sandbox_check 返回值证明这些能力。

真实确认来自 `human-decisions.json` 对本会话用户回复的机械保存，整体审查已核其与审批字节、执行顺序一致；这不是独立真人身份认证。旧批准、重规划、新版批准的来源分别为 `call_ZWTMsF6X81GPHikRt9wXUSPy/0`、`call_y1C96BSiygLZkIjKbGZZMMji/0`、`call_bAUqDu6CHZknYa5vxVjQCRWj/0`。

## 提交列表

在项目根实际执行 `git log 2f88d59b0d214967b64b285e96d764f26bc71c30..HEAD --oneline`，输出原样如下，共 6 个提交：

```text
0ff54fa feat(cli): 实现安全标题命令并补全使用说明
7182106 feat(reader): 实现 UTF-8 只读文件读取
ba56d3f chore(scaffold): 拆分文件读取测试与安全CLI骨架
6773f93 feat(title): 提取首个严格匹配的一级标题
65c9163 feat(title): 规范化标题空白并拒绝空标题
92e2d3f chore(scaffold): 预写标题工具占位与禁用验收测试
```

项目不存在 `CHANGELOG.md`，未创建该文件或新增收尾提交。

## 遗留

审查建议：无。方案风险中已成真的阻断项：无。重规划决定仅调整未验证 T03/T04 的拆分，原始需求、T01/T02 前缀、整体原始基线及错误正文保密条件均已保留，没有遗留未做的规格验收项。

1. 突变测试为 `not_run`：PATH 中未安装 mutmut 或 cosmic-ray，按冻结审查说明未运行、未安装，不算通过。见 `mutation-status.json`。
2. usage 数据缺失，不能记为 0，也未据此推定成本或调用量。
3. `retro` 与真人 gate 尚未完成，Work 尚未结束。隔离项目需求与整体审查通过不代表 C002 完成、C002-T16 所有宿主场景完成或任何发布批准。

## 对外动作

本项目是 T16 隔离演练。实际 `git remote -v` 输出为空，没有可用的推送目标；本次无需 push 或开 PR，没有适用的对外命令。未执行任何对外动作，未改 Sheltie 仓库或引擎状态，未 submit。

## 下一步建议

1. 按冻结任务书完成 `retro`，保留其输出供真实用户与本交付说明一起审阅。
2. 等真实用户明确批准后再按 Work 的真人 gate 继续；由协调者另外汇总 C002-T16 的宿主回归证据，保持本项目验收与父任务、发布结论的边界。
