import pathlib,subprocess,sys,json,time,datetime,uuid,hashlib,os
base=pathlib.Path('/private/tmp/sheltie-c002-t16-82c6c55');label=sys.argv[1];args=sys.argv[2:]
assert label.replace('-','').replace('_','').isalnum()
folder=base/'commands'/label;folder.mkdir(exist_ok=False)
write=len(args)>1 and ((args[0]=='work' and args[1] in ('start','cancel')) or (args[0]=='workbook' and args[1] in ('add','remove')) or args[0] in ('attempt','gate'))
rid=str(uuid.UUID(os.environ["T16_REQUEST_ID"])) if write else None
argv=[str(base/'delivery/sheltie-bin'),'--home',str(base/'home'),'--json']+(['--request-id',rid] if rid else [])+args
(folder/'request.json').write_text(json.dumps({'argv':argv,'request_id':rid,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},ensure_ascii=False,indent=2)+'\n')
start=time.monotonic();p=subprocess.run(argv,capture_output=True)
(folder/'stdout').write_bytes(p.stdout);(folder/'stderr').write_bytes(p.stderr)
(folder/'result.json').write_text(json.dumps({'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n')
sys.stdout.buffer.write(p.stdout);sys.stderr.buffer.write(p.stderr);sys.exit(p.returncode)
