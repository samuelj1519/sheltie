# 任务书：写需求规格

Work: 2026-10-02-001-retro-layout-fixture（retro-layout-fixture）
节点: spec#1，第 0 次尝试
来自: 入口
执行者: agent（strong）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| request | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/start-inputs/request | 5b309b8ce10f38ae82a59e7bd6b680dd5e83cb0bdad77f0e4384986337707e41 |
| project | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/start-inputs/project | a626a063e6b4c5d7280f59d04bbd168cb73f474fc0af2fbc74ed7589233b26c3 |
| template | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/workbook/resources/templates/spec.md | d6987fc17a535342253d5579ced7ac5f88a32f52b01f19073058d04f1010b423 |
| checklist | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/workbook/resources/checklists/spec-checklist.md | 0bdc7e6ebc0ddeee8059f0ec85afe933e7c9278766340769d3ac8b22743b2251 |
| decision | 尚无（上游 plan-review 还没有产出） | |

## 说明

你要把一句需求写成一份别人能照着做、做完能对着验的需求规格。

## 读什么

1. `request`：用户的原始需求。
2. `project`：项目根目录的绝对路径。只读根目录下的 `README.md`、`AGENTS.md`、`CONTEXT.md`（有哪个读哪个），再用 `ls` 看一层目录结构。**不要遍历整个仓库**，不要读源码。规格阶段不需要知道实现细节。
3. `template`：规格模板。输出必须按它的标题顺序写。
4. `checklist`：交稿前逐条自查。
5. `decision`：审核人的意见。任务书「来自」是 `plan-review` 时才有且才需要读。先读它，按意见改，改完在规格末尾「修订记录」里写一行改了什么。

## 怎么写

- 用简体中文，短句。每个标题下只写这个标题该有的内容。
- 「目标」一段话说清做完后用户能做到什么新的事。
- 「范围」列进来的和不进来的，各自一个列表。拿不准的放「不做」。
- 「验收标准」每条都要能执行、能观察，形如「运行 X，看到 Y」。不写「性能良好」「体验流畅」这类无法检验的话。至少三条，不超过十条。
- 「开放问题」列出你必须问用户才能定的事。**能自己合理假设的，写进「假设」，不要问。** 每个开放问题给一个你推荐的答案。
- 不写技术方案。怎么实现是下一步的事。

## 停下来的条件

如果原始需求少到连「目标」都写不出来，仍然按模板写完，「开放问题」里写明缺什么，然后正常交稿。审核人会回答。

## 写到哪

把规格写到任务书「输出要求」里 `spec` 对应的路径。

## 怎么回复协调者

三到五句话：目标一句，范围一句，验收标准几条，有没有开放问题。不要复述整份文档。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| spec | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/spec/occurrence-001/attempt-000/outputs/spec.md | 是 | 64 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
