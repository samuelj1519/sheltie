# 任务书：人工审核规格与方案

Work: 2026-10-02-001-retro-layout-fixture（retro-layout-fixture）
节点: plan-review#1，第 0 次尝试
来自: plan#1（main 边）
执行者: human

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| spec | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/spec/occurrence-001/attempt-000/outputs/spec.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| plan | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan/occurrence-001/attempt-000/outputs/plan.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| tasks | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan/occurrence-001/attempt-000/outputs/tasks.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |

## 说明

这一步由人完成，判断规格和方案能否开工，并保存本次实际审核的方案与任务清单。实现、验证、审查和修复由 agent 按批准版本执行；升级和最终批准仍按流程交给人。

## 读什么

1. `spec`：需求规格。先看「目标」和「验收标准」是不是你想要的；再看「开放问题」，每个问题你都要给答案。
2. `plan`：技术方案。重点看「改法」有没有明显走偏，「门禁」命令对不对。
3. `tasks`：任务清单。抽查两三个任务，看是不是够小（填几个函数体的量）、「要变绿的测试」名字是否能看出在验什么。

不需要逐字审。规格与方案的细节错误会在实现和审查阶段被 agent 自己发现。你把关的是方向。

## 写什么

写一份 `decision.md`。**第一行只写下面三个词之一**，协调者按它选下一步：

- `通过`：开工。下一步是强模型搭骨架（类型、签名、禁用的测试），之后才是逐任务实现。
- `修改规格`：回到写规格那一步。
- `修改方案`：回到写方案那一步。

第一行之后先写两行版本记录，把你的决定绑定到你看过的那一版（三个决定都写这两行，行名固定）：

```
批准的规格: <sha256>
批准的方案: <sha256>
```

对任务书输入表里 `spec`、`plan` 两个路径跑 `shasum -a 256`（Linux 是 `sha256sum`），把十六进制摘要抄在这里。选「通过」时这两行就是批准记录：之后 `scaffold`、`implement`、`verify` 每一步都会核对它们，方案在你批准后被修订过，旧批准就失效，agent 不会按没批过的版本继续。选「修改规格」「修改方案」时，它们记下你打回的那一版，改完回来重审时用来对账。

再往下写你的意见，每条一行，能定位到规格或方案的哪一节。开放问题的答案也写在这里。选「通过」时可以附带小意见（条件），实现阶段逐条照做，但不会再回来找你确认。

## 保存被审副本并提交

1. 把输入 plan 的原字节复制到输出 reviewed-plan，把输入 tasks 的原字节复制到输出 reviewed-tasks。所有决定，包括打回修改，都必须交这两份副本；不能重新排版、添备注或重新生成。
2. 分别计算每个输入与对应输出的 sha256，确认原字节一致。两份镜像各自的输出限额为 65536 字节；意见写入 decision，不混入镜像。
3. 把 decision.md 写到 decision 输出路径。版本记录仍取任务书输入 spec 和 plan 的摘要，三个决定都保留版本记录。
4. 三份输出都存在且核对完成后，运行任务书末尾的 sheltie attempt submit。后续 planner 会从 reviewed-plan/reviewed-tasks 恢复本次被审版本，不能只在聊天中传旧方案。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| decision | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | 是 | 16 KiB |
| reviewed-plan | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan-review/occurrence-001/attempt-000/outputs/reviewed-plan.md | 是 | 64 KiB |
| reviewed-tasks | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan-review/occurrence-001/attempt-000/outputs/reviewed-tasks.md | 是 | 64 KiB |

写完输出文件后，在终端运行：

    sheltie attempt submit 2026-10-02-001-retro-layout-fixture --attempt plan-review#1.0 --summary "<一句话结论>"
