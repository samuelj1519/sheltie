# 任务书：搭骨架：类型、签名、禁用的测试

Work: 2026-10-02-001-retro-layout-fixture（retro-layout-fixture）
节点: scaffold#1，第 0 次尝试
来自: plan-review#1（main 边）
执行者: agent（strong）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| spec | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/spec/occurrence-001/attempt-000/outputs/spec.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| plan | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan/occurrence-001/attempt-000/outputs/plan.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| tasks | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan/occurrence-001/attempt-000/outputs/tasks.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| decision | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| escalation | 尚无（上游 escalate 还没有产出） | |
| project | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/start-inputs/project | a626a063e6b4c5d7280f59d04bbd168cb73f474fc0af2fbc74ed7589233b26c3 |
| rules | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/workbook/resources/checklists/scaffold-rules.md | 306d0f50d136b59038a195897002ee90e4495e05559f5f2f0e413dbec1702fdb |
| template | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/workbook/resources/templates/scaffold.md | 16c4ff81f11b37c72d604312082a61186d5af6762a03470092d63b6a9a3e79e6 |

## 说明

你要把方案与任务清单变成一份**能编译、全是空壳、测试齐全但全部禁用**的骨架，提交到项目仓库。这一步做完，后面每个任务都只是「启用几个测试，填几个函数体」。你是这条流程里最后一个做设计决定的人；实现者不会再做任何设计。

## 读什么

1. `plan`：「改法」决定要新增和修改哪些文件；「门禁」决定命令。
2. `tasks`：每个任务的「改哪些文件」「要变绿的测试」「做完能观察到什么」。你的测试要覆盖每一条「做完能观察到什么」。
3. `spec`：「验收标准」逐条要有测试对应，哪怕只是最后一个任务的端到端测试。
4. `decision`：`plan-review` 的批准记录，开工前先核版本。它写的「批准的规格」「批准的方案」两个 sha256 必须分别等于任务书 `spec`、`plan` 输入文件的内容摘要（`shasum -a 256 <路径>`，Linux 是 `sha256sum`）。对不上说明方案在批准后被修订过、旧批准已失效：按卡住处理，把两个哈希写进「备注」，不按没批过的方案搭骨架。人可以在 `escalate` 的决定里更正批准记录，那时按人的更正继续并把更正抄进报告。对得上时，「通过」附带的条件逐条落进骨架（例如某条验收要多一个测试）。
5. `escalation`：任务书「来自」是 `escalate` 时读它——你上一轮卡住后人的意见与授权，照它继续，不重复上次的走法。来自别处时它是过期的，忽略。
6. `rules`：骨架规则，逐条遵守。
7. `template`：`scaffold.md` 的格式。
8. `project`：进入项目根。读方案「现状」指到的文件，理解现有类型与约定。不通读仓库。

## 怎么做

1. `git status` 确认工作区干净。
2. 新增或修改「改法」列出的文件：类型、函数签名、文档注释齐全，函数体是这个语言的「未实现」占位（Rust `todo!()`，Python `raise NotImplementedError`，TypeScript `throw new Error("todo")`，其他语言类推）。每个占位体在它那一行标上所属任务的编号（`todo!() // T03`、`raise NotImplementedError  # T03`），一个占位体只归一个任务，验证者靠编号判断哪些是本任务该填的、哪些是后续任务合法留的。改现有函数时保留原实现，只新增签名。
3. 每个公开函数的文档注释写两行：做什么、失败时返回什么。写到实现者不用再读方案就能填的程度。一个函数只做一件事；填不完的拆成多个私有函数，各自占位、各自注释。
4. 为每个任务写测试。函数名描述条件与行为，任务归属单独用项目注释或标记记录；全部禁用并注明任务（Rust `#[ignore = "T05"]`，pytest `@pytest.mark.skip(reason="T05")`，Jest `test.skip`）。期望值手写，不调用被测代码算。测试用到的构造 helper 与 fixture 由你写完，不留占位。
5. 写一条「单任务测试命令」，按任务归属或任务卡明确列出的测试名筛选，并在零个测试时失败。例如 `cargo nextest run --no-tests=fail -E 'test(/(^|::)(accepts_valid_input|rejects_missing_input)$/)'`，或 `pytest -k 'accepts_valid_input or rejects_missing_input'`（零个测试时退出码 5）。有项目 Task 脚本时优先复用；不靠 tNN 名字前缀推断归属。写进 scaffold.md。
6. 跑「门禁」全部命令。占位体与禁用测试不能让任何一条失败。不得改现有测试或门禁配置，除非方案「改法」明说。
7. 一次提交，信息格式见 `rules` 末尾「提交信息」。
8. 若到达本节点时项目里已有你上一次的骨架（方案被改过），在它基础上增量改，不推倒重来；已经变绿的测试不动。

## 什么时候算卡住

方案「改法」与现有代码冲突到无法只增不改；某个任务的「做完能观察到什么」写不出可判定的测试；需要新依赖而方案没写。写清原因，不提交半成品。

## 人工更正批准版本

只有绑定的 escalation 第一行为「继续」、明确写出 `更正原审批: <原decision路径>`、`批准的规格: <当前spec的sha256>`、`批准的方案: <当前plan的sha256>`，且原审批第一行为「通过」时，才按更正核验当前版本。普通「继续」不等于批准。保留原审批的条件；人明确改动条件时按更正记录逐条核验。

在交接记录写 `审批更正来源: <该escalation路径>`，后续节点即使绑定了新 escalation，也从这条明确引用读取并核验更正。verify 的 `审批来源` 和本轮累计表行引用实际更正文件，另写 `原审批来源: <原decision路径>`；未更正时引用 decision。缺引用、摘要不符或原审批未通过时停止，不猜更正内容。

## 写到哪

按 `template` 写 `scaffold.md` 到 `scaffold` 对应路径。第一行 `完成` 或 `卡住`。

## 怎么回复协调者

三句话：骨架提交哈希、共几个任务几个测试、单任务测试命令是什么。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| scaffold | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/scaffold/occurrence-001/attempt-000/outputs/scaffold.md | 是 | 64 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
