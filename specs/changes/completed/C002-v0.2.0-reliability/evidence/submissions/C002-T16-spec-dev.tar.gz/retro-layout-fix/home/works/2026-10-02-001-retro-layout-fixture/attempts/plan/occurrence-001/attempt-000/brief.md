# 任务书：写技术方案与任务清单

Work: 2026-10-02-001-retro-layout-fixture（retro-layout-fixture）
节点: plan#1，第 0 次尝试
来自: spec#1（main 边）
执行者: agent（strong）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| spec | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/spec/occurrence-001/attempt-000/outputs/spec.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| project | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/start-inputs/project | a626a063e6b4c5d7280f59d04bbd168cb73f474fc0af2fbc74ed7589233b26c3 |
| plan_tpl | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/workbook/resources/templates/plan.md | 4baf748d85a9295bb73f61a4095616adc96450dddb8ec572bbfb2b9d9350a6be |
| tasks_tpl | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/workbook/resources/templates/tasks.md | c7df4f8e17ec84c0c7a7377466985305e9676968a15bb46b73a3bca1705383cd |
| task_rules | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/workbook/resources/checklists/task-rules.md | 5d2faa7c3f57ee3a030badb56f950d5721420654f567cbf61f050417f9b34e38 |
| decision | 尚无（上游 plan-review 还没有产出） | |
| escalation | 尚无（上游 escalate 还没有产出） | |
| previous_plan | 尚无（上游 plan-review 还没有产出） | |
| previous_tasks | 尚无（上游 plan-review 还没有产出） | |
| previous_verification | 尚无（上游 verify 还没有产出） | |
| previous_change | 尚无（上游 implement 还没有产出） | |
| previous_fix_change | 尚无（上游 fix 还没有产出） | |

## 说明

你要把需求规格变成技术方案和任务清单。首次规划记录整体原始基线；重规划继承被审副本和已验证任务，再安排剩余工作。

## 读什么

1. `spec`：需求规格。以验收标准为准，不自行扩大范围。
2. `project`：项目根目录。先读 README、AGENTS 和构建文件，再用 `rg` 定位本需求涉及的模块。
3. `plan_tpl`、`tasks_tpl`、`task_rules`：输出模板与拆分规则。
4. `decision`：plan-review 的版本记录与意见。任务书来自 plan-review 时，按意见修订。
5. `escalation`：实现阶段的人工决定。任务书来自 escalate 时，按意见重新安排剩余工作。
6. `previous_plan`、`previous_tasks`：上一次人工实际审核的原字节副本。首次规划未绑定；之后必须读取。
7. 已绑定的 `previous_verification`、`previous_change`、`previous_fix_change`：独立验证记录与实现、修复记录。它们交接累计事实，不是新的批准。

## 首次规划

仅在 previous_plan 和 previous_tasks 都未绑定、且没有任何旧验证或变更输入时，读取 `git rev-parse HEAD` 作为原始基线。把完整哈希写入 plan 的「基线」行和 tasks 的「原始基线」字段。已验证任务表为空。

若旧验证或变更已经绑定，而被审方案或任务清单缺失，停止规划并报告缺失输入。不能取当前 HEAD 代替旧基线。

## 重规划

1. 读取 previous_plan 的原始基线与 previous_tasks 的原始基线。两者必须一致；把 plan 的原始基线行原样复制到新方案。后续提交不能改变这条整体基线。
2. 核 decision 的「批准的方案」摘要与 previous_plan 字节一致。若原通过审批已被人工更正，则从 previous_verification 的实际审批来源打开更正文件，核第一行为「继续」、更正原审批与报告的原审批来源都指向此 decision、被验方案与 previous_plan 字节相同，再核更正后的两摘要对应被验版本。不得从当前 escalation 的普通继续猜更正。被审副本缺失、字段缺失或版本不符时停止，指出具体文件和字段。
3. 从 previous_verification 取得已验证任务表及其继承来源；没有验证记录时，从被审方案和任务清单继承已有表。每个记录的原始基线必须与 previous_plan 一致。
4. 沿每份验证报告的本轮变更和继承来源递归读取历史 change/fix/report/plan，直到首次空表方案。每一层都核原始基线和累计前缀，来源循环、断链、漏行或改写时停止；最新验证表还必须保留被审 plan/tasks 已有前缀。只有验证报告第一行确为通过且独立检查完成，才允许比其来源多追加本轮一行；失败报告不得追加。
5. 逐行检查任务、任务基线、候选提交、审批来源、验证报告与原始证据路径。进入 project，核提交存在、Task trailer、历史任务卡白名单和 Git 改动范围；打开审批与证据引用，核原审批第一行为通过；若审批来源为人工更正，则核更正第一行为继续、明确引用同一原审批、两个批准摘要对应被验版本及条件；否则核审批摘要对应被验版本、验证第一行为通过，以及门禁实际 argv/stdout/stderr/退出状态。缺证据、被打回的材料、失败报告或 Git 不一致时停止。当前 decision 的修改意见只用于重规划版本核对，不等于历史任务通过的审批。不能从冻结的旧 tasks 或聊天猜后来完成事实。
已绑定的 previous_change/previous_fix_change 可能是旧记录，包括 Task: review 的修复。逐份核其来源链，并用候选提交与最新已验证提交的 Git 祖先关系区分：候选已经包含在最新已验证历史中的记录只提供合法旧前缀，不能覆盖最新累计事实；新的待验证候选或「无提交」卡住记录必须携带当前完整已验证前缀。不能只凭任务编号判旧记录。归属或先后无法证明时停止。下一任务或整体修复的自报不追加为已验证任务。

6. 把核对过的原始行复制到新 plan/tasks 的「已验证任务」表，注明本轮继承来源。只重新安排尚未验证的任务。验收条件改变时，在「需重验事项」列出受影响任务并安排重验；保留原来的历史证据，不把旧批准改写成新要求已满足。
7. 在修订记录写明人工意见、继承来源、保留的任务和新增重验事项。表只保存路径与哈希引用，不复制日志正文。

## 方案与任务怎么写

- 「现状」用三到八行说明相关代码和文件路径。
- 「改法」逐条列出修改文件、新增类型与函数名，不写实现代码。
- 「门禁」从项目 CI 或 README 取得完整命令，不编造。每个任务完成后都要运行。
- 「风险」写不确定条件及失败后的停止、恢复路径。
- 任务按依赖编号为 T01、T02 等。每项列白名单、描述行为的测试名、实现要点和可观察结果；不要求测试名带 tNN 前缀，任务归属通过项目的注释或标记记录。
- 每个任务是填一到六个函数体，能独立验证、提交。骨架步骤预写签名、测试和任务占位。
- 任务数为三到二十；超出时在风险中建议拆分。重规划时保留已验证任务的编号和事实，再安排剩余任务。

## 写到哪

新方案写到 plan 输出路径，任务清单写到 tasks 输出路径。提交前再次核对：原始基线未改变，已验证前缀完整，未验证任务没有被标成完成。

## 怎么回复协调者

用四句话说明改法、门禁数量、任务数量和最大风险。重规划时同时指出继承来源和需重验事项；缺输入时明确停止原因。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| plan | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan/occurrence-001/attempt-000/outputs/plan.md | 是 | 64 KiB |
| tasks | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan/occurrence-001/attempt-000/outputs/tasks.md | 是 | 64 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
