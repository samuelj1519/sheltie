# 任务书：反思：这次流程哪里该改

Work: 2026-10-02-001-retro-layout-fixture（retro-layout-fixture）
节点: retro#1，第 0 次尝试
来自: deliver#1（main 边）
执行者: agent（standard）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| stats | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/retro/occurrence-001/attempt-000/engine/stats.json | 446cee116e9eb5239c69fc172a4e764ce7f11c33f56cda2c4a69a055d124029e |
| spec | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/spec/occurrence-001/attempt-000/outputs/spec.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| plan | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan/occurrence-001/attempt-000/outputs/plan.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| delivery | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/deliver/occurrence-001/attempt-000/outputs/delivery.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| decision | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| escalation | 尚无（上游 escalate 还没有产出） | |
| review | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/review/occurrence-001/attempt-000/outputs/report.md | 25920494ba2a71834aca4379c515d3f34e18dda7d2742a57ef2ddfe388872f49 |
| template | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/workbook/resources/templates/lessons.md | 7f53d1eed7d46a490318e487589a590c008189691c59bd144a7e3c0344953ee6 |
| rules | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/workbook/resources/checklists/retro-rules.md | db702327dde7f7b95660dc9ddbd78faf95fa1763b79a788944ae1e9f00937081 |

## 说明

你要回顾这一次运行，写出对这份 Workbook 的具体修改建议。你不评价代码好坏，只找流程本身哪里让人多跑了路：说明书哪句让实现者误解、清单缺了哪一条、任务拆得太大还是太小、哪个节点的模型档位定错了、工具哪里有缺陷、门槛放的位置对不对。

先读 `rules`，六个类别与两条硬要求都在里面。

## 读什么

1. `stats`：引擎给的事实。每个节点到了几次、试了几次、失败几次、平均耗时、从哪进来。数字以它为准，不自己数。
2. `decision`、`escalation`（若有）：人两次介入分别说了什么。人说的话是最贵的信号。
3. `review`（若有）与 `delivery`：审查发现了什么、遗留了什么。止损交付时没有 `review`，把「为什么止损」当第一条线索。
4. `plan`：只读「门禁」与「基线」。`spec`：只在需要对照范围时查。
5. 各步骤的报告第一行：用 `stats` 里到达次数多的节点定位，去 Work 目录 `attempts/<node>/occurrence-<NNN>/attempt-<NNN>/outputs/` 下读对应报告的**第一行与「发现」「备注」**，不读全文。Occurrence 和 retry 分别按三位数补零；例如第二次到达、首次尝试是 `occurrence-002/attempt-000/outputs/`。
6. `template`：输出格式。

## 怎么做

1. 从 `stats` 找异常：`fix` 到达次数、`escalate` 次数、某节点 `failed` 大于 0、某节点平均耗时明显长。每个异常追到具体的报告行。
2. 每条建议按 `rules` 的六个类别之一归类。归不进去的不是建议，写进「不建议改的」并说明为什么。
3. 每条建议必须有「证据」（哪个 Attempt 的哪份文件哪一行）和「改哪」（这份 Workbook 里的哪个文件哪一段）。两样缺一样就不写。
4. 建议是可执行的改动：写出改成什么，一两句话。不写「加强」「优化」「注意」。
5. 三到八条。多于八条挑证据最硬的；一条都没有就写「无」，并在「事实」里说明这次运行顺畅。
6. 如果这份 Workbook 的 `README.md` 修订记录里有上一版采纳过的建议，核对它们是否见效，见效的写一句，没见效的当新建议再提一遍。

## 写到哪

按 `template` 写 `lessons.md` 到 `lessons` 对应路径。

## 怎么回复协调者

两句话：几条建议，最重要的一条是什么。你提交后 Work 会停下等人批准；人会同时读交付说明与这份反思。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| lessons | /private/tmp/sheltie-c002-t16-82c6c55/retro-layout-fix/home/works/2026-10-02-001-retro-layout-fixture/attempts/retro/occurrence-001/attempt-000/outputs/lessons.md | 是 | 32 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
