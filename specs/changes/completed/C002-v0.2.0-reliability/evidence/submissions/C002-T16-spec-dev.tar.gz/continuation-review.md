# C002-T16 后续决定与场景独立复核

Reviewer：`Codex /root/t16_evidence_review`。未参与本阶段用户决定记录、worker 产物、项目实现、独立 verify 或工具运行。只读核原始 CLI、文件字节、Git、任务测试原文与 bundle 元数据；未改源码/状态，未重跑 688 项。沿用中文技术文档 Skill 的审阅与事实保真规则。

结论：**通过，仅限本阶段证据及其边界表达**。T16 仍 `doing`，T17 仍 `not_run`，不能把此复核当完整 T16 验收或旧 M1 Spec 批准。本阶段不覆盖将来实际重规划、back 人工 final 或真实关闭并重开会话。

## 已核事实

- `human-decisions.json` 与本会话用户决定一致：选择当前 Codex，批准本地演练归档；旧「修改方案并附上述条件」已被替代问题的「通过方案，附上述条件」覆盖。有效条件为「错误信息不得回显输入正文」。实际执行沿原四任务方案进入 scaffold，没有新 plan；旧答复不算一次已完成改方案或重规划。plan-review `decision.md` 首行为通过，绑定 spec/plan SHA 与封存原字节一致，被审镜像未改写。此记录是用户决定的机械保存，不是 OS 用户身份带来的独立真人认证。
- `approve-notes` 原文记 `by=shushu`、revision 4，后续 archive worker 提交 revision 6、Work succeeded。独立核 archive 第一行之后全部字节与获批 notes 相同，实际 hash 与 `archive-copy-oracle.json` 一致。这里只是本地 Workbook 演练，不是 T17 发布。
- 原 article 用户回复「已复制」后，`manual-final-oracle.json` 与实际源稿/final 全字节一致，均为 3446 bytes、SHA256 `e271c307a132e146c649120e5e957a5fb1a6da7cc412dd2688b9292db541c2a4`。CLI submit-human-final revision 7 成功，Work succeeded。用户执行复制，协调者核验并提交，没有从「我会复制」推定完成。
- 独立重算目前 commands 的 23 个 submit ArtifactRef：实际文件长度、SHA256 和 0444 权限全部匹配。该计数包括本阶段以前已提交引用，仅说明已核引用，不充当完整场景覆盖数。
- spec-dev 项目整体原始基线仍为 `2f88d59b0d214967b64b285e96d764f26bc71c30`。scaffold 提交 `92e2d3f3fb14d077aac3cba9d10ec2b7df53f540`；T01 `65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c` 的父提交是 scaffold，T02 `6773f932765895735a5786220653440afcba2d8f` 的父提交是 T01。两任务实际 Git diff 都只含 `title_tools.py` 与 `tests/test_title_tools.py`，trailer 保留 Task。独立逐字核测试，分别仅删除 4 个 T01、5 个 T02 skip，断言不变。
- verify#1/report 第一行为「通过，下一任务 T02」，verify#2 第一行为「通过，下一任务 T03」。已验证任务表分别只有 T01 和 T01/T02；T02 的 T01 行与上轮完整六列原样一致，原始基线与审批来源相同。独立 verify 原始 argv/stdout/stderr 与退出状态可读：任务选择器分别实际跑 4/5 项、exit 0；完整 unittest 均收集 21 项，分别 `OK (skipped=17)`、`OK (skipped=12)`；compileall 均 exit 0。后续 skip 是尚未实现任务的显式边界，不是 21 项行为全部通过。T01/T02 的实际固定错误满足已实现路径不回显正文，T03 CLI 条件仍未验收。
- back 场景首稿被刻意限制为不完整输入，应标为**受控反例**，不能算自然首稿质量失败率或自然质量收益。独立首审原文首行为「不通过」，具体指出缺第二论据与 203 字不足；协调者走实际 back，draft#2 的 CLI inputs 与 brief 均绑定实际 review#1，摘要 `7abe9052b3f2bd5ec487793b19113b08c393497fd67927e502b4ec71ef74dbe0` 独立一致。修订后独立复审首行为「通过」，逐条检查冻结清单。stats 保存 draft 经 entry/back 两次进入。该 Work 冻结 Workbook 的每个文件摘要与候选 examples/article-review 一致，未为演练修改 Workbook。
- `host-app-metadata.json` 中 running app 清单来源记为 ChatGPT、`com.openai.codex`。独立读取同 bundle `/Applications/ChatGPT.app/Contents/Info.plist`，SHA、CFBundleIdentifier、版本 `26.928.31416`、build `12553` 全一致。工具明确拒绝该宿主窗口访问，窗口匹配仍 not_run；这里补的是 bundle 元数据，不证明本会话窗口匹配、自动发现、真实重开或模型计量。usage 仍 null。

## 尚未完成

核验时 back 已开始人工 publish Attempt，实际 final 文件不存在、没有该 Attempt submit；spec-dev 已开始 escalate#1，decision 文件不存在，尚无新实际重规划决定或新 plan。不得把旧已被覆盖的「修改方案」当本次 escalate 批准。T03/T04、条件在全部 CLI 错误路径的履行、重规划后累计事实与整体原始需求交付均待后续实证。

真实关闭并重开会话、状态查询续接、未指定 Workbook/缺输入的完整人机交互及 usage 缺口仍保留。固定 preparation tar `f83bd4549b4e99592f4f14885c44db715891c5f913926c48502969dcb9146173` 是收到人工决定前的历史快照；本阶段 home/Git 后续前进是预期变化，不能拿当前 live bytes 否定旧归档或改写其最初边界。本阶段应独立归档新请求响应、真实决定、task-runs 与本复核。

普通源码 688 PASS 不等于 T16 完成 gate PASS；旧正式 task completion FAIL 仍为真实历史。版本仍为本机 0.1.0 候选，不冒充 v0.2.0 rc、四平台资产或发布。旧 M1/SK、Linux和完整变异缺口未由本阶段补齐。
