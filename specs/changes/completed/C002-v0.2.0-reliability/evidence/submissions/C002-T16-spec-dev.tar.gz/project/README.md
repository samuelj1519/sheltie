# 标题工具

本项目用于 C002-T16 的真实 spec-dev 宿主回归，使用 Python 标准库，不联网。

把用户提供的标题规范化，并从 Markdown 文本提取首个一级标题。在项目根目录使用 `python3` 运行下列示例，无须安装第三方依赖。

## 函数

`normalize_title(text)` 去掉首尾 Unicode 空白，把内部连续空白合为一个 ASCII 空格；汉字、标点与大小写保留。空字符串或仅含空白的标题抛出 `ValueError`。

`extract_title(markdown)` 按行顺序选择第一个严格以 `# ` 开头的行，再规范化其标题。它忽略二级标题、前导缩进及 `#` 后缺空格的行。没有匹配行或首个匹配标题为空时抛出 `ValueError`，不回退到后续标题。它不解析 Markdown 语法上下文，因此代码块中的匹配行也会被选择。

```bash
python3 - <<'PY'
from title_tools import normalize_title, extract_title

print(normalize_title("\u3000AbC\u00a0\t\n你好，世界！\u3000"))
print(extract_title("## 二级\n # 缩进\n#缺空格\n# AbC\t\t你好，世界！\n# 后续\n"))
PY
```

两行输出均为 `AbC 你好，世界！`。

## 命令行

规范化标题时，把完整标题作为一个参数传入：

```bash
python3 -m title_tools normalize "  AbC   你好，世界！  "
```

提取标题时，先准备 UTF-8 文件，再明确指定文件名：

```bash
printf '# AbC\t\t你好，世界！\n# 后续\n' > example.md
python3 -m title_tools extract example.md
```

两个命令成功时均退出 `0`，仅向 stdout 输出 `AbC 你好，世界！` 和一个换行，stderr 为空。`extract` 以 UTF-8 只读文件，成功或失败均不修改原始文件字节。

标题为空、没有一级标题、首个标题为空、文件不存在、文件不可读、文件不是 UTF-8、缺少参数或子命令未知时，命令退出 `2`，stdout 为空，stderr 给出固定的安全原因。错误信息不得回显输入正文、参数正文或其 `repr`，也不输出 traceback。例如 `python3 -m title_tools normalize "   "` 会拒绝空白标题。

## 运行限制与验证

实现仅使用 Python 标准库，不联网。验收须在禁止联网的宿主环境中检查成功和失败行为。`python3 -S -m title_tools` 用于检查不加载 site-packages 的行为；`-S` 和静态导入检查不证明宿主禁止联网，真实环境证据由独立验证记录。

每个任务完成后，在项目根目录运行两条完整门禁：

```bash
python3 -m unittest discover -s tests -v
python3 -m compileall -q title_tools.py tests
```

实现由 Workbook 任务书驱动，拆分为至少三个小任务，本方案为 T01–T04 四项；每个任务独立提交并保留 `Task: TNN` trailer。任务基线、候选提交与原始证据由冻结文档指明，通过事实由独立验证追加。

人工审批、附加一次条件及修改方案前，须有真实用户明确确认；新版批准须匹配规格与方案摘要，并保留「错误信息不得回显输入正文」条件。实现者的候选提交不替代人工批准、条件履行的独立验证或整体需求验收。
