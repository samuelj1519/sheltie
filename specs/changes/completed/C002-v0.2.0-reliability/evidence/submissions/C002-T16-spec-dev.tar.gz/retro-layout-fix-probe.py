from pathlib import Path
import subprocess,json,hashlib,uuid,time
base=Path('/private/tmp/sheltie-c002-t16-82c6c55');out=base/'retro-layout-fix';out.mkdir(exist_ok=False);home=out/'home';binary=base/'delivery/sheltie-bin';sequence=0
# 仅检查修复文案能经过真实copy/BEGIN进入brief；合成产物不用于Host、真人或质量验收。
def cli(args):
 global sequence
 sequence+=1;folder=out/f'{sequence:02d}';folder.mkdir();argv=[str(binary),'--home',str(home),'--json','--request-id',str(uuid.uuid4())]+args;start=time.monotonic();p=subprocess.run(argv,capture_output=True);(folder/'request.json').write_text(json.dumps({'argv':argv,'purpose':'文案producer回归fixture，不是T16真人/模型回归'},ensure_ascii=False,indent=2)+'\n');(folder/'stdout').write_bytes(p.stdout);(folder/'stderr').write_bytes(p.stderr);(folder/'result.json').write_text(json.dumps({'exit_code':p.returncode,'seconds':time.monotonic()-start},indent=2)+'\n');assert p.returncode==0,(argv,p.stderr,p.stdout);return json.loads(p.stdout)
cli(['workbook','add',str(Path.cwd()/'workbooks/spec-dev')]);work=cli(['work','start','--workbook','spec-dev@0.2.1','--flow','default','--name','retro-layout-fixture','--input','request=producer文案回归fixture','--input','project='+str(base/'project')])['data']['work_id']
for node in ['spec','plan','plan-review','scaffold','implement','verify','review','deliver']:
 begin=cli(['attempt','begin',work,'--node',node])['data']
 for name,file in begin['outputs'].items():Path(file).write_text('文案producer回归fixture：不构成真实任务结果、人工审批或质量结论。\n')
 cli(['attempt','submit',work,'--attempt',begin['attempt'],'--summary','仅文案producer回归fixture'])
retro=cli(['attempt','begin',work,'--node','retro'])['data'];brief=Path(retro['brief_path']).read_text();expected=(Path.cwd()/'workbooks/spec-dev/instructions/retro.md').read_text();assert expected in brief;assert 'attempts/<node>/occurrence-<NNN>/attempt-<NNN>/outputs/' in brief;assert 'attempts/<node>/<n>/<retry>/' not in brief
old=(base/'home/works/2026-10-02-003-t16-spec-dev/workbook/instructions/retro.md').read_bytes();original=subprocess.check_output(['git','show','82c6c55:workbooks/spec-dev/instructions/retro.md']);assert old==original
result={'new_version':'0.2.1','new_brief':retro['brief_path'],'new_instruction_verbatim_in_brief':True,'current_worklayout_in_brief':True,'old_frozen_bytes_unchanged':True,'old_frozen_sha256':hashlib.sha256(old).hexdigest(),'scope':'真实add/start/begin/submit生成新brief的文案producer检查，合成输出不能算Host或真人验收'};(out/'oracle.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
