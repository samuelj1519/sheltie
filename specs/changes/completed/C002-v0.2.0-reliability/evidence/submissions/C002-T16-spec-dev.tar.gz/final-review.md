# C002-T16 最终场景与 F16-01 独立复核

Reviewer：`Codex /root/t16_evidence_review`。未参与被审场景、项目实现/验证、retro 或 F16-01 修复；只读核当前 diff、原始请求响应、产物字节、Git 与已有测试输出。未重跑 688 项，未更改仓库、状态或管理根。本文是阶段复核，不是最终 T16 验收。

结论：**通过，范围限定为已观察场景与 F16-01 文案修复闭环**。修复后的普通工程 gate 尚在运行，本文不预先记全部 PASS。T16 仍 `doing`，T17 仍 `not_run`。

## 场景与证据

- 用户第二次复制后，back 场景实际修订稿和人工 final 全字节相同，3391 bytes、SHA256 `3c94a359dc79a460988cd7be005818c836bb8aabcb2f92581c6165b20937ec84`。submit-back-human-final 原文 revision 11、Work succeeded。首稿仍是受控不完整反例；本次真实 back 链和真人 final 成立，不能扩为自然首稿质量或成本收益。
- 用户「同意上述重规划」被实际写为 escalate 首行「改方案」，再执行冷读 replanner；新版实际只重排未验证的 T03/T04，用户随后「批准新版，保留原条件」。独立重算新版 plan/tasks hash，与新版审批相符；用完整六列表格式独立核两份新文件的累计 T01/T02 行与 verify#2 全字节一致，未新增虚构验证行，原始基线仍为 `2f88d59b0d214967b64b285e96d764f26bc71c30`。这次实际改方案不依赖先前已被替代的旧答复。
- verify#3 首行为「通过，下一任务 T04」，累计只有 T01—T03；verify#4 首行为「通过，全部完成」，累计恰好 T01—T04，完整六列保留。verify#3 原文完整 unittest 收集 26 项、后续 12 skip；verify#4 实际 26 项全部通过、零 skip，compileall exit 0。该「全部完成」只指 fixture 项目的任务清单，不是 T16。
- 整体审查首行为通过，实际从上述原始基线到项目 HEAD `0ff54fa35002477c033f306e46089cfda738e3d1` 核四个文件：README、两份测试及 title_tools.py。没有缩小到重规划或新骨架基线。whole-review/closure.json 的全部输入 hash 与实际文件一致，原文再次实际跑 26/26、零 skip 和 compileall exit 0；阻断项 0、建议 0。CLI 条件、UTF-8、真实不可读前置及文件字节证据按独立报告保留。
- 空 venv、`-S`、seatbelt/禁网执行上下文标记、实际 TCP EPERM 和同闭包 CLI 成功/错误原文，只支持报告限定的这一 Python 执行闭包。单次 EPERM 不证明任意协议，`-S` 不单独证明禁网；私有 sandbox_check 返回值只是辅助观察，未扩大为整机或任意 Host 信任资格。嵌套 sandbox exit 71 的失败未记通过。这个边界足够明确，不需为本演练新增产品机制。
- deliver 与 retro 的实际 ArtifactRef 已提交；submit-retro revision 39 为 blocked(gate)，next 只有 retro gate approve/cancel。核验时没有最终用户 gate 批准，不能把 delivery、lessons 存在或局部审查通过当 Work 结束。独立重算 commands 的 38 个已提交引用，长度/hash/0444 全部一致。

## F16-01 的性质与修复

这是已观察到的 Workbook 说明缺陷。旧冻结 spec-dev 0.2.0 的 retro 第 5 项要求到 `attempts/<node>/<n>/<retry>/` 查历史报告；实际报告在 `attempts/<node>/occurrence-<NNN>/attempt-<NNN>/outputs/`。`crates/sheltie-core/src/work/layout.rs` 的 attempt_dir/outputs_dir 与 storage 合同 §5.4/输出目录定义同样使用后者。retro worker 已记录实际不得按旧目录找到报告，需要协调者定位更正。因此不是推测性改进，也不是引擎状态/目录实现错误。

当前 source diff 仅修改 retro 第 5 项路径及三位零补齐例子、Workbook manifest 0.2.0→0.2.1、README 版本记录；C002 plan/tasks 先把三文件纳入 T16 缺口修复白名单。没有改 Rust、Flow、核心/运行时判断、宿主安装或自然语言解析机制，符合 INV-1—INV-4；业务方法仍为 Workbook。新版本是避免同版本不同定义的必要变更，不改正在运行的 Work。

独立核 `retro-layout-fix/oracle.json`：新 0.2.1 安装 instructions 与 source 字节一致，真实 add/start/begin 链生成的新 retro brief 逐字包含新说明及新目录。旧 Work 冻结 retro hash 仍为 `3bf38deb3c77162f7fea8275fffa992fd2412bb47708d4546ef366484dd17407`，旧布局原文和旧历史 brief 没被改写。该隔离 probe 用合成输出走到 retro，只证明真实 brief producer 交付新说明；不能算新版本的真实 agent 业务交付、人工审批或 Host 全量验收。真实在途 0.2.0 Work 保持已记录缺陷及人工定位更正，不能反称其冻结说明已修好。

## gate 与剩余边界

核验时 fix-gates/results.json 只有 fmt/check/Clippy 三项 exit 0，其输出 hash 独立一致；nextest 正在运行，其余 deny/MSRV/dist/doc 等不能预判 PASS。F16-01 内容与 producer 局部闭环通过，不替代修复后普通 gate、最终证据封存和 task 完成 gate。

最终 retro 用户批准、真实关闭并重开会话且仅按当前状态续接、未指定 Workbook/缺输入完整人机交互仍待补。Host 版本为同 running bundle 元数据，窗口访问被工具拒绝；不推定自动发现或真实重开。usage 仍缺失，不记 0 或收益。M1/SK01/SK02、Linux、完整变异缺口不能因本阶段变 PASS；本机引擎仍 0.1.0 身份，Workbook 0.2.1 不等于引擎 v0.2.0 rc 或四平台发布。

固定 preparation 与 continuation 档案均是各自阶段快照；后续 live home、项目与新 Workbook 前进不能用于改写旧快照。最终应独立封存本阶段、F16-01 probe、修复后 gate 和本复核，保留正式完成 gate 的真实结果。
