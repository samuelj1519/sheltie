from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess
base=Path('/private/tmp/sheltie-c002-t16-82c6c55'); project=base/'project'; evidence=base/'task-runs/scaffold-2'; work=base/'home/works/2026-10-02-003-t16-spec-dev'
def read(relative,label):
    data=(work/relative).read_bytes(); (evidence/f'prefix-{label}.bytes').write_bytes(data); return data.decode()
def rows(text): return [line for line in text.splitlines() if re.match(r'^\| T\d{2} \|', line)]
r1=read('attempts/verify/occurrence-001/attempt-000/outputs/report.md','report-1')
r2=read('attempts/verify/occurrence-002/attempt-000/outputs/report.md','report-2')
c1=read('attempts/implement/occurrence-001/attempt-000/outputs/change.md','change-1')
c2=read('attempts/implement/occurrence-002/attempt-000/outputs/change.md','change-2')
p1=read('attempts/plan/occurrence-001/attempt-000/outputs/plan.md','plan-1')
t1=read('attempts/plan/occurrence-001/attempt-000/outputs/tasks.md','tasks-1')
d1=read('attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md','decision-1')
assert r1.startswith('通过') and r2.startswith('通过') and d1.startswith('通过\n')
assert rows(c1)==rows(p1)==rows(t1)==[]
assert rows(c2)==rows(r1)==rows(r2)[:1]
assert len(rows(r2))==2
for text in [r1,r2,c1,c2,p1,t1]: assert '2f88d59b0d214967b64b285e96d764f26bc71c30' in text
assert '批准的方案: '+hashlib.sha256(p1.encode()).hexdigest() in d1
for row in rows(r2):
    fields=[part.strip() for part in row.split('|')[1:-1]]
    assert len(fields)==6
    assert Path(fields[3]).is_file() and Path(fields[4]).is_file() and Path(fields[5]).is_dir()
(evidence/'approval-prefix.json').write_text(json.dumps({'first_plan_and_tasks_empty':True,'report1_appends_one_row':True,'report2_appends_one_row':True,'original_baseline':'2f88d59b0d214967b64b285e96d764f26bc71c30','inherited_rows':rows(r2),'new_approval_sha256':hashlib.sha256((evidence/'input-decision.bytes').read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n')
def run(name,argv,expected=0):
    start=datetime.now(timezone.utc).isoformat(); result=subprocess.run(argv,cwd=project,capture_output=True,check=False,timeout=30)
    for stream in ['stdout','stderr']: (evidence/f'{name}.{stream}').write_bytes(getattr(result,stream))
    (evidence/f'{name}.json').write_text(json.dumps({'argv':argv,'cwd':str(project),'stdin':None,'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'exit_code':result.returncode,'stdout':str(evidence/f'{name}.stdout'),'stderr':str(evidence/f'{name}.stderr')},ensure_ascii=False,indent=2)+'\n')
    assert result.returncode==expected,(name,result.stderr)
    return result.stdout.decode().strip()
for label,baseline,candidate in [('T01','92e2d3f3fb14d077aac3cba9d10ec2b7df53f540','65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c'),('T02','65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c','6773f932765895735a5786220653440afcba2d8f')]:
    assert run(f'prefix-{label}-parent',['git','rev-parse',candidate+'^'])==baseline
    assert 'Task: '+label in run(f'prefix-{label}-message',['git','log','-1','--format=%B',candidate])
    run(f'prefix-{label}-original-ancestor',['git','merge-base','--is-ancestor','2f88d59b0d214967b64b285e96d764f26bc71c30',candidate])
    run(f'prefix-{label}-files',['git','diff','--name-only',baseline+'..'+candidate])
message='''chore(scaffold): 拆分文件读取测试与安全CLI骨架

按新批准方案保留T01/T02实现和九项已启用测试，新增SafeArgumentParser.error占位及五项T03直接文件读取测试；原十二项CLI测试仅改归属为T04。
完整单任务命令为python3 - TNN，stdin见scaffold#2交接的四任务精确选择器，共26项测试。
正式unittest与compileall门禁通过（9通过、17禁用）；隔离临时副本T03正例单任务及全部门禁通过后删除，原项目业务占位保留。

Task: scaffold
Work: 2026-10-02-003-t16-spec-dev
Agent: GPT-6
'''
(evidence/'commit-message.txt').write_text(message)
run('git-add',['git','add','title_tools.py','tests/test_title_tools.py','tests/test_read_markdown.py'])
run('git-staged-diff',['git','diff','--cached'])
run('git-commit',['git','commit','-F',str(evidence/'commit-message.txt')])
head=run('git-head-after',['git','rev-parse','HEAD'])
assert run('git-status-after',['git','status','--porcelain=v1'])==''
assert run('git-candidate-parent',['git','rev-parse','HEAD^'])=='6773f932765895735a5786220653440afcba2d8f'
run('git-message',['git','log','-1','--format=%B'])
print(head)
