from pathlib import Path
import ast
import copy
import hashlib
import json
import re
import sys

from run import EVIDENCE, PROJECT, run

records = {}
expected_title = 'AbC 你好，世界！\n'.encode('utf-8')

def check(name, arguments, expected_code, expected_stdout=b'', private=(), site=True):
    argv = ['python3'] + ([] if site else ['-S']) + ['-m', 'title_tools', *arguments]
    result = run(name, argv)
    assert result.returncode == expected_code, name
    assert result.stdout == expected_stdout, name
    if expected_code == 0:
        assert result.stderr == b'', name
    else:
        assert result.stderr.strip() and b'Traceback' not in result.stderr, name
        assert all(fragment not in result.stderr for fragment in private if fragment), name
    records[name] = {'exit_code': result.returncode, 'stdout_matches': True,
                     'stderr_protocol_matches': True}

def file_case(name, content, expected_code, site=True):
    path = EVIDENCE / (name + '.input.md')
    path.write_bytes(content)
    (EVIDENCE / (name + '.before.bytes')).write_bytes(path.read_bytes())
    check(name, ['extract', str(path)], expected_code,
          expected_title if expected_code == 0 else b'',
          (content, repr(content).encode(), b'PRIVATE_BODY'), site)
    after = path.read_bytes()
    (EVIDENCE / (name + '.after.bytes')).write_bytes(after)
    assert after == content, name
    records[name]['original_bytes_preserved'] = True

check('cli-normalize-success', ['normalize', '  AbC   你好，世界！  '], 0, expected_title)
text = '\u3000\u00a0\t\n '
check('cli-normalize-whitespace', ['normalize', text], 2,
      private=(text.encode(), repr(text).encode()))
file_case('cli-extract-success', '## 二级\r\n# \u3000AbC\t\t你好，世界！\r\n# 后续\r\n'.encode(), 0)
file_case('cli-extract-no-heading', b'PRIVATE_BODY_MISSING_HEADING\n## subheading\n', 2)
file_case('cli-extract-empty-first', '# \u3000\t\n# PRIVATE_BODY_AFTER_EMPTY\n'.encode(), 2)
file_case('cli-extract-non-utf8', b'PRIVATE_BODY_INVALID_ENCODING\xff\n', 2)
missing = EVIDENCE / 'missing-file.md'
assert not missing.exists()
check('cli-extract-missing', ['extract', str(missing)], 2)
assert not missing.exists()
records['cli-extract-missing']['absent_before_and_after'] = True
content = b'# PRIVATE_BODY_UNREADABLE\n'
unreadable = EVIDENCE / 'unreadable-file.md'
unreadable.write_bytes(content)
(EVIDENCE / 'cli-extract-unreadable.before.bytes').write_bytes(content)
unreadable.chmod(0)
try:
    probe = run('permission-precondition', ['python3', '-S', '-c',
        'import pathlib, sys; pathlib.Path(sys.argv[1]).read_bytes()', str(unreadable)])
    assert probe.returncode != 0 and b'PermissionError' in probe.stderr
    check('cli-extract-unreadable', ['extract', str(unreadable)], 2,
          private=(b'PRIVATE_BODY_UNREADABLE', content, repr(content).encode()))
finally:
    unreadable.chmod(0o600)
after = unreadable.read_bytes()
(EVIDENCE / 'cli-extract-unreadable.after.bytes').write_bytes(after)
assert after == content
records['cli-extract-unreadable']['original_bytes_preserved'] = True
for suffix, arguments in [('no-command', []), ('no-title', ['normalize']), ('no-path', ['extract'])]:
    check('cli-' + suffix, arguments, 2)
private = 'PRIVATE_BODY_UNKNOWN_SUBCOMMAND'
check('cli-unknown', [private], 2, private=(private.encode(),))
check('without-site-normalize-success', ['normalize', '  AbC   你好，世界！  '], 0,
      expected_title, site=False)
check('without-site-normalize-error', ['normalize', text], 2,
      private=(text.encode(), repr(text).encode()), site=False)
file_case('without-site-extract-success', '# AbC\t\t你好，世界！\n# 后续\n'.encode(), 0, site=False)
file_case('without-site-extract-error', b'PRIVATE_BODY_WITHOUT_SITE\n', 2, site=False)

# Check the README's actual examples without creating a file in the project.
readme = (PROJECT / 'README.md').read_text()
example = re.search("python3 - <<'PY'\n(.*?)\nPY", readme, re.S).group(1) + '\n'
path = EVIDENCE / 'readme-functions.source'
path.write_text(example)
result = run('readme-functions', ['python3', '-'], path)
assert result.returncode == 0 and result.stdout == expected_title * 2 and not result.stderr
readme_file = EVIDENCE / 'example.md'
readme_content = '# AbC\t\t你好，世界！\n# 后续\n'.encode()
readme_file.write_bytes(readme_content)
(EVIDENCE / 'readme-cli-extract.before.bytes').write_bytes(readme_content)
check('readme-cli-extract', ['extract', str(readme_file)], 0, expected_title)
(EVIDENCE / 'readme-cli-extract.after.bytes').write_bytes(readme_file.read_bytes())
assert readme_file.read_bytes() == readme_content

before_tests = (EVIDENCE / 'before-tests-test_title_tools.py').read_bytes()
after_tests = (PROJECT / 'tests/test_title_tools.py').read_bytes()
assert before_tests.replace(b'    @unittest.skip("T04")\n', b'') == after_tests
before = ast.parse((EVIDENCE / 'before-title_tools.py').read_text())
after = ast.parse((PROJECT / 'title_tools.py').read_text())
def mask(tree):
    tree = copy.deepcopy(tree)
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in {'build_parser', 'main'}:
            node.body = [ast.Pass()]
        if isinstance(node, ast.ClassDef) and node.name == 'SafeArgumentParser':
            for item in node.body:
                if isinstance(item, ast.FunctionDef) and item.name == 'error':
                    item.body = [ast.Pass()]
    return ast.dump(tree, include_attributes=False)
assert mask(before) == mask(after)
assert (EVIDENCE / 'before-title_tools.py').read_bytes().split(b'# Task: T04', 1)[0] == (
    PROJECT / 'title_tools.py').read_bytes().split(b'# Task: T04', 1)[0]
assert not any(isinstance(n, ast.Name) and n.id == 'NotImplementedError' for n in ast.walk(after))
bindings = json.loads((EVIDENCE / 'input-hashes.json').read_text())
for record in bindings.values():
    assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest() == record['sha256']
decision = (EVIDENCE / 'input-decision.bytes').read_text()
assert '批准的规格: ' + bindings['spec']['sha256'] in decision
assert '批准的方案: ' + bindings['plan']['sha256'] in decision
assert '条件：错误信息不得回显输入正文。' in decision
human = json.loads((EVIDENCE / 'human-decisions.bytes').read_text())
approval = [item for item in human['decisions']
            if item.get('question_id') == 'call_bAUqDu6CHZknYa5vxVjQCRWj/0']
assert len(approval) == 1 and approval[0]['answer'] == '批准新版，保留原条件'
assert approval[0]['spec_sha256'] == bindings['spec']['sha256']
assert approval[0]['plan_sha256'] == bindings['plan']['sha256']
assert approval[0]['condition'] == '错误信息不得回显输入正文'
snapshots = {}
for name in ['title_tools.py', 'tests/test_title_tools.py', 'README.md']:
    data = (PROJECT / name).read_bytes()
    (EVIDENCE / ('candidate-' + name.replace('/', '-'))).write_bytes(data)
    snapshots[name] = hashlib.sha256(data).hexdigest()
summary = {'cli_checks': records, 'candidate_file_hashes': snapshots,
           'tests_only_removed_twelve_T04_skips': True,
           'source_only_changed_three_T04_function_bodies': True,
           'T01_T02_T03_source_bytes_unchanged': True,
           'frozen_inputs_unchanged': True, 'approval_actual_record_matches': True,
           'host_network_isolation': 'not_run; -S and import scanning are not network isolation',
           'independent_verification': 'pending; no T04 row added'}
(EVIDENCE / 'result.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print('Final implementation evidence and source/test scope checks passed.')
