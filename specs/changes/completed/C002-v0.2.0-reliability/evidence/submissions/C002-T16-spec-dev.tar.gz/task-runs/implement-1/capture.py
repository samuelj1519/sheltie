import json, subprocess, sys
from pathlib import Path
name, *argv = sys.argv[1:]
out = Path(__file__).parent
stdin_path = out / (name + ".stdin")
stdin = stdin_path.read_bytes() if stdin_path.exists() else None
r = subprocess.run(argv, cwd="/private/tmp/sheltie-c002-t16-82c6c55/project", input=stdin, capture_output=True)
(out / (name + ".stdout")).write_bytes(r.stdout)
(out / (name + ".stderr")).write_bytes(r.stderr)
(out / (name + ".json")).write_text(json.dumps({"argv":argv,"cwd":"/private/tmp/sheltie-c002-t16-82c6c55/project","stdin":str(stdin_path) if stdin is not None else None,"exit_code":r.returncode}, ensure_ascii=False, indent=2)+"\n")
print(json.dumps({"name":name,"argv":argv,"exit_code":r.returncode}, ensure_ascii=False))
sys.stdout.buffer.write(r.stdout); sys.stderr.buffer.write(r.stderr)
