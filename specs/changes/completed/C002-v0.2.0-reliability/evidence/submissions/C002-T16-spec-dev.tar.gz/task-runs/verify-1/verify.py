import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/private/tmp/sheltie-c002-t16-82c6c55')
WORK = ROOT / 'home/works/2026-10-02-003-t16-spec-dev'
PROJECT = ROOT / 'project'
OUT = ROOT / 'task-runs/verify-1'
CANDIDATE = '65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c'
BASE = '92e2d3f3fb14d077aac3cba9d10ec2b7df53f540'
ORIGINAL = '2f88d59b0d214967b64b285e96d764f26bc71c30'

def run(name, argv, stdin=None):
    started = time.time()
    result = subprocess.run(argv, cwd=PROJECT, input=stdin, capture_output=True)
    for suffix, value in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (OUT / f'{name}.{suffix}').write_bytes(value)
    if stdin is not None:
        (OUT / f'{name}.stdin').write_bytes(stdin)
    metadata = {'argv': argv, 'cwd': str(PROJECT), 'candidate_commit': CANDIDATE,
                'started_unix': started, 'finished_unix': time.time(),
                'exit_code': result.returncode, 'stdout': str(OUT / f'{name}.stdout'),
                'stderr': str(OUT / f'{name}.stderr'),
                'stdin': str(OUT / f'{name}.stdin') if stdin is not None else None}
    (OUT / f'{name}.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, (name, result.stderr)
    return result.stdout

brief = (WORK / 'attempts/verify/occurrence-001/attempt-000/brief.md').read_text()
inputs = {}
for name, path, sha in re.findall(r'^\| (\w+) \| (/[^|]+?) \| ([0-9a-f]{64}) \|$', brief, re.M):
    actual = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    inputs[name] = {'path': path, 'expected': sha, 'actual': actual}
    assert actual == sha, name
(OUT / 'input-hashes.json').write_text(json.dumps(inputs, ensure_ascii=False, indent=2) + '\n')
texts = {name: Path(item['path']).read_text() for name, item in inputs.items()}
assert texts['project'].strip() == str(PROJECT)
assert texts['decision'].splitlines()[0] == '通过'
assert '批准的规格: ' + inputs['spec']['actual'] in texts['decision']
assert '批准的方案: ' + inputs['plan']['actual'] in texts['decision']
assert '条件：错误信息不得回显输入正文。' in texts['decision']
assert '原始基线: ' + ORIGINAL in texts['change']
assert ORIGINAL in texts['plan']
assert '原始基线: ' + ORIGINAL in texts['tasks']
assert '继承来源: ' + inputs['plan']['path'] in texts['change']

def prefix(text):
    tail = text.split('## 已验证任务', 1)[1]
    tail = tail.split('\n## ', 1)[0]
    return [line for line in tail.splitlines() if re.match(r'^\| T\d+ \|', line)]

assert prefix(texts['change']) == prefix(texts['plan']) == prefix(texts['tasks']) == []
(OUT / 'approval-prefix.json').write_text(json.dumps({
    'approval_source': inputs['decision']['path'], 'spec_sha256': inputs['spec']['actual'],
    'plan_sha256': inputs['plan']['actual'], 'condition': '错误信息不得回显输入正文。',
    'original_baseline': ORIGINAL, 'inheritance_source': inputs['plan']['path'],
    'change_prefix': prefix(texts['change']), 'plan_prefix': prefix(texts['plan']),
    'tasks_prefix': prefix(texts['tasks']), 'result': 'PASS'
}, ensure_ascii=False, indent=2) + '\n')

assert run('git-head', ['git', 'log', '-1', '--format=%H']).decode().strip() == CANDIDATE
assert run('git-status-before', ['git', 'status', '--porcelain=v1']) == b''
run('git-original-ancestor', ['git', 'merge-base', '--is-ancestor', ORIGINAL, CANDIDATE])
assert run('git-candidate-parent', ['git', 'rev-parse', CANDIDATE + '^']).decode().strip() == BASE
changed = run('git-range-files', ['git', 'diff', '--name-only', BASE + '..' + CANDIDATE]).decode().splitlines()
assert set(changed) == {'title_tools.py', 'tests/test_title_tools.py'}
run('git-range-diff', ['git', 'diff', BASE + '..' + CANDIDATE])
run('git-tests-diff', ['git', 'diff', BASE + '..' + CANDIDATE, '--', 'tests/test_title_tools.py'])
old_tests = run('git-old-tests', ['git', 'show', BASE + ':tests/test_title_tools.py']).decode()
current_tests = (PROJECT / 'tests/test_title_tools.py').read_text()
assert old_tests.count('    @unittest.skip("T01")\n') == 4
assert old_tests.replace('    @unittest.skip("T01")\n', '') == current_tests
assert current_tests.count('@unittest.skip("T02")') == 5
assert current_tests.count('@unittest.skip("T03")') == 12
message = run('git-message', ['git', 'log', '-1', '--format=%B']).decode()
assert re.match(r'^\w+\([^)]+\): .+', message)
assert '\nTask: T01\n' in message and '\nAgent: ' in message
source = (PROJECT / 'title_tools.py').read_text()
for line in source.splitlines():
    if re.search(r'NotImplementedError|\btodo\b|\bpass\b', line):
        assert re.search(r'# T0[23]$', line), line
tree = ast.parse(source)
normalize = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'normalize_title')
assert not any(isinstance(node, ast.Name) and node.id == 'NotImplementedError' for node in ast.walk(normalize))
assert {alias.name for node in tree.body if isinstance(node, ast.Import) for alias in node.names} == {'argparse'}
for pattern in ('requirements*.txt', 'pyproject.toml', 'setup.py', 'setup.cfg', 'Pipfile*', 'poetry.lock'):
    assert not list(PROJECT.glob(pattern)), pattern
for name in ('title_tools.py', 'tests/test_title_tools.py', 'README.md'):
    (OUT / ('candidate-' + name.replace('/', '-'))).write_bytes((PROJECT / name).read_bytes())

selector = re.search(r'```bash\npython3 - T01 <<\'PY\'\n(.*?)\nPY\n```', texts['scaffold'], re.S).group(1) + '\n'
run('task-tests', ['python3', '-', 'T01'], selector.encode())
assert (OUT / 'task-tests.stdout').read_text() == 'T01: selected 4 tests\n'
assert 'Ran 4 tests' in (OUT / 'task-tests.stderr').read_text()
assert 'skipped' not in (OUT / 'task-tests.stderr').read_text()
run('gate-unittest', ['python3', '-m', 'unittest', 'discover', '-s', 'tests', '-v'])
full = (OUT / 'gate-unittest.stderr').read_text()
assert 'Ran 21 tests' in full and 'OK (skipped=17)' in full
run('gate-compileall', ['python3', '-m', 'compileall', '-q', 'title_tools.py', 'tests'])
observation = '''import title_tools
assert title_tools.normalize_title("\\u3000AbC\\u00a0\\t\\n你好，世界！\\u3000") == "AbC 你好，世界！"
print("Unicode normalization observation: PASS")
inputs = ("", "   ", "\\u3000", "\\u3000\\u00a0\\t\\n ")
for value in inputs:
    try:
        title_tools.normalize_title(value)
    except ValueError as error:
        assert str(error) == "标题不能为空或仅含空白"
        assert repr(value) not in str(error)
        if value:
            assert value not in str(error)
    else:
        raise AssertionError("Expected ValueError")
print("Empty rejection and fixed error without input body: PASS (4 inputs)")
'''
run('observations', ['python3', '-'], observation.encode())
assert run('git-status-after', ['git', 'status', '--porcelain=v1']) == b''
assert run('git-head-after', ['git', 'log', '-1', '--format=%H']).decode().strip() == CANDIDATE
(OUT / 'result.json').write_text(json.dumps({'result': 'PASS', 'task': 'T01',
    'candidate_commit': CANDIDATE, 'baseline': BASE, 'original_baseline': ORIGINAL,
    'task_tests': 4, 'full_tests_collected': 21, 'later_tests_skipped': 17,
    'condition_scope': 'T01 normalize_title error verified; T03 CLI remains not_run',
    'source_mutated': False}, ensure_ascii=False, indent=2) + '\n')
