from pathlib import Path
import ast, datetime, hashlib, json, os,re,subprocess
B=Path('/private/tmp/sheltie-c002-t16-82c6c55'); W=B/'home/works/2026-10-02-003-t16-spec-dev'; P=B/'project'; E=B/'task-runs/verify-4'; HEAD='0ff54fa35002477c033f306e46089cfda738e3d1'; BASE='71821061f32d9c6496c2d621e673527bc785e4f6'
env=os.environ.copy();env.pop('PYTHONPATH',None);env.update(PYTHONIOENCODING='utf-8',PYTHONPYCACHEPREFIX=str(E/'pycache'))
def run(n,a,i=None):
 s=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(a,input=i,cwd=P,env=env,capture_output=True,check=False,timeout=60)
 (E/(n+'.stdout')).write_bytes(r.stdout);(E/(n+'.stderr')).write_bytes(r.stderr)
 if i is not None:(E/(n+'.stdin')).write_bytes(i)
 (E/(n+'.json')).write_text(json.dumps({'argv':a,'cwd':str(P),'candidate':HEAD,'start_utc':s,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'stdout':str(E/(n+'.stdout')),'stderr':str(E/(n+'.stderr')),'stdin':str(E/(n+'.stdin')) if i is not None else None,'environment_overrides':{'PYTHONPATH':None,'PYTHONIOENCODING':'utf-8','PYTHONPYCACHEPREFIX':str(E/'pycache')},'execution_context':'exec_command/use_default inherited sandbox'},indent=2)+'\n');return r
readme=(P/'README.md').read_text();snippet=re.search(r"python3 - <<'PY'\n(.*?)\nPY",readme,re.S).group(1).encode()
r=run('readme-functions-exact',['python3','-'],snippet);assert (r.returncode,r.stdout,r.stderr)==(0,'AbC 你好，世界！\nAbC 你好，世界！\n'.encode(),b'')
raw=(W/'start-inputs/request').read_bytes();(E/'original-request.bytes').write_bytes(raw)
(E/'sdk-sandbox-header.bytes').write_bytes(Path('/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/usr/include/sandbox.h').read_bytes())
for f in ['network-denial.json','network-denial.stdout','network-denial.stderr','nested-sandbox-attempt.json']:(E/('root-environment-'+f)).write_bytes((B/'environment'/f).read_bytes())
initial_source=run('git-source-baseline',['git','show',BASE+':title_tools.py']).stdout.decode();current=(P/'title_tools.py').read_text()
def spans(s):
 lines=s.splitlines(keepends=True);return {n.name:''.join(lines[n.lineno-1:n.end_lineno]) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
a,b=spans(initial_source),spans(current)
for name in ['normalize_title','extract_title','read_markdown']:assert a[name]==b[name]
assert set(a)==set(b) and set(n for n in a if a[n]!=b[n])=={'build_parser','main'}
for i in [1,2,3]:
 rp=W/f'attempts/verify/occurrence-{i:03d}/attempt-000/outputs/report.md';t=rp.read_text()
 def field(n):return re.search('^'+n+r': (.+)$',t,re.M).group(1)
 approval=Path(field('审批来源'));at=approval.read_text()
 for n,k in [('被验规格','规格'),('被验方案','方案')]:
  f=Path(field(n));assert f.exists();h=hashlib.sha256(f.read_bytes()).hexdigest();assert f'批准的{k}: {h}' in at
 r=run('git-history-T0'+str(i),['git','show','--no-patch','--format=%H%n%P%n%B',field('提交')]);assert r.returncode==0 and ('Task: T0'+str(i)).encode() in r.stdout
 prefix_table=re.findall(r'^\| T\d\d \| [0-9a-f]{40} \|.*$',t,re.M)
 cell=[c.strip() for c in prefix_table[-1].split('|')[1:-1]];ed=Path(cell[-1])
 for gate in ['gate-unittest','gate-compileall']:
  for suffix in ['.json','.stdout','.stderr']:
   f=ed/(gate+suffix);assert f.exists();(E/f'history-T0{i}-{gate}{suffix}').write_bytes(f.read_bytes())
  metadata=json.loads((ed/(gate+'.json')).read_text());assert metadata.get('exit_code',metadata.get('returncode'))==0
inputs=json.loads((E/'input-hashes.json').read_text());assert all(hashlib.sha256(Path(v['path']).read_bytes()).hexdigest()==v['sha256'] for v in inputs.values())
assert run('git-final-head',['git','rev-parse','HEAD']).stdout.strip().decode()==HEAD
assert run('git-final-status',['git','status','--porcelain=v1']).stdout==b''
(E/'final-check-result.json').write_text(json.dumps({'input_hashes_unchanged':True,'previous_functions_exact_bytes_unchanged':True,'historical_approval_hashes_match':True,'historical_gate_raw_evidence_opened':True,'T01_T02_T03_trailers_present':True,'readme_functions_exact_block_passed':True,'network_policy_semantic_limit':'SDK sandbox.h does not document private sandbox_check, so numeric return values are auxiliary observations only. Qualification is limited to these Python subprocesses in declared CODEX seatbelt/network-disabled execution context plus actual EPERM, empty venv and CLI behavior; not Host trust or universal-protocol proof.'},ensure_ascii=False,indent=2)+'\n')
print('Historical approval hashes, raw gates, Task trailers, preserved source bytes, exact README examples and final frozen inputs passed')
