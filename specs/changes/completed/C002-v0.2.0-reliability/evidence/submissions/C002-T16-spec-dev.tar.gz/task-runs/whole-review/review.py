from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

B = Path('/private/tmp/sheltie-c002-t16-82c6c55')
P = B / 'project'
W = B / 'home/works/2026-10-02-003-t16-spec-dev'
E = B / 'task-runs/whole-review'
E.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env.pop('PYTHONPATH', None)
env['PYTHONIOENCODING'] = 'utf-8'
env['PYTHONPYCACHEPREFIX'] = str(E / 'pycache')
baseline = '2f88d59b0d214967b64b285e96d764f26bc71c30'

def run(name, argv, stdin=None):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    r = subprocess.run(argv, cwd=P, env=env, input=stdin, capture_output=True, timeout=60)
    (E / (name + '.stdout')).write_bytes(r.stdout)
    (E / (name + '.stderr')).write_bytes(r.stderr)
    if stdin is not None:
        (E / (name + '.stdin')).write_bytes(stdin)
    (E / (name + '.json')).write_text(json.dumps(dict(argv=argv, cwd=str(P), start_utc=start,
        end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), seconds=time.monotonic()-tick,
        exit_code=r.returncode, stdin_path=str(E/(name+'.stdin')) if stdin is not None else None,
        environment_overrides={k:env[k] for k in ('PYTHONIOENCODING','PYTHONPYCACHEPREFIX')},
        removed_environment=['PYTHONPATH'], sandbox_environment={k:env.get(k) for k in ('CODEX_SANDBOX','CODEX_SANDBOX_NETWORK_DISABLED')}), ensure_ascii=False, indent=2))
    return r

hashes = {}
def capture(name, path):
    data = path.read_bytes()
    (E / (name + '.bytes')).write_bytes(data)
    hashes[str(path)] = hashlib.sha256(data).hexdigest()
    return data.decode()

brief = capture('brief', W/'attempts/review/occurrence-001/attempt-000/brief.md')
for name,path,digest in re.findall(r'^\| (\w+) \| (/[^|]+?) \| ([0-9a-f]{64}) \|',brief,re.M):
    capture('input-'+name, Path(path))
    assert hashes[path] == digest, (name, hashes[path], digest)

initial_hashes = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [P/'title_tools.py',P/'README.md',P/'tests/test_title_tools.py',P/'tests/test_read_markdown.py']}
head = run('git-head',['git','rev-parse','HEAD']).stdout.decode().strip()
assert head == '0ff54fa35002477c033f306e46089cfda738e3d1'
assert not run('git-status-before',['git','status','--porcelain=v1']).stdout
assert not run('git-diff-check',['git','diff','--check',baseline+'..HEAD']).returncode
assert not run('git-original-ancestor',['git','merge-base','--is-ancestor',baseline,head]).returncode
run('git-stat',['git','diff',baseline+'..HEAD','--stat'])
full = run('git-full-diff',['git','diff',baseline+'..HEAD'])
assert full.returncode == 0
run('git-all-commits',['git','log','--reverse','--format=%H %P%n%B',baseline+'..HEAD'])
for p in ('title_tools.py','tests/test_title_tools.py','tests/test_read_markdown.py','README.md'):
    capture('candidate-'+p.replace('/','-'),P/p)
    run('diff-'+p.replace('/','-'),['git','diff',baseline+'..HEAD','--',p])

r=run('gate-unittest',['python3','-m','unittest','discover','-s','tests','-v'])
assert r.returncode==0 and b'Ran 26 tests' in r.stderr and b'skipped' not in r.stderr
assert run('gate-compileall',['python3','-m','compileall','-q','title_tools.py','tests']).returncode==0

def rows(text):
    section = text.split('## 已验证任务',1)[1].split('\n## ',1)[0]
    return re.findall(r'^\| T\d\d \| [0-9a-f]{40} \| [0-9a-f]{40} \| [^\n]+$',section,re.M)

reports=[]
for i in range(1,5):
    report_path=W/f'attempts/verify/occurrence-{i:03}/attempt-000/outputs/report.md'
    text=capture(f'history-verify-{i}',report_path)
    assert text.startswith('通过') and f'原始基线: {baseline}' in text
    reports.append(text)
    change=capture(f'history-implement-{i}',W/f'attempts/implement/occurrence-{i:03}/attempt-000/outputs/change.md')
    assert rows(change)==rows(text)[:-1]
    parts=[s.strip() for s in rows(text)[-1].strip('|').split('|')]
    task,task_base,candidate,approval_path,verification_path,evidence_path=parts
    assert task==f'T{i:02}' and verification_path==str(report_path)
    assert run(f'git-parent-{task}',['git','rev-parse',candidate+'^']).stdout.decode().strip()==task_base
    msg=run(f'git-message-{task}',['git','show','-s','--format=%B',candidate]).stdout.decode()
    assert f'Task: {task}' in msg
    assert not run(f'git-ancestor-{task}',['git','merge-base','--is-ancestor',candidate,head]).returncode
    approval=capture(f'approval-{task}',Path(approval_path))
    assert approval.startswith('通过\n') and '错误信息不得回显输入正文' in approval
    spec_path=re.search(r'^被验规格: (.+)$',text,re.M).group(1)
    plan_path=re.search(r'^被验方案: (.+)$',text,re.M).group(1)
    for key,path in [('spec',spec_path),('plan',plan_path)]:
        capture(f'history-{task}-{key}',Path(path))
        assert hashes[path] in approval
    for gate in ('gate-unittest','gate-compileall'):
        raw_path=Path(evidence_path)/(gate+'.json')
        metadata=json.loads(capture(f'history-{task}-{gate}',raw_path))
        assert metadata.get('exit_code',metadata.get('returncode'))==0
        capture(f'history-{task}-{gate}-stdout',Path(evidence_path)/(gate+'.stdout'))
        capture(f'history-{task}-{gate}-stderr',Path(evidence_path)/(gate+'.stderr'))
    if i>1:
        assert rows(text)[:-1]==rows(reports[i-2])
        assert f'继承来源: {W}/attempts/verify/occurrence-{i-1:03}/attempt-000/outputs/report.md' in text

for key in ('plan','tasks'):
    text=(E/f'input-{key}.bytes').read_text()
    assert rows(text)==rows(reports[1]) and rows(reports[3])[:2]==rows(text)
for key in ('plan','tasks'):
    text=capture('initial-'+key,W/f'attempts/plan/occurrence-001/attempt-000/outputs/{key}.md')
    assert rows(text)==[]
human=capture('human-decisions',B/'human-decisions.json')
decisions=json.loads(human)['decisions']
old=next(x for x in decisions if x.get('question_id')=='call_ZWTMsF6X81GPHikRt9wXUSPy/0')
replan=next(x for x in decisions if x.get('question_id')=='call_y1C96BSiygLZkIjKbGZZMMji/0')
new=next(x for x in decisions if x.get('question_id')=='call_bAUqDu6CHZknYa5vxVjQCRWj/0')
assert old['answer']=='通过方案，附上述条件' and old['condition']=='错误信息不得回显输入正文'
assert replan['answer']=='同意上述重规划'
assert new['answer']=='批准新版，保留原条件' and new['condition']==old['condition']
assert new['spec_sha256']==hashlib.sha256((E/'input-spec.bytes').read_bytes()).hexdigest()
assert new['plan_sha256']==hashlib.sha256((E/'input-plan.bytes').read_bytes()).hexdigest()
assert decisions.index(old)<decisions.index(replan)<decisions.index(new)
capture('replanning-decision',W/'attempts/escalate/occurrence-001/attempt-000/outputs/decision.md')
for i in (1,2):
    for key in ('plan','tasks'):
        reviewed=W/f'attempts/plan-review/occurrence-{i:03}/attempt-000/outputs/reviewed-{key}.md'
        text=capture(f'reviewed-{i}-{key}',reviewed)
        source=W/f'attempts/plan/occurrence-{i:03}/attempt-000/outputs/{key}.md'
        assert reviewed.read_bytes()==source.read_bytes()
capture('original-request',W/'start-inputs/request')
source=(P/'title_tools.py').read_text()
tree=ast.parse(source)
assert not any(isinstance(n,ast.Raise) and isinstance(n.exc,ast.Call) and isinstance(n.exc.func,ast.Name) and n.exc.func.id=='NotImplementedError' for n in ast.walk(tree))
assert not any(isinstance(n,ast.Pass) for n in ast.walk(tree))
assert all(not ('skip' in ast.unparse(d)) for n in ast.walk(ast.parse((P/'tests/test_title_tools.py').read_text())) if isinstance(n,(ast.FunctionDef,ast.ClassDef)) for d in n.decorator_list)
mutations={'mutmut_command':shutil.which('mutmut'),'cosmic_ray_command':shutil.which('cosmic-ray'),'status':'not_run'}
assert not mutations['mutmut_command'] and not mutations['cosmic_ray_command'], 'Installed mutation tool requires separate execution'
(E/'mutation-status.json').write_text(json.dumps(mutations,indent=2))
assert initial_hashes=={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in initial_hashes}
assert not run('git-status-after',['git','status','--porcelain=v1']).stdout
assert run('git-final-head',['git','rev-parse','HEAD']).stdout.decode().strip()==head
(E/'closure.json').write_text(json.dumps(dict(head=head,baseline=baseline,input_hashes=hashes,project_hashes=initial_hashes,
    verified_rows=rows(reports[3]),prefix_verified=True,approvals_verified=True,gates='passed',mutation=mutations),ensure_ascii=False,indent=2))
print('Whole baseline diff, 26 tests without skips, compileall, four-task source chain and approvals verified.')
