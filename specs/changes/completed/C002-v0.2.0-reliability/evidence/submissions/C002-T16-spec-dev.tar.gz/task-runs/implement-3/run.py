import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/private/tmp/sheltie-c002-t16-82c6c55')
WORK = ROOT / 'home/works/2026-10-02-003-t16-spec-dev'
PROJECT = ROOT / 'project'
OUT = ROOT / 'task-runs/implement-3'
ENV = dict(os.environ)
ENV.pop('PYTHONPATH', None)
ENV.update(PYTHONIOENCODING='utf-8', PYTHONPYCACHEPREFIX=str(OUT / 'pycache'))

def run(name, argv, stdin=None):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    if stdin is not None:
        (OUT / (name + '.stdin')).write_bytes(stdin)
    result = subprocess.run(argv, cwd=PROJECT, env=ENV, input=stdin,
                            capture_output=True, check=False, timeout=120)
    (OUT / (name + '.stdout')).write_bytes(result.stdout)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    record = dict(argv=argv, cwd=str(PROJECT), started=start,
                  finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  exit_code=result.returncode,
                  environment_overrides={'PYTHONIOENCODING': 'utf-8',
                                         'PYTHONPYCACHEPREFIX': str(OUT / 'pycache')},
                  environment_removed=['PYTHONPATH'],
                  stdin=str(OUT / (name + '.stdin')) if stdin is not None else None,
                  stdout=str(OUT / (name + '.stdout')),
                  stderr=str(OUT / (name + '.stderr')))
    (OUT / (name + '.json')).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    print(name, result.returncode)
    return result

def rows(text):
    return [line for line in text.splitlines() if re.match(r'\| T\d\d \| [0-9a-f]{40} \|', line)]

if sys.argv[1] == 'init':
    brief = WORK / 'attempts/implement/occurrence-003/attempt-000/brief.md'
    (OUT / 'brief.bytes').write_bytes(brief.read_bytes())
    inputs = {}
    for name, path, expected in re.findall(r'^\| (\w+) \| ([^|]+) \| ([0-9a-f]{64}) \|$', brief.read_text(), re.M):
        path = Path(path.strip())
        data = path.read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        assert actual == expected, (name, actual, expected)
        (OUT / ('input-' + name + '.bytes')).write_bytes(data)
        inputs[name] = dict(path=str(path), expected=expected, actual=actual)
    (OUT / 'input-hashes.json').write_text(json.dumps(inputs, ensure_ascii=False, indent=2) + '\n')
    decision = (OUT / 'input-decision.bytes').read_text()
    assert decision.splitlines()[0] == '通过'
    assert '批准的规格: ' + inputs['spec']['actual'] in decision
    assert '批准的方案: ' + inputs['plan']['actual'] in decision
    assert '错误信息不得回显输入正文' in decision
    report = (OUT / 'input-report.bytes').read_text()
    plan = (OUT / 'input-plan.bytes').read_text()
    tasks = (OUT / 'input-tasks.bytes').read_text()
    scaffold = (OUT / 'input-scaffold.bytes').read_text()
    original = '2f88d59b0d214967b64b285e96d764f26bc71c30'
    for text in [report, plan, tasks, scaffold]:
        assert re.search(r'原始基线[^\n]*' + original, text)
        assert rows(text) == rows(report)
    assert [line.split('|')[1].strip() for line in rows(report)] == ['T01', 'T02']
    for line in rows(report):
        fields = [field.strip() for field in line.split('|')[1:-1]]
        assert len(fields) == 6
        for path in fields[3:]:
            assert Path(path).exists()
        approval = Path(fields[3]).read_bytes()
        old_report = Path(fields[4]).read_bytes()
        (OUT / (fields[0] + '-approval.bytes')).write_bytes(approval)
        (OUT / (fields[0] + '-report.bytes')).write_bytes(old_report)
        assert approval.splitlines()[0] == '通过'.encode()
        assert re.search(r'原始基线[^\n]*' + original, old_report.decode())
        assert old_report.decode().splitlines()[0].startswith('通过')
    (OUT / 'approval-prefix.json').write_text(json.dumps(dict(
        original_baseline=original, inherited_rows=rows(report), approval=inputs['decision']['path'],
        condition='错误信息不得回显输入正文', next_task='T03'), ensure_ascii=False, indent=2) + '\n')
    selector = scaffold.split("python3 - T03 <<'PY'\n", 1)[1].split('\nPY\n', 1)[0] + '\n'
    (OUT / 'task-selector.stdin').write_text(selector)
    assert (ROOT / 'task-runs/scaffold-2/task-selector.stdin').read_bytes() == selector.encode()
    status = run('git-status-before', ['git', 'status', '--porcelain=v1'])
    assert status.returncode == 0 and status.stdout == b''
    head = run('git-head-before', ['git', 'rev-parse', 'HEAD'])
    assert head.stdout.strip() == b'ba56d3fc3a25a9ca170183fd2315beb0ff37db5b'
    assert run('git-original-ancestor', ['git', 'merge-base', '--is-ancestor', original, 'HEAD']).returncode == 0
    assert run('git-verified-ancestor', ['git', 'merge-base', '--is-ancestor', '6773f932765895735a5786220653440afcba2d8f', 'HEAD']).returncode == 0
    for path in ['title_tools.py', 'tests/test_read_markdown.py']:
        (OUT / ('before-' + path.replace('/', '-'))).write_bytes((PROJECT / path).read_bytes())
    fixture = OUT / 'permission-fixture.md'
    content = b'# PRIVATE_BODY_UNREADABLE\r\n'
    fixture.write_bytes(content)
    (OUT / 'permission-fixture.before.bytes').write_bytes(content)
    fixture.chmod(0)
    try:
        probe = run('permission-precondition', ['python3', '-S', '-c',
            'import pathlib, sys; pathlib.Path(sys.argv[1]).read_bytes()', str(fixture)])
        assert probe.returncode != 0 and b'PermissionError' in probe.stderr
    finally:
        fixture.chmod(0o600)
    after = fixture.read_bytes()
    (OUT / 'permission-fixture.after.bytes').write_bytes(after)
    assert after == content
elif sys.argv[1] == 'red':
    path = PROJECT / 'tests/test_read_markdown.py'
    before = (OUT / 'before-tests-test_read_markdown.py').read_bytes()
    assert path.read_bytes() == before
    assert before.count(b'    @unittest.skip("T03")\n') == 5
    path.write_bytes(before.replace(b'    @unittest.skip("T03")\n', b''))
    red = run('task-tests-red', ['python3', '-', 'T03'], (OUT / 'task-selector.stdin').read_bytes())
    assert red.returncode == 1
    assert b'Ran 5 tests' in red.stderr and b'FAILED (errors=5)' in red.stderr
    assert red.stderr.count(b'NotImplementedError') >= 5
elif sys.argv[1] == 'first':
    result = run('first-test-green', ['python3', '-m', 'unittest', 'discover', '-s', 'tests',
        '-p', 'test_read_markdown.py', '-k', 'test_read_markdown_returns_utf8_text_without_heading_validation', '-v'])
    assert result.returncode == 0 and b'Ran 1 test' in result.stderr
elif sys.argv[1] == 'green':
    result = run('task-tests-green', ['python3', '-', 'T03'], (OUT / 'task-selector.stdin').read_bytes())
    assert result.returncode == 0 and b'Ran 5 tests' in result.stderr and b'skipped=' not in result.stderr
    result = run('gate-unittest', ['python3', '-m', 'unittest', 'discover', '-s', 'tests', '-v'])
    assert result.returncode == 0 and b'Ran 26 tests' in result.stderr and b'OK (skipped=12)' in result.stderr
    assert run('gate-compileall', ['python3', '-m', 'compileall', '-q', 'title_tools.py', 'tests']).returncode == 0
    assert run('git-diff-check', ['git', 'diff', '--check']).returncode == 0
    result = run('git-diff', ['git', 'diff', '--', 'title_tools.py', 'tests/test_read_markdown.py'])
    assert result.returncode == 0
    before = (OUT / 'before-tests-test_read_markdown.py').read_bytes()
    assert (PROJECT / 'tests/test_read_markdown.py').read_bytes() == before.replace(b'    @unittest.skip("T03")\n', b'')
    source = (PROJECT / 'title_tools.py').read_bytes()
    old = (OUT / 'before-title_tools.py').read_bytes()
    replacement = b'    with open(path, "r", encoding="utf-8") as source:\n        return source.read()'
    assert source == old.replace(b'    raise NotImplementedError  # T03', replacement)
    assert source.count(b'raise NotImplementedError  # T04') == 3
    for path in ['title_tools.py', 'tests/test_read_markdown.py']:
        (OUT / ('candidate-' + path.replace('/', '-'))).write_bytes((PROJECT / path).read_bytes())
elif sys.argv[1] == 'bytes':
    cases = {
        'utf8-no-heading': '正文 AbC 你好，世界！\n\u3000没有标题\t保留空白\n'.encode(),
        'crlf-heading': '## 二级\r\n# \u3000AbC\t\t你好，世界！\r\n# 后续\r\n'.encode(),
        'invalid-utf8': b'PRIVATE_BODY_INVALID_ENCODING\xff\n',
        'unreadable': b'# PRIVATE_BODY_UNREADABLE\n',
        'missing': None,
    }
    stdin = b'''import json, sys
import title_tools
try:
    text = title_tools.read_markdown(sys.argv[1])
except (OSError, UnicodeError) as error:
    print(json.dumps({"type": type(error).__name__, "message": str(error)}, ensure_ascii=False), file=sys.stderr)
    raise SystemExit(2)
else:
    sys.stdout.write(text)
'''
    manifest = {}
    for name, content in cases.items():
        path = OUT / ('fixture-' + name + '.md')
        assert not path.exists()
        if content is not None:
            path.write_bytes(content)
            (OUT / (name + '.before.bytes')).write_bytes(path.read_bytes())
        if name == 'unreadable':
            path.chmod(0)
        try:
            if name == 'unreadable':
                probe = run('bytes-permission-precondition', ['python3', '-S', '-c',
                    'import pathlib, sys; pathlib.Path(sys.argv[1]).read_bytes()', str(path)])
                assert probe.returncode != 0 and b'PermissionError' in probe.stderr
            result = run('bytes-' + name, ['python3', '-', str(path)], stdin)
            if name in ['utf8-no-heading', 'crlf-heading']:
                assert result.returncode == 0 and not result.stderr
                assert result.stdout == content.replace(b'\r\n', b'\n')
            else:
                assert result.returncode == 2 and not result.stdout
                error = json.loads(result.stderr)
                expected = {'invalid-utf8': 'UnicodeDecodeError', 'unreadable': 'PermissionError', 'missing': 'FileNotFoundError'}[name]
                assert error['type'] == expected and error['message'].strip()
                assert 'PRIVATE_BODY' not in error['message']
                if content is not None:
                    assert repr(content) not in error['message']
                    assert content.decode(errors='replace') not in error['message']
        finally:
            if name == 'unreadable':
                path.chmod(0o600)
        if content is not None:
            after = path.read_bytes()
            (OUT / (name + '.after.bytes')).write_bytes(after)
            assert after == content
            manifest[name] = dict(path=str(path), before_sha256=hashlib.sha256(content).hexdigest(),
                                  after_sha256=hashlib.sha256(after).hexdigest(), preserved=True)
        else:
            assert not path.exists()
            manifest[name] = dict(path=str(path), before_exists=False, after_exists=False)
    (OUT / 'file-byte-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
elif sys.argv[1] == 'commit':
    status = run('git-status-precommit', ['git', 'status', '--porcelain=v1'])
    assert status.returncode == 0
    assert sorted(status.stdout.decode().splitlines()) == [' M tests/test_read_markdown.py', ' M title_tools.py']
    baseline = run('git-task-baseline', ['git', 'rev-parse', 'HEAD'])
    assert baseline.stdout.strip() == b'ba56d3fc3a25a9ca170183fd2315beb0ff37db5b'
    message = '''feat(reader): 实现 UTF-8 只读文件读取

以显式 UTF-8 和只读模式读取指定文件，保留读取及解码错误类别，不校验标题。
仅启用 T03 五项测试，保留已有九项通过测试及 T04 十二项禁用测试。
五项测试先全部占位失败后通过；真实不可读前置产生 PermissionError。
unittest 收集 26 项、十四项通过及十二项禁用；compileall 退出 0。
成功、非法编码及不可读文件的前后原始字节一致，不存在文件未创建。

Task: T03
Work: 2026-10-02-003-t16-spec-dev
Agent: GPT-6
'''
    (OUT / 'commit-message.txt').write_text(message)
    assert run('git-add', ['git', 'add', '--', 'title_tools.py', 'tests/test_read_markdown.py']).returncode == 0
    assert run('git-staged-check', ['git', 'diff', '--cached', '--check']).returncode == 0
    staged = run('git-staged-paths', ['git', 'diff', '--cached', '--name-only'])
    assert set(staged.stdout.decode().splitlines()) == {'title_tools.py', 'tests/test_read_markdown.py'}
    assert run('git-commit', ['git', 'commit', '-F', str(OUT / 'commit-message.txt')]).returncode == 0
    head = run('git-head-after', ['git', 'rev-parse', 'HEAD'])
    parent = run('git-candidate-parent', ['git', 'rev-parse', 'HEAD^'])
    assert parent.stdout.strip() == baseline.stdout.strip()
    assert run('git-message', ['git', 'log', '-1', '--format=%B']).returncode == 0
    status = run('git-status-after', ['git', 'status', '--porcelain=v1'])
    assert status.returncode == 0 and status.stdout == b''
    (OUT / 'result.json').write_text(json.dumps(dict(task='T03', original_baseline='2f88d59b0d214967b64b285e96d764f26bc71c30',
        task_baseline=baseline.stdout.decode().strip(), candidate=head.stdout.decode().strip(), enabled_tests=5,
        gate_unittest={'exit_code': 0, 'collected': 26, 'passed': 14, 'skipped': 12},
        gate_compileall={'exit_code': 0}, independent_verification='pending'), ensure_ascii=False, indent=2) + '\n')
elif sys.argv[1] == 'report':
    result = json.loads((OUT / 'result.json').read_text())
    inherited = json.loads((OUT / 'approval-prefix.json').read_text())['inherited_rows']
    target = WORK / 'attempts/implement/occurrence-003/attempt-000/outputs/change.md'
    report_path = WORK / 'attempts/verify/occurrence-002/attempt-000/outputs/report.md'
    decision_path = WORK / 'attempts/plan-review/occurrence-002/attempt-000/outputs/decision.md'
    text = f'''完成 T03

基线: {result['task_baseline']}
提交: {result['candidate']}
原始基线: {result['original_baseline']}
继承来源: {report_path}
修复轮次: 0
启用的测试: 5
改动文件:
- title_tools.py
- tests/test_read_markdown.py
门禁:
- python3 -m unittest discover -s tests -v: 通过
- python3 -m compileall -q title_tools.py tests: 通过
备注: 只填 read_markdown 的 UTF-8 只读函数体、移除五项 T03 skip；原九项启用测试及三个 T04 占位、十二项 T04 skip 均保留。候选待独立 verify，本轮不追加已验证事实。

审批来源: {decision_path}
批准的规格: bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38
批准的方案: 557a7ff9d0614ac2c0a69ba59eec3bb8a3ce5c3ea6c26cb6c5b3420bba4ad40d
条件: 错误信息不得回显输入正文。
原始证据: {OUT}/

## 已验证任务

原样保留最新独立 verify#2 的完整 T01/T02 两行；当前 plan/tasks/scaffold 的累计表与之逐字一致，原始基线一致。继承行的历史审批、报告及证据路径实际存在，历史审批首行为通过、报告原始基线相同。原始基线及 T02 最新已验证候选均是当前任务基线的 Git 祖先。

| 任务 | 任务基线 | 候选提交 | 审批来源 | 验证报告 | 原始证据 |
| --- | --- | --- | --- | --- | --- |
''' + '\n'.join(inherited) + f'''

## 本轮执行证据

所有命令 JSON 保存实际 argv、cwd、stdin 路径、起止时间、环境覆盖和退出状态；同名 stdout/stderr 保存原始字节，stdin 命令另存完整全文。输入冻结镜像为 input-*.bytes，任务基线源码/测试为 before-*，候选源码/测试为 candidate-*；input-hashes.json、approval-prefix.json、run.py、result.json 可复核过程。Python 字节码写入本证据目录 pycache，项目 git status 前后干净。

- 审批与继承：brief 所有绑定输入 SHA-256 均匹配，审批首行为通过，批准的规格/方案与当前输入一致，无审批更正；保留错误不回显正文条件。完整新选择器 stdin 与 scaffold-2/task-selector.stdin 原字节一致。
- 先红后绿：task-tests-red 使用完整四任务选择器精确选择 T03 五项，五项全部因 NotImplementedError 失败、无 skip；先完成 UTF-8 无标题正例 first-test-green，再完整 task-tests-green 五项实际运行通过、无 skip。未改测试断言或快照。
- 完整门禁：gate-unittest 收集 26 项，T01/T02 九项与 T03 五项实际通过、T04 十二项禁用；OK (skipped=12)。gate-compileall 退出 0。
- 真实权限前置：permission-precondition 与 bytes-permission-precondition 均以 python3 -S -c 的 pathlib.read_bytes 对真实 chmod(0) 文件运行，退出非零且原 stderr 含 PermissionError；随后被测读取保留 PermissionError 类别。未 mock 或 skip，finally 恢复权限后核字节一致。
- 文件边界：bytes-utf8-no-heading、bytes-crlf-heading 成功；bytes-invalid-utf8、bytes-unreadable、bytes-missing 分别保留 UnicodeDecodeError、PermissionError、FileNotFoundError，原始 stdout/stderr 和退出状态实际保存。错误说明非空且未回显 PRIVATE_BODY、完整正文或其 repr。file-byte-manifest.json、各例 before/after.bytes 保存成功及失败已有文件的完整原字节相等证据；missing 前后不存在。
- Git：git-task-baseline、git-staged-paths、git-commit、git-head-after、git-candidate-parent、git-message、git-status-after 保存原文。提交只含两项白名单文件，候选父提交就是任务基线，Task: T03、Work、Agent trailer 完整，提交后工作区干净。

本轮读取函数通过不代表 T04 CLI 协议、禁止联网环境、整体需求或 C002-T16 完成；不修改绑定输入、Sheltie 仓库或引擎状态，无 submit。
'''
    assert len(text.encode()) <= 32768
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
    assert rows(target.read_text()) == inherited
    print(str(target))
    print(result['candidate'])
