import sys, unittest
TASK_TESTS = {
  "T01": [
    "test_normalize_collapses_mixed_unicode_whitespace",
    "test_normalize_preserves_chinese_punctuation_and_case",
    "test_normalize_rejects_empty_and_whitespace_only",
    "test_normalize_keeps_single_word"
  ],
  "T02": [
    "test_extract_ignores_nonmatching_heading_prefixes",
    "test_extract_normalizes_first_heading",
    "test_extract_chooses_first_matching_heading",
    "test_extract_rejects_missing_heading",
    "test_extract_rejects_empty_first_heading_without_fallback"
  ],
  "T03": [
    "test_cli_normalize_prints_one_line",
    "test_cli_extract_uses_explicit_utf8_file_and_preserves_bytes",
    "test_cli_normalize_rejects_whitespace",
    "test_cli_extract_rejects_missing_heading",
    "test_cli_extract_rejects_empty_first_heading",
    "test_cli_extract_rejects_non_utf8_file",
    "test_cli_extract_rejects_missing_file",
    "test_cli_extract_reports_unreadable_file",
    "test_cli_rejects_missing_required_arguments",
    "test_cli_rejects_unknown_subcommand",
    "test_cli_runs_without_site_packages",
    "test_imports_are_standard_library_only"
  ]
}
if len(sys.argv) != 2 or sys.argv[1] not in TASK_TESTS:
    raise SystemExit("须选择 T01、T02 或 T03；T04 是文档任务")
expected = set(TASK_TESTS[sys.argv[1]])
def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item
selected = [test for test in flatten(unittest.defaultTestLoader.discover("tests"))
            if test.id().rsplit(".", 1)[-1] in expected]
found = {test.id().rsplit(".", 1)[-1] for test in selected}
if not selected or found != expected or len(selected) != len(expected):
    raise SystemExit("测试名单为空、重复或与任务卡不符")
print(f"{sys.argv[1]}: selected {len(selected)} tests", flush=True)
result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(selected))
raise SystemExit(0 if result.wasSuccessful() else 1)
