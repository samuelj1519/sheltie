from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json, os, shutil, subprocess, tempfile
base=Path('/private/tmp/sheltie-c002-t16-82c6c55'); project=base/'project'; evidence=base/'task-runs/scaffold-2'
selector=(evidence/'task-selector.stdin').read_bytes()
env=os.environ.copy(); env.pop('PYTHONPATH',None); env['PYTHONIOENCODING']='utf-8'; env['PYTHONPYCACHEPREFIX']=str(evidence/'pycache')
def run(name,argv,cwd=project,stdin=None,expected=0):
    start=datetime.now(timezone.utc).isoformat()
    result=subprocess.run(argv,cwd=cwd,env=env,input=stdin,capture_output=True,check=False,timeout=30)
    for stream in ['stdout','stderr']:
        (evidence/f'{name}.{stream}').write_bytes(getattr(result,stream))
    if stdin is not None: (evidence/f'{name}.stdin').write_bytes(stdin)
    record={'argv':argv,'cwd':str(cwd),'stdin':str(evidence/f'{name}.stdin') if stdin is not None else None,'environment_overrides':{'PYTHONIOENCODING':'utf-8','PYTHONPYCACHEPREFIX':env['PYTHONPYCACHEPREFIX'],'PYTHONPATH':None},'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'exit_code':result.returncode,'stdout':str(evidence/f'{name}.stdout'),'stderr':str(evidence/f'{name}.stderr'),'expected_exit_code':expected}
    (evidence/f'{name}.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    assert result.returncode==expected,(name,result.returncode,result.stderr.decode(errors='replace'))
    return result
run('git-head-before',['git','rev-parse','HEAD'])
run('git-status-before-gates',['git','status','--porcelain=v1'])
run('git-diff-before-gates',['git','diff'])
for task in ['T01','T02','T03','T04']:
    run(f'selector-{task}',['python3','-',task],stdin=selector,expected=0 if task in ['T01','T02'] else 1)
run('selector-unknown',['python3','-','UNKNOWN'],stdin=selector,expected=1)
run('selector-empty-manifest',['python3','-','T03'],stdin=selector.replace(b'expected = TASK_TESTS[sys.argv[1]]',b'TASK_TESTS["T03"] = []\nexpected = TASK_TESTS[sys.argv[1]]'),expected=1)
run('selector-duplicate-manifest',['python3','-','T03'],stdin=selector.replace(b'expected = TASK_TESTS[sys.argv[1]]',b'TASK_TESTS["T03"].append(TASK_TESTS["T03"][0])\nexpected = TASK_TESTS[sys.argv[1]]'),expected=1)
run('gate-unittest',['python3','-m','unittest','discover','-s','tests','-v'])
run('gate-compileall',['python3','-m','compileall','-q','title_tools.py','tests'])
formal={str(path.relative_to(project)):hashlib.sha256(path.read_bytes()).hexdigest() for path in [project/'title_tools.py',project/'tests/test_title_tools.py',project/'tests/test_read_markdown.py',project/'README.md']}
# §14: implement only T03 in a disposable copied tree and remove its five skip decorators.
with tempfile.TemporaryDirectory(prefix='scaffold2-trial-',dir=base) as folder:
    trial=Path(folder)
    shutil.copy2(project/'title_tools.py',trial/'title_tools.py'); shutil.copy2(project/'README.md',trial/'README.md'); shutil.copytree(project/'tests',trial/'tests',ignore=shutil.ignore_patterns('__pycache__'))
    source=(trial/'title_tools.py').read_text()
    source=source.replace('    raise NotImplementedError  # T03','    with open(path, "r", encoding="utf-8") as stream:\n        return stream.read()')
    assert source!=(trial/'title_tools.py').read_text()
    (trial/'title_tools.py').write_text(source)
    tests=(trial/'tests/test_read_markdown.py').read_text()
    assert tests.count('@unittest.skip("T03")')==5
    (trial/'tests/test_read_markdown.py').write_text(tests.replace('    @unittest.skip("T03")\n',''))
    for path in [trial/'title_tools.py',trial/'tests/test_read_markdown.py']:
        (evidence/('trial-'+str(path.relative_to(trial)).replace('/','-'))).write_bytes(path.read_bytes())
    run('trial-selector-T03',['python3','-','T03'],cwd=trial,stdin=selector)
    run('trial-gate-unittest',['python3','-m','unittest','discover','-s','tests','-v'],cwd=trial)
    run('trial-gate-compileall',['python3','-m','compileall','-q','title_tools.py','tests'],cwd=trial)
    trial_path=str(trial)
assert not Path(trial_path).exists()
assert formal=={name:hashlib.sha256((project/name).read_bytes()).hexdigest() for name in formal}
# Selector malformed collection or inherited enabled test skips must fail before tests run.
with tempfile.TemporaryDirectory(prefix='scaffold2-selector-',dir=base) as folder:
    copied=Path(folder); (copied/'tests').mkdir()
    run('selector-empty-collection',['python3','-','T03'],cwd=copied,stdin=selector,expected=1)
    shutil.copy2(project/'title_tools.py',copied/'title_tools.py'); shutil.copytree(project/'tests',copied/'tests',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
    readpath=copied/'tests/test_read_markdown.py'; original=readpath.read_text()
    readpath.write_text(original.replace('def test_read_markdown_returns_utf8_text_without_heading_validation','def disabled_read_markdown_returns_utf8_text_without_heading_validation'))
    run('selector-missing-test',['python3','-','T03'],cwd=copied,stdin=selector,expected=1)
    readpath.write_text(original)
    (copied/'tests/test_duplicate.py').write_text(original)
    run('selector-duplicate-collection',['python3','-','T03'],cwd=copied,stdin=selector,expected=1)
    (copied/'tests/test_duplicate.py').unlink()
    titlepath=copied/'tests/test_title_tools.py'
    titlepath.write_text(titlepath.read_text().replace('    def test_normalize_keeps_single_word','    @unittest.skip("T01")\n    def test_normalize_keeps_single_word'))
    run('selector-enabled-test-skipped',['python3','-','T03'],cwd=copied,stdin=selector,expected=1)
# Preserve all old test bytes apart from the approved task marker replacement.
oldtests=(evidence/'before-tests-test_title_tools.py').read_bytes()
assert (project/'tests/test_title_tools.py').read_bytes().replace(b'Task: T04',b'Task: T03').replace(b'@unittest.skip("T04")',b'@unittest.skip("T03")')==oldtests
oldsource=(evidence/'before-title_tools.py').read_bytes(); newsource=(project/'title_tools.py').read_bytes()
assert oldsource.split(b'# Task: T03\ndef read_markdown')[0]==newsource.split(b'# Task: T03\ndef read_markdown')[0]
for path in [project/'title_tools.py',project/'tests/test_title_tools.py',project/'tests/test_read_markdown.py',project/'README.md']:
    (evidence/('candidate-'+str(path.relative_to(project)).replace('/','-'))).write_bytes(path.read_bytes())
run('git-status-after-gates',['git','status','--porcelain=v1'])
(evidence/'result.json').write_text(json.dumps({'formal_file_sha256':formal,'preserved_enabled_tests':9,'total_tests':26,'scaffold_skipped_tests':17,'trial_total_tests':26,'trial_passed_tests':14,'trial_skipped_tests':12,'trial_removed':trial_path,'trial_removed_confirmed':True,'business_acceptance':False,'verified_prefix_rows':2},ensure_ascii=False,indent=2)+'\n')
print('All scaffold gates, positive trial and selector rejection checks passed.')
