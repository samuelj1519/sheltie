from pathlib import Path
import datetime
import json
import os
import subprocess
import sys

ROOT = Path('/private/tmp/sheltie-c002-t16-82c6c55')
PROJECT = ROOT / 'project'
EVIDENCE = ROOT / 'task-runs/implement-4'

def run(name, argv, stdin_path=None):
    env = os.environ.copy()
    env.pop('PYTHONPATH', None)
    overrides = {'PYTHONIOENCODING': 'utf-8',
                 'PYTHONPYCACHEPREFIX': str(EVIDENCE / 'pycache')}
    env.update(overrides)
    stdin = Path(stdin_path).read_bytes() if stdin_path else None
    if stdin is not None:
        (EVIDENCE / (name + '.stdin')).write_bytes(stdin)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=PROJECT, env=env, input=stdin,
                            capture_output=True, check=False, timeout=60)
    ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (EVIDENCE / (name + '.stdout')).write_bytes(result.stdout)
    (EVIDENCE / (name + '.stderr')).write_bytes(result.stderr)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=PROJECT).decode().strip()
    record = {'argv': argv, 'cwd': str(PROJECT), 'head': head,
              'stdin': str(EVIDENCE / (name + '.stdin')) if stdin is not None else None,
              'environment_overrides': overrides, 'environment_removed': ['PYTHONPATH'],
              'started_utc': started, 'ended_utc': ended, 'exit_code': result.returncode,
              'stdout': str(EVIDENCE / (name + '.stdout')),
              'stderr': str(EVIDENCE / (name + '.stderr'))}
    (EVIDENCE / (name + '.json')).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'name': name, 'exit_code': result.returncode}, ensure_ascii=False))
    print(result.stdout.decode('utf-8', errors='replace'), end='')
    print(result.stderr.decode('utf-8', errors='replace'), end='')
    return result

if __name__ == '__main__':
    name, mode, *arguments = sys.argv[1:]
    if mode == 'selector':
        run(name, ['python3', '-', 'T04'], EVIDENCE / 'task-selector.stdin')
    elif mode == 'test':
        run(name, ['python3', '-m', 'unittest', '-v',
                   'test_title_tools.TitleToolsTests.' + arguments[0]])
    elif mode == 'one':
        source = ('import sys, unittest\n'
                  'sys.path.insert(0, "tests")\n'
                  'suite=unittest.defaultTestLoader.loadTestsFromName(' + repr('test_title_tools.TitleToolsTests.' + arguments[0]) + ')\n'
                  'result=unittest.TextTestRunner(verbosity=2).run(suite)\n'
                  'raise SystemExit(0 if result.wasSuccessful() and not result.skipped and result.testsRun==1 else 1)\n')
        path = EVIDENCE / (name + '.source')
        path.write_text(source)
        run(name, ['python3', '-'], path)
    elif mode == 'gate-unittest':
        run(name, ['python3', '-m', 'unittest', 'discover', '-s', 'tests', '-v'])
    elif mode == 'gate-compileall':
        run(name, ['python3', '-m', 'compileall', '-q', 'title_tools.py', 'tests'])
    elif mode == 'command':
        run(name, arguments)
    else:
        raise SystemExit('unknown evidence mode')
