import sys, json, subprocess, datetime
from pathlib import Path
e=Path(__file__).parent
label=sys.argv[1]; argv=json.loads(sys.argv[2]); cwd="/private/tmp/sheltie-c002-t16-82c6c55/project"
stdin=Path(sys.argv[3]).read_bytes() if len(sys.argv)>3 else None
if stdin is not None: (e/(label+".stdin")).write_bytes(stdin)
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=cwd,text=True).strip()
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(argv,cwd=cwd,input=stdin,capture_output=True)
end=datetime.datetime.now(datetime.timezone.utc).isoformat()
(e/(label+".stdout")).write_bytes(r.stdout);(e/(label+".stderr")).write_bytes(r.stderr)
meta={"argv":argv,"cwd":cwd,"candidate_commit":head,"started_at":start,"ended_at":end,"exit_status":r.returncode,"stdout":str(e/(label+".stdout")),"stderr":str(e/(label+".stderr"))}
if stdin is not None: meta["stdin"]=str(e/(label+".stdin"))
(e/(label+".json")).write_text(json.dumps(meta,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(meta,ensure_ascii=False));sys.stdout.flush()
sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr)
