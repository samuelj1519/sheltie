import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from datetime import datetime, timezone

ROOT = Path('/private/tmp/sheltie-c002-t16-82c6c55')
WORK = ROOT / 'home/works/2026-10-02-003-t16-spec-dev'
PROJECT = ROOT / 'project'
OUT = ROOT / 'task-runs/verify-2'
CANDIDATE = '6773f932765895735a5786220653440afcba2d8f'
BASE = '65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c'
ORIGINAL = '2f88d59b0d214967b64b285e96d764f26bc71c30'
ENV = os.environ.copy()
ENV['PYTHONPYCACHEPREFIX'] = str(OUT / 'pycache')
ENV['PYTHONIOENCODING'] = 'utf-8'
ENV.pop('PYTHONPATH', None)
checks = []

def record(name, value):
    (OUT / (name + '.json')).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def check(name, ok, detail):
    checks.append({'name': name, 'passed': bool(ok), 'detail': detail})

def run(name, argv, stdin=None):
    start = datetime.now(timezone.utc).isoformat()
    data = stdin.encode() if stdin is not None else None
    result = subprocess.run(argv, cwd=PROJECT, env=ENV, input=data, capture_output=True, timeout=60)
    (OUT / (name + '.stdout')).write_bytes(result.stdout)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    if data is not None:
        (OUT / (name + '.stdin')).write_bytes(data)
    record(name, {'argv': argv, 'cwd': str(PROJECT), 'candidate': CANDIDATE,
                 'started_at': start, 'ended_at': datetime.now(timezone.utc).isoformat(),
                 'returncode': result.returncode,
                 'environment_overrides': {'PYTHONPYCACHEPREFIX': ENV['PYTHONPYCACHEPREFIX'],
                                           'PYTHONIOENCODING': 'utf-8', 'PYTHONPATH': None},
                 'stdout': str(OUT / (name + '.stdout')), 'stderr': str(OUT / (name + '.stderr')),
                 'stdin': str(OUT / (name + '.stdin')) if data is not None else None})
    return result

def rows(text):
    return [line for line in text.splitlines() if re.match(r'^\| T\d\d \|', line)]

brief = (WORK / 'attempts/verify/occurrence-002/attempt-000/brief.md').read_text()
inputs = {}
for line in brief.splitlines():
    fields = [p.strip() for p in line.split('|')]
    if len(fields) == 5 and re.fullmatch('[0-9a-f]{64}', fields[3]):
        data = Path(fields[2]).read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        inputs[fields[1]] = {'path': fields[2], 'expected': fields[3], 'actual': actual, 'matches': actual == fields[3]}
        (OUT / ('input-' + fields[1] + '.bytes')).write_bytes(data)
record('input-hashes', inputs)
check('brief-input-hashes', len(inputs) == 8 and all(i['matches'] for i in inputs.values()), inputs)
texts = {k: Path(v['path']).read_text() for k, v in inputs.items()}
check('project-pointer', texts['project'].strip() == str(PROJECT), texts['project'])
approved = {key: re.search('批准的' + key + r': ([0-9a-f]{64})', texts['decision']).group(1) for key in ['规格', '方案']}
check('approval', texts['decision'].splitlines()[0] == '通过' and approved['规格'] == inputs['spec']['actual'] and approved['方案'] == inputs['plan']['actual'], approved)
check('approval-condition', '条件：错误信息不得回显输入正文。' in texts['decision'], '错误信息不得回显输入正文')
inherit_path = Path(re.search(r'^继承来源: (.+)$', texts['change'], re.M).group(1))
inherit = inherit_path.read_text()
(OUT / 'inherited-report.bytes').write_bytes(inherit_path.read_bytes())
previous_change_path = Path(re.search(r'^本轮变更: (.+)$', inherit, re.M).group(1))
previous_change = previous_change_path.read_text()
(OUT / 'previous-change.bytes').write_bytes(previous_change_path.read_bytes())
previous_inherit_path = Path(re.search(r'^继承来源: (.+)$', inherit, re.M).group(1))
previous_inherit = previous_inherit_path.read_text()
prefix_ok = rows(texts['change']) == rows(inherit) and len(rows(inherit)) == 1 and rows(inherit)[0].startswith('| T01 |')
prefix_ok = prefix_ok and not rows(previous_change) and not rows(previous_inherit) and not rows(texts['tasks']) and not rows(texts['plan'])
prefix_ok = prefix_ok and inherit.splitlines()[0] == '通过，下一任务 T02' and f'提交: {BASE}' in inherit
prefix_ok = prefix_ok and all(ORIGINAL in text for text in [texts['change'], texts['plan'], texts['tasks'], inherit, previous_change, previous_inherit])
record('approval-prefix', {'approved': approved, 'inheritance': str(inherit_path), 'previous_change': str(previous_change_path),
                          'previous_inheritance': str(previous_inherit_path), 'original': ORIGINAL,
                          'change_rows': rows(texts['change']), 'inherited_rows': rows(inherit), 'passed': prefix_ok})
check('inherited-T01-prefix-original', prefix_ok, rows(inherit))
for row in rows(inherit):
    fields = [p.strip() for p in row.split('|')][1:-1]
    check('inherited-row-six-fields', len(fields) == 6 and all(fields), fields)
    check('inherited-evidence-exists', Path(fields[4]).is_file() and Path(fields[5]).is_dir(), fields[4:])

head = run('git-head', ['git', 'log', '-1', '--format=%H'])
status = run('git-status-before', ['git', 'status', '--porcelain=v1'])
check('candidate-head', head.returncode == 0 and head.stdout.decode().strip() == CANDIDATE, head.stdout.decode())
check('worktree-clean-before', status.returncode == 0 and not status.stdout, status.stdout.decode())
parent = run('git-candidate-parent', ['git', 'rev-parse', CANDIDATE + '^'])
ancestor = run('git-original-ancestor', ['git', 'merge-base', '--is-ancestor', ORIGINAL, CANDIDATE])
check('task-baseline-parent-original', parent.returncode == 0 and parent.stdout.decode().strip() == BASE and ancestor.returncode == 0 and f'基线: {BASE}' in texts['change'], parent.stdout.decode())
names = run('git-range-files', ['git', 'diff', '--name-only', BASE + '..' + CANDIDATE])
diff = run('git-range-diff', ['git', 'diff', BASE + '..' + CANDIDATE])
test_diff = run('git-tests-diff', ['git', 'diff', BASE + '..' + CANDIDATE, '--', 'tests/test_title_tools.py'])
old_tests = run('git-old-tests', ['git', 'show', BASE + ':tests/test_title_tools.py'])
old_source = run('git-old-source', ['git', 'show', BASE + ':title_tools.py'])
check('task-file-whitelist', names.returncode == 0 and set(names.stdout.decode().splitlines()) == {'title_tools.py', 'tests/test_title_tools.py'}, names.stdout.decode())
source = (PROJECT / 'title_tools.py').read_bytes()
tests = (PROJECT / 'tests/test_title_tools.py').read_bytes()
snapshot = {}
for file in ['title_tools.py', 'tests/test_title_tools.py', 'README.md']:
    data = (PROJECT / file).read_bytes()
    snapshot[file] = hashlib.sha256(data).hexdigest()
    (OUT / ('candidate-' + file.replace('/', '-'))).write_bytes(data)
check('tests-only-five-T02-skip-removals', old_tests.returncode == 0 and old_tests.stdout.count(b'    @unittest.skip("T02")\n') == 5 and old_tests.stdout.replace(b'    @unittest.skip("T02")\n', b'') == tests, '全文字节相等；只删除五行 T02 skip')
before_tree = ast.parse(old_source.stdout)
after_tree = ast.parse(source)
before_nodes = {n.name: ast.dump(n, include_attributes=False) for n in before_tree.body if isinstance(n, ast.FunctionDef)}
after_nodes = {n.name: ast.dump(n, include_attributes=False) for n in after_tree.body if isinstance(n, ast.FunctionDef)}
check('source-task-scope', before_nodes.keys() == after_nodes.keys() and all(before_nodes[n] == after_nodes[n] for n in before_nodes if n != 'extract_title'), '其他四个函数 AST 原样保留')
placeholders = [line for line in source.decode().splitlines() if 'NotImplementedError' in line or 'TODO' in line or 'pass' == line.strip()]
check('task-placeholder', len(placeholders) == 3 and all('NotImplementedError' in line and '# T03' in line for line in placeholders), placeholders)
imports = [n for n in after_tree.body if isinstance(n, (ast.Import, ast.ImportFrom))]
check('standard-library-no-network', len(imports) == 1 and isinstance(imports[0], ast.Import) and [i.name for i in imports[0].names] == ['argparse'] and not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ['open', 'eval', 'exec', '__import__'] for n in ast.walk(after_tree)), '仅 argparse 导入，T02 无 I/O 或网络调用；不等于 T03 宿主资格')
message = run('git-message', ['git', 'log', '-1', '--format=%B'])
check('commit-message', bool(re.match(r'^[a-z]+\([^)]+\): .+', message.stdout.decode())) and '\nTask: T02\n' in message.stdout.decode() and '\nAgent: ' in message.stdout.decode(), message.stdout.decode())

selector = re.search(r'```bash\npython3 - T01 <<\'PY\'\n(.*?)\nPY\n```', texts['scaffold'], re.S).group(1) + '\n'
task_result = run('task-tests', ['python3', '-', 'T02'], selector)
check('T02-five-tests', task_result.returncode == 0 and task_result.stdout == b'T02: selected 5 tests\n' and b'Ran 5 tests' in task_result.stderr and b'skipped' not in task_result.stderr and task_result.stderr.count(b' ... ok\n') == 5, task_result.stderr.decode())
gate = run('gate-unittest', ['python3', '-m', 'unittest', 'discover', '-s', 'tests', '-v'])
check('gate-unittest', gate.returncode == 0 and b'Ran 21 tests' in gate.stderr and b'OK (skipped=12)' in gate.stderr and gate.stderr.count(b' ... ok\n') == 9 and gate.stderr.count(b"skipped 'T03'") == 12, gate.stderr.decode())
compile_gate = run('gate-compileall', ['python3', '-m', 'compileall', '-q', 'title_tools.py', 'tests'])
check('gate-compileall', compile_gate.returncode == 0 and not compile_gate.stdout and not compile_gate.stderr, compile_gate.returncode)
observations = '''import json\nfrom title_tools import extract_title\ncases = [\n    ("## 二级\\n # 缩进\\n#缺空格\\n# AbC\\t\\t你好，世界！\\n# 后续\\n", "AbC 你好，世界！"),\n    ("正文\\n# \\u3000AbC\\t\\t你好，世界！\\u3000\\n", "AbC 你好，世界！"),\n    ("```\\n# 首个 AbC\\n```\\n# 后续\\n", "首个 AbC"),\n]\nresults = []\nfor text, expected in cases:\n    actual = extract_title(text)\n    assert actual == expected, (actual, expected)\n    results.append({"input": text, "result": actual})\nfor text, expected_error in [("PRIVATE_BODY_MISSING\\n## 二级\\n # 缩进\\n#缺空格\\n", "未找到一级标题"), ("# \\u3000\\t\\n# PRIVATE_BODY_AFTER_EMPTY\\n", "标题不能为空或仅含空白")]:\n    try:\n        extract_title(text)\n    except ValueError as error:\n        message = str(error)\n        assert message == expected_error\n        assert "PRIVATE_BODY" not in message\n        assert text not in message and repr(text) not in message\n        results.append({"input": text, "error_type": type(error).__name__, "error": message})\n    else:\n        raise AssertionError("必须拒绝而非返回后续标题")\nprint(json.dumps(results, ensure_ascii=False, indent=2))\n'''
observation = run('observations', ['python3', '-'], observations)
check('T02-observable-and-condition', observation.returncode == 0 and not observation.stderr, observation.stdout.decode())
head_after = run('git-head-after', ['git', 'log', '-1', '--format=%H'])
status_after = run('git-status-after', ['git', 'status', '--porcelain=v1'])
check('head-and-clean-after', head_after.returncode == 0 and head_after.stdout.decode().strip() == CANDIDATE and status_after.returncode == 0 and not status_after.stdout, {'head': head_after.stdout.decode(), 'status': status_after.stdout.decode()})
after_snapshot = {f: hashlib.sha256((PROJECT / f).read_bytes()).hexdigest() for f in snapshot}
check('project-source-bytes-preserved', snapshot == after_snapshot, {'before': snapshot, 'after': after_snapshot})
record('result', {'passed': all(c['passed'] for c in checks), 'candidate': CANDIDATE, 'baseline': BASE, 'original': ORIGINAL, 'checks': checks})
print(json.dumps({'passed': all(c['passed'] for c in checks), 'checks': len(checks), 'failures': [c for c in checks if not c['passed']]}, ensure_ascii=False))
