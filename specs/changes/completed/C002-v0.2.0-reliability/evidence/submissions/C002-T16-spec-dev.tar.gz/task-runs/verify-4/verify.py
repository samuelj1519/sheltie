from pathlib import Path
import ast, datetime, hashlib, json, os, re, subprocess
B=Path('/private/tmp/sheltie-c002-t16-82c6c55'); W=B/'home/works/2026-10-02-003-t16-spec-dev'; P=B/'project'; E=B/'task-runs/verify-4'
HEAD='0ff54fa35002477c033f306e46089cfda738e3d1'; BASE='71821061f32d9c6496c2d621e673527bc785e4f6'; ORIG='2f88d59b0d214967b64b285e96d764f26bc71c30'
env=os.environ.copy(); env.pop('PYTHONPATH',None); env['PYTHONIOENCODING']='utf-8'; env['PYTHONPYCACHEPREFIX']=str(E/'pycache')
def run(name,argv,stdin=None,cwd=P):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); r=subprocess.run(argv,input=stdin,cwd=cwd,env=env,capture_output=True,check=False,timeout=60)
 (E/(name+'.stdout')).write_bytes(r.stdout); (E/(name+'.stderr')).write_bytes(r.stderr)
 if stdin is not None: (E/(name+'.stdin')).write_bytes(stdin)
 (E/(name+'.json')).write_text(json.dumps({'argv':argv,'cwd':str(cwd),'candidate':HEAD,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'stdout':str(E/(name+'.stdout')),'stderr':str(E/(name+'.stderr')),'stdin':str(E/(name+'.stdin')) if stdin is not None else None,'environment_overrides':{'PYTHONIOENCODING':'utf-8','PYTHONPYCACHEPREFIX':str(E/'pycache'),'PYTHONPATH':None},'execution_context':'exec_command/use_default inherited sandbox'},ensure_ascii=False,indent=2)+'\n'); return r
inputs={}
brief=(W/'attempts/verify/occurrence-004/attempt-000/brief.md').read_text()
for n,p,h in re.findall(r'^\| (\w+) \| (/[^|]+?) \| ([0-9a-f]{64}) \|$',brief,re.M):
 data=Path(p).read_bytes(); (E/('input-'+n+'.bytes')).write_bytes(data); actual=hashlib.sha256(data).hexdigest(); assert actual==h,(n,actual,h); inputs[n]={'path':p,'sha256':actual}
(E/'input-hashes.json').write_text(json.dumps(inputs,indent=2)+'\n')
def text(n): return Path(inputs[n]['path']).read_text()
assert text('decision').splitlines()[0]=='通过'
for n,label in [('spec','规格'),('plan','方案')]: assert f'批准的{label}: '+inputs[n]['sha256'] in text('decision')
assert '条件：错误信息不得回显输入正文。' in text('decision')
(E/'human-decisions.bytes').write_bytes((B/'human-decisions.json').read_bytes())
rows=lambda t: [l for l in t.splitlines() if re.match(r'^\| T\d\d \| [0-9a-f]{40} \|',l)]
change=text('change'); prior=W/'attempts/verify/occurrence-003/attempt-000/outputs/report.md'; pref=rows(change); assert len(pref)==3 and pref==rows(prior.read_text())
assert ORIG in text('plan') and f'原始基线: {ORIG}' in change
history={}
for i in [1,2,3]:
 for kind,file in [('verify','report.md'),('implement','change.md')]:
  p=W/f'attempts/{kind}/occurrence-{i:03d}/attempt-000/outputs/{file}'; t=p.read_text(); (E/f'history-{kind}-{i}.bytes').write_bytes(p.read_bytes()); assert f'原始基线: {ORIG}' in t
  expected=pref[:i if kind=='verify' else i-1]; assert rows(t)==expected
  if kind=='verify': assert t.splitlines()[0].startswith('通过，')
  history[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['plan','tasks','scaffold']: assert rows(text(n))==pref[:2]
for l in pref:
 cells=[x.strip() for x in l.split('|')[1:-1]]; assert len(cells)==6
 for q in cells[3:]: assert Path(q).exists()
 p=Path(cells[3]); (E/f'history-approval-{cells[0]}.bytes').write_bytes(p.read_bytes()); assert p.read_text().splitlines()[0]=='通过'
for kind in ['plan','tasks']:
 p=W/f'attempts/plan/occurrence-001/attempt-000/outputs/{kind}.md'; assert rows(p.read_text())==[]; (E/f'history-initial-{kind}.bytes').write_bytes(p.read_bytes())
(E/'prefix.json').write_text(json.dumps({'rows':pref,'history_hashes':history,'original_baseline':ORIG},ensure_ascii=False,indent=2)+'\n')
assert run('git-head',['git','rev-parse','HEAD']).stdout.strip().decode()==HEAD
assert run('git-status-before',['git','status','--porcelain=v1']).stdout==b''
assert run('git-parent',['git','rev-parse','HEAD^']).stdout.strip().decode()==BASE
for n,h in [('original',ORIG),('verified',BASE)]: assert run('git-ancestor-'+n,['git','merge-base','--is-ancestor',h,HEAD]).returncode==0
files=run('git-files',['git','diff','--name-only',BASE+'..'+HEAD]); assert set(files.stdout.decode().splitlines())=={'title_tools.py','tests/test_title_tools.py','README.md'}
run('git-diff',['git','diff',BASE+'..'+HEAD]); run('git-test-diff',['git','diff',BASE+'..'+HEAD,'--','tests/test_title_tools.py'])
before=run('git-test-baseline',['git','show',BASE+':tests/test_title_tools.py']).stdout; current=(P/'tests/test_title_tools.py').read_bytes(); marker=b'    @unittest.skip("T04")\n'; assert before.count(marker)==12 and current==before.replace(marker,b'')
for f in ['title_tools.py','tests/test_title_tools.py','tests/test_read_markdown.py','README.md']: (E/('candidate-'+f.replace('/','-')+'.bytes')).write_bytes((P/f).read_bytes())
source=(P/'title_tools.py').read_text(); assert not any(s in source for s in ['NotImplementedError','TODO','pass #'])
msg=run('git-message',['git','log','-1','--format=%B']).stdout.decode(); assert 'Task: T04' in msg and 'Agent:' in msg and re.match(r'\w+\([^\n]+\): .+',msg)
selector=(B/'task-runs/scaffold-2/task-selector.stdin').read_bytes(); scaffold=text('scaffold'); assert selector.decode().strip() in scaffold
r=run('task-T04',['python3','-','T04'],selector); assert r.returncode==0 and b'selected 12 tests' in r.stdout and b'Ran 12 tests' in r.stderr and b'skipped' not in r.stderr
r=run('gate-unittest',['python3','-m','unittest','discover','-s','tests','-v']); assert r.returncode==0 and b'Ran 26 tests' in r.stderr and b'skipped' not in r.stderr
assert run('gate-compileall',['python3','-m','compileall','-q','title_tools.py','tests']).returncode==0
print('Static, history, selector 12, full 26 and compileall passed')
