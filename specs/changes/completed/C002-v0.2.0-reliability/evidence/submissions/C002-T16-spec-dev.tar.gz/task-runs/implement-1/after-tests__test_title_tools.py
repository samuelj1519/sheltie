"""冻结任务卡的 21 项测试；各任务只移除本任务的 skip 装饰器。"""

import ast
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import title_tools


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def run_cli(*arguments: str, without_site_packages: bool = False):
    """在项目根启动真实模块子进程，捕获两个输出流和退出码。"""
    command = [sys.executable]
    if without_site_packages:
        command.append("-S")
    command.extend(["-m", "title_tools", *arguments])
    environment = os.environ.copy()
    environment.pop("PYTHONPATH", None)
    environment["PYTHONIOENCODING"] = "utf-8"
    return subprocess.run(
        command, cwd=PROJECT_ROOT, env=environment, capture_output=True,
        text=True, encoding="utf-8", timeout=10, check=False,
    )


class TitleToolsTests(unittest.TestCase):
    def assert_cli_error(self, result, *private_fragments: str):
        """核对错误协议与批准条件：错误信息不得回显输入正文。"""
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertEqual(result.stdout, "")
        self.assertTrue(result.stderr.strip(), "stderr 必须说明失败原因")
        self.assertNotIn("Traceback", result.stderr)
        for fragment in private_fragments:
            if fragment:
                self.assertNotIn(fragment, result.stderr)

    def assert_file_cli_error(self, content: bytes, *private_fragments: str,
                              without_site_packages: bool = False):
        """创建真实文件，核对失败输出及读取前后的原始字节。"""
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "input.md"
            path.write_bytes(content)
            result = run_cli("extract", str(path),
                             without_site_packages=without_site_packages)
            self.assert_cli_error(result, *private_fragments)
            self.assertEqual(path.read_bytes(), content)

    # Task: T01
    def test_normalize_collapses_mixed_unicode_whitespace(self):
        self.assertEqual(title_tools.normalize_title(
            "\u3000AbC\u00a0\t\n你好，世界！\u3000"), "AbC 你好，世界！")

    # Task: T01
    def test_normalize_preserves_chinese_punctuation_and_case(self):
        self.assertEqual(title_tools.normalize_title("  AbC  你好，世界！  "),
                         "AbC 你好，世界！")

    # Task: T01
    def test_normalize_rejects_empty_and_whitespace_only(self):
        for text in ("", "   ", "\u3000", "\u3000\u00a0\t\n "):
            with self.subTest(text=repr(text)):
                with self.assertRaises(ValueError) as raised:
                    title_tools.normalize_title(text)
                self.assertTrue(str(raised.exception).strip())

    # Task: T01
    def test_normalize_keeps_single_word(self):
        self.assertEqual(title_tools.normalize_title("AbC"), "AbC")

    # Task: T02
    @unittest.skip("T02")
    def test_extract_ignores_nonmatching_heading_prefixes(self):
        markdown = "## 二级\n # 缩进\n#缺空格\n# AbC\t\t你好，世界！\n# 后续\n"
        self.assertEqual(title_tools.extract_title(markdown), "AbC 你好，世界！")

    # Task: T02
    @unittest.skip("T02")
    def test_extract_normalizes_first_heading(self):
        self.assertEqual(title_tools.extract_title("正文\n# \u3000AbC\t\t你好，世界！\u3000\n"),
                         "AbC 你好，世界！")

    # Task: T02
    @unittest.skip("T02")
    def test_extract_chooses_first_matching_heading(self):
        self.assertEqual(title_tools.extract_title("```\n# 首个 AbC\n```\n# 后续\n"),
                         "首个 AbC")

    # Task: T02
    @unittest.skip("T02")
    def test_extract_rejects_missing_heading(self):
        with self.assertRaises(ValueError) as raised:
            title_tools.extract_title("## 二级\n # 缩进\n#缺空格\n正文\n")
        self.assertTrue(str(raised.exception).strip())

    # Task: T02
    @unittest.skip("T02")
    def test_extract_rejects_empty_first_heading_without_fallback(self):
        with self.assertRaises(ValueError) as raised:
            title_tools.extract_title("# \u3000\t\n# 后续有效标题\n")
        self.assertTrue(str(raised.exception).strip())

    # Task: T03
    @unittest.skip("T03")
    def test_cli_normalize_prints_one_line(self):
        result = run_cli("normalize", "  AbC   你好，世界！  ")
        self.assertEqual((result.returncode, result.stdout, result.stderr),
                         (0, "AbC 你好，世界！\n", ""))

    # Task: T03
    @unittest.skip("T03")
    def test_cli_extract_uses_explicit_utf8_file_and_preserves_bytes(self):
        content = "## 二级\r\n# \u3000AbC\t\t你好，世界！\r\n# 后续\r\n".encode("utf-8")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "中文 file.md"
            path.write_bytes(content)
            result = run_cli("extract", str(path))
            self.assertEqual((result.returncode, result.stdout, result.stderr),
                             (0, "AbC 你好，世界！\n", ""))
            self.assertEqual(path.read_bytes(), content)

    # Task: T03
    @unittest.skip("T03")
    def test_cli_normalize_rejects_whitespace(self):
        text = "\u3000\u00a0\t\n "
        self.assert_cli_error(run_cli("normalize", text), text, repr(text))

    # Task: T03
    @unittest.skip("T03")
    def test_cli_extract_rejects_missing_heading(self):
        self.assert_file_cli_error(b"PRIVATE_BODY_MISSING_HEADING\n## subheading\n",
                                   "PRIVATE_BODY_MISSING_HEADING")

    # Task: T03
    @unittest.skip("T03")
    def test_cli_extract_rejects_empty_first_heading(self):
        content = "# \u3000\t\n# PRIVATE_BODY_AFTER_EMPTY\n".encode("utf-8")
        self.assert_file_cli_error(content, "PRIVATE_BODY_AFTER_EMPTY")

    # Task: T03
    @unittest.skip("T03")
    def test_cli_extract_rejects_non_utf8_file(self):
        self.assert_file_cli_error(b"PRIVATE_BODY_INVALID_ENCODING\xff\n",
                                   "PRIVATE_BODY_INVALID_ENCODING")

    # Task: T03
    @unittest.skip("T03")
    def test_cli_extract_rejects_missing_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "missing.md"
            self.assertFalse(path.exists())
            self.assert_cli_error(run_cli("extract", str(path)))
            self.assertFalse(path.exists())

    # Task: T03
    @unittest.skip("T03")
    def test_cli_extract_reports_unreadable_file(self):
        content = b"# PRIVATE_BODY_UNREADABLE\n"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "unreadable.md"
            path.write_bytes(content)
            path.chmod(0)
            try:
                # 真实权限前置条件：若宿主仍可读，本验收必须失败，不伪造权限错误。
                probe = subprocess.run(
                    [sys.executable, "-S", "-c",
                     "import pathlib, sys; pathlib.Path(sys.argv[1]).read_bytes()",
                     str(path)], capture_output=True, check=False, timeout=10,
                )
                self.assertNotEqual(probe.returncode, 0,
                                    "宿主可读取 chmod(0) 文件；不可读验收缺证据")
                self.assertIn(b"PermissionError", probe.stderr)
                self.assert_cli_error(run_cli("extract", str(path)),
                                      "PRIVATE_BODY_UNREADABLE")
            finally:
                path.chmod(0o600)
            self.assertEqual(path.read_bytes(), content)

    # Task: T03
    @unittest.skip("T03")
    def test_cli_rejects_missing_required_arguments(self):
        for arguments in ((), ("normalize",), ("extract",)):
            with self.subTest(arguments=arguments):
                self.assert_cli_error(run_cli(*arguments))

    # Task: T03
    @unittest.skip("T03")
    def test_cli_rejects_unknown_subcommand(self):
        private_argument = "PRIVATE_BODY_UNKNOWN_SUBCOMMAND"
        self.assert_cli_error(run_cli(private_argument), private_argument)

    # Task: T03
    @unittest.skip("T03")
    def test_cli_runs_without_site_packages(self):
        result = run_cli("normalize", "  AbC   你好，世界！  ",
                         without_site_packages=True)
        self.assertEqual((result.returncode, result.stdout, result.stderr),
                         (0, "AbC 你好，世界！\n", ""))
        whitespace = "\u3000\u00a0\t\n "
        self.assert_cli_error(run_cli("normalize", whitespace,
                                     without_site_packages=True), whitespace)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "input.md"
            content = "# AbC\t\t你好，世界！\n# 后续\n".encode("utf-8")
            path.write_bytes(content)
            result = run_cli("extract", str(path), without_site_packages=True)
            self.assertEqual((result.returncode, result.stdout, result.stderr),
                             (0, "AbC 你好，世界！\n", ""))
            self.assertEqual(path.read_bytes(), content)
        self.assert_file_cli_error(b"PRIVATE_BODY_WITHOUT_SITE\n",
                                   "PRIVATE_BODY_WITHOUT_SITE",
                                   without_site_packages=True)

    # Task: T03
    @unittest.skip("T03")
    def test_imports_are_standard_library_only(self):
        source = (PROJECT_ROOT / "title_tools.py").read_text(encoding="utf-8")
        standard_modules = sys.stdlib_module_names | {"__future__"}
        imports = set()
        for node in ast.walk(ast.parse(source)):
            if isinstance(node, ast.Import):
                imports.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                self.assertEqual(node.level, 0, "不得添加未批准的本地依赖")
                imports.add((node.module or "").split(".")[0])
        self.assertTrue(imports <= standard_modules, imports - standard_modules)
        self.assertFalse(imports & {"socket", "urllib", "http", "ftplib", "ssl"})
        for pattern in ("requirements*.txt", "pyproject.toml", "setup.py",
                        "setup.cfg", "Pipfile*", "poetry.lock"):
            self.assertEqual(list(PROJECT_ROOT.glob(pattern)), [], pattern)
        self.assertIn("不联网", (PROJECT_ROOT / "README.md").read_text(encoding="utf-8"))
        # -S 和静态导入检查不证明宿主禁止联网；实际环境证据交独立验证。
