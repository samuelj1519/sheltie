from pathlib import Path
import ast, hashlib, json, re, subprocess
base=Path('/private/tmp/sheltie-c002-t16-82c6c55')
work=base/'home/works/2026-10-02-003-t16-spec-dev'
project=base/'project'
evidence=base/'task-runs/scaffold-2'
brief=work/'attempts/scaffold/occurrence-002/attempt-000/brief.md'
hashes={}
for name,path,expected in re.findall(r'^\| (\w+) \| (/.+?) \| ([0-9a-f]{64}) \|$',brief.read_text(),re.M):
    data=Path(path).read_bytes(); actual=hashlib.sha256(data).hexdigest()
    assert actual==expected,(name,actual,expected)
    (evidence/f'input-{name}.bytes').write_bytes(data)
    hashes[name]={'path':path,'sha256':actual}
(evidence/'input-hashes.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2)+'\n')
decision=(evidence/'input-decision.bytes').read_text()
assert decision.splitlines()[0]=='通过'
assert f"批准的规格: {hashes['spec']['sha256']}" in decision
assert f"批准的方案: {hashes['plan']['sha256']}" in decision
assert '条件：错误信息不得回显输入正文。' in decision
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=project)==b''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=project).strip()==b'6773f932765895735a5786220653440afcba2d8f'
report=(work/'attempts/verify/occurrence-002/attempt-000/outputs/report.md').read_bytes()
(evidence/'inherited-report.bytes').write_bytes(report)
rows=[line for line in report.decode().splitlines() if line.startswith('| T0')]
assert len(rows)==2
for name in ['plan','tasks']:
    own=[line for line in (evidence/f'input-{name}.bytes').read_text().splitlines() if line.startswith('| T0')]
    assert own==rows
assert '2f88d59b0d214967b64b285e96d764f26bc71c30' in report.decode()
for name in ['title_tools.py','tests/test_title_tools.py','README.md']:
    (evidence/('before-'+name.replace('/','-'))).write_bytes((project/name).read_bytes())
source=(project/'title_tools.py').read_text()
point=source.index('# Task: T03\ndef build_parser')
source=source[:point]+source[point:].replace('T03','T04')
new='''# Task: T04
class SafeArgumentParser(argparse.ArgumentParser):
    """按规格验收 7 与审批条件安全报告命令行参数错误。
    非法参数通过 error 退出 2，不回显 argparse 的输入正文。
    """

    def error(self, message: str) -> None:
        """按方案改法用固定说明向 stderr 报告参数错误，忽略 message 正文。
        参数错误抛出 SystemExit(2)，stdout 为空且 stderr 不含输入或 traceback。
        """
        raise NotImplementedError  # T04


'''
source=source[:point]+new+source[point:]
(project/'title_tools.py').write_text(source)
tests=(project/'tests/test_title_tools.py').read_text()
assert tests.count('@unittest.skip("T03")')==12
(project/'tests/test_title_tools.py').write_text(tests.replace('Task: T03','Task: T04').replace('@unittest.skip("T03")','@unittest.skip("T04")'))
reader='''"""冻结 T03 的五项直接读取测试；只移除本任务 skip，不改断言。"""

from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import title_tools


class ReadMarkdownTests(unittest.TestCase):
    def assert_safe_read_error(self, error, content: bytes):
        """核错误说明非空且不回显手写正文或其 repr。"""
        message = str(error)
        self.assertTrue(message.strip())
        self.assertNotIn("PRIVATE_BODY", message)
        self.assertNotIn(repr(content), message)
        text = content.decode("utf-8", errors="replace")
        self.assertNotIn(text, message)
        self.assertNotIn(repr(text), message)

    # Task: T03
    @unittest.skip("T03")
    def test_read_markdown_returns_utf8_text_without_heading_validation(self):
        text = "正文 AbC 你好，世界！\\n\\u3000没有标题\\t保留空白\\n"
        content = text.encode("utf-8")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "中文 file.md"
            path.write_bytes(content)
            self.assertEqual(title_tools.read_markdown(str(path)), text)
            self.assertEqual(path.read_bytes(), content)

    # Task: T03
    @unittest.skip("T03")
    def test_read_markdown_preserves_original_file_bytes(self):
        content = "## 二级\\r\\n# \\u3000AbC\\t\\t你好，世界！\\r\\n# 后续\\r\\n".encode("utf-8")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "input.md"
            path.write_bytes(content)
            markdown = title_tools.read_markdown(str(path))
            self.assertEqual(title_tools.extract_title(markdown), "AbC 你好，世界！")
            self.assertEqual(path.read_bytes(), content)

    # Task: T03
    @unittest.skip("T03")
    def test_read_markdown_rejects_non_utf8_and_preserves_bytes(self):
        content = b"PRIVATE_BODY_INVALID_ENCODING\\xff\\n"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "input.md"
            path.write_bytes(content)
            with self.assertRaises(UnicodeError) as raised:
                title_tools.read_markdown(str(path))
            self.assert_safe_read_error(raised.exception, content)
            self.assertEqual(path.read_bytes(), content)

    # Task: T03
    @unittest.skip("T03")
    def test_read_markdown_rejects_missing_file_without_creating_it(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "missing.md"
            self.assertFalse(path.exists())
            with self.assertRaises(FileNotFoundError) as raised:
                title_tools.read_markdown(str(path))
            self.assertIsInstance(raised.exception, OSError)
            self.assertTrue(str(raised.exception).strip())
            self.assertFalse(path.exists())

    # Task: T03
    @unittest.skip("T03")
    def test_read_markdown_rejects_unreadable_file_and_preserves_bytes(self):
        content = b"# PRIVATE_BODY_UNREADABLE\\n"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "unreadable.md"
            path.write_bytes(content)
            path.chmod(0)
            try:
                probe = subprocess.run(
                    [sys.executable, "-S", "-c",
                     "import pathlib, sys; pathlib.Path(sys.argv[1]).read_bytes()",
                     str(path)], capture_output=True, check=False, timeout=10,
                )
                self.assertNotEqual(probe.returncode, 0,
                                    "宿主可读取 chmod(0) 文件；不可读验收缺证据")
                self.assertIn(b"PermissionError", probe.stderr)
                with self.assertRaises(PermissionError) as raised:
                    title_tools.read_markdown(str(path))
                self.assertIsInstance(raised.exception, OSError)
                self.assert_safe_read_error(raised.exception, content)
            finally:
                path.chmod(0o600)
            self.assertEqual(path.read_bytes(), content)
'''
(project/'tests/test_read_markdown.py').write_text(reader)
# Compare preserved prefix bytes and the exact approved test-marker-only change.
before=(evidence/'before-title_tools.py').read_text()
assert source[:source.index('# Task: T03\ndef read_markdown')]==before[:before.index('# Task: T03\ndef read_markdown')]
assert (project/'tests/test_title_tools.py').read_text().replace('Task: T04','Task: T03').replace('@unittest.skip("T04")','@unittest.skip("T03")')==tests
assert (project/'README.md').read_bytes()==(evidence/'before-README.md').read_bytes()
print(json.dumps({'approval':'matched','prefix_rows':len(rows),'enabled_tests_preserved':9,'new_tests':5},ensure_ascii=False))
