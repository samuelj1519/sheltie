exec((__import__('pathlib').Path(__file__).with_name('verify.py')).read_text())
import ctypes, socket
assert run('create-stdlib-venv',['python3','-m','venv','--without-pip',str(E/'venv')]).returncode==0
vpy=str(E/'venv/bin/python3')
venvcfg=(E/'venv/pyvenv.cfg').read_text(); assert 'include-system-site-packages = false' in venvcfg
(E/'venv-config.bytes').write_bytes((E/'venv/pyvenv.cfg').read_bytes())
site_dirs=list((E/'venv/lib').glob('python*/site-packages')); assert site_dirs and all(not list(d.iterdir()) for d in site_dirs)
(E/'empty-site-packages.json').write_text(json.dumps({'directories':[str(d) for d in site_dirs],'entries':[list(d.iterdir()) for d in site_dirs]},indent=2)+'\n')
policy=b'''import ctypes,json,os,sys,socket
lib=ctypes.CDLL('/usr/lib/libsandbox.dylib',use_errno=True)
f=lib.sandbox_check; f.restype=ctypes.c_int; f.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int]
checks={op:f(os.getpid(),op.encode(),0) for op in ['network-outbound','network-inbound','network-bind','file-read-data']}
s=socket.socket(); s.settimeout(3)
try:
 s.connect(('1.1.1.1',443)); probe={'connected':True,'denied':False}
except PermissionError as e:
 probe={'connected':False,'denied':True,'errno':e.errno,'message':str(e)}
except OSError as e:
 probe={'connected':False,'denied':False,'errno':e.errno,'message':str(e)}
finally: s.close()
print(json.dumps({'pid':os.getpid(),'executable':sys.executable,'prefix':sys.prefix,'path':sys.path,'sandbox_env':{k:v for k,v in os.environ.items() if k.startswith('CODEX_SANDBOX')},'policy_checks_filter_zero':checks,'connection_probe':probe}))
assert checks['network-outbound']==1 and probe['denied'] and probe['errno']==1
assert all('site-packages' not in p for p in sys.path)
'''
assert run('current-policy-and-stdlib-path',[vpy,'-S','-'],policy).returncode==0
fixtures={
 'success':'## 二级\r\n # 缩进\r\n#缺空格\r\n# \u3000AbC\t\t你好，世界！\r\n# 后续\r\n'.encode(),
 'no-heading':b'PRIVATE_BODY_NO_HEADING\n## nested\n',
 'empty-heading':'# \u3000\t\n# PRIVATE_BODY_AFTER_EMPTY\n'.encode(),
 'invalid-utf8':b'PRIVATE_BODY_INVALID_UTF8\xff\n',
 'unreadable':b'# PRIVATE_BODY_UNREADABLE\n',
}
paths={}
for n,content in fixtures.items():
 p=E/(n+'.md'); p.write_bytes(content); (E/(n+'.before.bytes')).write_bytes(content); paths[n]=p
missing=E/'missing.md'; assert not missing.exists()
for mode,command in [('normal',['python3','-m','title_tools']),('stdlib-no-site',[vpy,'-S','-m','title_tools'])]:
 r=run(mode+'-normalize-success',command+['normalize','  AbC   你好，世界！  ']); assert (r.returncode,r.stdout,r.stderr)==(0,'AbC 你好，世界！\n'.encode(),b'')
 r=run(mode+'-extract-success',command+['extract',str(paths['success'])]); assert (r.returncode,r.stdout,r.stderr)==(0,'AbC 你好，世界！\n'.encode(),b'')
 cases={'normalize-empty':['normalize','\u3000\u00a0\t\n '],'missing-file':['extract',str(missing)],'missing-command':[],'missing-normalize':['normalize'],'missing-extract':['extract'],'unknown-command':['PRIVATE_BODY_UNKNOWN_SUBCOMMAND'],'extra-argument':['normalize','PRIVATE_BODY_TITLE','PRIVATE_BODY_EXTRA_ARGUMENT']}
 cases.update({n:['extract',str(paths[n])] for n in ['no-heading','empty-heading','invalid-utf8']})
 for n,args in cases.items():
  r=run(mode+'-'+n,command+args); assert r.returncode==2 and r.stdout==b'' and r.stderr.strip() and b'Traceback' not in r.stderr and b'PRIVATE_BODY' not in r.stderr
 paths['unreadable'].chmod(0)
 try:
  r=run(mode+'-permission-precondition',[vpy,'-S','-c','import pathlib,sys; pathlib.Path(sys.argv[1]).read_bytes()',str(paths['unreadable'])]); assert r.returncode!=0 and b'PermissionError' in r.stderr
  r=run(mode+'-unreadable',command+['extract',str(paths['unreadable'])]); assert r.returncode==2 and r.stdout==b'' and r.stderr.strip() and b'PRIVATE_BODY' not in r.stderr and b'Traceback' not in r.stderr
 finally: paths['unreadable'].chmod(0o600)
 for n,p in paths.items():
  data=p.read_bytes(); assert data==fixtures[n]; (E/(mode+'-'+n+'.after.bytes')).write_bytes(data)
 assert not missing.exists()
functions=b'''from title_tools import normalize_title, extract_title
print(normalize_title("\\u3000AbC\\u00a0\\t\\n\u4f60\u597d\uff0c\u4e16\u754c\uff01\\u3000"))
print(extract_title("## \u4e8c\u7ea7\\n # \u7f29\u8fdb\\n#\u7f3a\u7a7a\u683c\\n# AbC\\t\\t\u4f60\u597d\uff0c\u4e16\u754c\uff01\\n# \u540e\u7eed\\n"))
'''
r=run('readme-functions',['python3','-'],functions); assert r.returncode==0 and r.stdout=='AbC 你好，世界！\nAbC 你好，世界！\n'.encode() and not r.stderr
assert run('git-status-after',['git','status','--porcelain=v1']).stdout==b''
for f in ['title_tools.py','tests/test_title_tools.py','tests/test_read_markdown.py','README.md']: assert (P/f).read_bytes()==(E/('candidate-'+f.replace('/','-')+'.bytes')).read_bytes()
(E/'behavior-result.json').write_text(json.dumps({'all_assertions_passed':True,'missing_file_exists_after':missing.exists(),'project_files_unchanged':True,'site_packages_empty':True,'network_interpretation':'same inherited seatbelt execution context: env disabled=1, unfiltered sandbox_check network-outbound=1, real IPv4 TCP connection PermissionError EPERM; scope is this execution context only, not arbitrary Hosts or every protocol'},ensure_ascii=False,indent=2)+'\n')
print('All CLI boundaries, byte preservation, PermissionError preconditions, README examples and no-third-party venv passed')
