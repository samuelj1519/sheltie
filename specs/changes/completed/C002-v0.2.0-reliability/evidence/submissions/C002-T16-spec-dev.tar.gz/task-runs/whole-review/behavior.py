from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

B=Path('/private/tmp/sheltie-c002-t16-82c6c55')
P=B/'project'
E=B/'task-runs/whole-review'
env=os.environ.copy()
env.pop('PYTHONPATH',None)
env.update(PYTHONIOENCODING='utf-8',PYTHONPYCACHEPREFIX=str(E/'pycache'))
def run(name,argv,stdin=None):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat(); tick=time.monotonic()
    r=subprocess.run(argv,cwd=P,env=env,input=stdin,capture_output=True,timeout=60)
    (E/(name+'.stdout')).write_bytes(r.stdout); (E/(name+'.stderr')).write_bytes(r.stderr)
    if stdin is not None: (E/(name+'.stdin')).write_bytes(stdin)
    (E/(name+'.json')).write_text(json.dumps(dict(argv=argv,cwd=str(P),start_utc=start,
        end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-tick,exit_code=r.returncode,
        stdin_path=str(E/(name+'.stdin')) if stdin is not None else None,
        environment_overrides={k:env[k] for k in ('PYTHONIOENCODING','PYTHONPYCACHEPREFIX')},removed_environment=['PYTHONPATH'],
        sandbox_environment={k:env.get(k) for k in ('CODEX_SANDBOX','CODEX_SANDBOX_NETWORK_DISABLED')}),ensure_ascii=False,indent=2))
    return r
project_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (P/'title_tools.py',P/'tests/test_title_tools.py',P/'tests/test_read_markdown.py',P/'README.md')}
assert run('create-empty-venv',['python3','-m','venv','--without-pip',str(E/'venv')]).returncode==0
venv=str(E/'venv/bin/python3')
cfg=(E/'venv/pyvenv.cfg').read_bytes(); (E/'venv-config.bytes').write_bytes(cfg)
assert b'include-system-site-packages = false' in cfg
sites=list((E/'venv/lib').glob('python*/site-packages'))
assert sites and all(not list(x.iterdir()) for x in sites)
(E/'empty-site-packages.json').write_text(json.dumps({str(x):[p.name for p in x.iterdir()] for x in sites},indent=2))
probe=b'''import errno, json, os, socket, sys
assert os.environ.get("CODEX_SANDBOX") == "seatbelt"
assert os.environ.get("CODEX_SANDBOX_NETWORK_DISABLED") == "1"
assert not any("site-packages" in p for p in sys.path)
s=socket.socket(); s.settimeout(3)
try:
    s.connect(("1.1.1.1",443))
    raise AssertionError("connection unexpectedly succeeded")
except PermissionError as e:
    assert e.errno == errno.EPERM
    print(json.dumps({"executable":sys.executable,"prefix":sys.prefix,"sys_path":sys.path,"sandbox":os.environ["CODEX_SANDBOX"],"network_disabled":os.environ["CODEX_SANDBOX_NETWORK_DISABLED"],"probe":"IPv4 TCP 1.1.1.1:443","errno":e.errno,"denied":True}))
finally:
    s.close()
'''
assert run('execution-environment',[venv,'-S','-'],probe).returncode==0
files={
    'success':"## 二级\r\n # 缩进\r\n#缺空格\r\n# \u3000AbC\t\t你好，世界！\r\n# 后续\r\n".encode(),
    'no-heading':b'PRIVATE_BODY_NO_HEADING\n## no\n',
    'empty-heading':"# \u3000\t\n# PRIVATE_BODY_AFTER_EMPTY\n".encode(),
    'invalid-utf8':b'PRIVATE_BODY_INVALID_UTF8\xff\n',
    'unreadable':b'# PRIVATE_BODY_UNREADABLE\n',
}
for name,content in files.items():
    (E/(name+'.md')).write_bytes(content); (E/(name+'.before.bytes')).write_bytes(content)
private='PRIVATE_BODY_ARGUMENT'
cases=[('normalize-success',['normalize','\u3000AbC\u00a0\t\n你好，世界！\u3000'],0),
       ('extract-success',['extract',str(E/'success.md')],0),
       ('normalize-empty',['normalize','\u3000\u00a0\t\n '],2),
       ('missing-file',['extract',str(E/'missing.md')],2),
       ('missing-command',[],2),('missing-normalize',['normalize'],2),('missing-extract',['extract'],2),
       ('unknown-command',[private],2),('extra-argument',['normalize','AbC',private],2)]
cases += [(name,['extract',str(E/(name+'.md'))],2) for name in ('no-heading','empty-heading','invalid-utf8','unreadable')]
for mode,python in [('normal',['python3']),('empty-venv-no-site',[venv,'-S'])]:
    for name,args,status in cases:
        if name=='unreadable':
            path=E/'unreadable.md'; path.chmod(0)
            try:
                r=run(mode+'-permission-precondition',python+['-c','import pathlib,sys;pathlib.Path(sys.argv[1]).read_bytes()',str(path)])
                assert r.returncode!=0 and b'PermissionError' in r.stderr
                r=run(mode+'-'+name,python+['-m','title_tools']+args)
            finally: path.chmod(0o600)
        else:
            r=run(mode+'-'+name,python+['-m','title_tools']+args)
        assert r.returncode==status,(mode,name,r.stderr)
        if status==0:
            assert r.stdout=='AbC 你好，世界！\n'.encode() and not r.stderr
        else:
            assert not r.stdout and r.stderr.strip() and b'PRIVATE_BODY' not in r.stderr and b'Traceback' not in r.stderr
        for file,content in files.items():
            actual=(E/(file+'.md')).read_bytes(); assert actual==content
            (E/(mode+'-'+name+'-'+file+'.after.bytes')).write_bytes(actual)
        assert not (E/'missing.md').exists()
readme=(P/'README.md').read_text()
block=readme.split("python3 - <<'PY'\n",1)[1].split('\nPY',1)[0]+'\n'
r=run('readme-functions',['python3','-'],block.encode())
assert r.returncode==0 and r.stdout=='AbC 你好，世界！\nAbC 你好，世界！\n'.encode() and not r.stderr
assert project_hashes=={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in project_hashes}
assert not run('behavior-final-status',['git','status','--porcelain=v1']).stdout
(E/'behavior-result.json').write_text(json.dumps(dict(cases_per_mode=len(cases),modes=['normal','empty-venv-no-site'],
    bytes_unchanged=True,missing_still_missing=True,permission_preconditions='real PermissionError',project_hashes_unchanged=True,
    environment_scope='Current use_default seatbelt Python execution closure; explicit disabled-network markers and IPv4 TCP EPERM; no arbitrary protocol or whole Host qualification.'),indent=2))
print('Independent 26 CLI runs, actual permissions, immutable input bytes, README and restricted empty-venv execution passed.')
