import ast
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path("/private/tmp/sheltie-c002-t16-82c6c55")
WORK = ROOT / "home/works/2026-10-02-003-t16-spec-dev"
OUT = ROOT / "task-runs/verify-3"
PROJECT = ROOT / "project"
REPORT = WORK / "attempts/verify/occurrence-003/attempt-000/outputs/report.md"
BASELINE = "ba56d3fc3a25a9ca170183fd2315beb0ff37db5b"
CANDIDATE = "71821061f32d9c6496c2d621e673527bc785e4f6"
ORIGINAL = "2f88d59b0d214967b64b285e96d764f26bc71c30"
OUT.mkdir(parents=True, exist_ok=True)
ENV = dict(os.environ)
ENV.pop("PYTHONPATH", None)
ENV["PYTHONIOENCODING"] = "utf-8"
ENV["PYTHONPYCACHEPREFIX"] = str(OUT / "pycache")
CHECKS = []

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def check(name, condition, detail=None):
    CHECKS.append({"name": name, "passed": bool(condition), "detail": detail})

def run(name, argv, stdin=None, cwd=PROJECT):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stdin_path = None
    if stdin is not None:
        stdin_path = OUT / (name + ".stdin")
        stdin_path.write_bytes(stdin)
    result = subprocess.run(argv, input=stdin, capture_output=True, cwd=cwd, env=ENV, timeout=60)
    stdout_path = OUT / (name + ".stdout")
    stderr_path = OUT / (name + ".stderr")
    stdout_path.write_bytes(result.stdout)
    stderr_path.write_bytes(result.stderr)
    dump(name + ".json", {
        "argv": argv, "cwd": str(cwd), "candidate": CANDIDATE,
        "stdin_path": str(stdin_path) if stdin_path else None,
        "start_utc": start, "end_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "returncode": result.returncode, "stdout_path": str(stdout_path), "stderr_path": str(stderr_path),
        "environment_overrides": {
            "PYTHONPATH": "removed", "PYTHONIOENCODING": ENV["PYTHONIOENCODING"],
            "PYTHONPYCACHEPREFIX": ENV["PYTHONPYCACHEPREFIX"],
        },
    })
    return result

def field(text, key):
    m = re.search(r"^" + re.escape(key) + r":\s*(.+)$", text, re.M)
    return m.group(1).strip() if m else None

def rows(text):
    section = text.split("## 已验证任务", 1)[1].split("\n## ", 1)[0] if "## 已验证任务" in text else ""
    return re.findall(r"^\| T\d\d \|.*$", section, re.M)

brief = WORK / "attempts/verify/occurrence-003/attempt-000/brief.md"
brief_bytes = brief.read_bytes()
(OUT / "brief.bytes").write_bytes(brief_bytes)
inputs = {}
hashes = []
for name, path, digest in re.findall(r"^\| (\w+) \| (\S+) \| ([0-9a-f]{64}) \|$", brief_bytes.decode(), re.M):
    source = Path(path)
    data = source.read_bytes()
    (OUT / ("input-" + name + ".bytes")).write_bytes(data)
    actual = hashlib.sha256(data).hexdigest()
    inputs[name] = {"path": path, "data": data, "text": data.decode(), "sha256": actual}
    hashes.append({"name": name, "path": path, "expected": digest, "actual": actual})
check("frozen_input_hashes", all(h["expected"] == h["actual"] for h in hashes), hashes)
dump("input-hashes.json", hashes)
change = inputs["change"]["text"]
plan = inputs["plan"]["text"]
tasks = inputs["tasks"]["text"]
scaffold = inputs["scaffold"]["text"]
decision = inputs["decision"]["text"]
check("new_approval", decision.splitlines()[0] == "通过"
      and field(decision, "批准的规格") == inputs["spec"]["sha256"]
      and field(decision, "批准的方案") == inputs["plan"]["sha256"]
      and "错误信息不得回显输入正文" in decision)
human_bytes = (ROOT / "human-decisions.json").read_bytes()
(OUT / "human-decisions.bytes").write_bytes(human_bytes)
human = json.loads(human_bytes)
approval = [d for d in human["decisions"] if d.get("question_id") == "call_bAUqDu6CHZknYa5vxVjQCRWj/0"]
check("actual_new_approval_record", len(approval) == 1
      and approval[0]["answer"] == "批准新版，保留原条件"
      and approval[0]["spec_sha256"] == inputs["spec"]["sha256"]
      and approval[0]["plan_sha256"] == inputs["plan"]["sha256"]
      and approval[0]["condition"] == "错误信息不得回显输入正文")
check("project_input", Path(inputs["project"]["text"].strip()).resolve() == PROJECT.resolve())
inherit_path = Path(field(change, "继承来源"))
inherited = inherit_path.read_bytes()
(OUT / "inherited-report.bytes").write_bytes(inherited)
prefix = rows(inherited.decode())
check("complete_prefix", len(prefix) == 2 and all(rows(doc) == prefix for doc in (change, plan, tasks, scaffold)))
check("original_baseline", all(ORIGINAL in doc for doc in (change, plan, tasks, scaffold, inherited.decode()))
      and field(change, "原始基线") == ORIGINAL and field(inherited.decode(), "原始基线") == ORIGINAL)
check("task_metadata", change.startswith("完成 T03")
      and field(change, "基线") == BASELINE and field(change, "提交") == CANDIDATE
      and field(change, "修复轮次") == "0" and field(scaffold, "提交") == BASELINE)
previous_report_path = Path(field(inherited.decode(), "继承来源"))
previous_report = previous_report_path.read_bytes()
(OUT / "previous-report.bytes").write_bytes(previous_report)
previous_change_path = Path(field(inherited.decode(), "本轮变更"))
previous_change = previous_change_path.read_bytes()
(OUT / "previous-change.bytes").write_bytes(previous_change)
first_change_path = Path(field(previous_report.decode(), "本轮变更"))
first_change = first_change_path.read_bytes()
(OUT / "first-change.bytes").write_bytes(first_change)
first_source_path = Path(field(first_change.decode(), "继承来源"))
first_source = first_source_path.read_bytes()
(OUT / "first-prefix-source.bytes").write_bytes(first_source)
check("recursive_prefix", rows(previous_report.decode()) == prefix[:1]
      and rows(previous_change.decode()) == prefix[:1]
      and rows(first_change.decode()) == [] and rows(first_source.decode()) == []
      and previous_report.decode().startswith("通过，下一任务 T02")
      and inherited.decode().startswith("通过，下一任务 T03")
      and all(field(doc, "原始基线") == ORIGINAL for doc in (
          previous_report.decode(), previous_change.decode(), first_change.decode())))
historical = []
for row in prefix:
    task, baseline, candidate, approval_path, report_path, evidence_path = [c.strip() for c in row.split("|")[1:-1]]
    old_approval = Path(approval_path).read_bytes()
    old_report = Path(report_path).read_bytes()
    (OUT / (task + "-approval.bytes")).write_bytes(old_approval)
    (OUT / (task + "-report.bytes")).write_bytes(old_report)
    report_text = old_report.decode()
    old_spec = Path(field(report_text, "被验规格")).read_bytes()
    old_plan = Path(field(report_text, "被验方案")).read_bytes()
    (OUT / (task + "-spec.bytes")).write_bytes(old_spec)
    (OUT / (task + "-plan.bytes")).write_bytes(old_plan)
    metadata = {
        "task": task, "baseline": baseline, "candidate": candidate,
        "approval": approval_path, "report": report_path, "evidence": evidence_path,
        "evidence_exists": Path(evidence_path).is_dir(),
        "approved_spec": field(old_approval.decode(), "批准的规格"),
        "spec_sha256": hashlib.sha256(old_spec).hexdigest(),
        "approved_plan": field(old_approval.decode(), "批准的方案"),
        "plan_sha256": hashlib.sha256(old_plan).hexdigest(),
    }
    historical.append(metadata)
    check(task + "_historical_reference", old_approval.decode().splitlines()[0] == "通过"
          and report_text.startswith("通过") and field(report_text, "任务") == task
          and field(report_text, "基线") == baseline and field(report_text, "提交") == candidate
          and field(report_text, "原始基线") == ORIGINAL and metadata["evidence_exists"]
          and metadata["approved_spec"] == metadata["spec_sha256"]
          and metadata["approved_plan"] == metadata["plan_sha256"])
dump("approval-prefix.json", {"prefix": prefix, "inherited_path": str(inherit_path),
    "original_baseline": ORIGINAL, "historical": historical, "new_human_approval": approval})

initial_files = {}
for name in ("title_tools.py", "tests/test_title_tools.py", "tests/test_read_markdown.py", "README.md"):
    data = (PROJECT / name).read_bytes()
    initial_files[name] = data
    (OUT / ("candidate-" + name.replace("/", "-"))).write_bytes(data)
head = run("git-head", ["git", "log", "-1", "--format=%H"])
status = run("git-status-before", ["git", "status", "--porcelain=v1"])
parent = run("git-candidate-parent", ["git", "rev-parse", CANDIDATE + "^"])
check("head_and_clean", head.returncode == status.returncode == 0
      and head.stdout.decode().strip() == CANDIDATE and status.stdout == b"")
check("parent_is_task_baseline", parent.returncode == 0 and parent.stdout.decode().strip() == BASELINE)
for label, commit in (("original", ORIGINAL), ("latest-verified", prefix[1].split("|")[3].strip())):
    ancestor = run("git-" + label + "-ancestor", ["git", "merge-base", "--is-ancestor", commit, CANDIDATE])
    check(label + "_git_ancestor", ancestor.returncode == 0)
range_files = run("git-range-files", ["git", "diff", "--name-only", BASELINE + ".." + CANDIDATE])
range_diff = run("git-range-diff", ["git", "diff", BASELINE + ".." + CANDIDATE])
check("task_file_scope", range_files.returncode == 0
      and set(range_files.stdout.decode().splitlines()) == {"title_tools.py", "tests/test_read_markdown.py"})
old_tests = run("git-old-tests", ["git", "show", BASELINE + ":tests/test_read_markdown.py"])
tests_diff = run("git-tests-diff", ["git", "diff", BASELINE + ".." + CANDIDATE, "--", "tests/test_read_markdown.py"])
check("only_five_skip_lines_removed", old_tests.returncode == 0
      and old_tests.stdout.count(b'    @unittest.skip("T03")\n') == 5
      and old_tests.stdout.replace(b'    @unittest.skip("T03")\n', b"") == initial_files["tests/test_read_markdown.py"])
old_source = run("git-old-source", ["git", "show", BASELINE + ":title_tools.py"])
baseline_ast = ast.parse(old_source.stdout)
candidate_ast = ast.parse(initial_files["title_tools.py"])
def remove_read_body(tree):
    value = copy.deepcopy(tree)
    for node in value.body:
        if isinstance(node, ast.FunctionDef) and node.name == "read_markdown":
            node.body = node.body[:1]
    return ast.dump(value, include_attributes=False)
check("only_read_markdown_body_changed", remove_read_body(baseline_ast) == remove_read_body(candidate_ast))
placeholder_lines = [line for line in initial_files["title_tools.py"].decode().splitlines() if "raise NotImplementedError" in line]
check("placeholder_scope", len(placeholder_lines) == 3 and all(re.search(r"# T04\s*$", line) for line in placeholder_lines))
message = run("git-message", ["git", "log", "-1", "--format=%B"])
msg = message.stdout.decode()
check("commit_conventions", re.match(r"^[a-z]+\([^)]+\): .+", msg) is not None
      and re.search(r"^Task: T03$", msg, re.M) is not None and re.search(r"^Agent: .+$", msg, re.M) is not None)
selector = re.search(r"python3 - T03 <<'PY'\n(.*?)\nPY\n", scaffold, re.S).group(1).encode() + b"\n"
stored_selector = (ROOT / "task-runs/scaffold-2/task-selector.stdin").read_bytes()
(OUT / "scaffold-selector.bytes").write_bytes(stored_selector)
selector_tree = ast.parse(selector)
selector_manifest = next(ast.literal_eval(node.value) for node in selector_tree.body
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "TASK_TESTS" for t in node.targets))
task_card = tasks.split("## T03 ", 1)[1].split("## T04 ", 1)[0]
task_test_names = re.findall(chr(96) + r"(test_[a-z0-9_]+)" + chr(96), task_card)
check("new_complete_selector", selector == stored_selector
      and set(selector_manifest) == {"T01", "T02", "T03", "T04"}
      and [len(selector_manifest[t]) for t in ("T01", "T02", "T03", "T04")] == [4, 5, 5, 12]
      and selector_manifest["T03"] == task_test_names)
task_test = run("task-tests", ["python3", "-", "T03"], stdin=selector)
check("five_direct_tests", task_test.returncode == 0
      and b"T03: selected 5 tests" in task_test.stdout and b"Ran 5 tests" in task_test.stderr
      and b"skipped" not in task_test.stderr
      and all((name + " ").encode() in task_test.stderr for name in task_test_names))
unit = run("gate-unittest", ["python3", "-m", "unittest", "discover", "-s", "tests", "-v"])
check("complete_unittest_gate", unit.returncode == 0
      and b"Ran 26 tests" in unit.stderr and b"OK (skipped=12)" in unit.stderr
      and all((name + " ").encode() in unit.stderr for name in task_test_names))
compile_gate = run("gate-compileall", ["python3", "-m", "compileall", "-q", "title_tools.py", "tests"])
check("compileall_gate", compile_gate.returncode == 0 and not compile_gate.stdout and not compile_gate.stderr)

read_probe = b'''import json, sys
import title_tools
path, mode, expected = sys.argv[1:]
try:
    text = title_tools.read_markdown(path)
except Exception as error:
    if mode == "success":
        raise
    allowed = {"UnicodeDecodeError": UnicodeError, "PermissionError": PermissionError, "FileNotFoundError": FileNotFoundError}
    assert isinstance(error, allowed[expected]), (type(error).__name__, expected)
    message = str(error)
    assert message.strip()
    assert "PRIVATE_BODY" not in message
    if mode != "missing":
        content = bytes.fromhex(mode)
        decoded = content.decode("utf-8", errors="replace")
        assert repr(content) not in message
        assert decoded not in message
        assert repr(decoded) not in message
    print(json.dumps({"class": type(error).__name__, "message": message}, ensure_ascii=False))
else:
    assert mode == "success", "expected read failure"
    assert text == expected, (text, expected)
    print(json.dumps({"text": text}, ensure_ascii=False))
'''
manifest = []
def file_case(name, content, expected_text=None, expected_error=None, permission=False):
    path = OUT / ("fixture-" + name + ".md")
    before_exists = content is not None
    if before_exists:
        path.write_bytes(content)
        (OUT / (name + ".before.bytes")).write_bytes(path.read_bytes())
    else:
        assert not path.exists()
    if permission:
        path.chmod(0)
    try:
        if permission:
            precondition = run("permission-precondition", [
                "python3", "-S", "-c", "import pathlib, sys; pathlib.Path(sys.argv[1]).read_bytes()", str(path)])
            check("real_permission_precondition", precondition.returncode != 0 and b"PermissionError" in precondition.stderr)
        mode = "success" if expected_error is None else ("missing" if content is None else content.hex())
        result = run(name, ["python3", "-", str(path), mode, expected_text if expected_error is None else expected_error], stdin=read_probe)
        check(name + "_read_result", result.returncode == 0 and result.stderr == b"")
    finally:
        if permission:
            path.chmod(0o600)
    after_exists = path.exists()
    after = path.read_bytes() if after_exists else None
    if after_exists:
        (OUT / (name + ".after.bytes")).write_bytes(after)
    entry = {"name": name, "fixture": str(path), "before_exists": before_exists, "after_exists": after_exists,
        "before_sha256": hashlib.sha256(content).hexdigest() if content is not None else None,
        "after_sha256": hashlib.sha256(after).hexdigest() if after is not None else None,
        "same_bytes": content == after, "permission_precondition_saved": permission}
    manifest.append(entry)
    check(name + "_bytes_preserved", content == after and before_exists == after_exists, entry)
    return path

plain = "正文 AbC 你好，世界！\n\u3000没有标题\t保留空白\n"
file_case("bytes-utf8-no-heading", plain.encode(), expected_text=plain)
crlf = "## 二级\r\n# \u3000AbC\t\t你好，世界！\r\n# 后续\r\n"
crlf_path = file_case("bytes-crlf", crlf.encode(), expected_text=crlf.replace("\r\n", "\n"))
combination = run("read-extract-combination", ["python3", "-", str(crlf_path)], stdin=b'''import sys
import title_tools
assert title_tools.extract_title(title_tools.read_markdown(sys.argv[1])) == "AbC \xe4\xbd\xa0\xe5\xa5\xbd\xef\xbc\x8c\xe4\xb8\x96\xe7\x95\x8c\xef\xbc\x81"
print("AbC \xe4\xbd\xa0\xe5\xa5\xbd\xef\xbc\x8c\xe4\xb8\x96\xe7\x95\x8c\xef\xbc\x81")
''')
check("read_extract_combination", combination.returncode == 0 and not combination.stderr
      and combination.stdout.decode() == "AbC 你好，世界！\n")
file_case("bytes-invalid-utf8", b"PRIVATE_BODY_INVALID_ENCODING\xff\n", expected_error="UnicodeDecodeError")
file_case("bytes-missing", None, expected_error="FileNotFoundError")
file_case("bytes-unreadable", b"# PRIVATE_BODY_UNREADABLE\n", expected_error="PermissionError", permission=True)
dump("file-byte-manifest.json", manifest)
source_imports = []
for node in ast.walk(candidate_ast):
    if isinstance(node, ast.Import):
        source_imports.extend(alias.name for alias in node.names)
    elif isinstance(node, ast.ImportFrom):
        source_imports.append(node.module)
read_fn = next(node for node in candidate_ast.body if isinstance(node, ast.FunctionDef) and node.name == "read_markdown")
open_calls = [node for node in ast.walk(read_fn) if isinstance(node, ast.Call)
    and isinstance(node.func, ast.Name) and node.func.id == "open"]
check("readonly_utf8_standard_library", source_imports == ["argparse"] and len(open_calls) == 1
      and ast.literal_eval(open_calls[0].args[1]) == "r"
      and next(ast.literal_eval(kw.value) for kw in open_calls[0].keywords if kw.arg == "encoding") == "utf-8")
head_after = run("git-head-after", ["git", "log", "-1", "--format=%H"])
status_after = run("git-status-after", ["git", "status", "--porcelain=v1"])
file_hashes = [{"path": name, "before": hashlib.sha256(data).hexdigest(),
    "after": hashlib.sha256((PROJECT / name).read_bytes()).hexdigest()} for name, data in initial_files.items()]
check("project_unchanged", all(h["before"] == h["after"] for h in file_hashes)
      and head_after.stdout.decode().strip() == CANDIDATE and head_after.returncode == 0
      and status_after.returncode == 0 and status_after.stdout == b"")
dump("result.json", {"candidate": CANDIDATE, "baseline": BASELINE, "original_baseline": ORIGINAL,
    "project": str(PROJECT), "report": str(REPORT), "checks": CHECKS, "file_hashes": file_hashes,
    "all_passed": all(c["passed"] for c in CHECKS)})
print(json.dumps({"all_passed": all(c["passed"] for c in CHECKS), "check_count": len(CHECKS),
    "failures": [c for c in CHECKS if not c["passed"]]}, ensure_ascii=False, indent=2))
