通过

任务: 整体
修复轮次: 0
基线: 2f88d59b0d214967b64b285e96d764f26bc71c30
提交: 0ff54fa35002477c033f306e46089cfda738e3d1
原始基线: 2f88d59b0d214967b64b285e96d764f26bc71c30

## 检查项

独立检查范围为绑定 `plan` 的整体原始基线到当前 HEAD，包含首次骨架、T01/T02、重规划后的增量骨架以及 T03/T04；未用重规划时的 `6773f932` 或新版骨架提交缩小范围。实际 diff 为四个文件，444 行增加、3 行删除：`title_tools.py`、`tests/test_title_tools.py`、`tests/test_read_markdown.py`、`README.md`。审查者未参与该项目的实施、骨架或逐任务验证。

原始证据目录：`/private/tmp/sheltie-c002-t16-82c6c55/task-runs/whole-review/`。下文文件名均相对此目录；`review.py` 和 `behavior.py` 保存独立核查方法。每条本轮业务、门禁及主要 Git 命令的 `.json` 保存实际 argv、cwd、UTC 起止时间、退出状态与环境覆盖，同名 `.stdout/.stderr` 保存原字节，经 stdin 运行的命令另存 `.stdin`。`closure.json`、`behavior-result.json`、`test-preservation.json` 保存汇总与输入摘要。

项目 cwd 为 `/private/tmp/sheltie-c002-t16-82c6c55/project`。本轮移除 `PYTHONPATH`，设置 `PYTHONIOENCODING=utf-8`，字节码缓存写入证据目录，完整门禁 argv 保持批准原文。额外环境验收使用本轮通过 `python3 -m venv --without-pip` 创建的空 venv，其 `bin/python3 -S` 不加载 site-packages。未修改项目源码、测试、README、冻结输入、Sheltie 仓库或引擎状态，没有 submit。

### 原始需求与验收

| 项 | 结果 |
| --- | --- |
| brief 绑定输入的完整性 | 通过。spec、plan、tasks、scaffold、project 指针、checklist、template 的实际 SHA-256 均等于 brief；保留 `input-*.bytes` 和 `closure.json`。`fix_change` 未绑定，本轮不是复审。 |
| 完整原始需求及重规划覆盖 | 通过。实际打开 `start-inputs/request`，与冻结 spec 验收 1—10、两版 plan/tasks 逐项比较；新版只重排未验证读取及 CLI 工作，保留 Unicode 空白、严格首个标题、UTF-8 明确文件、只读、CLI 协议、标准库与门禁要求，以及真实确认条件。见 `original-request.bytes`、`initial-plan/tasks.bytes`、`input-spec/plan/tasks.bytes`、`reviewed-1/2-plan/tasks.bytes`。 |
| 规格 1：Unicode 空白与字符保留 | 通过。`title_tools.py:12` 以 `split()` 的标准库空白定义和 ASCII 空格连接实现；T01 的混合全角空白、不换行空格、制表符、换行正例实际返回手写期望 `AbC 你好，世界！`，汉字、标点和大小写保留。见 `gate-unittest.stderr`、`readme-functions.*`、`normal-normalize-success.*`、`empty-venv-no-site-normalize-success.*`。 |
| 规格 2：空结果拒绝 | 通过。`title_tools.py:13-14` 在空结果时抛固定说明的 ValueError；四种空输入由原 T01 subTest 实际验证，CLI 空白输入退出 2 且 stdout 空。见 `gate-unittest.stderr`、两模式 `*-normalize-empty.*`。 |
| 规格 3：首个严格匹配标题 | 通过。`title_tools.py:24-26` 按 `splitlines()` 顺序仅匹配行首 `# `，复用 `normalize_title`，匹配后立即返回；二级、缩进、缺空格及后续标题的手写正例实际通过。代码块也按原文行顺序选择，符合冻结规格的不解析上下文假设，README 已说明。见 `gate-unittest.stderr`、`readme-functions.*`、两模式 `*-extract-success.*`。 |
| 规格 4：无标题和首个空标题拒绝 | 通过。无匹配抛固定 ValueError；首个匹配的空结果由规范化函数立即拒绝，没有回退。函数正反例和实际 CLI 均通过。见 `gate-unittest.stderr`、两模式 `*-no-heading.*`、`*-empty-heading.*`。 |
| 规格 5：normalize 成功输出 | 通过。本轮两种解释器模式实际退出 0，stdout 恰为 `AbC 你好，世界！` 加一个换行，stderr 空。入口 `main` 调用同一规范化函数。见两模式 `*-normalize-success.json/.stdout/.stderr`。 |
| 规格 6：extract 显式 UTF-8 与原字节保留 | 通过。`read_markdown` 明确使用 `open(path, "r", encoding="utf-8")`，不写回；CLI 将显式文件参数传入该函数，再调用既有提取函数。本轮真实含多个标题、CRLF、Unicode 空白的 UTF-8 文件，两模式均退出 0，输出首个规范标题一行；已有输入逐次全字节一致。文本模式转换 CRLF 不改变输入文件。见 `success.before.bytes`、两模式 `*-extract-success.*` 及各 `*.after.bytes`。 |
| 规格 7：全部规定错误边界 | 通过。本轮实际覆盖空白标题、无标题、首个空标题、非法 UTF-8、不存在、不可读、无子命令、两个子命令各缺参数、未知子命令；另测额外私密参数。两模式各 13 次 CLI 调用，包括两个成功路径。全部失败退出 2，stdout 空，stderr 有安全原因，无 traceback 或正文回显，已有输入字节不变，不存在文件没有创建。不可读用真实 chmod(0)，先由独立子进程得到 PermissionError 再调用 CLI，finally 恢复权限；未 mock、skip 或降低断言。见 `normal-*`、`empty-venv-no-site-*` 原文、`behavior-result.json`。 |
| 规格 8：标准库、无第三方及当前禁网执行闭包 | 通过，范围限定如下。本轮 venv 未安装 pip 或其他包，`include-system-site-packages=false`，site-packages 目录实际为空；`-S` 的实际 sys.path 只有项目入口和标准库目录。当前 use_default 子进程继承 seatbelt，实际记录 `CODEX_SANDBOX=seatbelt`、`CODEX_SANDBOX_NETWORK_DISABLED=1`，同闭包 IPv4 TCP connect(1.1.1.1:443) 得到 PermissionError/EPERM。上述空解释器在同执行上下文实际通过两个成功与全部失败用例。源码导入只有 argparse/sys，项目没有第三方声明或网络访问路径。见 `execution-environment.*`、`venv-config.bytes`、`empty-site-packages.json`、两模式 CLI 原文及原导入测试。 |
| 规格 9：README 两条完整门禁 | 通过。本轮独立运行 `python3 -m unittest discover -s tests -v`，退出 0，Ran 26 tests，全部实际通过，没有 skip；`python3 -m compileall -q title_tools.py tests` 退出 0，无编译错误，stdout/stderr 空。见 `gate-unittest.*`、`gate-compileall.*`。 |
| 规格 10：任务拆分、提交与真实确认 | 通过。原方案和新版方案均四项小任务；完整六个新增提交均带 Task trailer，四个业务提交分别为 T01—T04，骨架另标 scaffold。实际核旧版批准及条件、真实「同意上述重规划」、新版「批准新版，保留原条件」及对应被审字节；旧批准覆盖 T01/T02，新批准覆盖 T03/T04，没有拿旧批准代替新版。四层独立报告的原始基线一致，每层仅追加本轮任务，implement 自报只继承前缀；新 plan/tasks 中旧两行仍是最新四行的原样前缀。见下方额外历史来源说明、`human-decisions.bytes`、`approval-T01..T04.bytes`、`replanning-decision.bytes`、`reviewed-*.bytes`、`history-*`、`git-message-T01..T04.*` 和 `closure.json`。 |

### 审查清单

| 项 | 结果 |
| --- | --- |
| 1—4：需求证据、分支与边界、行为断言、无关闭测试 | 通过。逐条需求证据见上表；正反例断言手写输出、退出码、异常类型、真实文件字节和权限。原 21 项测试除启用 skip 及原 T03 归属改为 T04 外逐字保留；增量五项读取测试仅移除 T03 skip。当前 26 项没有 ignore、skip 或注释关闭，未用绿色数量替代语义审查。见完整 diff、`test-preservation.json` 和冻结测试历史镜像。 |
| 5—7：外部输入、秘密与路径 | 通过。argparse 校验命令结构，规范化拒绝空标题，读取显式 UTF-8 文件并在 CLI 安全分类错误；无硬编码秘密或项目实现中的个人绝对路径。产品允许显式选择读取文件，不存在项目目录内写入或由输入拼接命令执行的路径。错误输出使用固定说明，不直接输出 argparse message 或读取/解码异常正文；真实私密输入负例通过。 |
| 8—12：复用、真实接口、错误帮助与无占位机制 | 通过。提取复用规范化，CLI 复用读取及提取；公开函数及 parser 均有真实调用者。错误说明分别提示有效命令/参数、UTF-8 编码、文件与读取权限或标题问题，满足批准的固定安全说明方案。无复制业务规则、无额外依赖、无空实现、未来开关或兼容层。冻结接口说明用于解释合同与安全条件，未发现影响可维护性的注释问题。 |
| 13：每提交可编译且有 Task trailer | 通过。独立将原始基线之后六个提交各自的 Python 文件导出到证据目录，再逐个 compileall，全部退出 0；读取每个提交消息核 Task 行。四项任务的历史完整门禁原文亦逐项核验。见 `git-all-commits.*`、`compile-*.json/.stdout/.stderr`、`history-T01..T04-gate-*`。导出副本只在证据目录，未 checkout 或改变正式项目。 |
| 14：行为与 README 一致 | 通过。README 说明函数、命令、严格首个标题规则、只读、成功一行、错误退出 2、正文保密、标准库及禁网限制、原门禁和审批要求；函数示例按 README 原块实际执行得到两行手写期望，CLI 等价示例也独立实际通过。见 `readme-functions.json/.stdin/.stdout/.stderr`、README diff 与两模式成功原文。 |
| 15：改动范围 | 通过。仅四个批准的项目文件，全部服务原始标题工具需求；没有改宿主配置、引擎、网络资源、第三方依赖或引入规格范围外的能力。SafeArgumentParser 用于履行实际批准的错误正文保密条件，属于获批新版方案。 |
| 突变测试 | 未跑突变测试。当前 PATH 中未安装 Python 突变工具 mutmut 或 cosmic-ray；按冻结审查说明跳过，没有安装工具或把未运行写成通过。见 `mutation-status.json`。 |
| 项目与冻结输入保留 | 通过。HEAD 前后均为上述候选，git status 前后为空，四份正式项目文件全字节摘要未变。全部 brief 输入有初始摘要与原字节镜像；本轮未写入绑定输入。见 `git-status-before/after.*`、`git-final-head.*`、`behavior-final-status.*`、`closure.json` 与 `behavior-result.json`。 |

### 额外历史来源与证据边界

整体 brief 没有将 verify#4 作为绑定文件；本报告没有伪造绑定输入，也没有写 verify 专用交接字段、累计任务表或新增 Task 验证行。为核需求 10，实际另外打开与当前候选一致的 `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-004/attempt-000/outputs/report.md`，沿其继承来源逐层读取 verify#3 → verify#2 → verify#1 → 首次空表 plan/tasks，以及对应 implement#1—#4、两版真实审批、改方案决定和原始门禁输出。原始报告及实际来源路径、摘要保存在 `history-verify-*.bytes`、`history-implement-*.bytes` 和 `closure.json`。确认四项验证的累计前缀正确，没有把新版 plan 的旧两行当全部完成。

真实确认采用 `/private/tmp/sheltie-c002-t16-82c6c55/human-decisions.json` 机械保存的本会话用户回复：旧批准 `call_ZWTMsF6X81GPHikRt9wXUSPy/0`、重规划 `call_y1C96BSiygLZkIjKbGZZMMji/0`、新版批准 `call_bAUqDu6CHZknYa5vxVjQCRWj/0`。审批文件和被审原字节匹配对应规格/方案摘要，记录顺序与执行历史一致；这不是独立真人身份认证。条件「错误信息不得回显输入正文」由本轮实际错误正反例再核，未从批准本身推定履行。

规格 8 的环境结论仅覆盖本次明确记录的 Python 执行闭包。单次 EPERM 直接证明所测连接被权限拒绝；`-S` 直接证明不加载 site-packages。这里结合明确禁网执行上下文、实际空环境及同闭包业务成功/失败，接受这一具体执行环境的验收；未取得任意 Host、所有协议、任意攻击代码或整机信任资格，没有用私有 sandbox_check 返回值证明这些能力。

本报告「通过」只表示该隔离标题工具项目从整体原始基线到候选的冻结需求与审查清单没有阻断项，不代表整个 C002 完成、C002-T16 的所有宿主场景完成或任何发布批准。本轮没有取得 usage 数据，usage 保持缺失，不能记为 0。

补充静态证据收集时，首次猜测的 `task-runs/scaffold-1/` 路径不存在；该核查脚本停止，未修改项目。随后实际读取原始 scaffold 报告，并独立导出六个提交验证编译；该证据定位错误不是业务门禁失败，纠正说明保存在 `test-preservation.json`。

## 发现

无。阻断项 0 条，建议 0 条。
