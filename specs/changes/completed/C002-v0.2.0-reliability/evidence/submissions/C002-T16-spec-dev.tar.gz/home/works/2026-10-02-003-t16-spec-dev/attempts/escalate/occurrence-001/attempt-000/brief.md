# 任务书：人工决策：卡住、反复失败或需要授权

Work: 2026-10-02-003-t16-spec-dev（t16-spec-dev）
节点: escalate#1，第 0 次尝试
来自: verify#2（branch 边）
执行者: human

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| spec | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/spec/occurrence-001/attempt-000/outputs/spec.md | bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38 |
| approval | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | 707a70341dd63d69d4b315b984646e192e61d655441e2f253f5df94b42738466 |
| tasks | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-001/attempt-000/outputs/tasks.md | 1a40fb9e925596df71e713a696cd70c5c121042574a115435e08a41620a1dd20 |
| plan | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-001/attempt-000/outputs/plan.md | b07e36e2bb55162e0d3342cab3d8a2820544b370240fe528bd57bee2e1199bf3 |
| scaffold_report | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/scaffold/occurrence-001/attempt-000/outputs/scaffold.md | 65853b37a380582e68e9617f5f9111a59c066a0f915426c4c0b64d7627cc8437 |
| implement_change | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/implement/occurrence-002/attempt-000/outputs/change.md | 043e63e8e78984eac74aeb94ed6aa2179895d3794bb995e291bf66d5c811da4b |
| fix_change | 尚无（上游 fix 还没有产出） | |
| verify_report | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md | 5986d1198eb33a5ebc909a2904ddce19ded9ee1dec5e399e869ceb7c3918ee22 |

## 说明

这一步由人完成。agent 在实现阶段卡住了，或者同一个任务修了两轮还不过，或者要做一件需要你授权的事。你来决定接下来怎么走。

## 读什么

任务书开头的「来自」一行告诉你是谁卡住了（`scaffold`、`implement`、`fix` 或 `verify`）。对应的那份报告是你要看的，其余的可能是过期的：

1. `scaffold_report`、`implement_change` 或 `fix_change`：agent 的报告。第一行是 `卡住` 或类似，「备注」里写了卡在哪、需要什么。骨架卡住通常是方案与现有代码冲突，或某条验收写不出测试；这类问题多半要选 `改方案`。
2. `verify_report`：验证报告。第一行若是 `不通过，需要人`，「发现」里是反复修不掉的问题。
3. `tasks`、`plan`：需要时查任务描述与方案。

通常五分钟能看完。不需要自己去修代码；如果你想亲手改，改完提交到项目仓库，再在决定里说明。

## 写什么

写 `decision.md`。**第一行只写下面四个词之一**，协调者按它选下一步：

- `继续`：回到卡住的那一步（骨架、实现、修复或验证），带着你的提示再来一次。适合「agent 缺一个关键信息」「方向对但走偏了」「你已经亲手改了一部分」「批准记录写错了，要更正」。
- `跳过`：放弃当前任务，从下一个任务继续。第二行写 `下一任务 Tnn`。适合「这个任务本身不重要」或「先做别的再回头」。
- `改方案`：回到 `plan` 重写方案与任务清单。适合「任务拆错了」「方案走不通」。
- `止损`：停止实现，直接写交付说明，把已完成的部分交出去。适合「继续下去不值」。

第一行之后写你的意见，每条一行，越具体越好：缺的信息、你批准的动作（例如「可以安装 `xyz` 依赖」「可以删除 `legacy/` 目录」）、你亲手改了什么。这些话会原样进入下一步的任务书。

## 更正批准记录

批准摘要写错时选「继续」，并写 `更正原审批: <原decision路径>`、`批准的规格: <当前spec文件的sha256>`、`批准的方案: <当前plan文件的sha256>`。从本任务书 `approval` 输入取原审批路径，从 `spec`、`plan` 输入分别计算 sha256（`shasum -a 256 <路径>`）。原审批必须第一行为「通过」。保留原条件；需要改条件时逐条写明。普通「继续」或口头同意不能代替版本更正。下游报告会引用本文件与原审批，供后续重规划核验。

## 授权的写法

agent 因为「需要授权」卡住时，你的决定要写清授权范围，例如「允许修改 `.github/workflows/ci.yml`，只加一个步骤」。写「随便你」等于没写。不想授权就选 `跳过` 或 `止损`。

## 写到哪

把 `decision.md` 写到任务书「输出要求」里 `decision` 对应的路径，然后运行任务书末尾的 `sheltie attempt submit` 命令。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| decision | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/escalate/occurrence-001/attempt-000/outputs/decision.md | 是 | 16 KiB |

写完输出文件后，在终端运行：

    sheltie attempt submit 2026-10-02-003-t16-spec-dev --attempt escalate#1.0 --summary "<一句话结论>"
