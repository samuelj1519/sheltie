# 任务书：写交付说明

Work: 2026-10-02-003-t16-spec-dev（t16-spec-dev）
节点: deliver#1，第 0 次尝试
来自: review#1（main 边）
执行者: agent（standard）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| spec | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/spec/occurrence-001/attempt-000/outputs/spec.md | bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38 |
| plan | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-002/attempt-000/outputs/plan.md | 557a7ff9d0614ac2c0a69ba59eec3bb8a3ce5c3ea6c26cb6c5b3420bba4ad40d |
| tasks | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-002/attempt-000/outputs/tasks.md | 58f23f75ffc9feeab72f3b74f93833d38f0cdf357159b166d76bc0cde094e6be |
| project | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/start-inputs/project | a626a063e6b4c5d7280f59d04bbd168cb73f474fc0af2fbc74ed7589233b26c3 |
| report | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/review/occurrence-001/attempt-000/outputs/report.md | 07936dee4afa754055b439120495a5019ff557518d4817e0af3242acb354a930 |
| escalation | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/escalate/occurrence-001/attempt-000/outputs/decision.md | d2ae23a3f354a7c84762927711b1aeb79d0d212a009b651f1e6afe0724b8defe |

## 说明

你要写一份交付说明，让没跟过程的人五分钟内知道做了什么、怎么验、还欠什么。

## 读什么

1. `spec`：目标与验收标准。
2. `plan`：原始基线与门禁。
3. `tasks`：任务列表。
4. `report`：审查报告，里面的「建议」要抄进「遗留」。标「尚无」时说明这是止损交付，没有经过整体审查，在交付说明第一行注明。
5. `escalation`：人的决定。任务书「来自」是 `escalate` 时读它，把它的意见抄进「遗留」，并在「验收标准」逐条里如实写哪些没做。
6. `project`：进入项目根，`git log <原始基线>..HEAD --oneline` 拿提交列表；若项目有 `CHANGELOG.md`，在「未发布」一节加一条本次改动的摘要并单独提交一次，提交信息 `docs(changelog): <需求一句话>`，末尾 `Task: deliver`、`Work: <work_id>`、`Agent: <模型名>`。

## 写什么

`delivery.md` 按顺序：

1. 一句话：做了什么。止损交付时以「止损交付：」开头。
2. 验收标准逐条：怎么验证（命令或操作），结果。
3. 提交列表：`git log` 的输出原样。
4. 遗留：审查建议、方案「风险」里成真的、你注意到但没在范围内的。没有就写「无」。
5. 对外动作：把 push、开 PR 需要的准确命令写出来，例如 `git push origin <分支>`。**你不执行它们。** 对外动作由人在批准后自己做。
6. 下一步建议：一到三条，可以为空。

不写过程叙述，不写感想。

你提交之后还有一步 `retro`（反思）。之后 Work 停下等人批准；人同时读这份文件与反思，运行对外动作，执行 `sheltie gate approve`，Work 才算结束。

## 写到哪

写到 `delivery` 对应路径。

## 怎么回复协调者

一句话：交付说明已写，提交共几个，遗留几条。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| delivery | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/deliver/occurrence-001/attempt-000/outputs/delivery.md | 是 | 32 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
