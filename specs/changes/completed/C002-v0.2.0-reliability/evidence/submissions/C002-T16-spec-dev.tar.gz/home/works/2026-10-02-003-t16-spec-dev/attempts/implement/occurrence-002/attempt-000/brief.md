# 任务书：实现一个任务

Work: 2026-10-02-003-t16-spec-dev（t16-spec-dev）
节点: implement#2，第 0 次尝试
来自: verify#1（main 边）
执行者: agent（standard）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| tasks | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-001/attempt-000/outputs/tasks.md | 1a40fb9e925596df71e713a696cd70c5c121042574a115435e08a41620a1dd20 |
| spec | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/spec/occurrence-001/attempt-000/outputs/spec.md | bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38 |
| plan | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-001/attempt-000/outputs/plan.md | b07e36e2bb55162e0d3342cab3d8a2820544b370240fe528bd57bee2e1199bf3 |
| scaffold | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/scaffold/occurrence-001/attempt-000/outputs/scaffold.md | 65853b37a380582e68e9617f5f9111a59c066a0f915426c4c0b64d7627cc8437 |
| project | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/start-inputs/project | a626a063e6b4c5d7280f59d04bbd168cb73f474fc0af2fbc74ed7589233b26c3 |
| rules | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/workbook/resources/checklists/implementer-rules.md | 8134de2dbc39d65ad2de9ca9e0efc5c22d0d9543eb550e05403a173e8ac82a90 |
| report | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-001/attempt-000/outputs/report.md | 4bc14c926169f7c745e5a6cd7be539716d05ec0d1cc823bd4c469431e3b88bda |
| decision | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | 707a70341dd63d69d4b315b984646e192e61d655441e2f253f5df94b42738466 |
| escalation | 尚无（上游 escalate 还没有产出） | |

## 说明

你要完成任务清单里的**一个**任务。类型、签名、注释、测试都已经在骨架里，你的工作是启用这个任务的测试，把占位的函数体填成实现，让测试变绿，过门禁，提交一次。只做一个任务。

先读 `rules`，那是硬规则。

## 这轮做哪个任务

看任务书开头的「来自」一行：

| 来自 | 做什么 |
| --- | --- |
| `scaffold` | 从当前 plan/tasks 的已验证任务表确定前缀，选择第一个尚未验证的任务；首次空表时是 `T01` |
| `verify` | 读 `report`，做它第一行写的那个任务。报告里对前一个任务的提醒照做 |
| `escalate` | 读 `escalation`。第一行 `继续`：重做你上次卡住的任务，「备注」里有人给的信息与授权。第一行 `跳过`：做它第二行指定的任务 |

来自别处的 escalation/report 不用于选择本轮任务或替代人工决定。累计事实另按下面的交接规则读取，不能因为报告来自上一节点就丢弃已验证前缀。

## 读什么

1. `decision`：`plan-review` 的批准记录，开工前先核版本。它写的「批准的规格」「批准的方案」两个 sha256 必须分别等于任务书 `spec`、`plan` 输入文件的内容摘要（`shasum -a 256 <路径>`，Linux 是 `sha256sum`）。对不上说明方案在批准后被修订过、旧批准已失效：按卡住处理，把两个哈希写进「备注」，不按没批过的方案开工。人可以在 `escalate` 的决定里更正批准记录，那时按人的更正继续并把更正抄进报告。对得上时，「通过」附带的条件逐条照做。`spec` 只用来核摘要，内容不读。
2. `tasks`：只读你这轮的那一条。记下「只改哪些文件」与「要变绿的测试」。
3. `scaffold`：拿「单任务测试命令」；「给实现者的提醒」里若有你这个任务的，读。
4. 「只改哪些文件」列出的源码。函数的文档注释就是你要实现的行为。
5. 「要变绿的测试」的代码。它们是标准答案。
6. `plan`：只在注释和测试都没说清时查「改法」相关几行与「门禁」一节。
7. `project`：进入项目根工作。

不读别的文件。

## 交接已验证任务

开工前读取 plan/tasks 的原始基线及已验证任务表。只要 report 已绑定，就核其原始基线和证据来源，以其独立验证过的累计表为最新事实，包括 escalate「继续/跳过」返回。plan/tasks 的旧表可以落后，但必须是该最新表未改写的前缀；重规划后的 scaffold 也核新 plan/tasks 已保留此前事实。没有 report 时，只能使用可证明来源的 plan/tasks 表。缺字段、漏行、没有可信来源或两份输入基线不一致时按卡住处理，不能退回一个更旧的空表。

change 必须记录原始基线、继承来源文件路径和完整旧表，包括卡住的报告。只携带已有验证事实；本轮提交仍是待验证候选，不由实现者自己追加到已验证表。后续 verify 会独立核 Git、审批与原始证据后追加。

## 怎么做

1. `git status`，工作区必须干净。不干净就按「卡住」处理，不动文件。
2. 去掉本任务测试上的禁用标记（Rust 删 `#[ignore = "Tnn"]`，其他语言删对应标记）。跑单任务测试命令，看到它们全红。零个测试或编译不过，先修到能跑出红。
3. 挑一个红的测试，读它的断言，填对应的占位体。跑，绿了再挑下一个。不一次改很多。
4. 全绿后跑「门禁」全部命令，修到全过。
5. 记下 `git rev-parse HEAD`，这是本任务的**任务基线**。然后 `git add` 白名单里的文件加去掉禁用标记的测试文件，`git commit`。提交信息格式见 `rules` 末尾「提交信息」。
6. 提交后记下 `git rev-parse HEAD`，这是本任务的**候选提交**。

## 什么时候算卡住

`rules` 第 9 条。另外三种：缺只有人知道的信息；要做任务外的高风险动作（装依赖、改 CI、删目录、访问网络、改数据库、改别的模块接口）；环境坏了。卡住就 `git checkout -- .` 恢复工作区，不提交，写报告。「难」不算卡住。

## 人工更正批准版本

只有绑定的 escalation 第一行为「继续」、明确写出 `更正原审批: <原decision路径>`、`批准的规格: <当前spec的sha256>`、`批准的方案: <当前plan的sha256>`，且原审批第一行为「通过」时，才按更正核验当前版本。普通「继续」不等于批准。保留原审批的条件；人明确改动条件时按更正记录逐条核验。

在交接记录写 `审批更正来源: <该escalation路径>`，后续节点即使绑定了新 escalation，也从这条明确引用读取并核验更正。verify 的 `审批来源` 和本轮累计表行引用实际更正文件，另写 `原审批来源: <原decision路径>`；未更正时引用 decision。缺引用、摘要不符或原审批未通过时停止，不猜更正内容。

## 写到哪

把 `change.md` 写到 `change` 对应路径。**第一行只写 `完成 Tnn` 或 `卡住 Tnn`**，然后：

```
基线: <任务基线哈希，卡住时写 无>
提交: <候选提交哈希，卡住时写 无>
原始基线: <plan的整体原始基线，永不重设>
继承来源: <最新验证报告或当前方案路径；首次也是当前方案>
修复轮次: 0
启用的测试: <数量>
改动文件:
- path/a.rs
门禁:
- <命令>: 通过 | 失败（一行原因）
备注: <卡在哪、需要什么信息或授权；完成时可空>
```

在元数据之后写「已验证任务」表，列为 `任务 / 任务基线 / 候选提交 / 审批来源 / 验证报告 / 原始证据`。所有继承行原样复制，不追加本轮任务；首次写空表。只保存引用，不复制日志正文，change 总量不得超过 32768 字节。

## 怎么回复协调者

一句话重复第一行。完成就说完成，卡住就说卡住并带一句原因。不说「基本完成」。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| change | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/implement/occurrence-002/attempt-000/outputs/change.md | 是 | 32 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
