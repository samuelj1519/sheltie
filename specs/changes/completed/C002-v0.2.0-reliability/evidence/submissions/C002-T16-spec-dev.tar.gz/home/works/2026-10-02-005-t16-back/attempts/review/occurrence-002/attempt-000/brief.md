# 任务书：审查初稿

Work: 2026-10-02-005-t16-back（t16-back）
节点: review#2，第 0 次尝试
来自: draft#2（main 边）
执行者: agent（standard）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| article | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-005-t16-back/attempts/draft/occurrence-002/attempt-000/outputs/article.md | 3c94a359dc79a460988cd7be005818c836bb8aabcb2f92581c6165b20937ec84 |
| checklist | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-005-t16-back/workbook/resources/review-checklist.md | 887d65108d23a71b86f691183d2f9de26b8e45f864fc44e24c5e76ffbe96ed6a |

## 说明

读 `article`，按 `checklist` 逐条审查。你没有参与写作，只看结果。

- 每条清单项给「通过」或「不通过」，不通过的写明在文章哪一段、问题是什么、期望是什么。
- 不改文章。
- 结论写在输出文档第一行，只写「通过」或「不通过」。全部清单项通过才算通过。

写到 `verdict` 对应的路径。回复协调者时只重复第一行。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| verdict | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-005-t16-back/attempts/review/occurrence-002/attempt-000/outputs/review.md | 是 | 64 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
