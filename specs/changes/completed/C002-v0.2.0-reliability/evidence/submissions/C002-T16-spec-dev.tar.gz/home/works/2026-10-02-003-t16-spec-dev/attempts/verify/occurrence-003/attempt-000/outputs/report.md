通过，下一任务 T04

任务: T03
修复轮次: 0
基线: ba56d3fc3a25a9ca170183fd2315beb0ff37db5b
提交: 71821061f32d9c6496c2d621e673527bc785e4f6
原始基线: 2f88d59b0d214967b64b285e96d764f26bc71c30

本轮变更: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/implement/occurrence-003/attempt-000/outputs/change.md
继承来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md
被验规格: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/spec/occurrence-001/attempt-000/outputs/spec.md
被验方案: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-002/attempt-000/outputs/plan.md
被验任务: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-002/attempt-000/outputs/tasks.md
审批来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-002/attempt-000/outputs/decision.md

## 已验证任务

本轮 change、获批 plan/tasks 和新 scaffold 的 T01/T02 两行与继承来源逐字一致。已打开 verify#2、verify#1、两轮 change 及首次空表来源，并核历史审批摘要、报告字段和证据目录。本轮全部独立检查通过后仅追加 T03。

| 任务 | 任务基线 | 候选提交 | 审批来源 | 验证报告 | 原始证据 |
| --- | --- | --- | --- | --- | --- |
| T01 | 92e2d3f3fb14d077aac3cba9d10ec2b7df53f540 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-001/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-1/ |
| T02 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | 6773f932765895735a5786220653440afcba2d8f | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-2/ |
| T03 | ba56d3fc3a25a9ca170183fd2315beb0ff37db5b | 71821061f32d9c6496c2d621e673527bc785e4f6 | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-002/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-003/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-3/ |

## 检查项

原始证据目录为 /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-3/。以下文件名均相对此目录。每条命令的同名 .json 保存完整 argv、cwd、候选提交、stdin 路径、环境覆盖、起止时间和退出状态，.stdout/.stderr 保存原始字节；经 stdin 运行的 Python 命令另存完整 .stdin。独立复核脚本为 verify.py，37 项核对的汇总为 result.json。

项目命令的实际工作目录为 /private/tmp/sheltie-c002-t16-82c6c55/project。为保持项目只读，子进程移除 PYTHONPATH，设置 PYTHONIOENCODING=utf-8，将 PYTHONPYCACHEPREFIX 指向本证据目录 pycache/。未改批准的门禁 argv。

| 项 | 结果 |
| --- | --- |
| 重算 brief 绑定的 tasks、spec、plan、scaffold、change、project、template、decision、escalation SHA-256 | 通过；九项均与冻结摘要一致。见 brief.bytes、input-hashes.json、input-*.bytes。 |
| 新版审批首行、规格/方案摘要与条件 | 通过；审批首行为「通过」，规格摘要 bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38、方案摘要 557a7ff9d0614ac2c0a69ba59eec3bb8a3ce5c3ea6c26cb6c5b3420bba4ad40d 与被验字节一致，保留「错误信息不得回显输入正文」。本轮无审批更正，不用旧审批或普通 escalation 代替新版批准。见 input-decision.bytes、approval-prefix.json。 |
| 真实新版确认记录 | 通过；实际读取 human-decisions.json 的 call_bAUqDu6CHZknYa5vxVjQCRWj/0，答复为「批准新版，保留原条件」，两个摘要及条件均匹配。见 human-decisions.bytes、approval-prefix.json。该记录来源声明为本会话用户回复，不另声称真人身份认证。 |
| 累计两行与原始基线继承 | 通过；change、plan、tasks、新 scaffold 的六列累计表均原样保留 T01/T02；verify#2 → verify#1 → 首次空表来源未新增自报事实，原始基线一致。历史审批的被验摘要匹配，两条报告与证据目录存在。见 approval-prefix.json、inherited-report.bytes、previous-report.bytes、previous-change.bytes、first-change.bytes、first-prefix-source.bytes、T01-*.bytes、T02-*.bytes。 |
| 本轮 task baseline、candidate 与新 scaffold | 通过；change 的任务基线等于新 scaffold 提交 ba56d3fc3a25a9ca170183fd2315beb0ff37db5b，候选为 71821061f32d9c6496c2d621e673527bc785e4f6，修复轮次为 0。 |
| git log -1 --format=%H 与 git status --porcelain=v1，验证前后各一次 | 通过；HEAD 均为候选提交，status stdout 均为空。见 git-head、git-head-after、git-status-before、git-status-after 的 .json/.stdout/.stderr。 |
| git rev-parse <候选>^；git merge-base --is-ancestor <原始基线/最新已验证提交> <候选> | 通过；候选父提交正是本任务基线，整体原始基线及 T02 最新已验证候选均是其祖先。见 git-candidate-parent、git-original-ancestor、git-latest-verified-ancestor 的原文。 |
| 新 scaffold 的完整四任务选择器 | 通过；stdin 与 scaffold-2/task-selector.stdin 原字节一致，四项名单数量为 4/5/5/12，T03 精确对应任务卡五项直接读取测试。见 scaffold-selector.bytes、task-tests.stdin、verify.py。未复用旧 T03 CLI 名单。 |
| python3 - T03，stdin 为新 scaffold 完整选择器 | 通过；精确选中五项，全部实际运行成功，无 skip，退出 0。见 task-tests.json/.stdin/.stdout/.stderr。 |
| python3 -m unittest discover -s tests -v | 通过；独立运行退出 0，收集 26 项，T01/T02 九项及 T03 五项实际通过，T04 十二项仍禁用，结果为 OK (skipped=12)。见 gate-unittest.json/.stdout/.stderr。 |
| python3 -m compileall -q title_tools.py tests | 通过；独立运行退出 0，stdout/stderr 均为空。见 gate-compileall.json/.stdout/.stderr。 |
| git diff --name-only <任务基线>..<候选> | 通过；仅 title_tools.py、tests/test_read_markdown.py，无白名单外文件、快照或黄金文件。按单任务范围检查，未使用累计骨架范围。见 git-range-files、git-range-diff 的原文。 |
| git diff <任务基线>..<候选> -- tests/test_read_markdown.py，及完整测试字节比较 | 通过；只删除五行 T03 skip，其余名称、输入、断言和 helper 字节完全相同。见 git-tests-diff.stdout、git-old-tests.stdout、candidate-tests-test_read_markdown.py、verify.py。 |
| 本任务源码与占位体 | 通过；源码 diff 仅将 T03 read_markdown 占位替换为显式 UTF-8、r 模式的读取函数体；其余函数 AST 保留。三个剩余占位均明确标 T04，无 T03 或无编号占位。见 git-range-diff.stdout、git-old-source.stdout、candidate-title_tools.py。 |
| git log -1 --format=%B | 通过；首行为 feat(reader): 实现 UTF-8 只读文件读取，末段有 Task: T03 与 Agent: GPT-6。见 git-message.json/.stdout/.stderr。 |
| 无标题 UTF-8 正例与完整文件字节 | 通过；包含汉字、标点、大小写和 Unicode 空白的正文读取成功，无标题不被拒绝，返回值与手写期望相同；前后原字节相等。见 bytes-utf8-no-heading.json/.stdin/.stdout/.stderr/.before.bytes/.after.bytes。 |
| CRLF 文件读取、原字节与既有 extract_title 组合 | 通过；只读不改变 CRLF 原文件字节，读取文本按 Python 文本模式转为 LF；组合 extract_title 返回 AbC 你好，世界！。见 bytes-crlf 的原文及 before/after.bytes，read-extract-combination.json/.stdin/.stdout/.stderr。 |
| 无效 UTF-8 读取失败 | 通过；实际保留 UnicodeDecodeError（UnicodeError 子类），说明非空，未回显 PRIVATE_BODY、完整正文或其 repr；原文件字节相等。见 bytes-invalid-utf8.json/.stdin/.stdout/.stderr/.before.bytes/.after.bytes。 |
| 不存在文件读取失败且不创建文件 | 通过；实际保留 FileNotFoundError（OSError 子类），说明非空；前后均不存在。见 bytes-missing.json/.stdin/.stdout/.stderr、file-byte-manifest.json。无文件正文时，正文不回显检查无输入可比。 |
| 真实不可读文件前置 | 通过；实际 chmod(0) 后独立执行 python3 -S -c 'import pathlib, sys; pathlib.Path(sys.argv[1]).read_bytes()' <文件>，退出非零，原 stderr 明确含 PermissionError。未 mock、skip 或降低断言。见 permission-precondition.json/.stdout/.stderr。 |
| 不可读文件读取失败、正文保密及原字节 | 通过；前置成立后读取函数保留 PermissionError（OSError 子类），说明非空且未含正文私密标记、正文或 repr。finally 恢复权限后核完整原字节相等。见 bytes-unreadable.json/.stdin/.stdout/.stderr/.before.bytes/.after.bytes、file-byte-manifest.json。 |
| 本任务标准库、明确 UTF-8 与只读限制 | 通过；仅标准库 argparse 导入，读取使用 open(path, "r", encoding="utf-8")，无新增依赖、网络路径或写回。见 candidate-title_tools.py、verify.py。未据此声明 T04 禁止联网宿主资格已通过。 |
| 项目与绑定输入保留 | 通过；候选源码、两份测试及 README 的前后 SHA-256 相同，HEAD/status 未变化；冻结输入镜像仅保存在证据目录。见 result.json 的 file_hashes。 |

验证脚本首次解析将 scaffold 的任务文件表误计为累计表，并因正则未包含数字而漏识别带 utf8 的测试名。这两个证据解析问题已更正：累计表限定在「已验证任务」节，测试名允许数字。实际批准、表格字节和业务执行结果没有变化；未重复业务门禁。初次解析结果保存为 harness-parser-initial-result.json，更正说明在 result.json，verify.py 已使用更正后的解析规则。

## 发现

无。

本结论仅确认 fixture 项目 T03 的 UTF-8 只读读取路径独立通过，可以进入 T04。正文不回显条件已在本轮直接读取错误的适用范围内核对；CLI 成功输出、错误 stderr/退出 2、无 traceback、参数保密及禁止联网宿主资格仍由 T04 验证。当前十二项 T04 测试禁用，不构成 CLI 已完成、整体需求通过、C002-T16 完成或发布授权。

验证者未参与 T03 实现，仅写本报告及 verify-3 原始证据；未修改输入文件、project 源码、Sheltie 仓库或引擎状态，没有 submit。
