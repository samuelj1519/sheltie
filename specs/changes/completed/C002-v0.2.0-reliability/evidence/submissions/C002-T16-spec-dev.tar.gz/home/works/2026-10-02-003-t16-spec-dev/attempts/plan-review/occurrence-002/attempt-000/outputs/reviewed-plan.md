# 技术方案：保留已验证标题函数，拆分文件读取与 CLI 收尾

## 现状

- 项目根目录是 `/private/tmp/sheltie-c002-t16-82c6c55/project`；绑定的 `start-inputs/project` 指向此处。
- `README.md` 规定只用 Python 标准库、不联网，以及 unittest、compileall 两条门禁；项目没有 AGENTS.md、构建配置或 CI 工作流。
- `title_tools.py` 的 `normalize_title`、`extract_title` 已分别由 T01、T02 独立验证；`read_markdown`、`build_parser`、`main` 仍是占位体。
- `tests/test_title_tools.py` 共有 21 项预写测试：T01 四项、T02 五项已启用；原 T03 十二项 CLI 与依赖测试仍禁用。
- 最新独立报告为 verify#2；当前项目 HEAD 为已验证 T02 候选 `6773f932765895735a5786220653440afcba2d8f`，工作区干净。此 HEAD 只用于核查历史，不能替代整体原始基线。
- 真实 escalation 首行为「改方案」，仅授权重排未验证 T03/T04；原需求、已验证前缀与错误信息不回显输入正文条件均保留。

## 改法

- 新方案批准后的骨架阶段在 `title_tools.py` 保留全部函数签名和 T01/T02 实现字节，仅将 `build_parser`、`main` 的任务注释、占位标记改为 T04；新增 `SafeArgumentParser(argparse.ArgumentParser)` 及 `error(self, message: str) -> None` 的 T04 占位体。`read_markdown(path: str) -> str` 仍归 T03。
- 骨架新增 `tests/test_read_markdown.py`，预写 T03 五项直接调用读取函数的正反例并按 T03 禁用；在 `tests/test_title_tools.py` 仅将原十二项未启用测试的 `Task: T03`、skip 改为 T04，保留其名称、输入和全部断言，不修改九项已启用测试或公共测试辅助函数。选择器名单须完整写入新 scaffold 交接，不能复用旧选择器的 T03 名单。
- T03 只填写 `read_markdown` 一个函数体，显式以 UTF-8 只读指定文件，返回文本供既有 `extract_title` 使用；不检查标题、不写回文件。真实文件覆盖有效 UTF-8、原字节保留、无效 UTF-8、不存在、无法读取；错误保留读取和解码类别，不将文件正文或其 repr 拼入错误说明。
- T04 依赖 T03，填写 `SafeArgumentParser.error`、`build_parser`、`main` 三个函数体，提供 `python3 -m title_tools normalize <标题>` 和 `python3 -m title_tools extract <文件名>`。成功 stdout 仅有标题及一个换行，stderr 为空；规范化、读取、解码和参数错误均只在 stderr 安全说明原因、stdout 为空、退出 2。参数错误用固定说明处理，不能直接输出 argparse 含未知参数值的默认 message；同样不直接输出读取或解码异常中含输入信息的原始文本。
- T04 同时修改 `README.md`，收尾两个函数、两个子命令、UTF-8 明确文件参数、Unicode 空白和严格 `# ` 前缀、首个空标题拒绝、只读边界、输出与错误协议、标准库及不联网限制；保留两条门禁与 Task trailer 约定，逐项保留规格验收 1—10。
- 原 T01/T02 任务卡和已验证六列原始行原样保留；仅 T03/T04 待实施。每任务独立过全部门禁、提交并保留 `Task: TNN` trailer，候选提交及自报须交独立验证，不追加已验证行。

## 门禁

每个任务做完都要全部通过。命令取自项目 README，在项目根目录运行；本轮重规划未重新运行业务门禁，历史通过仅引用独立证据。

```bash
python3 -m unittest discover -s tests -v
python3 -m compileall -q title_tools.py tests
```

## 基线

原始基线（Work 开始时的 `git rev-parse HEAD`；改方案从上一版原样抄这一行，不重设）：`2f88d59b0d214967b64b285e96d764f26bc71c30`

## 风险

- 新方案和新任务仍待真实用户审核；escalation 只批准重规划，不等于批准这些新字节。对应执行动作前必须绑定新的实际审批与原字节副本；缺少批准摘要或条件时停止，不用旧方案审批覆盖新版。
- 不可读文件测试必须先由真实子进程证明读取失败为 PermissionError，再调用读取函数或 CLI；高权限环境若仍可读，则该项失败并停止交接，不能用 mock、跳过或降低断言冒充真实通过。恢复后还原权限并核对文件字节。
- Python `-S` 和标准库导入扫描只能证明不依赖 site-packages、未引入网络模块，不能证明宿主禁止联网。T04 独立验收须保存禁止联网环境的实际证据；缺证据时规格 8 不通过。
- 标题规则不变：只认行首 `# `，不接受二级、缩进或缺空格；首个空标题不回退；围栏中的匹配仍按原文行序选择，不解析上下文。出现与原需求冲突的实现需求时停在候选并交人决定。
- 读取错误、解码错误和 argparse 默认错误可能夹带输入信息。T03/T04 正反例分别核正文私密标记、输入原文及 repr 不进入错误说明；CLI 不输出 traceback，不能靠修改旧断言绕过审批条件。
- 白名单不够或函数体超过任务大小时停止并报告具体文件/接口；不悄悄增加任务或依赖。骨架只为未验证 T03/T04 准备测试和占位，不改冻结旧材料，不撤销其他 worker 编辑。
- 人工条件已由真实审批明确为“错误信息不得回显输入正文”，原 decision 与当前 escalation 均保存该条件；保留规格原文及验收 10，不重复询问已明确的条件。T01/T02 已实现路径的历史履行结果按原独立报告保留，T03/T04 的履行结果尚待独立验证，不能预记通过。

## 修订记录

- 2026-10-02 重规划：按 `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/escalate/occurrence-001/attempt-000/outputs/decision.md` 的真实人工「改方案」决定，仅把未验证 T03 改为读取和独立正反例、T04 改为 CLI 与 README；需求及错误不回显条件未改变。
- 从 `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md` 递归核 verify#1、对应 implement#1/#2、首次空表 plan/tasks；两层原始基线和累计前缀一致，独立报告均为通过，每层只追加本轮一行。实际打开审批、被验版本和 argv/stdout/stderr/退出状态，核 Git 提交、Task trailer、历史任务白名单和改动范围。
- 绑定 previous_change 的候选等于最新已验证 T02 提交，Git 祖先核查通过；它只保留合法旧 T01 前缀，不能覆盖最新 T01/T02 或追加自报事实。previous_fix_change 未绑定，无缺失的必需修复来源。
- 保留 T01/T02 两行历史事实和原始基线，未新增已验证任务；本轮没有改变旧验收条件，需重验事项为无。新 T03/T04 全部待骨架、实施与独立验证。

## 已验证任务

继承来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md；被审副本 /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/reviewed-plan.md、/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/reviewed-tasks.md

保留已独立验证的原始行；本轮核对来源链、审批与历史证据，不重做已验证任务。

| 任务 | 任务基线 | 候选提交 | 审批来源 | 验证报告 | 原始证据 |
| --- | --- | --- | --- | --- | --- |
| T01 | 92e2d3f3fb14d077aac3cba9d10ec2b7df53f540 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-001/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-1/ |
| T02 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | 6773f932765895735a5786220653440afcba2d8f | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-2/ |

## 需重验事项

无。原需求和已批准错误保密条件未改，不新增 T01/T02 重验任务；两项既有测试在后续每轮完整门禁中持续运行。T03/T04 的新测试、CLI 错误保密、只读、不可读文件及禁止联网环境均尚未验证，不能写成历史要求已满足。

## 本轮核对的版本引用

- `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/spec/occurrence-001/attempt-000/outputs/spec.md`：SHA-256 `bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38`。
- `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/reviewed-plan.md`：SHA-256 `b07e36e2bb55162e0d3342cab3d8a2820544b370240fe528bd57bee2e1199bf3`。
- `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/reviewed-tasks.md`：SHA-256 `1a40fb9e925596df71e713a696cd70c5c121042574a115435e08a41620a1dd20`。
- `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md`：SHA-256 `707a70341dd63d69d4b315b984646e192e61d655441e2f253f5df94b42738466`。
- `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/escalate/occurrence-001/attempt-000/outputs/decision.md`：SHA-256 `d2ae23a3f354a7c84762927711b1aeb79d0d212a009b651f1e6afe0724b8defe`。
- `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md`：SHA-256 `5986d1198eb33a5ebc909a2904ddce19ded9ee1dec5e399e869ceb7c3918ee22`。
- `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/implement/occurrence-002/attempt-000/outputs/change.md`：SHA-256 `043e63e8e78984eac74aeb94ed6aa2179895d3794bb995e291bf66d5c811da4b`。
