# 任务清单：保留 T01/T02，拆分读取与 CLI 收尾

按顺序做。T01/T02 已独立验证，以下原任务卡仅保留历史要求，不再实施；从 T03 开始。未验证任务是「启用预写测试、填占位体、过两条完整门禁、独立提交」，之后由独立验证者检查。新方案仍待真实用户审核。

原始基线: 2f88d59b0d214967b64b285e96d764f26bc71c30
继承来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md；被审副本 /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/reviewed-plan.md、/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/reviewed-tasks.md

## 已验证任务

原样复制最新独立验证报告的累计两行；不能从旧 tasks 的空表或 implement 自报重建完成事实。

| 任务 | 任务基线 | 候选提交 | 审批来源 | 验证报告 | 原始证据 |
| --- | --- | --- | --- | --- | --- |
| T01 | 92e2d3f3fb14d077aac3cba9d10ec2b7df53f540 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-001/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-1/ |
| T02 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | 6773f932765895735a5786220653440afcba2d8f | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-2/ |

## T01 规范化 Unicode 空白并拒绝空标题

- 只改哪些文件：`title_tools.py`、`tests/test_title_tools.py`
- 要变绿的测试：`test_normalize_collapses_mixed_unicode_whitespace`、`test_normalize_preserves_chinese_punctuation_and_case`、`test_normalize_rejects_empty_and_whitespace_only`、`test_normalize_keeps_single_word`
- 实现要点：填写 1 个函数体 `normalize_title`，用 Python 标准库的空白定义去掉首尾空白并把内部连续空白合为一个 ASCII 空格；空结果抛出带说明的 `ValueError`。空字符串、ASCII 空格、全角空格和混合 Unicode 空白在预置测试中分别检查，不增加依赖。
- 做完能观察到什么：启用本任务四项测试后运行两条完整门禁；包含全角首尾空白及不换行空格、制表符、换行的输入得到 `AbC 你好，世界！`，空白输入全部拒绝。
- 保留的验收要求：规格 1、2；规格 8 的标准库及不联网限制；规格 9 的两条门禁；规格 10 的任务独立提交和 `Task: T01` trailer。通过事实仅由独立验证追加。

## T02 按行提取首个严格匹配的一级标题

- 只改哪些文件：`title_tools.py`、`tests/test_title_tools.py`
- 要变绿的测试：`test_extract_ignores_nonmatching_heading_prefixes`、`test_extract_normalizes_first_heading`、`test_extract_chooses_first_matching_heading`、`test_extract_rejects_missing_heading`、`test_extract_rejects_empty_first_heading_without_fallback`
- 实现要点：依赖 T01，填写 1 个函数体 `extract_title`，按行顺序查找 `# ` 前缀，规范其内容后立即返回；没有匹配时抛出带说明的 `ValueError`。首个匹配内容为空时传播拒绝，不跳到后续标题；不接受前导缩进、二级标题或 `#` 后缺空格，不解析语法上下文。
- 做完能观察到什么：启用本任务五项测试后运行两条完整门禁；规格中的二级、缩进、缺空格行被忽略，首个匹配中的连续制表符合为一个 ASCII 空格，后续有效标题不影响结果。
- 保留的验收要求：规格 3、4；规格 8 的标准库及不联网限制；规格 9 的两条门禁；规格 10 的独立提交和 `Task: T02` trailer。

## T03 只读 UTF-8 文件读取与独立正反例

- 只改哪些文件：`title_tools.py`、`tests/test_read_markdown.py`
- 要变绿的测试：`test_read_markdown_returns_utf8_text_without_heading_validation`、`test_read_markdown_preserves_original_file_bytes`、`test_read_markdown_rejects_non_utf8_and_preserves_bytes`、`test_read_markdown_rejects_missing_file_without_creating_it`、`test_read_markdown_rejects_unreadable_file_and_preserves_bytes`
- 实现要点：依赖已验证 T01/T02，仅填写 1 个函数体 `read_markdown(path: str) -> str`，明确 UTF-8 和只读；它负责读取，不要求文本先有标题，不修改文件。真实正例包含汉字、标点、大小写和空白，另用含 CRLF 的文件比较读取前后完整字节，并组合既有 `extract_title` 得到首个标题；负例分别检查 UnicodeError、FileNotFoundError/OSError 和 PermissionError/OSError 等读取类别，异常说明不得拼入输入正文或 repr。不存在文件读取后仍不存在；已有文件在成功或失败后按字节不变。
- 做完能观察到什么：启用本任务五项预置直接读取测试，真实权限负例先以 `python3 -S -c 'import pathlib, sys; pathlib.Path(sys.argv[1]).read_bytes()' <文件>` 证明 PermissionError 再运行；完成后运行两条完整门禁。新增骨架后预计收集 26 项：既有九项及读取五项共 14 项实际通过，T04 十二项仍禁用；compileall 退出 0。保留完整 argv/stdout/stderr/退出状态及文件字节证据。权限前置不成立必须失败，不能 skip 或 mock。
- 保留的验收要求：规格 6、7 的 UTF-8、明确文件、只读、无效 UTF-8、不存在及无法读取边界；这一步只有读取函数通过，CLI 输出/退出协议继续由 T04 覆盖。规格 8 的标准库及不联网限制、规格 9 的完整门禁、规格 10 的独立任务提交和 `Task: T03` trailer；错误信息不回显正文条件全程保留。

## T04 提供两个 CLI 子命令并收尾 README

- 只改哪些文件：`title_tools.py`、`tests/test_title_tools.py`、`README.md`
- 要变绿的测试：`test_cli_normalize_prints_one_line`、`test_cli_extract_uses_explicit_utf8_file_and_preserves_bytes`、`test_cli_normalize_rejects_whitespace`、`test_cli_extract_rejects_missing_heading`、`test_cli_extract_rejects_empty_first_heading`、`test_cli_extract_rejects_non_utf8_file`、`test_cli_extract_rejects_missing_file`、`test_cli_extract_reports_unreadable_file`、`test_cli_rejects_missing_required_arguments`、`test_cli_rejects_unknown_subcommand`、`test_cli_runs_without_site_packages`、`test_imports_are_standard_library_only`
- 实现要点：依赖 T03，填写 3 个函数体 `SafeArgumentParser.error`、`build_parser`、`main`，启用原十二项 CLI 测试，保留其全部输入、断言和名称。使用 argparse 的子命令及位置参数；以固定说明覆盖其 error，避免未知子命令正文进入 stderr。成功只 stdout 一行和一个换行；输入、读取、解码、缺参数、未知命令错误 stdout 空、stderr 有安全原因、无 traceback、退出 2。`main` 对各类异常只输出安全固定类别文字，不输出异常原文、输入正文、repr 或私密标记。
- 做完能观察到什么：子进程实际执行 `python3 -m title_tools normalize`、`python3 -m title_tools extract` 成功及所有错误用例，核两个输出流、退出状态和每个既有文件前后字节；以 `python3 -S -m title_tools` 验证两子命令的成功与失败，检查无第三方依赖声明及网络导入。运行两条完整门禁，预计 26 项全部实际通过且无 skip，compileall 退出 0；真实不可读文件和禁止联网宿主证据须由独立验证保存，缺少则相应验收不通过。
- README 检查方式：首次读者能运行两个函数及两子命令的例子，理解 Unicode 空白整理、汉字标点大小写保留、只选首个行首 `# `、忽略二级/缩进/缺空格、首个空标题不回退、不解析上下文、UTF-8 明确文件名及只读、成功输出/错误退出 2、标准库/不联网限制。保留两条原门禁及 Task trailer 约定；逐项比对规格 1—10，不记录缺乏证据的通过。
- 保留的验收要求：规格 5、6、7 的完整 CLI 协议与所有失败边界；规格 8 的无第三方、禁止联网环境与成功失败行为；规格 1—4 的行为继续复用已验证函数且不改语义；规格 9 的完整门禁；规格 10 的至少三项小任务（本方案总计四项）、每任务 `Task: TNN` trailer、人工审批/一次条件/改方案动作之前的真实用户明确确认。人工条件已由真实审批明确为“错误信息不得回显输入正文”，履行结果尚待 T03/T04 独立验证；新版批准与验证结果不能由实施者补造。

## 骨架与验证交接约束

- 新版批准后再骨架：保留 T01/T02 源码、测试和历史卡；新增 `tests/test_read_markdown.py` 五项 T03 skip 测试、SafeArgumentParser.error 的 T04 占位，调整 build_parser/main 及原十二项 CLI 测试的任务注释/skip 为 T04。不改原十二项测试的行为或辅助函数，不关闭既有九项测试，不填业务实现。
- 新 scaffold 须完整保存 T01 四项、T02 五项、T03 五项、T04 十二项选择器名单和可执行完整 argv/stdin，不只记一条无法复原的选择器命令；未知任务、空集、重名、漏项或已启用测试被跳过须失败。下一 implement 从累计前缀后选择 T03，不复用旧 T03 十二项 CLI 名单。总计 26 项，scaffold 时九项通过、十七项待任务禁用。
- 每个未验证任务只移除本任务 skip、填写所属函数体；测试断言不由实现者改写，白名单外需求立即卡住报回。门禁沿用 README 两条完整命令，不能仅跑单任务选择器或关闭失败测试。
- 每项候选记录实际任务基线、完整候选提交、完整已验证两行、实际 argv/stdin/stdout/stderr/退出状态、时间及输入文件前后字节；候选需与最新已验证历史有可核 Git 祖先关系。Task trailer 和提交存在均不追加验证事实。
- 审批来源 `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md` 对应旧方案 SHA-256 `b07e36e2bb55162e0d3342cab3d8a2820544b370240fe528bd57bee2e1199bf3`；本轮依据 `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/escalate/occurrence-001/attempt-000/outputs/decision.md` 调整拆分，旧审批不能充作新版批准。新版审批须引用新方案与规格摘要、保留错误不回显正文条件、保存新方案/tasks 原字节审核副本。
- 递归继承事实仅来自 `/private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md` → verify#1 → 首次空表 plan/tasks；T01/T02 已逐行核历史审批、原始证据和 Git 范围。previous_change 是已包含在最新已验证候选中的旧前缀，不新增 T02 自报。无新增重验事项；后续全门禁持续覆盖既有九项。
- 原规格验收 10 的真实用户记录仅采用冻结确认材料；人工条件已由真实审批明确为“错误信息不得回显输入正文”，原 decision 与当前 escalation 均保存该条件，履行结果尚待 T03/T04 独立验证，不重复询问已明确的信息，不预记通过。保留规格原文及摘要，不将本方案或普通继续视作新版审批。业务通过不构成整体需求、C002-T16 完成或发布授权；本轮无 submit、无引擎状态修改。
