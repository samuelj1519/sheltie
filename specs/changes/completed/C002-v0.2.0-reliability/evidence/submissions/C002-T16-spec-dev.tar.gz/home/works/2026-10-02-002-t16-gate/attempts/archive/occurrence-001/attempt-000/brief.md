# 任务书：归档

Work: 2026-10-02-002-t16-gate（t16-gate）
节点: archive#1，第 0 次尝试
来自: notes#1（main 边）
执行者: agent（standard）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| notes | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-002-t16-gate/attempts/notes/occurrence-001/attempt-000/outputs/notes.md | d448480520dc672417c97ac2a3e1f04700a813b44581f5e1206a7b22310d75ba |

## 说明

读已批准的 `notes`，生成归档记录。

- 第一行：版本号与归档日期（UTC）。
- 第二行起：原样复制发布说明。

写到 `archive` 对应的路径。回复协调者一句「已归档」。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| archive | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-002-t16-gate/attempts/archive/occurrence-001/attempt-000/outputs/archive.md | 是 | 64 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
