完成

提交: 92e2d3f3fb14d077aac3cba9d10ec2b7df53f540
原始基线: 2f88d59b0d214967b64b285e96d764f26bc71c30
骨架前 HEAD: 2f88d59b0d214967b64b285e96d764f26bc71c30
审批来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md

## 单任务测试命令

在项目根运行下面的完整命令；将第一行的 T01 替换为 T02 或 T03。使用任务卡的完整测试名单精确选择，不靠名称前缀判断归属。空名单、缺测试或重复匹配均退出非零。T04 是纯文档任务，按任务卡人工核对 README 后运行完整门禁，不使用此选择器。

```bash
python3 - T01 <<'PY'
import sys, unittest
TASK_TESTS = {
  "T01": [
    "test_normalize_collapses_mixed_unicode_whitespace",
    "test_normalize_preserves_chinese_punctuation_and_case",
    "test_normalize_rejects_empty_and_whitespace_only",
    "test_normalize_keeps_single_word"
  ],
  "T02": [
    "test_extract_ignores_nonmatching_heading_prefixes",
    "test_extract_normalizes_first_heading",
    "test_extract_chooses_first_matching_heading",
    "test_extract_rejects_missing_heading",
    "test_extract_rejects_empty_first_heading_without_fallback"
  ],
  "T03": [
    "test_cli_normalize_prints_one_line",
    "test_cli_extract_uses_explicit_utf8_file_and_preserves_bytes",
    "test_cli_normalize_rejects_whitespace",
    "test_cli_extract_rejects_missing_heading",
    "test_cli_extract_rejects_empty_first_heading",
    "test_cli_extract_rejects_non_utf8_file",
    "test_cli_extract_rejects_missing_file",
    "test_cli_extract_reports_unreadable_file",
    "test_cli_rejects_missing_required_arguments",
    "test_cli_rejects_unknown_subcommand",
    "test_cli_runs_without_site_packages",
    "test_imports_are_standard_library_only"
  ]
}
if len(sys.argv) != 2 or sys.argv[1] not in TASK_TESTS:
    raise SystemExit("须选择 T01、T02 或 T03；T04 是文档任务")
expected = set(TASK_TESTS[sys.argv[1]])
def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item
selected = [test for test in flatten(unittest.defaultTestLoader.discover("tests"))
            if test.id().rsplit(".", 1)[-1] in expected]
found = {test.id().rsplit(".", 1)[-1] for test in selected}
if not selected or found != expected or len(selected) != len(expected):
    raise SystemExit("测试名单为空、重复或与任务卡不符")
print(f"{sys.argv[1]}: selected {len(selected)} tests", flush=True)
result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(selected))
raise SystemExit(0 if result.wasSuccessful() else 1)
PY
```

正式骨架实际选择数：T01 为 4、T02 为 5、T03 为 12，与任务卡逐项匹配；均因尚未实施而禁用。空测试目录运行同一选择器时，stdout 为空，stderr 为 `测试名单为空、重复或与任务卡不符\n`，退出 1。

## 任务与文件

| 任务 | 只改哪些文件 | 测试数 | 测试所在文件 |
| --- | --- | --- | --- |
| T01 | `title_tools.py`、`tests/test_title_tools.py` | 4 | `tests/test_title_tools.py` |
| T02 | `title_tools.py`、`tests/test_title_tools.py` | 5 | `tests/test_title_tools.py` |
| T03 | `title_tools.py`、`tests/test_title_tools.py` | 12 | `tests/test_title_tools.py` |
| T04 | `README.md` | 0（纯文档任务） | 无 |

共四个待实施任务、21 项预置测试；没有任何任务被标为完成或独立验证通过。

## 骨架里新增或修改的文件

- `title_tools.py`：新增五个获批函数签名、两行文档注释及带 T01/T02/T03 归属的 `raise NotImplementedError`；入口调用 `SystemExit(main())`。
- `tests/test_title_tools.py`：预写任务卡全部 21 项测试，使用 `Task: TNN` 注释和 `@unittest.skip("TNN")` 记录归属；完成真实 CLI 子进程、文件字节与安全错误检查 helper，未留下 helper 占位体。

## 审批核对

绑定文件全部按字节计算 SHA-256，与 brief 摘要一致。原审批第一行为「通过」，不存在审批更正。

| 核对项 | 实际 SHA-256 | 结论 |
| --- | --- | --- |
| spec | bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38 | 与批准的规格一致 |
| plan | b07e36e2bb55162e0d3342cab3d8a2820544b370240fe528bd57bee2e1199bf3 | 与批准的方案一致 |
| tasks | 1a40fb9e925596df71e713a696cd70c5c121042574a115435e08a41620a1dd20 | 与 brief 一致 |
| decision | 707a70341dd63d69d4b315b984646e192e61d655441e2f253f5df94b42738466 | 与 brief 一致 |
| project | a626a063e6b4c5d7280f59d04bbd168cb73f474fc0af2fbc74ed7589233b26c3 | 与 brief 一致 |
| rules | 306d0f50d136b59038a195897002ee90e4495e05559f5f2f0e413dbec1702fdb | 与 brief 一致 |
| template | 16c4ff81f11b37c72d604312082a61186d5af6762a03470092d63b6a9a3e79e6 | 与 brief 一致 |

条件原文：「错误信息不得回显输入正文。」

该条件落实到 T03 现有负向测试：空白 normalize 不得回显原参数或其 repr；无标题、首个空标题、非 UTF-8 和不可读文件不许泄漏正文中的手写私密标记；未知子命令不得回显提供的参数；`-S` 失败用例同样核对。所有 CLI 错误还核对退出 2、stdout 为空、stderr 有说明且无 traceback。未增加任务或额外测试名。

## 门禁结果

正式项目在新增骨架后运行以下真实命令，均退出 0：

| argv | stdout | stderr / 结果 |
| --- | --- | --- |
| `["python3", "-m", "unittest", "discover", "-s", "tests", "-v"]` | 空 | 收集 21 项；全部 `skipped 'T01'/'T02'/'T03'`；`Ran 21 tests in 0.000s`；`OK (skipped=21)` |
| `["python3", "-m", "compileall", "-q", "title_tools.py", "tests"]` | 空 | 空 |

骨架静态核对：恰好五个函数；每个函数只有文档字符串及 `raise NotImplementedError`；T01/T02/T03 禁用测试数为 4/5/12。提交只包含上述两个新文件。提交前、提交后项目工作区均无无关改动，提交后 `git status --short` 输出为空。

按 scaffold-rules §14 在自动清理的临时副本中完成最小任务正例试跑：仅临时填 T01 的 `normalize_title`、移除 T01 四个 skip。正式项目未填函数体，试跑前后正式文件的 SHA-256 不变。

临时试跑单任务的真实 argv 为 `["python3", "-", "T01"]`，stdin 为上面的完整选择器；stdout 和 stderr 原文分别为：

```text
T01: selected 4 tests
```

```text
test_normalize_collapses_mixed_unicode_whitespace (test_title_tools.TitleToolsTests.test_normalize_collapses_mixed_unicode_whitespace) ... ok
test_normalize_keeps_single_word (test_title_tools.TitleToolsTests.test_normalize_keeps_single_word) ... ok
test_normalize_preserves_chinese_punctuation_and_case (test_title_tools.TitleToolsTests.test_normalize_preserves_chinese_punctuation_and_case) ... ok
test_normalize_rejects_empty_and_whitespace_only (test_title_tools.TitleToolsTests.test_normalize_rejects_empty_and_whitespace_only) ... ok

----------------------------------------------------------------------
Ran 4 tests in 0.000s

OK
```

该命令退出 0。临时副本的完整 unittest 也退出 0，stdout 为空，stderr 报告 `Ran 21 tests in 0.000s`、`OK (skipped=17)`（T01 四项通过）；完整 compileall 退出 0，stdout、stderr 均为空。临时副本已自动清理，不构成正式 T01 候选或验收结果。

正式交付文件 SHA-256：

- `title_tools.py`: `02fc4ea949a9eda766929f715aa20f87d5d9fb42e32cc84e111f0fd69e12c44b`
- `tests/test_title_tools.py`: `269ef6df244710df2565f37ae59682420140819e3f7325b45dc72aeec9a41519`

## 给实现者的提醒

- 只移除当前任务预置测试的 skip，不关闭已经启用的测试；本轮骨架门禁成功仅说明空壳可加载、测试可收集和源码可编译，不证明产品行为完成。
- 获批条件涵盖 CLI 参数错误；argparse 默认的 invalid choice 会回显未知子命令参数，T03 必须在获批的五个函数内安全处理错误原因。不要为绕过该测试新增公开接口、文件或依赖。
- T03 的不可读文件测试先以真实子进程读取 `chmod(0)` 文件并核对 PermissionError；宿主仍可读取时该验收明确失败，不跳过、不模拟为通过。
- `python3 -S` 和静态导入检查只检查未加载第三方 site-packages 及源码导入，不证明宿主禁止联网；验收 8 的真实环境证据仍交独立验证。
- 原始基线保持不变；后续任务独立提交保留 `Task: TNN` trailer，累计表只能追加独立验证事实。人工审批、一次条件及改方案的对应动作仍须沿用真实用户确认记录。
- 没有修改 Sheltie 仓库、输入文件或引擎状态，没有 submit。

