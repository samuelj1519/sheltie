完成 T01

基线: 92e2d3f3fb14d077aac3cba9d10ec2b7df53f540
提交: 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c
原始基线: 2f88d59b0d214967b64b285e96d764f26bc71c30
继承来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-001/attempt-000/outputs/plan.md
修复轮次: 0
启用的测试: 4
改动文件:
- title_tools.py
- tests/test_title_tools.py
门禁:
- python3 -m unittest discover -s tests -v: 通过（21 项收集，4 项通过，后续任务 17 项禁用）
- python3 -m compileall -q title_tools.py tests: 通过
备注: 

## 已验证任务

| 任务 | 任务基线 | 候选提交 | 审批来源 | 验证报告 | 原始证据 |
| --- | --- | --- | --- | --- | --- |

## 本轮候选与原始证据

- 审批来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md
- 核对 spec SHA-256: bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38
- 核对 plan SHA-256: b07e36e2bb55162e0d3342cab3d8a2820544b370240fe528bd57bee2e1199bf3
- 原审批第一行为「通过」。条件「错误信息不得回显输入正文」保留，T01 空标题错误使用固定文字，未回显输入；CLI 条件留待 T03 及独立验证。
- plan/tasks 原始基线一致且累计表均为空；report 未绑定，继承当前方案空表。本轮候选未追加验证事实。
- 开工工作区干净；原始基线经 git merge-base --is-ancestor 核为 HEAD 祖先，任务基线为骨架提交。提交后工作区干净。
- 四项预置测试先全红（NotImplementedError），先实现 Unicode 空白规范化后仅空输入用例失败，再补拒绝空标题后全部变绿；测试只删除四个 T01 skip，断言未改。
- 原始 argv、stdout、stderr、exit_code 与完整选择器 stdin: /private/tmp/sheltie-c002-t16-82c6c55/task-runs/implement-1/；红绿证据为 red、green-step-1、green 的 .json/.stdout/.stderr/.stdin；门禁证据为 gate-unittest、gate-compileall 的 .json/.stdout/.stderr。审批哈希、原始基线、Git 变更与提交证据同目录。源码和测试前后字节快照以 before-/after- 文件保留。
- 本轮只自报 T01 候选，尚待独立 verify；没有 submit，没有修改冻结输入或引擎状态。
