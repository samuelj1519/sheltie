完成 T03

基线: ba56d3fc3a25a9ca170183fd2315beb0ff37db5b
提交: 71821061f32d9c6496c2d621e673527bc785e4f6
原始基线: 2f88d59b0d214967b64b285e96d764f26bc71c30
继承来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md
修复轮次: 0
启用的测试: 5
改动文件:
- title_tools.py
- tests/test_read_markdown.py
门禁:
- python3 -m unittest discover -s tests -v: 通过
- python3 -m compileall -q title_tools.py tests: 通过
备注: 只填 read_markdown 的 UTF-8 只读函数体、移除五项 T03 skip；原九项启用测试及三个 T04 占位、十二项 T04 skip 均保留。候选待独立 verify，本轮不追加已验证事实。

审批来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-002/attempt-000/outputs/decision.md
批准的规格: bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38
批准的方案: 557a7ff9d0614ac2c0a69ba59eec3bb8a3ce5c3ea6c26cb6c5b3420bba4ad40d
条件: 错误信息不得回显输入正文。
原始证据: /private/tmp/sheltie-c002-t16-82c6c55/task-runs/implement-3/

## 已验证任务

原样保留最新独立 verify#2 的完整 T01/T02 两行；当前 plan/tasks/scaffold 的累计表与之逐字一致，原始基线一致。继承行的历史审批、报告及证据路径实际存在，历史审批首行为通过、报告原始基线相同。原始基线及 T02 最新已验证候选均是当前任务基线的 Git 祖先。

| 任务 | 任务基线 | 候选提交 | 审批来源 | 验证报告 | 原始证据 |
| --- | --- | --- | --- | --- | --- |
| T01 | 92e2d3f3fb14d077aac3cba9d10ec2b7df53f540 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-001/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-1/ |
| T02 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | 6773f932765895735a5786220653440afcba2d8f | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-2/ |

## 本轮执行证据

所有命令 JSON 保存实际 argv、cwd、stdin 路径、起止时间、环境覆盖和退出状态；同名 stdout/stderr 保存原始字节，stdin 命令另存完整全文。输入冻结镜像为 input-*.bytes，任务基线源码/测试为 before-*，候选源码/测试为 candidate-*；input-hashes.json、approval-prefix.json、run.py、result.json 可复核过程。Python 字节码写入本证据目录 pycache，项目 git status 前后干净。

- 审批与继承：brief 所有绑定输入 SHA-256 均匹配，审批首行为通过，批准的规格/方案与当前输入一致，无审批更正；保留错误不回显正文条件。完整新选择器 stdin 与 scaffold-2/task-selector.stdin 原字节一致。
- 先红后绿：task-tests-red 使用完整四任务选择器精确选择 T03 五项，五项全部因 NotImplementedError 失败、无 skip；先完成 UTF-8 无标题正例 first-test-green，再完整 task-tests-green 五项实际运行通过、无 skip。未改测试断言或快照。
- 完整门禁：gate-unittest 收集 26 项，T01/T02 九项与 T03 五项实际通过、T04 十二项禁用；OK (skipped=12)。gate-compileall 退出 0。
- 真实权限前置：permission-precondition 与 bytes-permission-precondition 均以 python3 -S -c 的 pathlib.read_bytes 对真实 chmod(0) 文件运行，退出非零且原 stderr 含 PermissionError；随后被测读取保留 PermissionError 类别。未 mock 或 skip，finally 恢复权限后核字节一致。
- 文件边界：bytes-utf8-no-heading、bytes-crlf-heading 成功；bytes-invalid-utf8、bytes-unreadable、bytes-missing 分别保留 UnicodeDecodeError、PermissionError、FileNotFoundError，原始 stdout/stderr 和退出状态实际保存。错误说明非空且未回显 PRIVATE_BODY、完整正文或其 repr。file-byte-manifest.json、各例 before/after.bytes 保存成功及失败已有文件的完整原字节相等证据；missing 前后不存在。
- Git：git-task-baseline、git-staged-paths、git-commit、git-head-after、git-candidate-parent、git-message、git-status-after 保存原文。提交只含两项白名单文件，候选父提交就是任务基线，Task: T03、Work、Agent trailer 完整，提交后工作区干净。

本轮读取函数通过不代表 T04 CLI 协议、禁止联网环境、整体需求或 C002-T16 完成；不修改绑定输入、Sheltie 仓库或引擎状态，无 submit。
