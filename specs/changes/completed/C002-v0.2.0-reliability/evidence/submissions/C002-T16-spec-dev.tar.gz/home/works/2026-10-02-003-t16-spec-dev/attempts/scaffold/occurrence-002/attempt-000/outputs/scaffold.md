完成

提交: ba56d3fc3a25a9ca170183fd2315beb0ff37db5b
原始基线: 2f88d59b0d214967b64b285e96d764f26bc71c30
骨架前 HEAD: 6773f932765895735a5786220653440afcba2d8f
审批来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-002/attempt-000/outputs/decision.md
继承来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md
原始证据: /private/tmp/sheltie-c002-t16-82c6c55/task-runs/scaffold-2/

本轮只增量准备未验证 T03/T04。共四个任务、26 项测试；T01/T02 九项已独立验证并保持启用，T03 五项、T04 十二项仍禁用。此次骨架提交和临时试跑不追加业务验证事实。

## 单任务测试命令

在项目根运行下列完整命令。把第一行 T03 替换成 T01、T02 或 T04，stdin 保持原样。完整 argv 分别为 `["python3", "-", "T01"]`、`["python3", "-", "T02"]`、`["python3", "-", "T03"]`、`["python3", "-", "T04"]`；stdin 即下方 Python 全文，也保存为 `/private/tmp/sheltie-c002-t16-82c6c55/task-runs/scaffold-2/task-selector.stdin`。四个任务的完整测试名单全部列出，不复用旧 T03 的 CLI 名单。

```bash
python3 - T03 <<'PY'
import collections
import sys
import unittest

TASK_TESTS = {
    "T01": [
        "test_normalize_collapses_mixed_unicode_whitespace",
        "test_normalize_preserves_chinese_punctuation_and_case",
        "test_normalize_rejects_empty_and_whitespace_only",
        "test_normalize_keeps_single_word",
    ],
    "T02": [
        "test_extract_ignores_nonmatching_heading_prefixes",
        "test_extract_normalizes_first_heading",
        "test_extract_chooses_first_matching_heading",
        "test_extract_rejects_missing_heading",
        "test_extract_rejects_empty_first_heading_without_fallback",
    ],
    "T03": [
        "test_read_markdown_returns_utf8_text_without_heading_validation",
        "test_read_markdown_preserves_original_file_bytes",
        "test_read_markdown_rejects_non_utf8_and_preserves_bytes",
        "test_read_markdown_rejects_missing_file_without_creating_it",
        "test_read_markdown_rejects_unreadable_file_and_preserves_bytes",
    ],
    "T04": [
        "test_cli_normalize_prints_one_line",
        "test_cli_extract_uses_explicit_utf8_file_and_preserves_bytes",
        "test_cli_normalize_rejects_whitespace",
        "test_cli_extract_rejects_missing_heading",
        "test_cli_extract_rejects_empty_first_heading",
        "test_cli_extract_rejects_non_utf8_file",
        "test_cli_extract_rejects_missing_file",
        "test_cli_extract_reports_unreadable_file",
        "test_cli_rejects_missing_required_arguments",
        "test_cli_rejects_unknown_subcommand",
        "test_cli_runs_without_site_packages",
        "test_imports_are_standard_library_only",
    ],
}
if len(sys.argv) != 2 or sys.argv[1] not in TASK_TESTS:
    raise SystemExit("须选择 T01、T02、T03 或 T04")
expected = TASK_TESTS[sys.argv[1]]
all_expected = [name for names in TASK_TESTS.values() for name in names]
if any(not names for names in TASK_TESTS.values()) or len(set(all_expected)) != len(all_expected):
    raise SystemExit("任务测试名单为空或重复")

def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item

all_tests = list(flatten(unittest.defaultTestLoader.discover("tests")))
found = collections.Counter(test.id().rsplit(".", 1)[-1] for test in all_tests)
if found != collections.Counter(all_expected):
    raise SystemExit("测试为空、漏项、额外项或重复，与四个任务卡不符")
for test in all_tests:
    name = test.id().rsplit(".", 1)[-1]
    method = getattr(test, test._testMethodName)
    if name in TASK_TESTS["T01"] + TASK_TESTS["T02"] and (
        getattr(method, "__unittest_skip__", False)
        or getattr(type(test), "__unittest_skip__", False)
    ):
        raise SystemExit("已启用的 T01/T02 测试被跳过")
selected = [test for test in all_tests if test.id().rsplit(".", 1)[-1] in expected]
if not selected or len(selected) != len(expected):
    raise SystemExit("当前任务测试为空或数量不符")
print(f"{sys.argv[1]}: selected {len(selected)} tests", flush=True)
result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(selected))
if result.skipped:
    raise SystemExit("当前任务测试仍禁用，不能报告通过")
raise SystemExit(0 if result.wasSuccessful() else 1)
PY
```

未知任务、任一任务空名单、名单重复、收集为空、漏项、额外项、收集重名、已启用 T01/T02 被跳过或所选任务仍禁用均失败。正式运行精确选择数为 4/5/5/12；T01/T02 退出 0 且实际运行，T03/T04 因仍禁用退出 1。这两次预期失败证明未实施不会误报通过，不是正式门禁失败。

负例已实际运行：selector-unknown、selector-empty-manifest、selector-duplicate-manifest、selector-empty-collection、selector-missing-test、selector-duplicate-collection、selector-enabled-test-skipped 均退出 1。集合缺失、重复和跳过检查在隔离副本执行，副本已清理；正式项目未添加选择器脚本或配置。

## 任务与文件

| 任务 | 只改哪些文件 | 测试数 | 测试所在文件 |
| --- | --- | --- | --- |
| T01（已验证，不再实施） | `title_tools.py`、`tests/test_title_tools.py` | 4 | `tests/test_title_tools.py` |
| T02（已验证，不再实施） | `title_tools.py`、`tests/test_title_tools.py` | 5 | `tests/test_title_tools.py` |
| T03 | `title_tools.py`、`tests/test_read_markdown.py` | 5 | `tests/test_read_markdown.py` |
| T04 | `title_tools.py`、`tests/test_title_tools.py`、`README.md` | 12 | `tests/test_title_tools.py` |

## 骨架里新增或修改的文件

- `title_tools.py`：保留 T01/T02 源码字节及 read_markdown 签名、文档和 T03 占位；新增 SafeArgumentParser.error 的两行文档与 T04 占位，仅将 build_parser/main 的任务注释与占位归属改为 T04。
- `tests/test_read_markdown.py`：新增五项 T03 禁用测试与完整 helper。真实 UTF-8 无标题正例、CRLF 原字节与 extract_title 组合、非法 UTF-8、不存在、不具读取权限均有手写期望值和可判定断言；权限负例不用 mock 或 skip。
- `tests/test_title_tools.py`：只将原十二项禁用测试的 Task 注释和 skip 从 T03 改为 T04。逆向替换后与旧文件逐字一致，测试名称、输入、断言、公共 helper 和九项已启用测试未改。

README 本轮字节未变；T04 按任务卡收尾。正式源码恰有四个占位：read_markdown 归 T03；SafeArgumentParser.error、build_parser、main 归 T04。

## 审批与继承核对

brief 八个绑定输入均重算 SHA-256 并保存原字节镜像。审批第一行为「通过」，批准的规格与方案与当前输入一致，无审批更正；未用旧版审批或过期 escalation 覆盖新版。

| 输入 | 实际 SHA-256 |
| --- | --- |
| spec | bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38 |
| plan | 557a7ff9d0614ac2c0a69ba59eec3bb8a3ce5c3ea6c26cb6c5b3420bba4ad40d |
| tasks | 58f23f75ffc9feeab72f3b74f93833d38f0cdf357159b166d76bc0cde094e6be |
| decision | 9afe7f32756513232e36a6226f04df386fce4a9a67d334538a1be917ec0ad5eb |
| escalation | d2ae23a3f354a7c84762927711b1aeb79d0d212a009b651f1e6afe0724b8defe |
| project | a626a063e6b4c5d7280f59d04bbd168cb73f474fc0af2fbc74ed7589233b26c3 |
| rules | 306d0f50d136b59038a195897002ee90e4495e05559f5f2f0e413dbec1702fdb |
| template | 16c4ff81f11b37c72d604312082a61186d5af6762a03470092d63b6a9a3e79e6 |

条件原文：「错误信息不得回显输入正文。」

新增读取错误测试保留 UnicodeError、FileNotFoundError/OSError、PermissionError/OSError 类别，说明须非空且不含正文私密标记、完整输入或 repr。原十二项 CLI 测试继续核对参数与正文保密、stdout 空、退出 2、无 traceback，保留全部旧断言。正式 T03/T04 的条件履行仍待独立 verify，不预记通过。

实际打开 verify#2 → verify#1 → 首次 plan/tasks，以及 implement#1/#2 原始文件。首次累计表为空；verify#1 仅追加 T01，implement#2 仅继承该行，verify#2 原样保留并仅追加 T02。各层原始基线相同，两条历史审批、报告与证据目录实际存在；Git 父提交、原始基线祖先及 Task trailer 均核对。新 plan/tasks 与 verify#2 两行逐字相同，本交接完整保留。

## 已验证任务

| 任务 | 任务基线 | 候选提交 | 审批来源 | 验证报告 | 原始证据 |
| --- | --- | --- | --- | --- | --- |
| T01 | 92e2d3f3fb14d077aac3cba9d10ec2b7df53f540 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-001/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-1/ |
| T02 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | 6773f932765895735a5786220653440afcba2d8f | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-2/ |

## 门禁结果

在正式项目 `/private/tmp/sheltie-c002-t16-82c6c55/project` 实际运行两条批准的完整门禁，均退出 0：

| argv | stdout | stderr / 结果 | 原始证据 |
| --- | --- | --- | --- |
| `["python3", "-m", "unittest", "discover", "-s", "tests", "-v"]` | 空 | 收集 26 项，T01/T02 九项实际通过，T03/T04 十七项禁用；`OK (skipped=17)` | gate-unittest.json/.stdout/.stderr |
| `["python3", "-m", "compileall", "-q", "title_tools.py", "tests"]` | 空 | 空 | gate-compileall.json/.stdout/.stderr |

按冻结 scaffold-rules §14，在隔离临时副本中仅填 read_markdown 的 UTF-8 只读函数体、移除五个 T03 skip；原九项和 CLI 断言不改。实际运行 `["python3", "-", "T03"]`，stdin 为上述完整选择器，五项全部通过；两条完整门禁均退出 0，unittest 收集 26 项、十四项通过、十二项 T04 禁用。权限负例先以真实子进程证明 PermissionError，再调用被测函数；恢复权限后核对原字节。

试跑原文为 trial-selector-T03、trial-gate-unittest、trial-gate-compileall 的 JSON/stdin/stdout/stderr；临时源码镜像为 trial-title_tools.py 与 trial-tests-test_read_markdown.py。临时项目 `/private/tmp/sheltie-c002-t16-82c6c55/scaffold2-trial-o976h2qo` 已删除；正式四文件试跑前后 SHA-256 相同，T03/T04 业务占位保留，试跑不构成正式候选或独立验收。

每条命令 JSON 保存完整 argv、cwd、stdin 路径、时间、退出状态与输出路径；同名 stdout/stderr 保存原字节，stdin 命令另存全文。业务门禁设置 PYTHONIOENCODING=utf-8、移除 PYTHONPATH，字节码写到证据目录 pycache；未修改门禁命令、断言或项目配置。输入镜像为 input-*.bytes，原文件为 before-*，交付镜像为 candidate-*；input-hashes.json、approval-prefix.json、result.json 及本目录 Python 脚本保存核对过程。

独立骨架提交仅含三个批准的文件，父提交为最新已验证 T02 候选，保留 Task: scaffold、Work、Agent trailer；提交后 git status --porcelain=v1 stdout 为空。原文见 git-commit、git-head-after、git-candidate-parent、git-message、git-status-after。

正式文件 SHA-256：

- `title_tools.py`: `03720042a2d14ffdbf7a1473279d4e6f38d7116505d6e49b94c0588a5c4d1aa6`
- `tests/test_title_tools.py`: `8c8427dc60eb6c57f85e4852ab62e217332c02fd91f4174d5e9b4a61c09b24bb`
- `tests/test_read_markdown.py`: `77a2129e0d25d728866b9e31d7f7651da1a633bb5eafdcec2fe889490c107bbe`
- `README.md`: `5106a20c617bb5e4aa4a2639fb8329de6835a12c9d787f5eccb060c6958c8592`

## 给实现者的提醒

- 下一项是 T03，只移除五个 T03 skip、填写 read_markdown 一个函数体，不复用旧 CLI 名单，不改断言，不关闭已启用测试。
- T04 仅填写 SafeArgumentParser.error、build_parser、main，启用原十二项测试并收尾 README。argparse 默认 message 可能回显参数，error 必须固定安全说明；读取及解码错误也不直接输出原异常。
- 权限前置不成立必须停止，不能 skip、mock 或降低断言；finally 恢复权限并核字节。
- 规格 1—4 由原九项持续覆盖；5—7 由读取与原 CLI 测试覆盖；8 的 -S、导入扫描不证明宿主禁止联网，独立验收还须真实环境证据；9 每任务运行两条完整门禁；10 沿用真实确认及独立 Task 提交。
- 每任务提交后由独立 verify 追加事实。累计表仅含原 T01/T02，T03/T04 尚未正式实施或独立验证；骨架和试跑不等于整体需求、C002-T16 完成或发布授权。
- 未修改绑定输入、Sheltie 仓库或引擎状态，没有 submit。实现若须超出白名单、签名或任务体范围则停止报回。
