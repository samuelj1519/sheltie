# 任务书：审查整体改动

Work: 2026-10-02-003-t16-spec-dev（t16-spec-dev）
节点: review#1，第 0 次尝试
来自: verify#4（main 边）
执行者: agent（strong）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| spec | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/spec/occurrence-001/attempt-000/outputs/spec.md | bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38 |
| plan | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-002/attempt-000/outputs/plan.md | 557a7ff9d0614ac2c0a69ba59eec3bb8a3ce5c3ea6c26cb6c5b3420bba4ad40d |
| tasks | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-002/attempt-000/outputs/tasks.md | 58f23f75ffc9feeab72f3b74f93833d38f0cdf357159b166d76bc0cde094e6be |
| scaffold | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/scaffold/occurrence-002/attempt-000/outputs/scaffold.md | a976df7b9cb4d298865c00f3012aa9be563c1ef6f9c6c5f8825cf405849c7dae |
| project | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/start-inputs/project | a626a063e6b4c5d7280f59d04bbd168cb73f474fc0af2fbc74ed7589233b26c3 |
| fix_change | 尚无（上游 fix 还没有产出） | |
| checklist | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/workbook/resources/checklists/review-checklist.md | bdac26d4839e0e853d55717b43be7381d42667c13a99e22872ef629cc002164b |
| template | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/workbook/resources/templates/report.md | a9c5e72fdc69e6b53f788478d1087a3ac3af566e95a929742f38cfcb98c92551 |

## 说明

你是审查者，没有参与实现。所有任务都已各自通过验证，你要看的是整体：需求是否真的做到了，代码整体上站不站得住。

## 读什么

1. `plan`：读「基线」拿到**原始基线**——Work 开始时的 `HEAD`，改方案也不改它；再读「门禁」。`scaffold`：拿骨架提交哈希，区分哪些是骨架、哪些是实现者填的。
2. `spec`：读「验收标准」，这是你的检查清单的第一部分。
3. `checklist`：审查清单，是检查清单的第二部分。
4. `tasks`：知道一共做了哪些任务。
5. `fix_change`：只在你是第二次及以后到达时才有，是修复者对你上一份报告的处理。先读它的「备注」，看哪些发现被标为「未修加理由」，判断理由是否成立。
6. `project`：项目根目录。进入后运行 `git diff <原始基线>..HEAD --stat` 看改动范围，再按文件读 diff。整体范围从原始基线算到 `HEAD`：改方案重排任务不缩小这个范围，改方案前完成的任务必须还在这里。**只读 diff，不读整个仓库。**
7. `template`：报告模板。

## 怎么审

1. 先跑一遍门禁。不过直接判「不通过」。
2. 对「验收标准」逐条找证据：哪个测试或哪段代码证明它成立。找不到证据的算不成立。
3. 按 `checklist` 逐条过 diff。
4. 若项目语言有突变测试工具（Rust `cargo-mutants`、Python `mutmut`、JavaScript `stryker`）且已安装，对本次改动的文件跑一遍。存活的突变体说明有逻辑没被测到：判断是测试漏了（写进「发现」，标「阻断」，要求骨架补测试）还是死代码（标「建议」）。没装就跳过，在报告里写「未跑突变测试」。
5. 只报会影响正确性、安全、可维护性的问题。命名偏好、格式细节不报，门禁已经管了格式。
6. 每条问题给出文件、位置、现象、期望。修复者要能不问你就动手。需要改测试或签名的发现，写明「需骨架步骤处理」；修复者不会改它们。
7. 你不改代码。

## 写什么

按 `template` 写 `report.md`。**第一行只写下面两种之一**：

- `通过`：验收标准全部有证据，清单没有阻断项。可以有非阻断建议，写在「发现」里并标「建议」。
- `不通过`：任一验收标准无证据，或清单有阻断项。

## 使用报告模板

整体 review 在 template 的定位字段写：任务为「整体」，原始基线和基线均取 plan 的整体基线，提交为当前 HEAD。首轮修复轮次写 0；任务书来自 fix 的复审轮次从 fix_change 记录继承。

template 中的本轮变更、继承来源、被验规格/方案/任务、审批来源和已验证任务表属于 verify 的逐任务交接，整体 review 省略这些专用字段，不伪造未绑定的输入，也不追加 Task 验证行。整体结论依然来自原始基线到 HEAD 的独立检查。fix 若针对整体报告修复，仍按 fix 说明从最新 verify_report 或获批方案取得累计前缀。

## 写到哪

写到 `report` 对应路径。

## 怎么回复协调者

一句话重复第一行，再一句话说阻断项几条、建议几条。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| report | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/review/occurrence-001/attempt-000/outputs/report.md | 是 | 32 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
