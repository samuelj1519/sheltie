# 任务书：验证本任务

Work: 2026-10-02-003-t16-spec-dev（t16-spec-dev）
节点: verify#2，第 0 次尝试
来自: implement#2（main 边）
执行者: agent（standard）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| tasks | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-001/attempt-000/outputs/tasks.md | 1a40fb9e925596df71e713a696cd70c5c121042574a115435e08a41620a1dd20 |
| spec | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/spec/occurrence-001/attempt-000/outputs/spec.md | bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38 |
| plan | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan/occurrence-001/attempt-000/outputs/plan.md | b07e36e2bb55162e0d3342cab3d8a2820544b370240fe528bd57bee2e1199bf3 |
| scaffold | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/scaffold/occurrence-001/attempt-000/outputs/scaffold.md | 65853b37a380582e68e9617f5f9111a59c066a0f915426c4c0b64d7627cc8437 |
| change | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/implement/occurrence-002/attempt-000/outputs/change.md | 043e63e8e78984eac74aeb94ed6aa2179895d3794bb995e291bf66d5c811da4b |
| fix_change | 尚无（上游 fix 还没有产出） | |
| project | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/start-inputs/project | a626a063e6b4c5d7280f59d04bbd168cb73f474fc0af2fbc74ed7589233b26c3 |
| template | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/workbook/resources/templates/report.md | a9c5e72fdc69e6b53f788478d1087a3ac3af566e95a929742f38cfcb98c92551 |
| decision | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | 707a70341dd63d69d4b315b984646e192e61d655441e2f253f5df94b42738466 |
| escalation | 尚无（上游 escalate 还没有产出） | |

## 说明

你是独立验证者。你没有参与实现，只看结果。你的报告第一行决定流程往哪走，所以它必须准确。

## 读什么

1. 任务书「来自」是 `implement` 就读 `change`，是 `fix` 就读 `fix_change`，是 `escalate` 就先读 `escalation`（人对上一轮分歧的裁决），再读它点名的那份 change 或 fix_change；`escalation` 没点名就看 `fix_change` 有没有绑定：有是修复那一轮的记录，没有是 `change`。来自别处的报告是过期的，忽略。从 change / fix_change 拿：任务编号、任务基线、提交哈希、`修复轮次`。
2. `tasks`：找到这个任务，读它的「只改哪些文件」「要变绿的测试」「做完能观察到什么」。
3. `scaffold`：拿骨架提交哈希与单任务测试命令。
4. `plan`：读「门禁」一节。
5. `decision`、`spec`：见「怎么验」第 1 步的批准核对。
6. `project`：项目根目录。进入这个目录。
7. `template`：报告模板。

## 怎么验

1. 核批准版本。`decision` 写的「批准的规格」「批准的方案」两个 sha256 必须分别等于 `spec`、`plan` 输入文件的内容摘要（`shasum -a 256 <路径>`，Linux 是 `sha256sum`）。对不上判「不通过，需要人」，「发现」里写两个哈希与文件路径：方案在批准后被修订过、旧批准已失效，不是修复能解决的。对得上时，把「通过」附带的条件逐条当作验收的一部分。人若已在 `escalation` 里更正批准记录，按更正办并把更正抄进报告。
2. `git log -1` 确认最新提交就是报告里写的哈希，`git status` 确认工作区干净。不符直接判「不通过」。
3. 用单任务测试命令跑本任务的测试。**不信实现者的报告，自己跑。** 数量要和任务卡「要变绿的测试」一致，少了就是没全启用。
4. 自己运行「门禁」里的每条命令。
5. `git diff --name-only <基线>..<提交>` 只看**本任务**（含它的修复轮次）改了什么：改动文件必须都在任务卡「只改哪些文件」里，外加去掉禁用标记的测试文件。测试文件里除了删禁用标记不能有别的改动（`git diff <基线>..<提交> -- <测试文件>` 应只有删除 `ignore` 那几行）。快照或黄金文件不得有改动。不要用骨架提交到 HEAD 的累计范围——那会把前面任务的改动算成本任务的越界。任一条不满足直接判「不通过」，「发现」里写「改了不该改的文件」并列出。
6. 占位体只查本任务的。占位体带任务编号（骨架规则）：残留占位体标的是**本任务**编号就判「不通过」（该填的没填完）；标的是别的任务——后续任务在共用文件里合法留的占位——不判。没带编号的占位体判「不通过」，「发现」里写「占位体没标任务编号」。
7. `git log -1 --format=%B` 的提交信息末尾有 `Task:` 与 `Agent:` 两行，第一行形如 `type(scope): 摘要`。缺了写进「发现」标「建议」，不因此判不通过。
8. 对照任务的「做完能观察到什么」逐条检查。能运行的运行，能看文件的看文件。
9. 不做代码风格审查，那是审查阶段的事。你只判「这个任务做完了没有、有没有越界」。

## 核累计继承

在本任务检查之前，核本轮 change/fix 的原始基线与 plan 一致，并沿它的继承来源打开上一次验证报告或当前获批方案。逐行比较已验证任务前缀；漏行、改写或缺字段时判「不通过，需要人」，说明文件和字段。已绑定的实现、修复记录只交接旧事实，不能因自报完成而直接进入累计表。

每条门禁保存实际命令参数、工作目录、stdout、stderr、退出状态和候选提交到原始证据文件；不能只写一行自报通过。报告引用这些文件。

报告记录本轮实际检查的 change/fix 路径、继承来源、原始基线和候选提交，并原样携带全部旧行。只有本任务的 Git 范围、审批、门禁和可观察结果都由验证者独立核对通过，才追加本任务一行。新行包含任务基线、候选提交、审批来源、当前验证报告输出路径和原始证据路径。失败报告只保留旧前缀，不追加失败任务。

## 写什么

按 `template` 写 `report.md`。**第一行只写下面四种之一**：

- `通过，下一任务 T06`：本任务完成，清单里还有任务。编号写清单里紧接着的下一个。
- `通过，全部完成`：本任务完成，它是清单里最后一个。
- `不通过`：门禁失败或「做完能观察到什么」有一条不成立，且 `修复轮次` 小于 2。
- `不通过，需要人`：问题不是修复能解决的：`修复轮次` 已经是 2，或者需要人裁决（批准失效、任务卡与方案矛盾、验证要授权）。

第一行之后写 `任务: Tnn`、`修复轮次: N`、`基线: <任务基线>`、`提交: <候选提交>`、`原始基线: <整体原始基线>`（原样抄本轮 change/fix 的字段）；另写 `本轮变更`、`继承来源`、`被验规格`、`被验方案`、`被验任务`、`审批来源` 的实际输入路径，再写「检查项」表：每条命令或观察项一行，结果一列。判「不通过」时「发现」一节每条问题写清：哪个文件、什么现象、期望是什么。发现要能让修复者不用再问就能动手。

累计表按 template 的六列写，原始证据只保存路径，不复制正文，以保持 report 在 32768 字节以内。报告行与引用文件必须可供一个新 worker 独立重建验证事实。

## 人工更正批准版本

只有绑定的 escalation 第一行为「继续」、明确写出 `更正原审批: <原decision路径>`、`批准的规格: <当前spec的sha256>`、`批准的方案: <当前plan的sha256>`，且原审批第一行为「通过」时，才按更正核验当前版本。普通「继续」不等于批准。保留原审批的条件；人明确改动条件时按更正记录逐条核验。

在交接记录写 `审批更正来源: <该escalation路径>`，后续节点即使绑定了新 escalation，也从这条明确引用读取并核验更正。verify 的 `审批来源` 和本轮累计表行引用实际更正文件，另写 `原审批来源: <原decision路径>`；未更正时引用 decision。缺引用、摘要不符或原审批未通过时停止，不猜更正内容。

## 写到哪

写到 `report` 对应路径。

## 怎么回复协调者

一句话：第一行的内容原样重复一遍。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| report | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md | 是 | 32 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
