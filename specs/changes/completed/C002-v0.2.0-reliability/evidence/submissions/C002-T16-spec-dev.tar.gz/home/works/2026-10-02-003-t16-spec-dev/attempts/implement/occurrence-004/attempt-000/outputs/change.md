完成 T04

基线: 71821061f32d9c6496c2d621e673527bc785e4f6
提交: 0ff54fa35002477c033f306e46089cfda738e3d1
原始基线: 2f88d59b0d214967b64b285e96d764f26bc71c30
继承来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-003/attempt-000/outputs/report.md
修复轮次: 0
启用的测试: 12
改动文件:
- title_tools.py
- tests/test_title_tools.py
- README.md
门禁:
- python3 -m unittest discover -s tests -v: 通过（26 项全部实际通过，无 skip，退出 0）
- python3 -m compileall -q title_tools.py tests: 通过（退出 0，stdout/stderr 均为空）
备注: 只完成 T04 待验证候选；未追加已验证行。禁止联网宿主资格仍待独立验证，-S 与导入检查不等于网络隔离。

审批来源: /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-002/attempt-000/outputs/decision.md
原始证据: /private/tmp/sheltie-c002-t16-82c6c55/task-runs/implement-4/

## 已验证任务

继承最新独立 verify#3 的三行，原样保留 T01–T03。plan/tasks 与新 scaffold 的旧两行均是该表未改写的前缀；已核 verify#2 → verify#1 → 首次空表及 implement#1/#2/#3，各层原始基线一致，历史审批、报告与证据目录存在。候选、提交与完整门禁不新增独立验证事实。

| 任务 | 任务基线 | 候选提交 | 审批来源 | 验证报告 | 原始证据 |
| --- | --- | --- | --- | --- | --- |
| T01 | 92e2d3f3fb14d077aac3cba9d10ec2b7df53f540 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-001/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-1/ |
| T02 | 65c9163a4ef2b45892f3cc2f87e2d16ea6eedc3c | 6773f932765895735a5786220653440afcba2d8f | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-001/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-002/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-2/ |
| T03 | ba56d3fc3a25a9ca170183fd2315beb0ff37db5b | 71821061f32d9c6496c2d621e673527bc785e4f6 | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/plan-review/occurrence-002/attempt-000/outputs/decision.md | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-003-t16-spec-dev/attempts/verify/occurrence-003/attempt-000/outputs/report.md | /private/tmp/sheltie-c002-t16-82c6c55/task-runs/verify-3/ |

## 本轮执行与证据

brief 绑定的九个输入均重算 SHA-256，与冻结摘要相同；只对 spec 核摘要，未将其正文用作实施上下文。新版 decision 首行为「通过」，规格摘要 bc8a275fbe0e6b802b9d2d99e6ddd5c9c0054710a9624b54c073af4b63e0bf38、方案摘要 557a7ff9d0614ac2c0a69ba59eec3bb8a3ce5c3ea6c26cb6c5b3420bba4ad40d 与当前输入相符，条件原文为「错误信息不得回显输入正文」。实际读取 human-decisions.json 的 call_bAUqDu6CHZknYa5vxVjQCRWj/0，答复「批准新版，保留原条件」，对应两个摘要及条件匹配；只核记录，不另主张身份认证。原文为 input-*.bytes、input-hashes.json、human-decisions.bytes、prefix.json 与历史 *-report/approval/change.bytes；绑定输入在提交后未变。

开工 git status --porcelain=v1 stdout 为空，HEAD 为任务基线。测试文件仅移除十二行 T04 skip，测试名称、输入、全部断言与 helper 字节未变。源码仅填写 SafeArgumentParser.error、build_parser、main 三个函数体，签名、类型、文档和 T01–T03 源码字节未变；无新增项目文件或依赖。静态比较与交付镜像见 capture-final.py、result.json、before-*、candidate-*。

完整四任务选择器 stdin 与新 scaffold 原字节一致，完整 argv 为 ["python3", "-", "T04"]。首次启用后 red-T04 实际选中十二项、退出 1：十一项 CLI 测试方法失败，既有标准库静态检查一项通过；缺参数的三个 subTest 使 unittest 计十三次失败。没有为制造全红改断言或依赖边界，也没有将静态通过写为 CLI 已实现。随后按单项断言依次实现成功输出、标题拒绝、读取及解码安全分类、参数安全拒绝；每项原文为 green-*/red-*。其中 red-encoding 命名保留原执行记录，其实际退出为 0：UnicodeError 属于 ValueError，已被初次安全标题分支捕获；随后按任务卡补充明确 UTF-8 解码类别，再次执行 green-encoding-category 通过，不把该记录称为失败。

green-T04 精确选中十二项，全部实际通过、无 skip、退出 0。两条完整门禁的 argv 未修改，原文见 gate-unittest、gate-compileall。执行使用项目根 cwd，移除 PYTHONPATH，设置 PYTHONIOENCODING=utf-8，字节码写入本证据目录 pycache，避免污染项目；每条命令 .json 保存完整 argv、cwd、HEAD、stdin 路径、环境覆盖、起止 UTC 与退出状态，同名 .stdout/.stderr 保存原始字节；stdin 命令另存全文。

补充 CLI 原始证据 cli-* 与 without-site-* 保存成功一行 stdout、失败 stdout 空/stderr 安全原因/退出 2/无 traceback/无私密正文回显。既有文件前后完整字节保存为 *.before.bytes/*.after.bytes；不存在文件前后均不存在。permission-precondition 真实 chmod(0) 后以 python3 -S -c 的 pathlib.read_bytes 证明 PermissionError，随后实际运行 CLI 退出 2，finally 恢复权限，再核完整原字节一致；未 mock 或 skip。-S 下两个子命令均实际覆盖成功和失败。此范围是实施者证据，不替代独立 verify，也不证明宿主网络隔离；本轮未访问网络。

README 保留并说明 Unicode 空白、汉字标点大小写、首个严格行首 # 空格、被忽略前缀、首个空标题不回退、不解析上下文、UTF-8 明确文件名与只读、成功及失败协议、标准库与不联网限制、两条原门禁、至少三项小任务/本方案四项、独立 Task trailer 与真实确认要求。函数及 CLI 示例已实际执行，原文 readme-functions/readme-cli-extract；宿主禁止联网证据明确交独立验证。

提交仅含三个白名单文件，父提交等于任务基线，整体原始基线与最新已验证 T03 候选均为祖先。Task: T04、Work、Agent trailer 已保留，提交后工作区干净。原文见 git-task-baseline、git-commit、git-head-after、git-candidate-parent、git-message、git-range-files/diff、git-original-ancestor、git-latest-verified-ancestor、git-status-after。

没有修改 Sheltie 仓库、引擎状态或冻结输入，没有 submit。本轮完成仅指 fixture T04 候选与本任务门禁；整体规格、人工条件的独立验收及 C002-T16 完成仍由后续验证判断。
