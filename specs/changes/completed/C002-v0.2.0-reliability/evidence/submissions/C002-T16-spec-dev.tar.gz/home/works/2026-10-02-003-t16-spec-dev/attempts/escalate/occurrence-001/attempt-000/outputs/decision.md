改方案

用户明确同意重规划：未验证的T03改为UTF-8只读文件读取及独立正反例；T04改为CLI及README。
原始需求不变，已独立验证的T01/T02及完整证据前缀原样保留，整体原始基线不得重设。
保留审批条件：错误信息不得回显输入正文。
这是T16实际重规划回归，不是验证失败或原T04违规。决定来源：/private/tmp/sheltie-c002-t16-82c6c55/human-decisions.json，call_y1C96BSiygLZkIjKbGZZMMji/0。
Codex依据用户实际决定机械记录，不代替人作决定。
