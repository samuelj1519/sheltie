# 任务书：定稿

Work: 2026-10-02-005-t16-back（t16-back）
节点: publish#1，第 0 次尝试
来自: review#2（main 边）
执行者: human

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| article | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-005-t16-back/attempts/draft/occurrence-002/attempt-000/outputs/article.md | 3c94a359dc79a460988cd7be005818c836bb8aabcb2f92581c6165b20937ec84 |
| review | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-005-t16-back/attempts/review/occurrence-002/attempt-000/outputs/review.md | 1f94895889d4b2e3b67b79d0f963ca015a453e1f973d2d4216fd48b4d17f50c6 |

## 说明

阅读审查通过的文章，确认可以发布。把最终版复制到 final.md。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| final | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-005-t16-back/attempts/publish/occurrence-001/attempt-000/outputs/final.md | 是 | 1 MiB |

写完输出文件后，在终端运行：

    sheltie attempt submit 2026-10-02-005-t16-back --attempt publish#1.0 --summary "<一句话结论>"
