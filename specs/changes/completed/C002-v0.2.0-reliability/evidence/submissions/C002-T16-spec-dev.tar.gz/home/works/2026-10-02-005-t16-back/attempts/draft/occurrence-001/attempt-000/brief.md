# 任务书：写初稿

Work: 2026-10-02-005-t16-back（t16-back）
节点: draft#1，第 0 次尝试
来自: 入口
执行者: agent（standard）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| topic | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-005-t16-back/start-inputs/topic | 07d954788d6112efc720535a4c891d3167f775776310dc76cf28ccf0a622e7a2 |
| review | 尚无（上游 review 还没有产出） | |

## 说明

读 `topic`，写一篇 800 到 1200 字的文章。

- 有明确的论点，至少两个论据，每个论据有例子或数据。
- 结构：引言、正文两到三段、结论。
- 用简体中文。

`review` 是审查意见文档的路径，列在任务书输入表里，正文不在任务书里重复。首次开工它标「尚无」：还没有意见，正常写首稿。

如果任务书「来自」是 `review`，说明上一稿被打回：读 `review` 指向的文档（最近一次成功审查的意见），逐条回应审查意见再改，不要只改措辞。

写到 `article` 对应的路径。回复协调者时说一句：论点是什么，改了哪几处（首稿写「首稿」）。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| article | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-005-t16-back/attempts/draft/occurrence-001/attempt-000/outputs/article.md | 是 | 256 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
