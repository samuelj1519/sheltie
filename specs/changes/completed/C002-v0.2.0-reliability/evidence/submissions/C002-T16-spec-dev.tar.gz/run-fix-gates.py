import os,subprocess,pathlib,json,time,hashlib
out=pathlib.Path('/private/tmp/sheltie-c002-t16-82c6c55/fix-gates');out.mkdir(exist_ok=True); env=dict(os.environ,RUSTC_WRAPPER='',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',NEXTEST_TEST_THREADS='2',CARGO_TARGET_DIR='/private/tmp/sheltie-simplify-t38-target')
env['PATH']=str(pathlib.Path.cwd()/'target/t31-validation/tools')+':'+env['PATH']
commands=[('fmt',['cargo','fmt','--all','--','--check']),('check',['cargo','check','--all-targets','--all-features','--locked']),('clippy',['cargo','clippy','--all-targets','--all-features','--locked','--','-D','warnings']),('nextest',['cargo','nextest','run','--all-features','--no-tests=pass','--locked']),('core-doc',['cargo','test','-p','sheltie-core','--all-features','--doc','--locked']),('deny',['cargo','deny','--offline','--config','/private/tmp/sheltie-t38-gates/deny.toml','check']),('msrv',['cargo','+1.85.0','check','--workspace','--all-targets','--all-features','--locked']),('dist',['/Users/shushu/.cargo/bin/dist','plan','--output-format=json'])]+[(name,['scripts/check-'+name+'.sh']) for name in ('docs','specs','core-vocab','tests','skill')]
records=[]
for name,argv in commands:
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  p=subprocess.run(argv,env=env,stdout=stdout,stderr=stderr)
 row={'name':name,'argv':argv,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)}
 for stream in ('stdout','stderr'):
  file=out/(name+'.'+stream);row[stream]=str(file);row[stream+'_sha256']=hashlib.sha256(file.read_bytes()).hexdigest()
 records.append(row);(out/'results.json').write_text(json.dumps({'candidate':'82c6c551+T16-workbook0.2.1-worktree','env':{k:env[k] for k in ('RUSTC_WRAPPER','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','NEXTEST_TEST_THREADS','CARGO_TARGET_DIR')},'results':records},ensure_ascii=False,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:break
