# C002-T17 本版本 macOS 范围独立审查

Reviewer：`Codex /root/t16_reopen_review`。未参与本轮平台范围、workflow、Cargo 或文档修改；只读核当前相对 `33b08bc` 的源码和范围记录、实际用户指示、既有 CI 失败与 worker 静态结果。仅写本文，不改任何其它文件、档案、先前报告或状态，不复跑完整 700 测试，不进行网络写。

结论：**新候选的 macOS 范围与 CI 接线内容通过；新版实物和实际 CI 仍待验证。** 本版本可按用户实际指示仅验收及发布 macOS aarch64/x86_64。Linux 失败保留为 FAIL，范围状态为 `excluded_by_user`，不能由本轮排除推成 Linux、全平台原生运行或完整安全验证通过。发布前另需实际材料与用户的具体发布批准。

## 用户授权和版本边界

`ci/linux-exclusion-authorization.json` 保存本轮用户直接指示「此版本可以忽略Linux平台」、版本 0.2.0、两个 macOS target、保留 Linux 失败及不建立永久豁免的范围，与任务来源一致。此指示是本版发布验收范围的授权，不能解释为 Linux 通过、删除历史错误、跨版本豁免、清理数据或已经批准发布。

C002 plan §6 新增本轮例外，完整质量/MSRV、两个实际平台包/manifest/checksum、真实安装/远端指定版本更新/rollback与发布批准仍保留。原四平台门槛和先前候选证据作为历史事实保留，当前收尾以用户指定范围为准；T17 仍 doing，不因 scope 修改直接完成。

progress 新增「T17 本版本当前入口」，明确上方四平台步骤为范围调整前交接，当前要求新候选同 SHA 的两个 Mac 包和完整原生 Mac quality/MSRV。CHANGELOG 也把新版目标与历史 M1/SK、usage 和原 Linux FAIL 分开，未升级缺失项。

## 源码与 CI 接线

- Cargo dist 当前目标恰好 `aarch64-apple-darwin`、`x86_64-apple-darwin`；移除两个 Linux 目标，版本、Cargo.lock 和产品 Rust 行为未因本轮 scope 修改。由真实新 dist plan 和构建取得最终两个包，不能只凭目标列表记资产通过。
- release quality runner 为 macos-14；build-rust 矩阵为 macos-14、macos-15-intel，MSRV 为 macos-14。GitHub 官方当前 runner 表分别将这两个标签列为 arm64 和 Intel，符合两 CPU 架构的原生工程检查方向。见 [GitHub-hosted runners](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)。实际 runner 架构、toolchain、命令成功和测试结果仍由新 run 原文证明。
- build.yml 三处 checkout 都使用 `github.event.pull_request.head.sha || github.sha` 并关闭 persist-credentials。release plan/quality 仍直接使用该候选，其余 local/global/host/announce 使用 plan 的 candidate-sha；quality 保留 HEAD 相等断言，Release target 也不改。新 native Mac quality 与新资产必须核同一实际 SHA，不能使用历史 7f42/33b08bc 的成功包替代新质量记录。
- publishing、tag/host create 仍限定 tag push；host/announce 的 publishing guard 保留，announce 仍同时要求 plan、host、quality success。PR 只走临时构建/证据上传路径。未新增 workflow_dispatch、跳过质量、continue-on-error、lint 许可或权限扩大。Ubuntu 上的 docs/plan/global/发布协调 job 仍可执行脚本；它们不构成本版 Linux 产品原生资格。
- macOS quality 不再依赖 GNU sha256sum。嵌入标准库 Python 从 Git NUL 分隔路径取清单，用 fsdecode/Path.read_bytes/hashlib 保存 path/sha256 JSON；UTF-8 和含空格路径不会按空白拆开。它跟随 tracked LICENSE 软链读取内容，与此前 sha256sum 的内容口径一致；HEAD/commit/run identity 另行记录，内容摘要不代替完整 Git 对象/权限证明。
- worker 的两份 YAML 解析结构与实际 job 配置一致，报告 40 个 run 块 bash-n 通过；嵌入 Python 已真实生成 299 个唯一路径摘要。Reviewer 独立比对这些实际摘要与当时文件字节全一致，并核 Cargo/lock/workflow 的独立摘要匹配。原始输出为 `/private/tmp/c002-t17-macos-source-sha256.json`、`c002-t17-macos-workflows.json`。这些是静态/本机摘要证据，不是 GitHub 实际 quality PASS。
- release_governance 的 workflow 断言没有硬编码 Ubuntu、Linux 或哈希工具命令，只核候选、全历史、MSRVlocked、quality needs/if 和 Release SHA。原断言保留，runner 与摘要实现变化无需修改其行为期望；本报告未把测试源码存在当作本轮已执行通过。

## 已修复与未继续修复的 Rust 范围

fsx.rs 仍为已独立审查的三处 `Mode::from_raw_mode(... as _)` 修复，SHA256 `a2d1efce26f523cb1838327fb40ce48e4f2b81251a4114f13541b94d4e64f83a`。Mac u16 恒等、Linux u16→u32 无损扩展，原 constructor 去 S_IFMT/truncate、公开 API、锁/句柄和 fchmod/failpoint/fsync 次序保持。

第二次 Linux 失败原文 `ci/37032589688-failed.log` 实际指向 fsx.rs:1307/1381/1447/2373 的四个既有 u64→u64 unnecessary_cast。本轮没有为 Linux 更改这四处、增加 lint allow 或新的 cfg 兼容层。33b08bc 的四个实际包和部分 MSRV/build 成功不等于 Linux quality、完整 workspace 或总体 CI 通过；第一次 E0308 和第二次 Clippy FAIL 都应按原 run 单列保留。

## 最终记录与发布前收尾

最终标准验证表只能将本版 Mac 限定要求及其真实结果列为 PASS。Linux 排除的用户授权与失败披露可以核「披露完整/范围已授权」，不能据此写「Linux 执行 PASS」。旧 M1/SK01/SK02、215 项额外变异及最终 Spec 批准、历史 Linux not_run/FAIL、T16 的 0.1.0 身份、usage 缺失与手动 skill 边界均保持，checker 的精确六列/非空字段/当前 Result 规则没有放宽。

README 顶部已经明确本版仅 Mac 和历史 v0.1.0 Linux 资产保留。初次核验时 quickstart 仍写「装引擎（macOS 与 Linux…）」且下载 latest，Reviewer 已指出入口范围矛盾；Owner 随后将精确安装行改为「装引擎（本版本 macOS，aarch64 与 x86_64）：」。本报告复读当前文件确认该问题已关闭，顶部使用版本发布范围表述，未声称 tag/Release 已存在。

本报告核到的当前 workflow SHA256：build `b241f89b71b22cf0a6639c8d31fb6f305e26d3956c56e4019b1af2bc40d6f276`，release `7f447eee0e482e5b6e28b465f7cb6773d923f7d46a28cc11748668808ddcfffe`；Cargo.toml `5fdaea5fcfe98758fb2947a41ff69fa5d91e3cfdb656748efd5ca83a128cd896`。新候选尚需实际同 SHA Mac quality/MSRV 和两包实物补核；本文不预判绿色、远端或 T17 done，也不是外部发布批准。

文案收尾后的 README SHA256 为 `99456b0922bfdfac0d8a4f6e4f9b7caab477e8782b67afdce16558d51a8758f8`；progress 当前入口 SHA256 为 `cfbc932e11e5e51da27eef1d72be5700f0d2ebade90307f3d3e0b240c67bceb1`。Owner 新的本机完整门禁正在运行，本文不将其预记为 PASS，不重复执行这些门禁。
