import copy, hashlib, json, pathlib, sqlite3, subprocess, sys, tempfile
binary=pathlib.Path(sys.argv[1]).resolve()
root=pathlib.Path(tempfile.mkdtemp(prefix='sheltie-t38-decode-',dir='/private/tmp'))
home=root/'home'
fixture=pathlib.Path.cwd()/'examples/two-step'
def cli(*args):
    run=subprocess.run([str(binary),'--home',str(home),'--json',*args],text=True,capture_output=True)
    return {'exit':run.returncode,'stdout':json.loads(run.stdout),'stderr':run.stderr}
assert cli('workbook','add',str(fixture))['exit']==0
start=cli('work','start','--workbook','two-step','--flow','default','--input','topic=probe')
assert start['exit']==0
work=start['stdout']['data']['work_id']
assert cli('attempt','begin',work,'--node','outline')['exit']==0
conn=sqlite3.connect(home/'store.db')
raw=conn.execute('SELECT state_json FROM works WHERE work_id=?',(work,)).fetchone()[0]
pristine=json.loads(raw)
control=cli('work','status',work)
assert control['exit']==0
report={'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'home':str(home),'control':control,'cases':[]}
def business():
    return {str(p.relative_to(home)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(home.rglob('*')) if p.is_file() and p.name not in {'.lock','store.db','store.db-wal','store.db-shm','store.db-journal'}}
def facts():
    return list(conn.execute('SELECT revision,status,state_json FROM works WHERE work_id=?',(work,)).fetchone())+list(conn.execute('SELECT (SELECT count(*) FROM requests),(SELECT count(*) FROM audit)').fetchone())
for label in ['root','attempt_id','status']:
    changed=copy.deepcopy(pristine)
    target={'root':changed,'attempt_id':changed['attempts'][0]['id'],'status':changed['status']}[label]
    target['unexpected']='single unknown field'
    payload=json.dumps(changed,ensure_ascii=False,separators=(',',':'))
    conn.execute('UPDATE works SET state_json=? WHERE work_id=?',(payload,work));conn.commit()
    before=facts(); before_files=business()
    result=cli('work','status',work)
    after=facts();after_files=business()
    report['cases'].append({'case':label,'cli':result,'state_json_sha256_before':hashlib.sha256(before[2].encode()).hexdigest(),'state_json_sha256_after':hashlib.sha256(after[2].encode()).hexdigest(),'state_revision_request_audit_unchanged':before==after,'business_files_unchanged':before_files==after_files,'response_equal_to_control':result['stdout']==control['stdout']})
    assert before==after and before_files==after_files
conn.execute('UPDATE works SET state_json=? WHERE work_id=?',(raw,work));conn.commit();conn.close()
out=pathlib.Path('/private/tmp/sheltie-t38-nested-fields-cli-probe.json');out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for case in report['cases']:
    print(case['case'],'exit',case['cli']['exit'],'ok',case['cli']['stdout']['ok'],'unchanged',case['state_revision_request_audit_unchanged'],case['business_files_unchanged'])
print('evidence',out,'home',home)
