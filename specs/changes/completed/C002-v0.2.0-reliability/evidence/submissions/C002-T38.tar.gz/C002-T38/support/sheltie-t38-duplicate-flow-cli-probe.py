import hashlib,json,pathlib,shutil,sqlite3,subprocess,tempfile,sys
binary=pathlib.Path(sys.argv[1]).resolve()
root=pathlib.Path(tempfile.mkdtemp(prefix='sheltie-t38-flows-',dir='/private/tmp'))
source=root/'source';home=root/'home'
shutil.copytree(pathlib.Path.cwd()/'examples/two-step',source)
manifest=source/'workbook.toml';pristine=manifest.read_text();assert 'flows = ["flows/default.toml"]' in pristine
manifest.write_text(pristine.replace('flows = ["flows/default.toml"]','flows = ["flows/default.toml", "flows/duplicate.toml"]'))
shutil.copyfile(source/'flows/default.toml',source/'flows/duplicate.toml')
def cli(*args):
 r=subprocess.run([str(binary),'--home',str(home),'--json',*args],text=True,capture_output=True)
 return {'exit':r.returncode,'stdout':json.loads(r.stdout),'stderr':r.stderr}
rid='duplicate-flows'
first=cli('--request-id',rid,'workbook','add',str(source))
conn=sqlite3.connect(home/'store.db');rows=lambda:list(conn.execute('SELECT (SELECT count(*) FROM workbooks),(SELECT count(*) FROM requests),(SELECT count(*) FROM audit),(SELECT published FROM requests WHERE request_id=?)',(rid,)).fetchone())
before=rows();second=cli('--request-id',rid,'workbook','add',str(source));third=cli('--request-id','next-workbook','workbook','add',str(pathlib.Path.cwd()/'examples/gated-release'));after=rows()
report={'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'home':str(home),'source':str(source),'first':first,'replay':second,'new_request':third,'rows_before_replay':before,'rows_after_next_request':after,'final_dir_exists':(home/'workbooks/two-step/1.0.0').exists(),'pending_payloads':[str(p) for p in home.glob('pending/*/payload')]}
out=pathlib.Path('/private/tmp/sheltie-t38-duplicate-flow-cli-probe.json');out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for key in ['first','replay','new_request']:
 v=report[key];print(key,v['exit'],v['stdout'].get('error',{}).get('code'),'committed',v['stdout'].get('committed'),'cause',v['stdout'].get('error',{}).get('detail',{}))
print('rows',before,after,'final_dir',report['final_dir_exists'],'evidence',out)
