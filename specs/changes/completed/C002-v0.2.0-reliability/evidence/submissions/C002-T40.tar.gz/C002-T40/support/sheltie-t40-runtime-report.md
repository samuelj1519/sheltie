# C002-T40 Runtime测试精简实施报告

范围：`crates/sheltie-runtime/tests/**`、`src/store/tests.rs`与测试专用支持。输入为保留T38/T39的工作区，旧源文件保存在`/tmp/sheltie-t40-runtime-before/`；逐文件SHA256均与父任务`/tmp/sheltie-t40-evidence/input-hashes.json`一致。默认生产源码、依赖、安全原语、格式、specs、提交均未改。

## 已落实

- 3条确定退休：虚构失败但没有失败夹具的allocate_seq、较弱checksum拒绝重复、取消的tmp删除布局义务。
- 6组合并：旧add/remove生命周期2组、completed submit、Active引用remove、首次install、installed tamper。先迁入原返回reply/data/revision、SQL行数/digest、files bytes/mode/inode等独有判定。
- 生命周期同时保留同内容/不同内容两个独立case；终态Workbook删除查询同时保留0/1提交历史，迁入`status: cancelled`文本判定。
- Started历史快照workbook/name、Cancelled历史快照错状态/未知字段合成两组数据表，case独立建Home，每个单字段corruption都保留EFFECT_PENDING原响应资格断言。
- 共享7个文件的literal/input/start构造；fs_boundary/selfmgmt真实哨兵byte/mode；effect_contracts原始SQL全行观察；3个精确/越界limit-tree生成；3种tar格式的打包动作；preflight合法retry的001 oracle。删除无调用者`_svc_ref`、`_wid_of`，删除make_release没有消费者的tamper=true分支；删schema1同一个lock拒绝断言的第二份。
- 扩展已有`RendezvousWorker<T>`保留真实子线程返回结果；11个相同绑定/生命周期的单同步窗口共享release/join/timeout，原两窗口observer保留；正常finish传播join/业务错误，Drop只负责失败时释放和收束。所有serial锁与实际checkpoint名/作用域保留。

## Oracle修正与独立判定

- `open_rejects_same_version_different_table_shape`：手写独立schema2、仅少status列、精确works表诊断、ReadOnly/ReadWrite都拒绝、main/WAL字节不变。
- `open_rejects_same_whitespace_different_column_type`：独立schema2、仅state_json从TEXT换BLOB且保留空白、同一精确拒绝与no-write判定。
- 新增`handwritten_schema2_control_accepts_both_open_modes`：独立合法schema2在两种mode均接受，非零sequence事实7保留。没有用production TABLES/create_script生成期望。
- `observation_rejection_before_commit_leaves_store_unchanged`：持外部TempDir保活，是真实可达sentinel；完整SQL观察五张表全部列（含revision/state_json/requests/audit）及外部bytes/mode完全不变。
- `status_card_missing_is_regenerated_on_next_write`：最新revision2/Active事实加独立手写精确状态卡字节，核outline#1.0 running及合法下一步。
- `begin_effects_recovered_by_next_write`：恢复brief逐字节等于提交后保存的原bytes，完成标记pending count0；保留由不同下一写命令触发的恢复入口。

以上schema/observation相关4个测试与其store_rows/sentinel/snapshot语义已提供父任务冻结入口。定向负控制由父任务在独立临时源码副本完成，本agent不标记其结果。

## 保留判断

精确限额不同consumer及+1两端、SafeFile/effects/真实submit/恢复、COMMIT/rename/delete窗口、9种sync及重复失败、lock/root inode替换、只读load/cleanup/replay原响应资格均保留。`write_session`等待父锁释放的异常排序有独立资源所有权，保留其专用guard/join，避免通用worker在父锁仍持有时Drop等待线程。递归chmod helper按各自软链/缺对象语义保留。tar poison外部哨兵case保留其具体打包边界，不并入普通pack helper。

## 数量与可审查映射

旧318个测试函数→307个：3条退休、9条旧函数合并、1条保留函数改名、1条新增合法schema2对照，净减少11。所有原case、独有oracle和故障窗口有完整映射；函数数不能证明产品完整覆盖。

13个测试/支持文件相对于开工字节净减少433行（不是git diff包含T38/T39的口径）。`src/`除cfg(test)专用`store/tests.rs`外，每个原字节SHA256一致。

完整318项旧函数→保留函数→cases/oracles/入口/窗口/归属及原/现函数字节：`/tmp/sheltie-t40-runtime-dispositions.json`。逐文件行数与输入/输出hash：`/tmp/sheltie-t40-runtime-line-metrics.json`。

## 局部验证

环境：`RUSTC_WRAPPER=`、`CARGO_NET_OFFLINE=true`、`CARGO_TARGET_DIR=/tmp/sheltie-t40-runtime-target`，PATH先仓库`target/t31-validation/tools`。

- `cargo check -p sheltie-runtime --tests --all-features`：PASS。
- `cargo clippy -p sheltie-runtime --all-targets --all-features -- -D warnings`：PASS。
- `cargo fmt -p sheltie-runtime`：完成。
- 显式相关nextest run `f3672b0e-2496-4268-aa38-809827aeb6ff`：103/103 PASS，0 FAIL，scope排除204（明确不是全runtime/全仓run）。75.525秒；exact limit正常consumer仍执行69.906秒，未缓存或跳过重型copy/sync。

过滤器保留在`/tmp/sheltie-t40-runtime-nextest-command.txt`。完整输出在本agent工具执行记录；结果尾部保存`/tmp/sheltie-t40-runtime-nextest-summary.txt`。后续整仓门禁、MSRV、doc/test checker、dist与独立review由父任务完成。全量mutants为not_run，本次不修改M1/SK或Linux/Host/发布边界。候选已停止编辑，不提交。
