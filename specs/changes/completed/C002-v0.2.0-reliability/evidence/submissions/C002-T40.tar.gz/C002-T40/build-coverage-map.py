from pathlib import Path
import json,subprocess,re,hashlib
out=Path('/private/tmp/sheltie-t40-evidence')
def owners(text):
 return {parts[1]:{'task':parts[0],'location':parts[2],'ignore':parts[3]} for line in text.splitlines() if (parts:=line.split())}
before=owners((out/'original-test-owners.txt').read_text());after=owners(subprocess.check_output(['scripts/test-owners.sh'],text=True))
retired={}
for row in json.loads(Path('/tmp/sheltie-t40-core-dispositions.json').read_text())['dispositions']:
 m=re.search(r'::([a-z][a-z0-9_]*)',row.get('old',''))
 if m and m[1] in before and m[1] not in after:
  replacement=[]
  for target in row.get('replacement',[]):
   n=re.search(r'::([a-z][a-z0-9_]*)',target)
   if n and n[1] in after:replacement.append(n[1])
  retired[m[1]]={'replacement':replacement,'disposition':row['disposition'],'cases':row.get('cases',[]),'oracle':row.get('oracle',''),'reason':row['reason']}
for row in json.loads(Path('/tmp/sheltie-t40-cli-dispositions.json').read_text())['retirements']:
 old=row['old_function'].split('::')[-1];replacement=row['retained_function'].split('::')[-1]
 retired[old]={'replacement':[replacement],'disposition':row['disposition'],'cases':[row['condition']],'oracle':row['independent_oracles'],'entrypoint':row['entry']}
for row in json.loads(Path('/tmp/sheltie-t40-runtime-dispositions.json').read_text())['entries']:
 if row['old_fn'] not in after:
  retired[row['old_fn']]={'replacement':[row['retained_fn']],'disposition':row['classification'],'cases':row.get('cases',[]),'oracle':row.get('oracles',[]),'entrypoints':row.get('entrypoints',[]),'windows':row.get('windows',[]),'reason':row['reason']}
entries=[]
for name,old in before.items():
 if name in after:entries.append({'old':name,'before':old,'current':after[name],'disposition':'retained_identity','details':'Detailed per-crate mapping records helper/strengthened oracle changes'})
 else:
  assert name in retired,'Missing deletion disposition '+name
  row=retired[name];assert row['replacement'] and all(p in after for p in row['replacement']),(name,row)
  entries.append({'old':name,'before':old,**row})
new=[{'name':name,**record} for name,record in after.items() if name not in before]
record={'before_test_functions':len(before),'after_test_functions':len(after),'disappeared_names':len(set(before)-set(after)),'new_names':new,'entries':entries,'source_maps':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['/tmp/sheltie-t40-core-dispositions.json','/tmp/sheltie-t40-runtime-dispositions.json','/tmp/sheltie-t40-cli-dispositions.json']}}
(out/'coverage-map.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print('Coverage identities:',len(before),'->',len(after),'removed/renamed names',record['disappeared_names'],'new names',len(new))
