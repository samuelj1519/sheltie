# Runtime 测试精简只读排查

候选：HEAD `4b86279a863f941cc282fa6cb772f7359fda585a` 加保留中的 T38/T39 未提交输入。只读检查，不改仓库、不运行新测试或 mutants。本报告依据当前源码、`specs/engineering.md` §3、`specs/contracts/storage.md` §1–3/§5/§9，以及现有 T39 日志；旧记忆只用于提醒检查当前合同与保留历史边界。

## 1. 范围与统计

已逐文件阅读 runtime 的 15 个集成测试文件、2 个 common 支持文件、`src/store/tests.rs` 与其他 9 个有单元测试的 src 文件的全部测试模块。也核了被测路径的 `Store::check_schema`/`allocate_seq`、Workbook add/remove、effects/ManagedFs/WriteSession 恢复与接口。

| 范围 | 文件 | 测试函数 | 行数口径 |
| --- | ---: | ---: | ---: |
| `tests/*.rs` | 15 | 266 | 10,840 行，含测试内 helper |
| `tests/common/*.rs` | 2 | 0 | 266 行 |
| `src/store/tests.rs` + 其他 src 的 cfg(test) module | 10 源文件 / 13 测试模块或文件 | 52 | 1,463 行，仅测试模块与 store/tests.rs；不含生产源码 |
| 合计 | 27 个带测试或支持的源文件 | 318 | 12,569 行 |

行数包含空行、注释、属性与 helper；318 是 cfg/failpoint 全特性下的函数数，循环参数化 case 不另算。src 整个文件行数不能当测试行数：例如 fsx.rs 首个 cfg(test) module 后还有大量生产代码。

## 2. 可以直接删除的确定冗余

此节是静态高信心候选，仍需在实施后实际运行保留者；不声称本次已验证删除后的候选。

| 删除候选 | 保留者 / 理由 | 合同、入口与 oracle |
| --- | --- | --- |
| `src/store/tests.rs:366` `allocate_seq_is_not_reused_after_failed_start` | 保留 `:356` `allocate_seq_starts_at_1_per_day_and_increments` | 两者都新建 Store、不建任何 Work、同日连续调用两次 allocate_seq。所谓失败用例没有引入失败；第二次为 2 的 oracle 已在保留者，保留者另核第一次 1 与次日 1。应删除这条模拟叙述；真实 COMMIT 前失败空号与重放序号边界由真实 start/crash 用例独立承担。 |
| `tests/selfmgmt.rs:109` `update_rejects_checksum_mismatch_and_leaves_binary_intact` | 保留 `:1048` `update_failed_digest_leaves_old_binary_and_cleans_tmp` | 同 `install → local release(raw binary) → update(None)`，唯一拒绝条件为清单 digest 与可下载资产 bytes 不同；均断 UpdateChecksumMismatch、旧二进制 bytes 不变、tmp 清空；后者还断 prev 未创建。全零错 digest 与另一个 payload 的错 digest均为合法 64 hex，当前同一校验路径，无不同产品分支。 |
| `tests/workbook_repo.rs:431` `remove_moves_dir_to_tmp_before_delete` | 退休已取消的旧 tmp 布局义务；保留当前 `workbook_txn` 删除窗口/marker 用例 | 当前 remove 的目标为 `pending/<id>/payload`（storage §3.2/§3.3，workbook_repo.rs:1149）；本用例在 add/remove 后仅断空 tmp，没有观察 rename，也未建 tmp 哨兵。因此对当前 pending 删除流程无辨别力。当前 `remove_deletes_row_and_directory` 及 pending/marker/recovery tests 保留。 |

**直接删除测试函数：3 条**。此外可直接删 `tests/schema2_replay.rs:92–95` 与前条完全相同的第二个 `.lock` 不存在断言；删未调用 helper `tests/fs_boundary.rs:596` `_svc_ref` 与其唯一为它导入的 `WorkService`、`tests/workbook_identity.rs:222` `_wid_of` 与其 `WorkId` import。`rg` 搜索确认两个 helper 只有定义，当前允许 dead_code 的自证用途已经不需要。

## 3. 必须先迁移 oracle，再合并的同层候选

| 组 | 候选与保留位置 | 精简办法与不得丢失的条件 |
| --- | --- | --- |
| 旧 Workbook 生命周期重放 | `workbook_txn.rs:828 old_remove_replay_does_not_delete_readded_workbook` 与 `:1041 completed_old_remove_and_add_replays_preserve_new_lifecycle_bytes_and_row` | 同 `add(old) → remove(old) → readd(new) → replay(old remove/add)` 调用链。保留后者的不同内容/digest、final inode/bytes、当前 row digest、两份历史 reply_json 原字节与 replayed；先迁入前者的当前行数 1 oracle，才删前者。当前 PK不等于行数 oracle可省略。 |
| 旧 add 重放快照 | `workbook_txn.rs:1465 old_add_replay_does_not_bind_to_a_readded_workbook_lifecycle` 与上一保留者 | 同旧 add 的新生命周期场景；后者有文件/inode/row/历史响应字节，但 `:1465` 明确比较 replayed_old.data 与 old.data，后者没断返回 data。迁入返回 data oracle、最好 remove也比较原 data后合并。不能以 DB历史 bytes不变代替响应 data相等。 |
| completed submit 重放 | `schema2_replay.rs:123 submit_replay_after_output_change_returns_original_snapshot` 与 `:165 completed_submit_replay_does_not_seal_or_rewrite_the_output_again` | 都 start/begin/submit 后 chmod+写入 later bytes，再同 rid/summary replay。合并为一条：必须同时保留原 reply/data/revision、replayed、外部后来 bytes与mode不变；两条现在各只断一半，不能直接删一条。 |
| 活跃引用拒绝 remove | `workbook_repo.rs:395 remove_rejects_when_active_work_references_version` 与 `workbook_txn.rs:46 remove_rejects_active_reference_and_rolls_back_row` | 同一 registered two-step/start Active/remove 入口。迁入前者 WorkbookInUse.works 精确含该 WorkId，保留后者错误码/行数1/原 Work Active，最好加当前final byte/digest；然后一条可删。二者都不强制在事务内引入新引用，所以不宣称已覆盖并发引用插入窗口。 |
| 新根 install 幂等 | `selfmgmt.rs:70 install_copies_current_exe_and_is_idempotent` 与 `workbook_identity.rs:105 self_install_on_new_home_creates_root_store_and_bin` | 同 new home/install/reinstall。集中断第一次 already_installed=false、installed_to/final binary、Store存在、第二次already_installed=true。这是同层相同入口，可共享一次 fixture；对已安装不同 bytes与update lifecycle的独立用例保留。 |
| installed byte tamper verify | `workbook_repo.rs:454 verify_reports_tampered_after_byte_change` 与 `workbook_identity.rs:34 load_rejects_tampered_registered_digest` | 都改已安装outline.md字节并 verify(None)→Tampered；后者还 start拒绝 WorkbookTampered、无 Work物化。可保留后者并迁入必要明确Workbook身份断言。前者与后者当前不同中文payload无不同分支；这不是跨crate验证删除。 |

上面是 **6 个合并组，最多再减少 6 条函数**（旧生命周期两条分别合入同一保留者，计两组）。它们不是 6 条可立即删除测试；逐组保留触发前置与所有 oracle、实际执行后才可处置。`service.rs:245 status_works_after_workbook_removed` 与 `workbook_identity.rs:151 work_readable_after_workbook_removed` 仅部分重叠：后者有成功提交产物史，前者从未begin/submit且断状态卡 `status: cancelled`；只在保留这两个不同前置（例如参数化0/1历史）后合并。不能把有历史终态视为完全覆盖无历史终态。

## 4. 参数化与 fixture 共享优先于删反例

- `service.rs:1291/1321` Started快照 malformed workbook/name：同合法 start → 改 reply_json 的一个 data字段 → 同rid start → EFFECT_PENDING(original省略)，可表驱动复用同一小fixture并对每 case重置原快照。字段/值/预期 original资格应留在测试数据中，不能变成通用“任意坏JSON必须报错”。
- `service.rs:1351/1381` Cancelled status错状态/未知字段：同入口同fixture可表驱动，但 WorkStatus错状态与 unknown字段是两条独立义务，两个case都留下。后续T39 core/CLI测试走state_json载荷，不能替代这里 reply_json 历史投影载荷。
- `start_preflight.rs:67/87/104/121/134` 的现有5个拒绝用例，setup/db_counts与失败后retry极相似，表驱动能少代码；保留 missing/extra input、invalid name、missing flow/workbook各不同前置和各错误码/无seq、原表数、无Work目录、合法retry序号1。当前单独用例名字更易定位，抽出 fixture/positive retry helper的收益通常优于压成一条长测试。
- `workbook_repo.rs:196/221/244` 正确fixture造7个32MiB+补齐最后一个文件重复，可提取 `make_limit_tree(total_delta)`；必须从独立合同固定限额设计，留 metadata计总量和越界前I/O停点，别把 expected规模由同一个被测helper算出。exact正例、普通total+1反例、不可读文件total+1但应先报总量的优先级反例继续独立。
- `selfmgmt.rs:~650/762/1172` 的 tar.gz/tgz/tar.xz 构造可以只共享写包/打包动作。包内目录布局、后缀选择、cargo-dist真实形状/缺checksums/毒顶层asset是独立条件，不统一成一个规范fixture掩盖格式差异。
- `tests/common/mod.rs:145 start_two_step` 固定two-step + 多文件里lit/start_args 可共享小型参数构造；不要建支持任意workbook/graph/state的fixture框架。`fs_boundary.rs` 与 `selfmgmt.rs` 的 sentinel/snapshot纯外部oraclehelper可移入common。各文件递归 `make_writable` 不能直接合一：service版本 follows path，workbook_txn版本有缺失对象处理；安全测试包含软链/替换目录，不能把任何safe cleanup改成路径追随chmod。
- failpoint rendezvous的guard/timeout/release/join重复较多；当前common `RendezvousWorker` 已覆盖部分模式。只在同绑定、相同故障窗口下复用“等待reached/失败释放join”的资源生命周期，不吞异常，不取消guard序列化，不能把同步窗口退化为sleep。

## 5. 先修 oracle 的测试质量缺口

1. **两条 schema形状用例被旧版本早退掩盖**：`src/store/tests.rs:98 open_rejects_same_version_different_table_shape` 与 `:220 open_rejects_same_whitespace_different_column_type` 都写 `PRAGMA user_version=1`（第一条还使用schema1全表形状）。当前 `store/mod.rs:55–63 check_schema` 先比较当前schema2，因此根本不触发表形状/normalize_sql。它们当前是wrong-version重复，但这不能成为删除产品形状义务的理由。应先用独立合法schema2控制、固定版本2，只改works一个列/类型，断诊断指向该表且main/WAL bytes不变；两种 corruption case可以共享setup。
2. **“提交前Store不变”只比较Active**：`fs_boundary.rs:266 observation_rejection_before_commit_leaves_store_unchanged` 的 before/after只序列化status；status一直Active也能掩盖revision、requests/audit变化。同条 `sentinel(tempfile::tempdir().unwrap().path(), ...)` 临时目录在表达式后已销毁，symlink指向不存在路径，无法证明真实外部哨兵保留。保留owner TempDir，记录 raw SQL revision/state_json/requests/audit 与外部bytes/mode，拒绝后逐项相同才满足其名称。此测试是当前合法负例义务，不能因低信息直接删。
3. **恢复正例存在不等于精确恢复**：`crash.rs:13 status_card_missing_is_regenerated_on_next_write`、`schema2_replay.rs:437 begin_effects_recovered_by_next_write` 等只断文件存在。前者与service状态卡更新用例条件不同，后者与same-rid begin replay条件不同。可把它们的比较升级为状态卡当前合法内容/历史brief精确提交字节，再在相同触发条件内合并。原始字节/独立状态卡当前revision优先于用productionrender helper生成expected。
4. `workbook_repo.rs:596 workbook_publish_requires_digest_root_before_recovery_io` 同时改audit为原始schema2 hash wire形式并删digest_root。其意图可以保留，但case前应证明单独合法audit形态control被接受（已有 `workbook_txn.rs:1184 schema2_workbook_recovery_accepts_original_audit_command_bytes`），再造唯独字段缺失。不要因为多字段setup相似就删当前audit字节合同测试。

## 6. 相似但保留的独立测试

| 组 | 独立辨别力 |
| --- | --- |
| SafeFile seal unit (`src/fsx.rs:2174/2196/2215`)、effects unit (`src/effects.rs:1417/1449/1484`)、real submit/afterCOMMIT与recovery (`tests/service.rs:1853–1986`) | primitive校验、effects交接所持原handle、真实caller COMMIT/封存窗口、恢复时重新打开原引用不同。effects缺observedhandle断言只有该层能直接触发，不能被正常real_submit成功覆盖。 |
| lock身份unit (`selfmgmt.rs:1288/1302`)、session新连接unit (`src/session.rs:76/102`)、真实helddirectory/write/session-init/purge交错 | identity检测与消费者每次调用是否重核不同；root替换与lock替换不同。并发初始化两种install/add顺序独立，不能留一个方向。 |
| digest32/256MiB、add exact32/256MiB、installed manifest32MiB、materialize_summary32MiB、output_declared size | digest reader/复制+登记/编译合法文本/输入物化/输出观察映射不同 consumer。MAX_FILE与MAX_TOTAL相同常量也不能证明真实consumer wiring。每层exact/+1接受拒绝都保留。 |
| publish9种sync + retry、matching history parent sync、output目录parent sync、completed历史repair sync | rename前后、published0/1、file/dir父同步不同，需要保证每种sync二次失败仍pending、恢复同对象、字节不变；不能合并成一次sync fail。 |
| cleanup反例 versus replay反例 versus readonlyload反例 | 同effects字段在不同消费者入口被使用；整索引在首个删除前核完、历史original资格、readonly不拿锁不恢复都各有不同oracle与failure-stop。 |
| actual子进程CLI crash 与 runtime手工published0/rename | 前者核真实退出/kill；后者精确造破损闭包与维护/读取行为。注入机制不同不能替代。 |

## 7. 性能与验证矩阵

已读 `/private/tmp/sheltie-t39-evidence/gates/nextest.stderr`：total256MiB digest 17.512s；add exactlimits 69.877s，唯一slow；全仓测试阶段166.013s。这是T39同输入的历史观测，**本次没有新运行**，不能用它证明删测/改夹具候选通过。69.877s本身不是冗余理由。共享fixture生成可以少setup行，但新鲜root/独立对象边界和完整copy/sync不能缓存成假路径；重型组运行范围/线程资源优化留给root统一审查。

后续实施逐组保存 `原test → 保留test → 前置/入口/oracle/故障窗口/平台feature` 映射。直接删除、迁移断言合并、坏oracle修复三个类别分别记数。

| 改动 | 最少验证 |
| --- | --- |
| 删纯重复assert/helper | fmt/check/clippy；相关测试binary，确认没有0-match |
| 删3个确定重复/旧义务 | 保留seq/failed_digest/当前remove+deletemarker+recovery用例实际运行；对Task测试name/file筛选核无义务丢失 |
| 同层合并组 | 全部迁移后的正常/拒绝case运行；检查new output含非零case、返回snapshot与实际bytes/mode/SQL都断；exact/+1与关键stop不丢 |
| 修schema伪覆盖 | 合法schema2 control + same-version column/type corruption；缺列与只换类型分别让绕过表形状校验的临时负控制失败（只在授权实施时） |
| 修I/O拒绝oracle | 可达真实sentinel + SQL revision/state/requests/audit完整before/after；错删Store拒绝guard的临时负控制确实失败 |
| 共用failpointguard或fixture | --all-features对所有涉及binary；保留进程内serial锁，跨nextest进程隔离与每case新root；必要真实caller窗口补跑 |
| 最终候选 | current工程四门禁与package指定门禁；不得把单个T39历史run、测试数或scope选项当新候选PASS；不自行重跑完整mutants或改M1/SK边界 |

结论：runtime 有少量真重复、较多 setup与同层oracle可集中，但安全、恢复、合法边界的相似测试多数有独立故障辨别力。可立即处置的测试函数是3条；6组合并必须先迁移oracle。首轮保守精简应以改fixture/重复setup为主，修正两个shape早退和一个weakStore oracle，不能按路径覆盖/测试耗时批量删。
