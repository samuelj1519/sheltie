# CLI 测试只读审计

范围：crates/sheltie-cli/tests 全部 23 个顶层 Rust 文件、common 两个文件、src/cli.rs 的单元测试。完整阅读 10,676 行；源文本 #[test] 共 181 个（包含 feature/platform 条件，静态数量不是本轮运行数量）。审查未改仓库、未跑 full tests/mutants、未提交。当前未提交 T38/T39 必须保留。

## 1. 已证实可直接删除：至少 2 个测试

| 删除候选 | 保留者 | 同层同入口同条件同 oracle 的证据 |
| --- | --- | --- |
| work.rs:174 work_start_default_name_is_flow_id | work.rs:11 work_start_creates_work_and_prints_next | 两者都 Env::new + add two-step + work start 默认 flow、topic=x、未给 name；wid.ends_with("-default") 完全相同。后者还验证 next outline/cancel 和状态卡。不涉及失败窗口。默认名称/Flow id 合同通过保留者覆盖。 |
| work.rs:36 work_start_missing_input_exits_1_with_input_missing | work.rs:305 start_deterministic_rejections_leave_home_unchanged_and_do_not_burn_seq 首分支 | 同已安装 two-step，start default 没有输入；exit1、INPUT_MISSING 完全重复。保留者增加 detail.missing=["topic"]、目录快照无变化和补输入后序号001。覆盖“确定性拒绝发生在分配序号前”更强。 |

两者相加可删 20 行函数正文（14+6）；连同 Task/attribute/各一个空行共26行（work.rs:34-50与:172-180）。不能把“未给 name 与显式 default intent 区分” replay.rs:248 当重复；它是 request fingerprint 反例。

## 2. 不能直接删除，但 union assertions 后可合并：至少 3 组、6 个函数

1. work.rs:53 work_start_accepts_at_file_input 与 replay.rs:68 start_request_replay_does_not_require_the_original_input_file。
   - 两者首段都真实 CLI start topic=@file；前者唯一 oracle 是冻结 start-inputs/topic 精确字节。后者增加原文件变化及删除后重放、同 work id/revision。
   - 保留 replay 测试，在首次响应后用返回 work_id 手写路径读取 start-inputs/topic，断言 "first observed value"；再保留 changed/deleted 两个重放。然后可删独立 at_file positive。
   - 不能只删除前者，因为后者现状不验证首次冻结内容；不能用生产读/摘要 helper 算 expected。

2. attempt.rs:96 attempt_submit_summary_from_at_file 与 replay.rs:144 submit_request_replay_does_not_reread_a_deleted_summary_file。
   - 初始都是 outline 产物 + --summary @file 提交；前者唯一 oracle 是 status.last_attempt.summary 精确内容；后者则删除文件后要求 replay、revision/outputs 不变。
   - 保留 replay，在首次成功提交后添加 env.status(work).data.last_attempt.summary == "recorded summary"，再删除源并重放；可删独立 positive。
   - 必须保留 fail reason 与 start input 的重放，分别触发 CLI parse_text 参数、runtime fail command 与 start freeze，不由 submit case 互代。

3. scenario_article_review.rs:102 downstream_binds_latest_succeeded_occurrence_output 与 :25 review_back_edge_creates_second_draft_occurrence。
   - 同 draft1->review1->draft2->review2->publish 链。前者多出的唯一 oracle 为 publish input article 路径来自 draft occurrence002。
   - 保留 :25 的真实 next 走法、draft/review/publication Attempt 与 occurrence 断言；在末尾 publish response 上搬入该 path oracle，可以删 :102。
   - 不可把 later_back_to_draft(:193) 同时删掉：它验证的是 draft3 回环输入 review occurrence002；source edge/back 与输入方向不同。

以上是安全合并机会，不是现状已经完全包含；实际净减行数需要最终 diff 后计数，未估算为成果。

另一个可合并候选：work.rs:533 named_but_missing_workbook_is_not_silently_replaced 与 :310 ghost workbook 分支；前者还独有 error.message 点名 ghost 与 work list为空，因此只可迁移两项oracle后删除，现状不列直接冗余下界。

## 3. Support 可精简的证实下界

### 3.1 复制目录：1 个完全重复函数体

common/mod.rs:136 copy_dir 和 :173 copy_example 内嵌 copy 的递归普通文件复制相同。copy_example 只需命名 target 后调用 copy_dir。skill_delivery.rs:19 copy_tree 同样普通复制，可让公共 support 服务它，但不应顺手使 symlink 语义变化。

release_governance.rs:17 copy_tree 带 specs evidence 非Markdown过滤，不能替换成无条件 copy；crash.rs:31 make_writable_tree 用 metadata，workbook.rs:9 用 symlink_metadata，不能只按函数名相似统一成会跟随外部目标的递归 chmod。

### 3.2 子进程同步：至少 3 处可重用同一 RAII support

保留/抽出 reliability_crash.rs:23 Process（spawn 清环境、reached 精确内容、finish deadline、Drop release/kill/wait）：
- work.rs:612 stats_and_next_keep_one_snapshot... 的 PausedReader 自建 Drop 与 reached loop。
- implementation_repairs.rs:16 killed_first_store_initializer... 的 child/spawn/deadline/kill/wait。
- tmp_cleanup.rs:208 replaced_expired_directory... 的 child/spawn/deadline/release/wait。

这些测试都不能删：stats_after_load 的 reader/writer 同版本快照、write_session_after_store_create 的首次完整schema建库中断、delete_before_root_unlink(tmp-cleanup) 的删前身份换绑，是 3 个不同产品窗口。共用 mechanics 后保留每条 reached name/id、Exit70 vs SIGKILL、old/new inode/bytes 和成功响应不变 oracle。Process spawn 目前不支持 current_dir；relative_input_resolution...(:1572) 需要自建builder或最小构造接口，不能添加庞大test harness。

### 3.3 SQLite 全表快照：至少 2 处实现可共用，oracle语义不能统一丢失

strict_state.rs:23 persisted SQL rows 与 reliability_crash.rs:1218 store_facts 都 SELECT * 五表、按稳定键排序、读全部列。可统一一个 typed SQL rows snapshot，供两种 caller 使用，减少1个重复SQL捕获。
- strict_state 文件快照记录目录项为 None、文件精确bytes，覆盖 works/workbooks/pending，捕捉增删目录。
- reliability tree(:155) 只文件bytes，same_files(:175)只核 expected subset，store_facts本身不看目录。
- work.rs:276 snapshot_tree 只有path、跳wal/shm，没有bytes；只用于start预检目录零变化。
不能把所有不同snapshot换成same_files，或用store.db字节替代 logical rows（SQLite正常control文件行为不同）。

### 3.4 spec-dev fixture：至少 5 处 T01 写入/提交片段可共享

scenario_spec_dev.rs:603、:756、:1282、:1437 与 common/spec_dev_replan.rs:385 都实现相同 T01 write export.py + unskip test_export + gate + commit + change元数据。可提取“真实write/gate/commit，返回base/candidate”的小 helper，至少去掉4份复制。各caller自己的审批来源、已验证前缀、report inheritance及负例必须留在caller。

scenario_spec_dev.rs:935 own_task_placeholder... 与 :991 unmarked_placeholder... 可用小fixture helper参数化，仅保留不同是否Task tag和expected lists；:839 future placeholder positive不要削弱为helper测试。至少2个negative body可以减少1份setup；三个场景仍是三个行为cases。

## 4. 高相似但必须保留/不能直接删除

### 4.1 JSON vs text

workbook add文本(:23)与JSON(:37)、self install/update JSON纯度(self_cmd:90/:105)与schema/rollback文本(:137/:153)、work status text(:79)与JSON(:114)互不替代。JSON from_slice 验 stdout没有前后缀；文本断言验提示与契约字段，处于不同输出分支。

workbook.rs:109 verify_exits_1_after_tamper（Verify None）与scenario_workbook_lifecycle.rs:56 verify_detects_the_edit（Verify Some id@version）可共用造tamper，但需要保留all/targeted两个CLI命令、exit与results[0].status两个oracle。当前不可直接删。

### 4.2 opaque request 重放/历史绑定

src/cli.rs:218 input_file_arguments_are_lexical... unit验证parse阶段不探测不存在文件；replay.rs start/submit/fail真实链验证request lookup先于新observe。这是不同调用边界，不能用unit替代端到端。

replay.rs:100 历史unique prefix->later ambiguous 与 work.rs:161 new ambiguous prefix tests 不重复；同 selector重放必须绑定request.work_id，new status则列候选。
replay.rs:209 invalid changed name->REQUEST_CONFLICT 与 :248 omitted/explicit default distinct intent 不重复；一个验证fingerprint优先于规范化错误，一个验证相同最终name也不等于相同用户意图。
work.rs:564 current status after historical replay，reliability_crash.rs:378 cross cancel after committed begin/submit 与T39 strict_state历史payload controls互不替代；历史next不代表当前状态。

### 4.3 Crash 旧测试与新矩阵

crash.rs:46 before_commit begin（原state last_attempt None，runtime svc.begin同id成功）没有被 reliability begin/submit矩阵(:378)覆盖；新begin矩阵只after_commit/firsthistory，不测before_commit。保留。
crash.rs:83 after_commit begin 是同请求runtime service重启、brief初始不存在再重建；reliability:378 是另一个CLI cancel先恢复，核registered history bytes、current cancelled、历史original。不能直接删old。
crash.rs:124/:233 与 reliability:448 删除中断窗口有重叠，但old验证typed EffectPending cause STORE_CORRUPT、original内容/marker不存在，new验证2 termination modes、CLI caller/blocked新请求/残余bytes不变。若合并必须把old所有oracle迁入对应case并证明typedruntime边界由别处覆盖；现状不列下界。
crash.rs:592 update_between_renames 与 reliability:547 installed prev rollback同窗口；旧直接runtime rollback API，新从prev executable真实CLI rollback并保全store bytes，caller层不同。可以迁移oracle减少旧fixture，但直接删除须确认runtime direct rollback consumer已有覆盖。低信心，未列删除计数。
delete root替换、different final/pending tree、删除marker未知、部分删除digest不符不能互代（生命周期/handle身份/完成证明三个不同约束）。
Exit70 与实际SIGKILL不能选一种：工程与T31要求不同进程终止方式；published-before-cleanup、rename-before-parent-sync也不能合并成泛before/after。

### 4.4 T39 四边界与 Flow/tmp新回归

strict_state.rs:104（WorkState顶层、/attempts/0/id）、:135（每个WorkStatus变体）、:199（Reply.attempt与NextOp submit/fail attempt）、:242（audit Command submit/fail attempt）都必留。
从state读取 -> load/status/list/write，PersistedResponse ->历史Reply+NextOp的完整解码，audit.command_json -> Command解码，分别进入不同serde载荷；同AttemptId newtype不能证明嵌套派生入口始终严格。control包含历史current已cancelled仍能合法重放，corrupt oracle必须不暴露original/pending_original、不改全部持久行和文件。WorkStatus active/blocked/succeeded/cancelled由enum实现必须覆盖所有variant。

flow_identity.rs:34 distinctids CLI add/show/start positive、:62 duplicatedids BEFORE COMMIT拒绝后无业务/request/audit/seq行且same-id修正后可重试、:121 direct load_dir不触Store、:145 committed corrupt snapshot不迁移并阻断另一写，四者boundary不同。不因触发同duplicate id删direct加载或historicalsnapshot。

tmp_cleanup.rs:50 成功businesswrite接入、:84 readonly/failed不维护、:105 replay维护失败仍返回same success、:133 self write另一路接入、:143叶/嵌套symlink仅删自身外部sentinel mode不变、:174特殊FIFO保留、:208删前替换目录保留并告警互不重复。runtime age cutoff测试可证明恰好24h；CLI wallclock old=86410只是接线，不能替代精确24h测试。

### 4.5 spec-dev worker/Git evidence

common/spec_dev_replan.rs不是生产第二状态机：cold_replan/cold_lineage是按Workbook说明书独立实现的fixture worker oracle，输入仅任务书绑定文件，不接收原始基线/已完成列表。core/runtime不读自然语言下结论（INV-1/2），因此不能下沉到production helper，也不能仅单测这些oracle取代真实CLI+boundfiles+isolatedGit。
T12简单G5(:1427)与T30cold(:530)都涉及原始基线；T12还手写 resetbaseline反例range、plan#2/im#3定位，T30检查无会话冷恢复、证据原始stdout/stderr+sha/Git ancestry+Task trailers/白名单/lineage前缀。未逐条迁入前不能直接删T12。
deep droppedrows/failedreports/deniedapproval/cycles(:1155)、explicit human correction(:1175)、missing currentchange(:1215)不能按“都坏继承链”删一个，它们是不同拒绝条件。
所有这些是fixture worker可行性，不代表真实Host/模型完成T16/T17。

### 4.6 发布与skill治理

remote_update stderr_exact 默认latest(:128)与explicit pinned(:189)触发不同发现过程；stream stdout/stderr limits与asset bytes limits分别transport/read limits/发布资产，不互代。可以抽取home/bin/store capture+samebytes断言，仍保留每个case及url log顺序、lockfd不继承、tmp零泄漏。
release_governance Version/RC/wrong target/noChangelog/fullhistory/shallow/noTag七分支互不冗余；可以参数化makefixture之后的小run/assert，不删除case。
skill.rs:10 source SKILL命令存在 与 skill_delivery.rs:306/:345 packed/install/tar的 assert_delivery_resolves检命令相似，但pack改写SKILL本地链接；现状没有source/delivered command sequence equality证明，不能直接删source test。可以新增“产物命令sequence与源码相等”的独立oracle后合并，未列计数。
release_governance.rs:374/:411 同一release quality MSRV assertion重复，:394与:374同positive announce predicate重复。可从:411只保留build fetchdepth/MSRV与RELEASE_COMMIT，将announce positive只留:394，:374只quality SHA/history/MSRV；属于断言重复，不能删除任何整个test（各有不同workflow条件）。

## 5. 结论与落地约束

弱断言：scenario_artifacts.rs:104 submit_with_symlink_output_is_rejected 只检查exit1与ok!=true，未固定准确错误、request/audit零新增、outside bytes/mode不变。本scope没有同一触发（提交前输出叶symlink）的更强CLI case能够直接替代它；reliability_crash.rs:960检历史brief/Attempt目录且是已提交begin重放，不能互代。可增强或把完整oracle并入同触发矩阵，现状不宜以“弱”作为删除理由。直接冗余的missinginput test则确实已被同入口、更强detail+无副作用+序号断言替代。

静态已证实下界：2个whole test直接冗余；至少3组需要迁移独有oracle后可少3个函数但保留3项产品cases；4组support可重用（复制1body、3处child sync、2处SQL实现、5处T01write片段）。不把下界包装成全部可减规模。
后续如获授权实施：先提交test coverage映射（产品能力->入口->失败条件->oracle->保留case），仅移support/unionassertions/删strictsubsets，保留JSONshape、snapshots、正反与限额两端、真实caller/窗口；跑候选确切features下受影响testbins，再按任务plan最终gates。此次没有运行，因此不承诺mutation equivalence或全覆盖PASS。
