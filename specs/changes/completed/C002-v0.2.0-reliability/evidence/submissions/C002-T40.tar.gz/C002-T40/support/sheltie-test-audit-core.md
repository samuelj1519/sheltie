# sheltie-core 测试精简只读审查

范围：当前工作区 `HEAD = 4b86279a863f941cc282fa6cb772f7359fda585a`，含未提交 T38/T39。完整阅读 core 的 12 个 `cfg(test)` 模块、3 个 integration 文件、testkit 与相关生产调用链；读取 CONTEXT、specs 入口、engineering、C002 plan、核心合同。未改仓库、未运行 Cargo/Nextest/mutation。以下是静态覆盖分析，不是改后测试 PASS。

## 统计口径

| 项 | 文件/区域 | 用例 | LOC |
| --- | ---: | ---: | ---: |
| 内联 core 单元模块 | 12 | 191 个 `#[test]`，其中 1 个 proptest | 3238 |
| core integration | 3 | 26 个 `#[test]` | 897 |
| 状态卡/任务书/统计快照 | 7 | 被上面用例使用，不额外算测试 | 173 |
| testkit | 1 | 0 个测试入口 | 612 |
| compile_fail doctest | 2 个生产文件中的 5 块 | 5 | 已混在生产文档里，不另算 LOC |

LOC 包括模块 wrapper/import/helper/comment/空行，来自当前文件 `splitlines()`；不是可删行数。测试与支持区域合计 4920 LOC，217 个普通/属性测试入口及 5 个 compile_fail。Core `src`+`tests` 的 Rust 文件总物理行数为 `wc -l` 9428（包括生产代码和 testkit，未包括快照）。

testkit 由 `src/lib.rs:24` 的 `#[cfg(feature = "testkit")]` 显式控制，是测试支持，不属于默认生产路径；在 `--all-features` 编译中作为公开 feature 模块存在。Core 的 dev-dependency 自依赖开启它，runtime/cli 在 dev-dependencies 中开启它。不能把其 612 行全部算成引擎生产复杂度，或把 Fixture 同名动作当作第二套状态机：`testkit.rs:445` 直接调用真实 `decide`。

单元分布：digest 7/131 LOC，compile 29/454，parse 19/285，ids 20/228，path 3/38，text 2/29，decide 49/817，layout 5/113，render 27/604，start 4/99，state 6/161，manifest 20/279。

## 最确定可删除项

### CORE-01：纯编译 smoke 被同文件更强用例完全包含（高）

- 删除候选：`crates/sheltie-core/tests/examples.rs:32`，`all_examples_compile`，函数本体 5 LOC。
- 保留：同文件 `:95 no_example_declares_requires`。两者都按同一 `["two-step", "article-review", "gated-release", "spec-dev"]` 顺序调用完全相同 `compile_example(name)`；后者额外验证各节点 requires 为空。四个样例还分别被 `:40/:49/:88/:104` 的结构断言用例编译。
- 产品覆盖：GF-01 三类 Flow 与 spec-dev 装入可编译；Workbook 解析/编译规则全部仍执行。原 smoke 无独立输出 oracle、拒绝例或入口差异。
- 停止条件：`no_example_declares_requires` 必须仍包含全部四个名字，不能同时合并掉这些编译入口。
- 治理依赖：此名字被 MVP archive plan `specs/releases/v0.1.0/plan.md:278` 点名，删除会触发 `scripts/check-tests.sh:44-55`。实施时按已采用 C002-T03/T12 的前例，在原任务卡保留原名字与历史缘由，以 Replacement 注记说明当前保留用例并链接 active package 验证；不需要新增 retirement registry 或修改 checker。不能无注记改写旧历史或跳过 gate。

### CORE-02：公开日期前缀测试与单元断言逐字相同（高）

- 删除候选：`crates/sheltie-core/tests/api_surface.rs:66 timestamp_day_is_date_prefix`，函数本体 6 LOC。
- 保留：`crates/sheltie-core/src/work/state.rs:512 timestamp_parse_accepts_utc_second_precision`，其 `:524-528` 使用同一个 `2026-09-24T03:00:00Z` 调 `Timestamp::parse(...).day()` 并断言 `2026-09-24`。
- 产品覆盖：WorkId 日期和 Timestamp 日期前缀。两者没有入口/输入差异；day 的外部可访问性还被 runtime caller 和 persisted_contracts 公共 API 调用覆盖。
- 该名字未见 legacy/active plan 测试名单引用。

### CORE-03：没有调用方的测试支持函数（高；范围仅本仓库）

- 删除候选：`crates/sheltie-core/src/testkit.rs:604 pub fn require`，函数本体 9 LOC，并清理只由它使用的 `HostRequire/RequireKind` import。
- 全仓 `.rs` 搜索 `testkit::require`、通配导入、`require(` 只找到定义，没有调用。
- 不删除任何测试或产品 oracle。它只是组装 HostRequire 的旧辅助函数。
- 注意：这是公开 `testkit` feature API 删除，静态证明只覆盖本仓库，不能宣称已经证明任意外部 feature consumer 没有依赖。默认生产 API/产品行为不受影响。

## 适合合并断言或参数化；不可直接丢 oracle

### CORE-04：两条 engine.stats begin 测试完全重复准备与查找（高）

- `work/decide.rs:1047 begin_binds_engine_stats_and_emits_write_file` 与 `:1073 begin_engine_stats_counts_current_attempt`。
- 同一个 `Fixture::with_engine_stats_input`、同一次 `begin("only")`、同一输入引用、同一 WriteFile 查找。
- 合并到第一条，原样保留手写 `attempts = 1`（D-29 当前 Attempt 已计入）、精确路径、digest/bytes 与 WriteFile 字节一致、nodes 内容存在的断言。第二条函数本体 16 LOC，没有拒绝边界。
- 不删除 `:1094 begin_with_two_engine_stats_inputs_writes_one_stats_json`（两输入只写一次是独立条件），不删除 `:1463 retry_binds_engine_stats_under_retry_dir`（retry=1 目录是独立条件）。
- 原测试名是否进入 task 手册需由父审查统一核对；第一条在 MVP plan 的 T07 列表内。

### CORE-05：受阻计数 0/1 用例准备重复（高；合并后）

- `work/render.rs:1056 stats_blocked_count_by_reason` 与 `:1129 blocked_count_accumulates_across_kinds_and_keeps_after_approve`。
- 后者各自新建 exhausted/gate/retry 三份 Fixture，只断言 1/1/0；没有一个 Work 跨多个 kind 累计到 2。前者走了相同 transitions，并包含普通 submit、NoLegalEdge 和批准前后 renderer count 断言。
- 将后者的直接 `state.blocked_count` 断言加到前者各控制点后删除后者；保留原 `render_stats_json(...).blocked_count` oracle，不能仅依靠生产中 `render.rs:645 blocked_count: state.blocked_count` 推定测试等价。
- 后者函数本体 17 LOC。不是“统计经常测所以冗余”，而是同模块、同状态生产者、相同生命周期和数值。
- 必须保留 `:1117 blocked_count_survives_cancel_after_no_legal_edge`，真实 Gate→NoLegalEdge 的 1→2 caller oracle，以及 `tests/persisted_contracts.rs:377 each_blocking_command_rejects_counter_overflow_without_mutating_its_input` 的 MAX 溢出与原输入不变边界。

### CORE-06：同样例终点与非终点断言可共用一次编译（高）

- `flow/compile.rs:354 compiles_article_review_example` 与 `:710 node_with_out_edges_is_not_terminal`。
- 两者都调用 `compile_text(base())`；第一条断言 3 nodes/3 edges/publish terminal，第二条断言 draft/review nonterminal。
- 可将两个非终点断言加到第一条，再删除第二条入口。独立正/反终点判据保留，不能只留 terminal 的正例。
- 不使用 CLI 场景代替这些 `Graph::is_terminal` 独立静态判断。

### CORE-07：任务书来源的 main 半段被固定快照覆盖（高；只删重复半段）

- `work/render.rs:875 brief_shows_entered_from_line_or_entry` 的 review 半段 `:886-894` 重新走 draft submit→review begin，只断言 `来自: draft#1（main 边）`。
- `:700 brief_for_review_node` 的固定快照 `work/snapshots/...brief_for_review_node.snap:10` 已精确包含同一行，且相同状态构造。
- 可以保留该用例的 entry 半段（`来自: 入口`），删重复 review setup/render/assert；不要删除整个用例。若改名，先核 task 名字 gate。
- 保留完整 review/human/requires 快照：它们锁格式、路径、模型档位、输出限制、宿主资源提示等，不是仅存在一个来源子串的测试。

### CORE-08：大小正/反边界可以成对表达（高；表达精简）

- `workbook/manifest.rs:466 rejects_description_over_2kib` + `:563 description_accepts_exactly_2048_bytes`。
- `work/decide.rs:1204 submit_rejects_summary_over_4096_bytes` + `:1486 submit_accepts_summary_of_exactly_4096_bytes`。
- `work/decide.rs:1245 submit_rejects_output_over_max_bytes` + `:1498 submit_accepts_output_of_exactly_max_bytes`。
- 每对是同字段、同生产路径、相同 fixture 的 exact/+1 两侧。可在一个行为用例里保留两侧并减少重复 setup/import/task wrapper；拒绝仍核错误变体/字段/实际限额，合法仍核记录的字节数/摘要长度。
- 不是删除一侧，更不能用普通短字符串成功替换 exact 成功。max_visits/retries、node/edge counts、instruction/resource limits、UTF-8 字节语义也必须保留各自精确正反例。
- 改名或删除 legacy 点名测试入口需按现有 Replacement 注记前例同步任务卡。减少用例数本身不是覆盖或性能收益证据。

### CORE-09：HostRequire JSON 的 version/source 超限重复（中高；局部参数收敛）

- `workbook/manifest.rs:378 host_require_snapshot_decode_rejects_one_invalid_field` 的 version=33/source=513 反例，与 `tests/persisted_contracts.rs:63 host_requirement_snapshots_accept_exact_byte_limits_and_reject_one_extra_byte` 相同 Deserialize 路径与限额。
- 可保留 public integration exact/+1 两侧及所有字段往返期望，内部 invalid table 只保留 name/digest 特有反例。name/digest 不能丢；合法 some digest baseline 也不能因为 integration digest=null 而直接删除。
- `:363 host_require_snapshot_decode_accepts_valid_fields` 与紧邻 invalid 测试的合法 baseline JSON 文本相同，适合共享一个明确 const/fixture，而不是新的 generic case 框架。
- 不能拿 TOML `require_version_limit_is_32_bytes`、`require_source_limit_is_512_bytes` 代替 JSON 载荷测试：DTO convert 和 HostRequire Deserialize 是两个真实入口。

## 次优候选：需要父审查交叉确认

### CORE-10：core 手工向量只测 SHA wrapper，没有测试产品帧实现（中高）

- `digest.rs:170 digest_v2_framing_known_vectors_match_independent_hashes`，函数本体 49 LOC。
- 它自己手工拼 prefix/BE64/frame，完全不调用生产 `WORKBOOK_DIGEST_V2_PREFIX`、`be64`、`digest_v2_file_frame`，只调用 `Sha256Hex::of_bytes`。改变生产 frame 不会让本测试失败。
- 五个 expected 常量全部被 `runtime/tests/workbook_digest.rs:42 digest_matches_independent_vectors_on_disk` 和 `:66 framing_collision_pair_now_yields_two_different_digests` 对真实 `digest_dir_v2` 使用；后者经过受限树枚举、真实 framing、单次 hash，具备完整产品路径 oracle。
- 可以退休 core 的手工复演，保留 `digest.rs:105 of_bytes_matches_known_vector`、`:127 prefix literal`、`:139 BE64 手写数组`、`:151 frame 手写字节`，并保留 runtime 五向量和碰撞不等断言。不是机械删除跨层测试：这里用调用证据证明旧 core 测试没有覆盖帧实现，而完整独立向量已在真实 consumer。
- 若用于“core-only 运行也验证规范向量”的显式当前门禁，须先调整那个门禁承诺，而不是悄悄声称仍完整验证了目录摘要。

### CORE-11：样例的可选输入断言仅复述 compile 不变式（中高）

- `tests/examples.rs:186 spec_dev_optional_inputs_all_point_to_reachable_upstream`，函数本体 16 LOC。
- 当前唯一检查：所有 `!required` input 都是 `InputSource::Node`。`compile` rule5（`flow/compile.rs:185-207`）对 Start/Resource/EngineStats 的 required=false 无条件拒绝，同样例还在多条 spec-dev 结构回归中调用 compile。测试没有独立 reachability 计算、具体 input/source/product expectation。
- 可退休并让 rule5 的独立拒绝例守 generic invariant，具体 replan/history/binding 用例守样例业务声明。
- 现有 `rejects_optional_input_on_start_or_resource_source` 名字虽然含 resource，但实际只有 Start mutation；不要将这条样例断言误认为补齐了 resource 拒绝覆盖。精简时仍保留/核对全部三类来源的单条件拒绝义务。
- 被 MVP plan:278 点名，治理依赖同 CORE-01。

### CORE-12：两份 Manifest unknown-field 回归（中）

- `tests/examples.rs:235 mutated_two_step_manifest_with_extra_field_is_rejected` 与 `workbook/manifest.rs:432 rejects_unknown_field` 都对合法 manifest 顶层追加 `author = "x"` 后走 `parse_manifest`；内层断言还核 WorkbookInvalid。
- baseline 一个是真实样例、一个手写 minimal，因此建议优先收敛为一条更强测试（用实际 TWO_STEP_MANIFEST 并保留精确 ErrorCode/field），而非未经核对直接删除样例测试。
- 不删除 T39 AttemptId/WorkStatus 未知字段回归：不同嵌套类型和字段位置并非同一入口义务。
- 同样被 archive 点名，按现有 Replacement 注记前例同步任务卡。

## 测试支持重复与边界

1. `work/render.rs:738` 与 `:794` 两条 requires-render 回归，绝大部分 import、manifest/flow parse、Graph、WorkId/name/workbook/ref/start/Begin Command 构造重复。适合一个局部 `started_node_with_requires(manifest, flow)` helper 或一个测试内 table，参数仅是明确 manifest/flow 字节，返回真实 decide 的 Graph/Decision；expected 提示行/版本字面值仍留在各用例内。两种 oracle 必须保留：带版本/无版本写 `-`，以及同名不同 kind 不串。不要把 render 和 decide 的 crossed-kind 测试相互删除：Reply 与 brief 是不同 consumer。
2. `work/decide.rs:720 start_texts` 与 `render.rs` 上述手写 start，以及 `tests/persisted_contracts.rs:93 gated_fixture` 的换 graph/manifest workaround 有共同输入构造。现有 `testkit::Fixture::from_texts` 已有真正构造过程但私有。若实际开始精简，可决定仅让这些真实测试 caller 共享最小 constructor；不要先造动态 graph DSL、统一断言 trait、fake 成功状态或另一套状态迁移引擎。
3. `tests/examples.rs:9 compile_example` 用 `example_files` 建列表，再调用 `resources_of(name)` 再建一次同列表；可以在这一个 helper 内从已读 files 构 ResourceIndex，或共享现有 testkit example constructor。只是支持代码重复，不能据此声称样例测试 oracle 都重复。
4. testkit 的 include_str 文件清单是让 core 无 I/O，同时保证实际样例字节参与编译的必要支持；不能用运行时扫描替代并把 fs 依赖塞到 core。

## 必须保留、不能被 CLI 场景替换的 core 测试

- `tests/persisted_contracts.rs:168`：7 种真实合法 lifecycle、28 次标签清楚的单字段矛盾拒绝、当前 gate/跨 node/前一 occurrence 的批准身份。这些组合是装入不变式，CLI 通常生成不了非法结构；需要纯 WorkState 验证与 Store/CLI 拒绝接线各自保留。
- `:377`：3 种 blocking Command 的 MAX overflow、1/2 非默认 counter、decide 不改原输入。有效 state 边界不能靠普通 CLI happy path覆盖。
- `examples.rs:331 public_legal_next_does_not_offer_retry_at_the_node_retry_limit`：它将 retry 已达上限的持久合法 state 的 status 改为 Active，直接验证 public legal_next 的防线；普通 fail_at_max_retries 生成 Blocked 状态，走不同 branch，不能代替。
- `flow/compile.rs:592 proptest_compile_never_panics`：任意小图/非法边混合的 panic-free 属性，固定三场景不等价。
- 5 个 compile_fail：Manifest/FlowDef 不可外部改字段、不能未经 parse serde Deserialize，以及 NodeDef gate 不可外部改。Nextest 不运行 doctest；不能以其217个条目全绿替代这5个编译期边界。
- 7 snapshots：任务书与状态卡/统计表整体格式、路径和固定公开文案；逐字段 JSON 和快照测不同 contract。可移除重复子串断言，不能凭“JSON已测”整体删快照。
- Timestamp parse 与 serde、from_unix_secs 与 unix_secs、render::secs_between 三者分别覆盖输入规范/双向日历算法/负差饱和与耗时语义；世纪修正、9999 saturation、1970 前负值、running 不计 avg、retry不重复 entered_via 不可因日期相同删除。
- core Missing/Modified/Optional binding 与真实 CLI frozen目录/读取/停止是规则与 I/O 分工，不能机械选CLI然后删core拒绝边界。

## 运行调度不等于用例冗余

Core 没有额外 nextest serial override；`.config/nextest.toml` 只对 runtime crash binary 限流。`scripts/task.sh` 按全仓唯一测试名过滤，`check-tests.sh` 核名字/Task/卡点名；同一测试在局部、全仓、MSRV、变异阶段重复运行是不同验证目的。是否可复用要核完整输入闭包和 run identity，不能从重名/重复 argv 推断可以省。父审查需统一对 CI/release/precommit 和 mutation 的运行调度给结论。

## 后续实施与证据建议

直接可删的 high 测试入口只有 CORE-01/CORE-02，共 2 条，mapping 见下表；CORE-03 是没有调用的 support helper，不计测试删减数。CORE-04/05/06 等是需要搬移断言后才能删入口的合并候选，CORE-10/11/12 不计确定可删数。实施时每条登记旧测试→保留 oracle；再考虑较低信心项。

| High 删除用例 | 保留用例 | 保留能力/独立 oracle |
| --- | --- | --- |
| `tests/examples.rs:32 all_examples_compile` | `tests/examples.rs:95 no_example_declares_requires` | 同一四个样例、同一 compile_example、同一失败 unwind；后者再核 requires 为空 |
| `tests/api_surface.rs:66 timestamp_day_is_date_prefix` | `src/work/state.rs:512 timestamp_parse_accepts_utc_second_precision` | 同一 RFC3339 字节，day() 恰为手写日期 2026-09-24 |不要为了“减少测试数”把28个状态矛盾塞进不透明 dispatcher或删除 exact/+1。修改后原217个测试数量可下降，不能拿数量差直接当覆盖损失/收益。

用受影响core测试、core doctests、对应runtime consumer及治理 gate 做验证；最终按新C002任务要求执行普通工程门禁。此审查不重跑已记录 717 测试，也不改变M1例外/215项缺失变异/Linux/T16/T17。

记忆快速核对使用了 MEMORY.md:85 当前进度入口提示；所有当前状态以本次读取 plan 为准，未将旧M1状态沿用。
