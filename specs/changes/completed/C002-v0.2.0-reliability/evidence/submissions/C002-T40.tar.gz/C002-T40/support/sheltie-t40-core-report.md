# C002-T40 Core 测试精简

相对 T40 开工输入，修改 9 个文件，测试与测试支持净减少 292 行，217 个测试入口收敛为 205 个。12 条入口的删除或合并映射及保留边界逐项见 `sheltie-t40-core-dispositions.json`。

已迁移 engine.stats 当前 Attempt、blocked_count 直接状态、terminal 正反判断；description/summary/output 的 exact/+1 均保留。HostRequire JSON 的重复 version/source 拒绝由 public integration 的 exact/+1 统一守护，name/digest 反例与 Some digest 完整 roundtrip 留在单元测试。真实 two-step manifest 的 unknown-field 反例收敛为精确错误检查。

退休不调用产品 framing 的 SHA 手工复演；真实 runtime digest_dir_v2 的全部五个独立向量和碰撞对仍在。退休只复述 compile 不变式的 optional 样例断言，补上原 Start/Resource 用例遗漏的真实 resource 单字段拒绝。共享既有 Fixture 构造器消除 requires-render、手写 Start、gated_fixture 与样例 setup；expected 仍留在测试侧。无调用者 require helper 删除。

局部 `cargo test -p sheltie-core --all-features --locked`：205/205 通过，零忽略；5/5 compile_fail 通过。7 份快照字节与默认生产代码前缀同开工输入逐字节相等。日志、增量 patch 和 LOC 口径见同目录的 core-test.log、core-increment.patch、core-metrics.json。

新增 oracle 的 5 个现存函数归 C002-T40，名称与原任务的 Replacement 工作交父 agent。未改 specs、legacy、依赖或 T38/T39 改动；未运行全仓门禁、runtime caller 或完整变异，未提交。
