from pathlib import Path
import json,subprocess,re
root=Path.cwd();out=Path('/private/tmp/sheltie-t40-evidence')
owners={line.split()[1]:line.split()[0] for line in subprocess.check_output(['scripts/test-owners.sh'],text=True).splitlines()}
replacements={}
core=json.loads(Path('/tmp/sheltie-t40-core-dispositions.json').read_text())
for row in core['dispositions']:
 if row.get('old') and '::' in row['old'] and row.get('replacement'):
  old=row['old'].split('::')[-1]
  if old in owners:continue
  replacements[old]=[p.split('::')[-1].split(' [')[0] for p in row['replacement']]
cli=json.loads(Path('/tmp/sheltie-t40-cli-dispositions.json').read_text())
for row in cli['retirements']:
 replacements[row['old_function'].split('::')[-1]]=[row['retained_function'].split('::')[-1]]
runtime=json.loads(Path('/tmp/sheltie-t40-runtime-dispositions.json').read_text())
for row in runtime['entries']:
 if row['old_fn']!=row['retained_fn'] or row['old_fn'] not in owners:
  replacements[row['old_fn']]=[row['retained_fn']] if row['retained_fn'] else []
path=Path('specs/releases/v0.1.0/plan.md');original=path.read_text();task=None;changes=[];result=[]
for line in original.splitlines(keepends=True):
 match=re.match(r'^### (T\d\d)',line)
 if match:task=match.group(1)
 if task and line.startswith('**测试。**'):
  def rewrite(m):
   name=m.group(1)
   if name in owners and owners[name]==task:return m.group(0)
   if name not in replacements and name not in owners:raise ValueError('Missing disposition '+name)
   retained=[name] if name in owners else [p for p in replacements[name] if p in owners]
   targets='、'.join('`'+p+'`' for p in retained)
   why='加强并迁移归属' if name in owners else '退休或合并'
   detail='；当前保留 '+targets if targets else '；旧布局义务取消，当前能力见T40记录'
   changes.append({'task':task,'old':name,'retained':retained,'reason':why})
   return '（原列 '+name+'：C002-T40 '+why+detail+'；见 [T40验证](../../changes/active/C002-v0.2.0-reliability/validation.md#c002-t40-测试精简验证)）'
  # Existing full-width historical notes are opaque to check-tests; preserve them verbatim.
  parts=re.split(r'(（[^）]*）)',line)
  line=''.join(part if part.startswith('（') else re.sub(r'`([a-z][a-z0-9_]*)`',rewrite,part) for part in parts)
 result.append(line)
path.write_text(''.join(result));(out/'legacy-replacements.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
print('Historical test references annotated:',len(changes))
