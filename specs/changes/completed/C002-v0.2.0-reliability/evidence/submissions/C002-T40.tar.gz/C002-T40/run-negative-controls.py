from pathlib import Path
import hashlib,json,os,subprocess,time
out=Path('/private/tmp/sheltie-t40-evidence');tree=out/'negative-control-tree';env=os.environ.copy()
env.update(RUSTC_WRAPPER='',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR='/private/tmp/sheltie-t40-controls-target')
records=[]
def run(name,argv,expected):
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log:result=subprocess.run(argv,cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'argv':argv,'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3),'raw':str(out/(name+'.log')),'sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()}
 records.append(row);(out/'negative-controls.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,result.returncode,flush=True)
 text=(out/(name+'.log')).read_text()
 if expected=='pass':assert result.returncode==0 and '1 passed' in text,text[-3000:]
 else:assert result.returncode==101 and 'FAILED' in text and 'could not compile' not in text,text[-3000:]
base=['cargo','test','-p','sheltie-runtime','--all-features']
run('observation-control',base+['--test','fs_boundary','observation_rejection_before_commit_leaves_store_unchanged','--','--test-threads=1'],'pass')
p=tree/'crates/sheltie-runtime/src/store/mod.rs';original=p.read_text()
needle='if schema::normalize_sql(&got) != schema::normalize_sql(sql) {'
assert original.count(needle)==1
changed=original.replace(needle,'if false {')
p.write_text(changed);(out/'schema-negative.diff').write_text(subprocess.run(['git','diff','--no-index','--','/dev/null',str(p)],capture_output=True,text=True).stdout)
try:run('schema-negative',base+['--lib','open_rejects_same_','--','--test-threads=1'],'fail')
finally:p.write_text(original)
p=tree/'crates/sheltie-runtime/src/service.rs';original=p.read_text();start=original.index('    pub fn submit(');position=original.index('        let request_id = ',start)
changed=original[:position]+'''        let invalid_write = rusqlite::Connection::open(self.home.store_path().as_str())?;
        invalid_write.execute("UPDATE works SET revision = revision + 1 WHERE work_id = ?1", [work.as_str()])?;
        drop(invalid_write);
'''+original[position:]
p.write_text(changed)
(out/'observation-negative-injection.txt').write_text('submit() before observation: UPDATE works SET revision=revision+1; status/state unchanged\n')
try:run('observation-negative',base+['--test','fs_boundary','observation_rejection_before_commit_leaves_store_unchanged','--','--test-threads=1'],'fail')
finally:p.write_text(original)
