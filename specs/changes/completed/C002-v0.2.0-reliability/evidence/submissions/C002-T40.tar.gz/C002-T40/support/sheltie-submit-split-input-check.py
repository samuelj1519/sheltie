import argparse
import hashlib
import json
import pathlib
import posixpath
import subprocess

ROOT = pathlib.Path('/Users/shushu/orca/workspaces/sheltie/codex')
MANIFESTS = {
    'T38': pathlib.Path('/private/tmp/sheltie-t38-gates/input-files.json'),
    'T39': pathlib.Path('/private/tmp/sheltie-t39-evidence/gates/input-files.json'),
    'T40': pathlib.Path('/private/tmp/sheltie-t40-evidence/gates/input-files.json'),
}
SCOPE = ('crates', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'deny.toml', '.config', 'examples', 'workbooks', 'skills', 'scripts', '.github')
parser = argparse.ArgumentParser()
parser.add_argument('phase', choices=MANIFESTS)
parser.add_argument('--revision', default=':')
args = parser.parse_args()
manifest = json.loads(MANIFESTS[args.phase].read_text())
if args.revision == ':':
    listing = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT).decode().split('\0')
    files = {}
    for line in listing:
        if not line:
            continue
        header, path = line.split('\t', 1)
        mode, oid, stage = header.split()
        if stage != '0':
            raise SystemExit('Unmerged stage: ' + path)
        files[path] = (mode, oid)
else:
    listing = subprocess.check_output(['git', 'ls-tree', '-r', '-z', args.revision], cwd=ROOT).decode().split('\0')
    files = {line.split('\t', 1)[1]: (line.split('\t', 1)[0].split()[0], line.split('\t', 1)[0].split()[2]) for line in listing if line}

def content(path, seen=()):
    if path in seen:
        raise ValueError('Symlink cycle: ' + path)
    mode, oid = files[path]
    value = subprocess.check_output(['git', 'cat-file', 'blob', oid], cwd=ROOT)
    if mode == '120000':
        target = posixpath.normpath(posixpath.join(posixpath.dirname(path), value.decode()))
        return content(target, seen + (path,))
    return value

selected = {path for path in files if any(path == base or path.startswith(base + '/') for base in SCOPE)}
missing = sorted(set(manifest) - selected)
extra = sorted(selected - set(manifest))
mismatch = [path for path, expected in manifest.items() if path in selected and hashlib.sha256(content(path)).hexdigest() != expected]
result = {'phase': args.phase, 'revision': args.revision, 'input_count': len(manifest), 'selected_count': len(selected), 'missing': missing, 'extra': extra, 'hash_mismatches': mismatch, 'status': 'PASS' if not (missing or extra or mismatch) else 'FAIL'}
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if result['status'] == 'PASS' else 1)
