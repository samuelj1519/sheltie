# C002-T40 CLI测试精简结果

范围仅CLI tests，保留T38/T39生产与测试改动。15个测试/支持文件有本轮diff，未改生产代码、依赖、快照、Workbook或提交。固定输入tracked文件来自input-tree；三份T39文件原文副本在`/private/tmp/sheltie-t40-cli-baseline/`，SHA256逐一匹配`input-hashes.json`。测试src/cli.rs未变。

## 减少与保留

- tests目录静态test函数180→174（净减6），含支持文件源码10441→10270行（净减171）；src/cli.rs单元测试另计1项且未改。函数数不代表产品cases或实际运行数量。
- 严格子集退休2项；首轮冻结输入字节、@summary摘要、publish上游occurrence002、ghost点名/空Work列表分别先迁入4个保留用例，再退休4个函数。完整旧函数→保留函数/条件/oracle映射见dispositions.json。
- Process/精确rendezvous/RAII从reliability移到common，复用至stats、首次Store初始化SIGKILL、tmp删前替换3个额外caller。清继承故障环境、reached精确字节、deadline、Drop释放/kill/wait、Exit70+SIGKILL及namespace均保留；stats仍15秒reached。自定义安装binary/cwd builder保留具体构造。
- 全表快照共享StoreRows，读五表全部原始SqlValue、稳定键序，保留raw TEXT/BLOB等类型。strict_state目录项+文件原字节、reliability文件/子集检查、work目录名字快照仍分别保留。
- copy_example重复递归复用copy_dir；skill_delivery私有copy_tree保留，因为它原来跟随目录symlink，而common不跟随；过滤发布evidence的copy和两种chmod策略也保留，不加strategy框架。
- 5处T01真实write/gate/Git commit共用小helper，sim/cold-fixture trailer与调用方审批、metadata、白名单、继承链及独立冷worker期望保留。两种placeholder负例共用具体fixture/提交动作，文字条件与独立expected留在cases；future placeholder正例独立保留。
- 仅去掉workflow两处相同announce/MSRV断言，不删三种治理测试。
- 输出symlink原弱测试增强为准确INVALID_REQUEST/链接诊断、Store五表原始行零变化、独立外部哨兵bytes/mode不变及输出链接仍同目标；新增覆盖归C002-T40。
- 所有T39不同解码/Flow/tmp边界、旧crash typed runtime与新CLI窗口、JSON/text、opaque历史重放、remote传输边界与版本治理、source/delivered skill独立artifact检查均保留，处置理由见JSON。

## 局部验证

- CLI all-targets/all-features check与Clippy -D warnings：exit0。
- 12受影响test binaries：118/118 PASS，0 skipped，51.737秒。日志`/tmp/sheltie-t40-cli-tests.log`。
- 恢复skill复制策略后：skill_delivery 8/8 PASS，0 skipped。日志`/tmp/sheltie-t40-cli-skill-final.log`。
- 最终T40标记后的symlink case：1/1 PASS。日志`/tmp/sheltie-t40-cli-symlink-final.log`。
- own CLI diff-check：exit0。全workspace门禁与针对性负控制由父agent负责；没有跑全mutants或推断完整产品/Host/发布PASS。

固定diff：`/private/tmp/sheltie-t40-cli.patch`，SHA256 `6dd5531467dba001e6d43d138b0f8504bbfb58eaa231c78f5681a3704cf074ee`。映射：`/private/tmp/sheltie-t40-cli-dispositions.json`。源文件已停止编辑，可独立审查。
