from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path('/Users/shushu/orca/workspaces/sheltie/codex');out=Path('/private/tmp/sheltie-submit');phase=sys.argv[1];target=out/phase
# Only paths belonging to this three-task submission can be replaced or removed.
base=subprocess.check_output(['git','diff','--name-only','4b86279'],cwd=root,text=True).splitlines()
initial=json.loads((out/'final-input-hashes.json').read_text())
head_paths=subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD'],cwd=root,text=True).splitlines()
for p in initial:
 if p not in head_paths:base.append(p)
for p in ['specs/changes/active/C002-v0.2.0-reliability/README.md']:base.append(p)
base.extend(str(p.relative_to(target)) for p in target.rglob('*.tar.gz'))
base.extend(str(p.relative_to(root)) for p in (root/'specs/changes/active/C002-v0.2.0-reliability/evidence/submissions').glob('*.tar.gz'))
for source in target.rglob('*'):
 if source.is_file():
  name=str(source.relative_to(target));current=root/name
  if name.startswith(('crates/','specs/')) and (not current.is_file() or current.read_bytes()!=source.read_bytes()):base.append(name)
paths=sorted(set(base))
for name in paths:
 if not name.startswith(('crates/','specs/')):raise ValueError('Out of scope '+name)
 source=target/name;destination=root/name
 if source.is_file():
  destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,destination);shutil.copymode(source,destination)
 elif destination.is_file():destination.unlink()
# Assert the content we are about to commit matches the original validated phase.
gates={'t38':'/private/tmp/sheltie-t38-gates/input-files.json','t39':'/private/tmp/sheltie-t39-evidence/gates/input-files.json','t40':'/private/tmp/sheltie-t40-evidence/gates/input-files.json'}
inputs=json.loads(Path(gates[phase]).read_text());assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==sha for p,sha in inputs.items())
# Added future test files must not participate in an earlier phase's autodiscovery.
source_paths={str(p.relative_to(root)) for p in (root/'crates').rglob('*.rs') if '/target/' not in str(p)}
expected={str(p.relative_to(target)) for p in (target/'crates').rglob('*.rs')}
assert source_paths==expected, (source_paths-expected,expected-source_paths)
(out/(phase+'-materialized-paths.json')).write_text(json.dumps(paths,indent=2)+'\n');print(phase,'materialized',len(paths),'authorized paths;',len(inputs),'validated inputs match')
