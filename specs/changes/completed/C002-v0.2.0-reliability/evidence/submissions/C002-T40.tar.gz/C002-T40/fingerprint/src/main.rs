use quote::ToTokens;
use syn::{Attribute, Item, ImplItem, visit_mut::{self, VisitMut}};
fn test_only(attrs: &[Attribute]) -> bool {
    attrs.iter().any(|attr| {
        if !attr.path().is_ident("cfg") { return false; }
        let value = attr.meta.to_token_stream().to_string().replace(' ', "");
        value == "cfg(test)" || value == "cfg(any(test,feature=\"testkit\"))"
            || value.starts_with("cfg(all(test,")
    })
}
fn attrs(item: &Item) -> &[Attribute] {
    match item {
        Item::Const(x)=>&x.attrs, Item::Enum(x)=>&x.attrs, Item::ExternCrate(x)=>&x.attrs,
        Item::Fn(x)=>&x.attrs, Item::ForeignMod(x)=>&x.attrs, Item::Impl(x)=>&x.attrs,
        Item::Macro(x)=>&x.attrs, Item::Mod(x)=>&x.attrs, Item::Static(x)=>&x.attrs,
        Item::Struct(x)=>&x.attrs, Item::Trait(x)=>&x.attrs, Item::TraitAlias(x)=>&x.attrs,
        Item::Type(x)=>&x.attrs, Item::Union(x)=>&x.attrs, Item::Use(x)=>&x.attrs,
        _=>&[],
    }
}
struct StripTests;
impl VisitMut for StripTests {
    fn visit_file_mut(&mut self, value: &mut syn::File) {
        value.items.retain(|item| !test_only(attrs(item)));
        visit_mut::visit_file_mut(self, value);
    }
    fn visit_item_mod_mut(&mut self, value: &mut syn::ItemMod) {
        if let Some((_, items)) = &mut value.content { items.retain(|item| !test_only(attrs(item))); }
        visit_mut::visit_item_mod_mut(self, value);
    }
    fn visit_item_impl_mut(&mut self, value: &mut syn::ItemImpl) {
        value.items.retain(|item| !test_only(match item {
            ImplItem::Const(x)=>&x.attrs, ImplItem::Fn(x)=>&x.attrs,
            ImplItem::Type(x)=>&x.attrs, ImplItem::Macro(x)=>&x.attrs, _=>&[],
        }));
        visit_mut::visit_item_impl_mut(self, value);
    }
}
fn main() {
    let root = std::path::PathBuf::from(std::env::args().nth(1).expect("source root"));
    let files = std::io::read_to_string(std::io::stdin()).expect("file list");
    for file in files.lines() {
        if file.ends_with("/testkit.rs") || file.ends_with("/store/tests.rs") { continue; }
        let code = std::fs::read_to_string(root.join(file)).expect(file);
        let mut syntax = syn::parse_file(&code).expect(file);
        StripTests.visit_file_mut(&mut syntax);
        println!("{}\t{}", file, syntax.to_token_stream());
    }
}
