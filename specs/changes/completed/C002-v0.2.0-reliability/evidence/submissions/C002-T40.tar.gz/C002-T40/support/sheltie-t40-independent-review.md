# C002-T40 测试精简独立审查

结论：**通过**。core、runtime、CLI 三个 scope 均无未关闭的阻断 finding。审查覆盖全部 disposition、实际原/现 diff、共享 helper、弱 oracle 修复、定向负控制与 legacy 替代注记，不以减少行数或局部全绿代替语义判断。

Reviewer：`/root/review_repairs`。未参与生产代码、测试或仓库文档编写；只读审查，唯一写入为本临时报告。未自行运行 tests、mutants 或全仓门禁，未提交、未启动其他 agent。

## 基线与范围

逐文件比较使用 `/private/tmp/sheltie-t40-evidence/input-tree/` 与 `input-hashes.json`，保留原 T38 简化及 T39 三项修复。三份未跟踪的 T39 测试使用已还原初始字节，避免把本轮已修改测试当作基线。完整依据为当前 engineering §2.2/§3/§5、C002-T40 plan，以及相关 Workbook、storage、protocol 合同。

独立重新计数：本次真实增量为 37 个 Rust 文件，净减少 896 行；core 9 文件/-292、runtime 13 文件/-433、CLI 15 文件/-171。该数字只说明代码量，不代表产品覆盖完整。

独立核对默认 CLI 源码与初始镜像全字节相同；runtime 源码仅 `src/store/tests.rs` 改变，其余全字节相同。core 六个修改源码文件在 `#[cfg(test)]` 前的生产前缀不变；`testkit.rs` 变更仅属于既有 testkit feature。七份 snapshot 独立逐字节相同；`ids.rs`、`work/state.rs`、T39 `flow_identity.rs`、`skill_delivery.rs`、Cargo 依赖与两份 CI workflow 均与初始字节相同。父任务 `integrity.json` 另记录 52 个非支持生产源码剥除 cfg(test) 后 token hash 相同、44 个 fixture/config/依赖文件字节不变。

## Core：全部 disposition

| 项 | 实际核对与结论 |
| --- | --- |
| CORE-01 | 四份相同样例仍由 `no_example_declares_requires` 真实 parse/compile，原纯编译 smoke 无独有 oracle；通过 |
| CORE-02 | `Timestamp::parse(...).day()` 同一字面 UTC 输入与日期输出已存在于保留单元；外部 runtime 仍使用公开 `day()`；通过 |
| CORE-03 | `require` 无仓内调用者，仅移除 testkit 支持及专属 imports；不声称外部消费者兼容；通过 |
| CORE-04 | 当前 Attempt 的 `attempts=1` 断言迁入原真实 begin/stats 测试；路径、bytes/digest/effect 一致性、nodes 断言保留；通过 |
| CORE-05 | 原三套独立 0/1 状态计数迁入 renderer 对应真实转换；gate 批准前后状态计数保留。真正跨类别 1→2、MAX 溢出及 cancel 保留仍是独立测试；通过 |
| CORE-06 | 同一 article-review compile 后 publish terminal、draft/review nonterminal 三条断言保留；通过 |
| CORE-07 | review 的 `来自: draft#1（main 边）` 原 snapshot 保留且字节未改，entry 字面断言保留；仅移除同生命周期重复 render；通过 |
| CORE-08a/b/c | description 2048/2049、summary 4096/4097、output 262144/262145 的成功与拒绝均保留；后两项精确错误字段更强。拒绝后使用同夹具做合法对照，没有缺掉一端；通过 |
| CORE-09 | HostRequire 的 Some digest 完整 roundtrip 及单字段 name/digest 拒绝保留；公开 JSON version 32/33、source 512/513 与 null digest 控制不删除；TOML/交叉 kind-name 消费者保持独立；通过 |
| CORE-10 | 原手工 framing 测试只调用 SHA，没有调用产品 framing builder；独立的 prefix/BE64/frame 字节 oracle 与 SHA known vector 仍在。runtime 实际 `digest_dir_v2` 五个独立摘要字面值及旧碰撞对保留；通过 |
| CORE-11 | 原样例测试重复 compile 已保证的不变式；保留 spec-dev 具体输入/source/required/return-edge 判定，额外补真实 resource optional 单条件拒绝；start/resource/engine.stats 三种拒绝齐全；通过 |
| CORE-12 | 相同真实 two-step manifest 的额外 author 字段反例归并到 `rejects_unknown_field`，精确 WorkbookInvalid/toml 错误检查保留；合法样例控制仍在；通过 |
| SUPPORT-1..4 | `Fixture::from_example/from_texts` 只共享真实 parse/compile/start/内存文件 setup，不生成 expected。requires-render 字面 table-row、Start 决策、gated 生命周期及腐坏状态判定留在 caller。`start_texts` 原 `/sheltie-test` 改为等价合法 `/tmp/sheltie-test`，无旧根字面 oracle 被删除；通过 |

所有其余 exact/+1 限额、状态/计数 overflow、历法/世纪/饱和/时间差、冻结引用、重试特定路径、双 stats binding、public legal_next、property testing、五条 compile_fail 和七份 snapshot 保留。T39 嵌套未知字段测试原字节不变。审查指出的 stats 历史重放旧注释及 SUPPORT-2 对根路径的错误描述已由父任务修正并复核，不涉及行为改动。

## Runtime：318 项映射与全部实质变化

独立机械核对全部 318 条 `original_fn_body` / `retained_fn_body` 均为对应原/现源码的精确子串，SHA-256 与记录一致；独立抽取函数集合为旧 318、当前 307，零遗漏映射、零虚构映射。306 个唯一保留目标加一个新增 control 对应当前全部函数。再逐条阅读所有退休/合并/改名/修复/加强条目的旧现 oracle，并审完其余 helper 修改的 diff。

| 变化 | 原 oracle 与实际保留判定 |
| --- | --- |
| 3 条退休 | allocate_seq 的“假装失败”没有失败夹具，真实同日 1/2 与翌日 1 保留；较弱 checksum mismatch 由相同 fixed-tag/raw-asset 错摘要拒绝保留，并核旧 binary/tmp/no-prev；旧 remove→tmp 布局义务已经被当前 pending/marker 合同替代，不保留错误布局断言，删除结果及真实窗口仍有独立测试 |
| completed submit 合并 | replayed、原 revision/reply/data 精确相同均迁入；后来输出字节与权限不再封存/改写也保留，未用当前响应重算旧 expected |
| Active 引用 remove 合并 | 精确 WorkbookInUse WorkId 列表、原 row、Active 状态及 installed instruction 原字节保留；不冒充并发插入引用窗口 |
| 首次 install 合并 | first false、exact installed_to、当前 executable 原字节、Store 存在和 second true 保留；原测试同样使用已存在的空 temp root，不声称补了不存在 root 的新场景 |
| installed tamper 合并 | verify(None) 的精确 id/version/Tampered、start WorkbookTampered 和无 Work 物化同时保留；另一 selector 的 CLI verify 未退休 |
| 两组旧 add/remove 生命周期合并 | fresh Home 分别测试同内容与不同内容 readd，核 equal/unequal digest；旧 add/remove 的返回 data、replayed、新 row count/digest/inode/bytes 与旧 reply_json 原字节全部保留；没有用相同 digest 场景替代不同 digest 场景 |
| 终态 status 合并 | fresh Home 分别保留无 Attempt 历史与已 submit 历史，cancel→remove→status 真实入口，Cancelled JSON/文本/header 全在 |
| Started/Cancelled 坏快照参数化 | workbook={}、合法但错误 name、错误 active status、cancelled 加 unknown field 分别在独立 Home 修改单字段；EFFECT_PENDING、committed、request id、StoreCorrupt 和不释放 original/pending_original 判定保留 |
| 两项 schema weak oracle 修复 | 手写完整 schema 2，不复用生产 TABLES/create_script；合法 control 在 RO/RW 均收且非零 sequence=7 保留。反例仅少 status 列或仅 state_json TEXT→BLOB 且空白不变，RO/RW 精确 works 诊断、main/非空 WAL 原字节保持；已取消 schema1 版本拒绝掩盖形状验证的盲区 |
| observation weak oracle 修复 | 外部 TempDir 保活，是真实可达目标；真实 submit 软链观察拒绝，直接读取五张表全列 SqlValue，包含 revision/state_json/requests/audit，不再仅比较 status。外部 bytes/mode 也保持 |
| card/brief 恢复加强 | card 缺失后下一 begin 核最新 revision=2、Active、outline#1.0 running 与独立手写完整状态卡字节；begin brief 缺失后由不同下一写 fail 触发恢复，逐字节等于先前真实提交后保存的 bytes，pending 请求清零。该合成已提交缺文件例不代替真实 kill 例 |
| 支持代码 | literal/input/start 构造保持各 caller 原参数；sentinel/snapshot 和原始 SQL 只观察实际状态，不构造成功 expected。limit-tree 固定独立 32/256 MiB 常量并保留 exact/+1 与复制/sync 消费者；tar helper 仅打包，三种格式/布局/权限/manifest 条件不合并 |
| RendezvousWorker<T> | 同步点名/作用域与真实返回值保留，正常 finish 传播 join/业务错误，失败 Drop 释放后收束。原双窗口仍在；write_session 父锁释放顺序有独立资源所有权，保留专用 guard。没有把子线程失败或模型结果伪造为成功 |

另外七组 retained audit 的保留依据成立：SafeFile/effects/真实 submit/recovery、锁/root/session/held directory/purge、各限额 consumer、各 publication/parent-sync/delete marker 窗口、cleanup/replay/read-only 的不同 I/O 义务、schema2 raw audit wire、递归 chmod 的不同链接策略。九类 sync 及连续失败、COMMIT/rename/delete 窗口、历史 original 资格、整索引先校验、只读不取锁/不恢复、真正 Exit70/SIGKILL 全部保留。

## CLI：全部退休与支持/保留 disposition

六条退休/合并均已落实：默认名由原 start/next/card 测试保留；缺 input 由同真实入口的 deterministic no-side-effect/sequence 控制保留；`@file` 首次冻结原字节迁入 start replay 后再删源；summary 首次内容迁入 submit replay 后再删源；latest succeeded occurrence 的 publish 输入路径迁入原 next-driven 第二轮完整 lifecycle；明确 ghost selector 的错误文本与空 Work 列表迁入原 preflight。没有拿 lexical parser、别的错误码或新的失败窗口替代真实入口。

六组支持 disposition 均落实：copy 只共享相同普通树语义；Process 搬原真实 spawn/reached/release/finish/Drop，保留 exact point/name/id、stats 15 秒 reached、真实 Kill/Exit70；SQL 由 JSON 投影改为每列原 SqlValue，五张表与稳定排序仍在；spec-dev 的 export/placeholder helper 只准备真实文件、gate、Git commit，Agent trailer、change metadata、caller 白名单和手写期望保留；重复 workflow 断言由同一 artifact 的既有正/反例守护。

八组 retained audit 均有实际依据：JSON/text 输出分支、Workbook verify selector、opaque/history replay、旧 typed runtime crash 与真实 CLI crash、T39 回归、cold worker、remote release、source/delivered skill。`skill_delivery::copy_tree` 跟随目录软链，与 common 的 no-follow entry type 复制不同，已恢复初始字节；递归 chmod/filtered copy 的不同语义没有强行归并。

T39 的 strict state/Reply+NextOp/audit 原字节拒绝、Flow precommit/direct-load/historical bad snapshot、tmp exact age/成功/读/失败/self/replay/links/FIFO/目录替换 case 均保留。shared StoreRows 不编码 JSON；shared Process 不生成业务 expected、失败时不遗留暂停进程。leaf-symlink weak oracle 已改为可达外部哨兵、精确 INVALID_REQUEST/symlink reason、五张表全行不变、外部 bytes/mode 与原链接保留。

## Legacy 注记与验证边界

独立抽取 21 条 C002-T40 Replacement 注记：每个保留目标函数实际存在。将注记精确还原为原列测试名后，`specs/releases/v0.1.0/plan.md` 与输入镜像逐字节相同；历史完成状态、历史实现说明和其他文案没有修改。没有改 checker 来放宽约束。

已读取 Owner 局部日志：core 205/205、零 ignored，另五条 compile_fail；CLI 选定 12 个 binary 的 118/118（另 12 binary scope 排除），run id `9166b479-6782-4c1d-bc6e-ad9e669ddd53`；runtime 103/103，204 明确 scope 排除，run id `f3672b0e-2496-4268-aa38-809827aeb6ff`，exact copy/sync 仍真实执行 69.906 秒。上述均不是当前全仓 gate。

定向负控制在独立临时副本完成，审查读取原文及注入记录：合法 schema/observation/CLI symlink 正控 PASS；仅取消表形状 guard 后两项 shape 测试在正常编译后 FAIL；submit 观察前注入 revision 违规写后完整行 oracle 在正常编译后 FAIL；仅对 leaf open 同时 follow stat/remove NOFOLLOW 后 CLI symlink 测试在正常编译后因意外成功 FAIL。原文为 evidence 目录下 `schema-{control,negative}.log`、`observation-{control,negative}.log`、`cli-symlink-{control,negative}.log`。这些是针对性 oracle 敏感度证据，不冒充完整 mutants。

审查时 `git diff --check` 通过。父任务仍须对完整冻结候选运行 plan 要求的统一门禁并保存原始输出；旧局部运行不复用为新的全仓 PASS。本报告不改变 M1/SK、完整变异、Linux、Host 或发布范围，也不声称新的产品能力验收。

## 审查输入标识

| 文件 | SHA-256 |
| --- | --- |
| sheltie-t40-core-dispositions.json | 23f90d2ba30b9eec976755955f6a34e3b7612b275cebde07b98ff7b3cc1a0778 |
| sheltie-t40-cli-dispositions.json | c32d539e999105bcd426378aea5cb133ff5ce9116fc0edaa8e4c6cce76381629 |
| sheltie-t40-runtime-dispositions.json | 4029e3a47d70de56297032ba3d9b77c37f4c3da2c18a5eee37abdf804b7ab7db |
| specs/releases/v0.1.0/plan.md | 3d1823b19c79c4f2823a07a8cb589fdd06bc732eb92f8857cc0b2c0503b47a10 |
| sheltie-t40-evidence/integrity.json | 69dd88d9fb0e9b5e47c68aeec65c1a0409a65de8a17f9779b59b400bb2295359 |

父任务默认生产 token hash：`8cdf7bcd5e65df18148fd00b2f5b37dca628f7e7b84851f3076b9066f71e0461`。其余文件级冻结 hash 在各 scope metrics 与初始 input-hashes；本报告仅绑定以上已审 diff 与映射，后续若改源码或覆盖内容，应审实际增量。
