from pathlib import Path
import shutil,subprocess,json,hashlib,os,time
out=Path('/private/tmp/sheltie-t40-evidence');tree=out/'negative-control-tree';root=Path('/Users/shushu/orca/workspaces/sheltie/codex')
for crate in ['sheltie-core','sheltie-cli']:
 for folder in ['src','tests']:
  shutil.copytree(root/'crates'/crate/folder,tree/'crates'/crate/folder,dirs_exist_ok=True)
env=os.environ.copy();env.update(RUSTC_WRAPPER='',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR='/private/tmp/sheltie-t40-controls-target')
records=json.loads((out/'negative-controls.json').read_text())
argv=['cargo','test','-p','sheltie-cli','--all-features','--test','scenario_artifacts','submit_with_symlink_output_is_rejected','--','--test-threads=1']
def run(name,expected):
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log:result=subprocess.run(argv,cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'argv':argv,'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3),'raw':str(out/(name+'.log')),'sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()}
 records.append(record);(out/'negative-controls.json').write_text(json.dumps(records,indent=2)+'\n');print(name,result.returncode,flush=True)
 text=(out/(name+'.log')).read_text()
 if expected=='pass':assert result.returncode==0 and '1 passed' in text,text[-3000:]
 else:assert result.returncode==101 and 'FAILED' in text and 'could not compile' not in text,text[-3000:]
run('cli-symlink-control','pass')
p=tree/'crates/sheltie-runtime/src/fsx.rs';original=p.read_text();start=original.index('fn open_regular_at(');end=original.index('fn open_directory_at(',start)
part=original[start:end]
assert part.count('AtFlags::SYMLINK_NOFOLLOW')==1 and part.count('OFlags::NOFOLLOW')==1
changed_part=part.replace('AtFlags::SYMLINK_NOFOLLOW','AtFlags::empty()',1).replace(' | OFlags::NOFOLLOW','',1)
p.write_text(original[:start]+changed_part+original[end:]);(out/'cli-symlink-negative-injection.txt').write_text('Only open_regular_at: follow stat target; remove NOFOLLOW from leaf open. Other filesystem guards unchanged.\n')
try:run('cli-symlink-negative','fail')
finally:p.write_text(original)
