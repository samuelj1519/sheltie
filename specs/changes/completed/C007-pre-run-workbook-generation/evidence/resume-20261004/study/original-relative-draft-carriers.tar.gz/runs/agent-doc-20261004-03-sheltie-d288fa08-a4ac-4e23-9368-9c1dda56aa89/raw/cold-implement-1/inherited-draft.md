# 继续任务、执行失败与内容返工的选择

本指南面向接手已有 Work 的操作者。先查询当前状态，再判断是否继续原 Attempt、记录真实执行失败，或按 Workbook 的显式边返工。状态、命令和错误以[协议合同](../contracts/protocol.md)为准；接续能力的范围见 [C004](../changes/completed/C004-verifiable-delegation/README.md)，资格撤销的边界见 [C005 产品方案](../changes/completed/C005-executor-continuity/spec.md)。

## 先判断发生了什么

| 实际触发 | 选择与前提 | 观察与停止条件 |
| --- | --- | --- |
| 重开会话、等待后继续，或已确认旧执行者停止后换人 | 查询 `work status`；当前 Attempt 仍为 `running` 时，按 `resume` 读取任务书与冻结输入，继续同一个 Attempt | 确认当前 `next` 和草稿位置。会话重开不会产生失败或新 Attempt；不能因此调用 `fail` 或重复 `begin` |
| 执行确实失败，例如执行者崩溃或超时且不能完成本次执行 | 仅在当前 `next` 有对应 `attempt fail` 时，记录真实原因；随后只在新的 `next` 允许时重试 | 成功响应返回 `data.attempt`、`data.work_status` 与 `next`。失败计入 `failed`；重试额度耗尽时停止，不自行增加额度 |
| 审查完成，但产物内容需要返工 | 将完整审查报告写到任务书声明的输出位置，正常 `submit`；协调者读报告后选择 `next` 中的显式 `back` 边 | 审查“不通过”不等于执行失败。返工进入目标节点的新 Occurrence，受 `max_visits` 限制；没有合法回边时停止 |
| 确需撤销旧 Attempt 的正式提交资格 | 选择当前 `next` 中的 `attempt replace`，具体前提和效果见 [C005](../changes/completed/C005-executor-continuity/spec.md) | 这是行政撤销事实，由操作者决定。引擎不停止旧进程、不认证接手者、不隔离宿主；处置未确认时不派新执行者写共享工作区 |

## 重开会话后继续同一个 Attempt

例子中的 `<专用Home绝对路径>` 指本 Work 创建时使用的管理根。开发候选应使用与旧版本分开的新管理根；接续时保持原路径，不改用默认 Home 或为接续另建 Work。将所有占位符换成真实值后执行。只读查询不带 `--request-id`。

```text
sheltie --home <专用Home绝对路径> --json work status <完整WorkId>
sheltie --home <专用Home绝对路径> --json work stats <完整WorkId>
```

1. 核对 `data.work_id`、`data.revision`、`data.status`、`data.current` 与当前 `next`。如果只需要查询，到此结束，不提交或推进 Work。
2. 读取 `data.resume`。没有当前 Attempt 时它是 `null`；有当前 Attempt 时包含 `attempt`、`brief_path`、`inputs` 和 `draft_outputs`。`resume` 存在本身不证明 Attempt 仍为 `running`，应结合当前状态和 `next` 判断资格。
3. 当前 Attempt 仍为 `running` 时，读取 `brief_path` 及全部绑定的冻结 `inputs`；可选输入的 `null` 保持未绑定。核对工作区里已有草稿，再按任务书继续写声明输出。`draft_outputs` 只列声明位置，不证明文件存在、完整或封存。
4. 接手者开始写共享工作区前，操作者确认旧执行者已停止，或新执行环境已隔离。该确认属于操作者事实，不能表述为引擎保证。

`effects_pending=true` 表示本 Work 有已提交但未完成的文件效果；只读查询不会恢复效果。此时停止正常推进，保留原响应和请求身份，按[协议合同 §5](../contracts/protocol.md)的效果恢复规则处理。任务书缺失或草稿不完整不能直接推导为业务执行失败。

## 真实执行失败后才重试

调用前确认当前 `next` 包含目标 Attempt 的 `attempt fail`，并预先生成、保存本次写意图的 UUID。理由应说明实际失败，最多 4096 字节。

```text
sheltie --home <专用Home绝对路径> --json --request-id <本次fail请求UUID> attempt fail <完整WorkId> --attempt <当前AttemptId> --reason "<真实失败原因>"
```

成功后只从响应的 `next` 选择操作。若其中有同节点的 `attempt begin`，可使用另一个预先保存的请求 UUID 开始重试：

```text
sheltie --home <专用Home绝对路径> --json --request-id <本次begin请求UUID> attempt begin <完整WorkId> --node <next给出的节点>
```

重试沿用同一 Occurrence，并创建新的 Attempt。Attempt ID 后缀 `number` 是从 0 起连续递增的创建顺序号，不能当作失败数。`max_retries=k` 允许同一 Occurrence 的 k 次业务失败重试；第 k+1 次真实 `failed` 进入 `blocked(retries_exhausted)`。行政撤销产生的 `superseded` 不计入失败。额度耗尽时报告状态，由用户决定后续，不为恢复可用性虚构新的失败或撤销。

## 内容审查退回沿显式 back 边

审查者已经完成任务并写出“不通过”的报告时，仍正常提交审查 Attempt。引擎核对声明输出并封存文件，不判断审查结论是否正确。

```text
sheltie --home <专用Home绝对路径> --json --request-id <本次审查submit请求UUID> attempt submit <完整WorkId> --attempt <审查AttemptId> --summary "<审查结论与报告位置>"
```

协调者读取审查报告，确认返工必要后，仅选择成功响应 `next` 中 `op="attempt begin"` 且 `edge="back"` 的目标，使用新的请求 UUID 调用 `attempt begin`。进入目标节点时创建新的 Occurrence；不要把内容返工伪装成同一 Occurrence 的业务失败重试。若目标已达 `max_visits`、当前受阻或没有声明回边，停止并报告现有合法操作。

若进入门槛阻塞，等待用户明确批准；不能通过选回边、替换或标失败绕过门槛。Work 为 `succeeded` 或 `cancelled` 时已终态，`next` 为空，保持只读查询。
