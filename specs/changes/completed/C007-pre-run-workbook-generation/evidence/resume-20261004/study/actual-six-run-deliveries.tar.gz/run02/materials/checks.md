成功：两项必需机械检查均退出 0，绑定同一个 staged/commit tree；内容独立审查、完整 patch 独立应用及最终质量/接受 not_run。

## 候选绑定与环境

cwd：`/private/tmp/sheltie-completion-20261003/c007-agent-paired-study/repos/source-start/sheltie`。检查基线 HEAD/tree：`351feb7ac22c21317a686693b732d5ae0c4b4bcc` / `80ea3046b1b3575f07e68313444c051ee7c5b7db`。

检查 staged tree：`02966cae1d3fe7a601c26d4bd6f69c66e323a8c4`；提交 candidate：`957efb7076861d1dc54e780d841e0b0bb767bccd`，commit tree 同值。before/after tree 原件、允许文件 SHA 和 candidate JSON 均在 `/Users/shushu/orca/workspaces/sheltie/codex/specs/changes/active/C007-pre-run-workbook-generation/evidence/resume-20261004/study/runs/agent-doc-20261004-02-sheltie-a45a4141-4c51-4b69-a6ed-6ae0fdd431d0/raw/implement-1`；checked-input.json 保存必需 argv、tree 与 SHA，candidate-status.stdout 为空。完整 baseline→HEAD 路径集仅 README.md 和新增 guide，candidate-patch-paths 原件可核。

使用冻结 study/capture.py.execute，逐命令 120 秒上限，run 总 deadline 2026-10-03T20:32:28.417368+00:00。没有改脚本或标准。每项原件 .json 给实际 argv/cwd/start/end/elapsed、exit/timed_out/deadline、stdout/stderr 路径与 SHA、control_environment；PATH/LANG/LC_ALL 与 Git/Cargo 有关环境见 actor.json。SHELTIE_HOME 与列出的 failpoint/test 控制变量均为 null；两项未调用引擎或 Rust 构建。没有依据本地退出码声称引擎核验源码或质量。

## 必需检查

| 实际 argv（cwd 相同） | 原件 basename（位于上述 raw 目录） | 退出码 | 覆盖 |
| --- | --- | --- | --- |
| `scripts/check-docs.sh README.md specs/guides/source-quick-start.md` | required-docs.json / required-docs.stdout / required-docs.stderr | 0 | 两文件的相对链接存在、脚本禁用措辞与决策编号机械规则；stdout 为 check-docs: OK (2 个文件)，stderr 空。 |
| `git diff --cached --check` | required-staged-diff.json / required-staged-diff.stdout / required-staged-diff.stderr | 0 | 已 stage 的两个允许文件 diff 空白规则；stdout/stderr 空。 |

required-docs UTC：2026-10-03T20:17:39.148438+00:00 → 20:17:41.533107+00:00。
required-staged-diff UTC：2026-10-03T20:17:41.534026+00:00 → 20:17:41.547075+00:00。

## 已保留的诊断失败与执行记录

早期只读源码搜索遇不存在 glob，zsh 返回 `no matches found: crates/sheltie-core/src/protocol*`、exit 1；原工具合并输出在 worker transcript，actor.json 记录实际命令/cwd/输出/exit，分流 unknown。随后按真实文件读取，此命令不属于 required checks。

首个自有 runner 在计数断言处 AssertionError、exit 1；`git ls-files '*.rs'` 命令本身 exit 0 且列出 127 项，原件为 source-file-list.json/.stdout/.stderr。run_checks.py 与 diagnostic-runner1-failure.json 保留误把冻结 192 项全文件 map 当 Rust 数的原因、工具实际失败和协调者澄清。该失败发生在 stage/必需检查之前；未改被冻结 task/project 检查或输入。新原件 run_checks_continuation.py 从核对 HEAD/tree 开始续跑，并完成两项原必需检查。没有删除失败、覆盖旧记录或降低标准。

stage-authorized-files、staged-paths、staged-tree-before-checks、staged-tree-after-checks、candidate-commit、candidate-identity、candidate-patch-paths、candidate-status、candidate-stat 各自 .json/.stdout/.stderr 保留实际命令；提交明确 core.hooksPath=/dev/null、commit.gpgsign=false。只有允许文件 stage/commit，新增文件未遗漏。

## 未执行与剩余覆盖

Rust 构建/测试、安装/更新/发行、Sheltie 演练未执行，符合本次文档 trial 授权。scripts/check-specs.sh 不在被冻结 project checks 内，本次未执行。完整 patch 的生成/同基线独立应用和所有允许文件逐字节核对交给 deliver，当前 `not_run`。内容独立 review、最终质量盲审与代理接受仍 `not_run`；机械规则不会确认指南实际可用性或用户价值。真实运行模型 metadata 由 Root 核，usage/费用 unknown。
