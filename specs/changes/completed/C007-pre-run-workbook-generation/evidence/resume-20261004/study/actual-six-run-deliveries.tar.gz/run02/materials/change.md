可审查：已完成授权的当前源码快速开始文档 patch，两项必需机械检查成功；独立审查、完整 patch 独立应用、最终质量与代理接受尚未执行。

## 目标与实际变化

目标是补齐首次使用者从当前 0.3.0-rc.1/schema 4 源码开始、运行 code-change 并取得明确成果的入口。基线没有 specs/guides/source-quick-start.md；README 只有 v0.2.0 远端安装和分散的开发方法入口。

现在 README 只新增一个当前源码入口段落，原 v0.2.0 安装历史和其他正文不变。新增指南给出：Cargo JSON executable、空 RUSTC_WRAPPER 与独立 target；新的显式 Home；具体 README 文档任务的 task/project 文件；add/verify/show/start/begin；真实任务书、声明输出、submit、独立 review、back 返工、deliver、result；当前 status/resume 接续；错误、pending、次数预算、终态、未知及旧 schema 原件保留的停止边界。指南内操作是交给使用者的说明，本 worker 没有执行源码构建或 Sheltie 演练。

## 候选与范围

- 独立仓库：`/private/tmp/sheltie-completion-20261003/c007-agent-paired-study/repos/source-start/sheltie`。
- 初始 HEAD：`351feb7ac22c21317a686693b732d5ae0c4b4bcc`；tree：`80ea3046b1b3575f07e68313444c051ee7c5b7db`。开工只读核对一致、初始工作区干净。
- 当前本地 candidate：`957efb7076861d1dc54e780d841e0b0bb767bccd`；tree：`02966cae1d3fe7a601c26d4bd6f69c66e323a8c4`；工作区干净。
- 仅修改 `README.md`，新增并已 stage/commit `specs/guides/source-quick-start.md`。完整 baseline→HEAD 路径集就是这两个允许文件。
- README sha256：`27e090dc77a461ac9a026e03767622b46b2e95c76e2494c75991aa4f8e40be2b`。
- guide sha256：`d5bda458d7bda78450005d9c98af933c2a3508f554d8e182d043debde60cb850`。
- 提交使用 core.hooksPath=/dev/null、commit.gpgsign=false；中文 docs(study) 格式及 Change:C007、Task:C007-T05、Sample:source-start、Arm:sheltie、真实 Agent trailer，原件见 `/Users/shushu/orca/workspaces/sheltie/codex/specs/changes/active/C007-pre-run-workbook-generation/evidence/resume-20261004/study/runs/agent-doc-20261004-02-sheltie-a45a4141-4c51-4b69-a6ed-6ae0fdd431d0/raw/implement-1/candidate-commit.json` 和 commit-message.txt。

## 依据与使用

已完整读取实际 begin brief 与冻结 task/project、assigned repo 的 CONTEXT.md、specs/README.md、specs/engineering.md、README、code-change README/Workbook/Flow/三份 instruction、protocol 合同、Sheltie skill、result-export 指南。读取共享 tech-doc-style-chinese SKILL.md 与受控技术写作参考，使用项目术语、保留约束和机器标识。CLI 参数/self version 字段、Cargo 版本与 schema 常量另从源码核对。

实际任务/项目输入 sha 与 brief 对应，见 `/Users/shushu/orca/workspaces/sheltie/codex/specs/changes/active/C007-pre-run-workbook-generation/evidence/resume-20261004/study/runs/agent-doc-20261004-02-sheltie-a45a4141-4c51-4b69-a6ed-6ae0fdd431d0/raw/implement-1/actor.json`；首次 previous-review 未绑定，无返工反馈。现阶段未替他人做 review 或 deliver。

使用者从 README 新链接进入指南，在新源码副本和获准范围准备真实材料，所有调用保持同一个显式 Home。协调者派各节点工作 agent，读输出并从当前 next 选边，方法默认无 gate。指南内 code-change 示例仅写 change/review/delivery 声明输出，不把本次 study 的 checks 槽混入产品方法。

## 检查与真实失败

必需检查的 argv/cwd/env/stdout/stderr/exit、UTC 原件见 checks.md；两项退出码 0，检查前后 staged tree 及 commit tree 相同，文件 SHA 不漂移。额外只读诊断曾因 shell glob 不存在而退出 1；一个自有前检把 source192 map 数量误当 Rust 文件数，runner AssertionError 退出 1。两个失败如实留存；协调者澄清 192 为全文件输入 map，不是冻结任务的 Rust 计数标准，未修改标准。新续跑只执行原先声明的必要检查。

## 交付的完整 patch 与独立应用规则（冻结 project 复述）

完整 patch 从该初始 commit 到当前 HEAD 生成，cwd 为上述 assigned repo，patch_file 使用交付阶段声明的新记录路径，不覆盖旧原件：

```bash
git diff --binary --full-index 351feb7ac22c21317a686693b732d5ae0c4b4bcc HEAD -- README.md specs/guides/source-quick-start.md > "$patch_file"
```

新增文件必须先 stage/commit 才进入 patch；本候选已完成。比较完整 diff 路径集与 allow_files/candidate，不能用 plain unstaged diff，不能遗漏新 guide。patch 上限 8388608 字节，两份报告各上限 262144 字节，达到上限停止而不截必要事实。

指定 Sheltie 独立应用副本：`/private/tmp/sheltie-completion-20261003/c007-agent-paired-study/patch-check/source-start/sheltie`。该副本须由原 archive/full initial snapshot 建立，初始 HEAD/tree 必须分别为 `351feb7ac22c21317a686693b732d5ae0c4b4bcc` / `80ea3046b1b3575f07e68313444c051ee7c5b7db`，工作区干净；不从另一 arm 取答案、不修改源 Root 或另一 arm。候选和检查证据的源为本 assigned repo。

在核基线身份后，对完整 patch 顺序执行：

```bash
git -C "$verify_repo" apply --check "$patch_file"
git -C "$verify_repo" apply --index "$patch_file"
git -C "$verify_repo" write-tree
git -C "$candidate_repo" rev-parse 'HEAD^{tree}'
```

其中 verify_repo 为上述指定副本，candidate_repo 为本 assigned repo；write-tree 必须等于当前 candidate tree `02966cae1d3fe7a601c26d4bd6f69c66e323a8c4`。另比较所有授权文件实际字节/SHA与 candidate 完全相同，并核完整路径集只含两项。完整 patch 生成和独立应用由 deliver 实际执行并保留原件，本 worker 未冒充执行。

## 限制与未完成项

只完成可审查文档实现及两项既定机械检查；脚本的链接存在与空白规则不代替内容审查。Rust build/check、安装、更新、发布、Sheltie 流程演练、独立 review、deliver/patchapply、最终质量盲审、代理接受均 `not_run`。模型声明为继承 gpt-6.1-sol/high 无 override，实际 session metadata 由 Root 独立核；usage/费用 unknown。引擎 submit 和运行状态仍由协调者办理。
