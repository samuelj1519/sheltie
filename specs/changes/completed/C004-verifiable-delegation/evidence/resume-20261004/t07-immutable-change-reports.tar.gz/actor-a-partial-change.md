部分完成：已独立核对冻结输入、C005 原延期义务及来源，形成开工包草稿；精确执行步骤、完整正反验收和最终检查记录仍待同一 running Attempt 续接补齐。未执行 C005 撤销试用，未修改仓库。

# C005 恢复开工交接包

受众是继续 C001–C008 请求的下一协调者。本报告只准备 C005 的恢复判断，不是 C005 已恢复 active、代码修复或真实撤销试用完成的证明。当前 C004 仍 active；下一消费者先只读原件并整理本轮范围判断，待 C004 最终归档后再另任务恢复 C005。

## 1. 当前输入与采用边界

仓库绝对根为 `/Users/shushu/orca/workspaces/sheltie/codex`。以下表格的 `C005/` 均指该根下 `specs/changes/completed/C005-executor-continuity/`；`行` 是本次冻结原文件的行号，标题用于行号变化时定位。所有结论以原文件为依据，不以这份摘要替代来源。

| 标识 | 本次实际值与含义 |
| --- | --- |
| 文档 Work | `2026-10-03-001-c005-opening-package`，当前为 `implement#1.0` 的声明草稿 |
| 冻结 task SHA-256 | `66feae2dda4b66a94aaad56ed9f34e67ff90903fb66f0a7d67174dbf503a760e` |
| 冻结 project SHA-256 | `8720c0940953935968d8b6a5c3925690f70718112282fcd9f6d1327684cb2e7b` |
| 本次冻结源码候选 | `ccf7a0cc4d4c4a3a1b3c040473ab2cbc069a1982`，来自 C004 事前 freeze，不是本报告新造候选 |
| 本次读取的仓库 HEAD | `af830f5d188e7fc8a8fff8ff329bcbbe56a86464`；读取时 C004 plan 与 run 证据已有协调者修改，未回退或改写 |
| C005 历史限定验收候选 | `d8d8c20fc71e3bd8bb813afecc6a4aa1af4a63f4`；该历史候选的 PASS 不自动适用于当前源码或真实用户价值 |
| 当前格式与开发线 | `0.3.0-rc.1`、Store schema `4`、`cli-result/v4`；`work-result/v1` 与 `workbook-digest/v2` 保持。已发布 `v0.2.0` 是另一 release，不由开发目标推断已发布 |
| C005 全部冻结原件检查 | 已对 `freeze.json` 的 `complete_C005_package_files_sha256` 逐文件核 SHA-256：62 文件，`drift=[]` |

冻结清单与来源政策的原件为 `/Users/shushu/orca/workspaces/sheltie/codex/specs/changes/active/C004-verifiable-delegation/evidence/resume-20261004/freeze.json`；执行规程为同目录 `protocol.md`。需新增未冻结来源或任一输入漂移时，停止本 run，先独立重审与重新冻结，不能在报告完成后换材料。

C005 的采用记录允许实施机械行为和本地提交，旧真实试用与环境缺项按当时授权延期。历史延期不是本轮补验完成。普通上下文恢复、换人继续可以沿 `work status` 的 `resume` 使用同一 `running` Attempt；只有确需撤销旧正式提交资格才调用 `attempt replace`。替换是一次事务内旧 `superseded`、同一 Occurrence 新 `running`，不是执行失败；每 Occurrence 最多一次，顺序号 `number` 不等于业务失败数。引擎不停止旧进程、不认证执行者、不隔离宿主工作区。

现行依据：`specs/contracts/protocol.md` §3 `attempt replace`（行125–133）、§6 状态卡（行332–334）；`specs/contracts/storage.md` §5.5（行250–254）。历史采用依据：`C005/adoption.md` 行3–11；`C005/README.md` 行10–24。没有 push、merge、release、部署或宿主安装授权。

## 2. 原延期与未知义务清单

以下是 C005 最终留下的义务和信号，不是早期预定义表的所有 `not_run`。`C005/validation.md` §3 证据表（行46–55）与 `C005/review.md` §历史方案审查、§两次实施审查（行4、20–21）的 `not_run` 是当时阶段事实；其后 M1/M2 有限定结论。保留阶段原文，当前未补义务按 validation §原义务、未执行与未知（行143–154）判断。

| 义务或信号 | 原状态与未获事实 | 精确来源与原文路径 | 本轮恢复前提与边界 |
| --- | --- | --- | --- |
| 真实撤销、接手、原约束保持、完整投入与用户接受 | `not_run / authorized_defer`；真实 Work、旧 Attempt、撤销事件、旧执行者停止或隔离证据、新执行者、原目标/验收、质量与总活动成本均缺失 | `C005/validation.md` §C005-T03（行121–127）、§原义务（行147）；`C005/plan.md` §T03 本轮采用范围与未执行义务（行160–162）；原结构化盘点 `C005/evidence/t03/preflight.json` 的 `actual_trial` 全部为 `null`、`result="not_run"` | 先提供真实对象和“普通继续为何不足”的理由。新执行者开始前由操作者确认旧进程已停止或新宿主环境已隔离。操作者报告与实际证据分别记；不把替换响应称为停止或隔离验证 |
| 原要求的 nextest `0.9.145` 门禁 | `not_run`；原要求命令 exit `92`，没有执行测试。历史实际用 `0.9.140` override | `C005/validation.md` 行75、83、115、148；`C005/experiments/runbook.md` §机制验证（行18）；错误原文 `C005/evidence/t01/required-task.txt` 行1–2 | 记录本轮实际工具版本与命令。后来的其他包工具证据不能自动清除 C005 的原版本缺项；只有相同输入闭包和原 run ID 才能明确引用，不称旧命令已跑 |
| 在线 fresh advisory | `not_run`；只有固定 RustSec 缓存快照结果 | `C005/validation.md` 行91、139、149；缓存原文 `C005/evidence/t01/deny-cached.txt`、`C005/evidence/t02/gates-revised.txt` | 缓存 HEAD 为 `117edb3bed98e9be112f277b7615eea3252e7c43`，记录时点 `2026-10-02T10:58:33+02:00`。本轮若采用更新审查，需对应实际 Cargo/lock/policy/features/环境；不得将缓存审查写成在线最新 |
| 其他平台及 Rust `1.85` 测试执行 | `not_run`；历史 `1.85.0` 仅 macOS arm64 locked 全 targets/features 编译 PASS，测试由 `1.98.1` 执行 | `C005/validation.md` 行141、150、160；编译原文 `C005/evidence/m2/msrv-check.txt` | 本轮范围仅 macOS aarch64。平台或编译结论不代替测试；未跑平台和 Rust 1.85 测试继续具体 `not_run` |
| 历史 LEAK | `unknown`；4 个不同原 run/case，原因均未定位。后来的 T02 干净回归不能证明旧运行没有残留 | `C005/validation.md` 行75、83、87、115、127、151；下面四条原文索引 | 只记新运行实际观察到的信号。旧未知保持，不以断言 PASS、进程命令返回或后续无 LEAK 推断永久无泄漏、宿主全进程树关闭 |
| 两次全 cached whitespace 诊断 | `raw_diagnostic_exception`；全 cached 检查 exit `2`，排除指定不可变 raw 后作者范围 exit `0` | `C005/validation.md` 行107、119、152；原结构化结果 `C005/evidence/t04/whitespace-check.json`、`C005/evidence/t02/whitespace-check.json` | 保留 raw 原字节及例外范围；不把作者范围 PASS 改称全 cached PASS。此项是原检查异常边界，不是源码缺陷或真实试用 |

历史 LEAK 的逐条来源如下；同一 case 在同一 raw 中重复出现只记一次：

| 原 run ID | 原 case 与信号 | 原文路径/行 |
| --- | --- | --- |
| `a1295822-a8e8-488a-b5cc-2debf16ec6e5` | `result_selects_terminal_bound_input_and_sealed_output_in_key_order`，LEAK | `C005/evidence/t01/runtime-consumers.txt` 行5、17 |
| `c1f30428-2691-47cf-befc-3821fc4986e7` | `install_modify_path_flag_is_rejected`，LEAK | `C005/evidence/t01/gates-repaired.txt` 行13、18 |
| `f4212b4e-a74c-4857-96e3-2ee4605f1094` | `post_commit_card_failure_returns_committed_response`，FAIL + LEAK | `C005/evidence/t01/future-red.txt` 行5、67；行269是同条输出重复 |
| `e2e42412-cead-461e-a4fc-d11cbf0acf4c` | `generated_reference_keeps_authority_prose_verbatim`，LEAK | `C005/evidence/t03/skill-consumers-revised.txt` 行4、6 |

`usage=null`、`paid_cost=null`、`human_activity=null`、`user_acceptance=null`。本报告没有获得这些事实；Work/Attempt 墙钟不折算人工时间或费用。当前自动 agent 文档交接也不替代历史真人配对、真人宿主重开或净收益义务。

## 3. 首次接续者的来源索引

| 读取顺序 | 原件入口 | 用途与限制 |
| --- | --- | --- |
| 1 | 冻结 task/project；C004 当前 `protocol.md` | 明确本次只能写文档、不能提前 activate 或写 C005；真实消费者先只读准备 |
| 2 | `C005/adoption.md` 行3–11；`C005/README.md` §产品目标、§采用条件 | 明确已采用机械范围、真实需求与停止/隔离的边界、版本和发布限制。README 行24仍保留历史“已移入 active”的表述；当前目录和根入口为 C005 completed、C004 active，不按历史句子提前激活 |
| 3 | `C005/validation.md` §原义务、未执行与未知（行143–160）；`C005/evidence/t03/preflight.json` | 确认真正需补的事实，区分历史预定义 not_run 与后来限定 PASS |
| 4 | `C005/plan.md` §C005-T03（行116–126）、§C005-M2（行128–130）、§T03 本轮采用范围（行160–162） | 明确责任、真实操作、停止和独立验收；这是历史任务卡，本轮若恢复须另明确任务与范围，不能直接把历史 done 改成新义务已完成 |
| 5 | `C005/experiments/runbook.md` §真实接续的前提、§记录停止与交接（行20–38） | 提供同绝对 Home/WorkId 的 status→有理由的 replace→status 命令，真实变量先由任务记录填写，不执行替代样本 |
| 6 | `specs/contracts/protocol.md` §3 `attempt replace`、§6 `resume`；`specs/contracts/storage.md` §5.5 | 现行精确资格、一次额度、输入继承、重放、错误优先级和原子事务规则；合同优先于手册摘要 |
| 7 | `C005/spec.md`；`C005/design.md` §原子替换、§顺序号与失败数、§并发重放与恢复 | 解释普通 resume 与撤销资格不同、完整 caller 和失败前缀；机制测试不作为真实撤销样本 |
| 8 | `C005/verification/commands.sh`；`C005/plan.md` T01/T02 测试清单；`C005/tasks.toml` | 定向机制验证入口与历史任务归属/白名单。当前只交文档，不运行空 task.sh；历史 future-red 是阶段准备证据，不在当前实现上冒充预定失败或产品 PASS |
| 9 | `C005/review.md` §C005-M1、§C005-T03、§C005-M2（行31–61）；`C005/progress.md` 行3–7 | 理解历史独立限定 PASS 的范围，原件/run ID 与缺项保持；审查、实现完成和真实价值分别判断 |

下一协调者的第一个合法准备动作：只读 `C005/validation.md` 行143–160 和 `C005/evidence/t03/preflight.json`，列出本轮能提供的真实撤销对象及证据缺口，并判断是否只有普通续接需求。当前 C004 active 期间不写 C005、不调用替换来制造样本、不激活下一 change。

可直接执行的首动作如下，仅读取已冻结的原件：

```bash
sed -n '143,160p' /Users/shushu/orca/workspaces/sheltie/codex/specs/changes/completed/C005-executor-continuity/validation.md
cat /Users/shushu/orca/workspaces/sheltie/codex/specs/changes/completed/C005-executor-continuity/evidence/t03/preflight.json
```

## 4. 已执行检查与本次剩余工作

本执行者实际执行了 `cat`、`nl -ba`、`sed -n`、`rg`/`rg --files` 读取上述原件；执行 `git status --short`、`git rev-parse HEAD` 只读核仓库状态；执行只读 Python SHA-256 核对 62 个冻结 C005 原件及 task/project，输出 `{"frozen_C005_files":62,"drift":[]}`，task/project 摘要与 brief 一致。这些命令均同步结束，工具返回 exit `0`；原始 stdout/stderr/exit 位于本执行者工具调用记录，由协调者按事前规程收录。本报告不把执行者报告说成引擎已核验仓库或检查。

本次只创建任务书声明的 `outputs/change.md`。未运行 C005 试用、Rust 测试、nextest、cargo deny、docs/specs 全仓库门禁；未 submit/begin/fail/replace，未启动后台、长驻命令或其他 agent，未写其他槽位、管理元数据、仓库或 C005 状态。全仓库文档门禁不作为本外部草稿的内容验收替代物。

同一 running Attempt 的下一执行者仍需独立读取 frozen brief/task/project/原件及本草稿，完成以下内容，再由协调者 submit：

1. 将真实准备和 C004 归档以后 C005 才可执行的步骤分开，补完整 Owner、输入、精确命令和正反判据。
2. 按当前合同核旧提交/失败错误优先级、一次额度、number/failed、输入/标准/gate 保持、重放与只读边界；未执行项继续保留。
3. 核原始工具结果、命令退出事实、输出大小与全部来源路径，更新第一行实际完成程度。独立 review、delivery、三成果封存及下一消费者实际使用尚未发生，不提前记 PASS。
