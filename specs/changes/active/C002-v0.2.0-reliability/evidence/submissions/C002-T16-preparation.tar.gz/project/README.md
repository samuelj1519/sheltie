# 标题工具

本项目用于 C002-T16 的真实 spec-dev 宿主回归，使用 Python 标准库，不联网。

目标：把用户提供的标题规范化，并从 Markdown 文本提取首个一级标题。

验证命令：

```bash
python3 -m unittest discover -s tests -v
python3 -m compileall -q title_tools.py tests
```

实现由 Workbook 任务书驱动，任务提交保留 Task trailer；各任务基线及原始证据由冻结文档指明。
