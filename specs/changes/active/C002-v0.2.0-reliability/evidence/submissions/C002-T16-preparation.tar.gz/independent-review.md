# C002-T16 部分证据与交接独立复核

Reviewer：`Codex /root/t16_evidence_review`。未参与本轮文档、门禁运行、演练或 worker 产物。按 C002 plan 的独立 Reviewer 职责只读检查；报告写作使用 `tech-doc-style-chinese`。范围为本轮 package diff、`/private/tmp/sheltie-c002-t16-82c6c55` 的候选/门禁/请求响应/交付/独立 oracle，以及 `evidence/submissions/C002-T16-preparation.tar.gz`。未重跑长测试，未更改仓库或管理根。

结论：**需修改**。本轮实际门禁、局部 CLI 观察与原文归档基本可信；但把 T04 纯文档任务断定为违反冻结 Workbook 的规则不够准确。以下结论只针对部分证据和交接记录，不能替代完整 T16 验收、旧 M1 最终 Spec 批准或 T17 发布。

## 必要纠正

1. `progress.md` 的 spec-dev 后续动作、`validation.md` 的 spec-dev 未完成项把「T04 纯文档任务」写成确定违规。冻结 `workbook/instructions/plan.md` 和 `resources/checklists/task-rules.md` 第 7 条确实要求每任务填 1—6 个函数体；但同一冻结 task-rules 第 4 条明确允许「没有可测行为的任务（纯文档）写明检查方式」，第 9 条要求最后任务收尾文档。T04 已明确不填函数体，并列人工检查和两条完整门禁。完整输入存在表述张力，不能只选函数体要求忽略纯文档例外。应改为准确记录这项歧义，或按纯文档例外解释其合规性；不得把未经确认的解释写成 planner 已确认缺陷或据此要求用户修改方案。是否附条件、修改方案仍由真人决定。
2. 若交接要长期可独立恢复，建议在 T16 验证段明确归档 SHA256、根层布局和恢复命令。当前紧接其后的恢复命令仍指 `C002-T40.tar.gz`；T16 归档实际直接以 `candidate.json`、`commands/`、`home/` 等为顶层，没有 `C002-T16/` 前缀。T16 tar 不含两份二进制或演练 Git 对象；不能把恢复证据称为已恢复可执行候选或原始 Git 项目。此项是交接可用性改进，不影响已核原文真实性。

## 已核实的证据

- `candidate.json` 记录源码 `82c6c55159592db5cdb485549e933960863de185`、开工干净状态、macOS arm64、Rust 1.98.1 和 289 个 tracked 路径摘要。286 个普通文件与该 commit 的 Git blob 独立一致；3 个 crate LICENSE 为 `120000` 软链，记录的是跟随软链后的 LICENSE-MIT 内容摘要，当前内容一致。当前漂移仅 package 文档，不改源码/测试/配置。候选身份与文档候选一致。
- `gates/results.json` 的全部 stdout/stderr 摘要独立一致。首次默认 Nextest 原文明确报告要求 0.9.145、当前 0.9.140，exit 92；没有测试执行。后续脚本通过 PATH 使用本机 0.9.146 工具，未传版本检查绕过参数。最终原文明确为 `688 tests run: 688 passed (1 slow), 0 skipped`，测试 summary 164.367 秒；记录的 185.402 秒是整条命令耗时，两者不矛盾。core doctest 原文为 5 个 compile-fail 全通过。
- fmt、check、Clippy、deny offline、MSRV 1.85.0、dist plan 和六类文档/静态 gate 的退出码及原文可恢复。deny 使用本地公告缓存，不能推定在线刷新。现有原文不证明文档最终编辑后已重跑 gate，收尾仍应实际核对。
- `gates/build.stdout` 的 Cargo JSON 实际给出 release 可执行路径；`delivery/manifest.json` 的全部交付文件摘要独立一致。`sheltie-bin` SHA256 `eba587d3a6e84578317bd5a0c0b6f677e6632a54924ae06891f86dd92095752d`，与 `home/bin/sheltie` 逐字节相同。原文版本和 dist app_version 均为 0.1.0，文档正确限制为本机候选，未冒充 v0.2.0 rc 身份或四平台发布。
- 逐 CLI 请求/响应、退出码与已有结果摘要一致；原 outline submit 和重放使用同 request-id。独立解析并只去掉 `data.replayed` 后完整结构相同，历史 revision 3；两次当前 status 与终态错误后的 status 完全相同。新 begin 的错误确为 `WORK_TERMINAL`，没有从历史 `next` 推进。
- `artifact-oracle.json` 的 8 个已提交 ArtifactRef，实际长度、hashlib SHA256 与 0444 权限独立全部一致。Finder 前后四文件摘要和权限一致；只能证明已记录的一次访问完整性。真实 UI 访问及 worker 委派身份仍依赖会话工具记录，tar 内没有工具响应原文或截图，文档已说明这一限制。
- gate-status 原文为 blocked(gate)，next 只有 gate approve/cancel；commands 没有 gate approve。plan-review、publish 只保存 begin 原文，未见其人工提交产物。spec-dev 临时 Git HEAD 确为 `2f88d59b0d214967b64b285e96d764f26bc71c30`，任务已验证表为空，没有伪造完成事实。
- tar 实际为 230493 bytes，SHA256 `cf214beb1d6bd8b853e5262dfb613c69a89678603b7f56398b0afa169f203ed3`，324 个普通文件均与本机对应文件逐字节相同；包含门禁/命令原文、skill、产物和 Store 记录。排除二进制、项目 `.git` 对象的边界与本机 archive-manifest 声明一致。恢复证据不等于恢复二进制或发布资产。

## 必须保留的未完成边界

T16 维持 `doing`，T17 维持 `not_run`。本轮未取得 gate 批准、方案决定/人工条件或人工 article final，不能用「继续 C002」代为批准或定稿；article back 回环未跑；真实关闭并重开会话未做；spec-dev 至少两个已验证任务、一次人工条件、一次改方案与全需求交付未完成。Host version/build 与 usage 仍为 null，手动读 skill 不证明新会话自动发现。未指定 Workbook/缺输入的真实人机往返未完成，CLI NOT_FOUND 不等于交互验收通过。

四平台 v0.2.0 实际资产、manifest/checksum/同 SHA quality、指定版本远端更新与 rollback、release record、CHANGELOG 和对外发布尚未完成。dist plan 的四平台资产名字是 0.1.0 计划，不能证明资产存在。Linux、本轮完整变异、旧 M1 SK01/SK02 缺口未由本次通过项补齐。当前 package 记录基本保留这些限制；以上缺口阻止完整 T16/T17 验收，但无需否认本次已核的局部观察。

必要纠正完成并实际复核文档 gate 后，可再对本轮记录给出有限「通过」；仍不得把该结论写成 T16 done 或 M1 Spec 批准。

## 纠正后复核

已复读当前工作树 `README/plan/progress/validation/review` diff。**纠正后结论：通过，仅限本轮部分证据与交接记录的内容。**

- progress/validation 已将 T04 改为 task-rules §4 明确允许的纯文档例外，保留「尚无人工决定/条件、未重规划或实现任务」。validation 保留初次误判及撤回，并明确不记产品 finding、不要求 planner 修复。按完整冻结输入解释纯文档例外是合理的，初次问题已关闭。
- review.md 首段已明确为 M1 历史结论、历史 `not_run` 时点，并指向 plan 的后续进度；未补造旧 M1 Spec 批准或将 T16 升为 done。
- `gates/documentation-results.json` 与 docs/specs/diff-check 原文分别 exit 0；正式 `scripts/check-task.sh C002-T16 82c6c55` 原文 exit 1，明确仅因 plan 的 T16 不是 done。失败被保留，没有放宽 checker、跳过完成条件或提交。该失败不能被「工程门禁通过」笼统覆盖；最终交接应明确分开普通工程 gate 与任务完成 gate。
- 当前 tar SHA `cf214beb…203ed3` 仍绑定纠正前快照。初次 patch 保留为历史并已在文档明示，不冒充纠正后最终材料。实施者计划追加本复核原文、纠正 patch、正式任务 FAIL 和文档 gate 后重建归档；本报告没有预先核准尚未生成的新 tar/hash。新归档需要实际核摘要、字节和文档引用后再称为最终归档。

本轮内容通过不改变上述 T16、T17、Host、人工、旧 M1/SK 缺口。初次「需修改」记录保留；纠正后只批准文档忠实表达当前局部事实与未完成边界。后续仅需核收尾材料实际包含和引用一致，无需因此重跑 688 项或扩为完整 T16 review。
