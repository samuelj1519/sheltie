# 任务清单：规范化标题并提取 Markdown 首个一级标题

按顺序做。每个代码任务是「启用测试、填占位体、过门禁、提交」。测试由骨架预写，使用 `Task: TNN` 注释记录函数和测试归属；不得关闭此前已启用测试。T04 是纯文档收尾，按其检查方式验证。所有任务待实施，每项提交保留对应 `Task: TNN` trailer；没有任何完成或批准事实。

原始基线: 2f88d59b0d214967b64b285e96d764f26bc71c30
继承来源: 无

## 已验证任务

原样复制 plan 的累计行，首次为空。下一次 scaffold/implement 从该前缀之后选择任务，不能重做已验证任务。

| 任务 | 任务基线 | 候选提交 | 审批来源 | 验证报告 | 原始证据 |
| --- | --- | --- | --- | --- | --- |

## T01 规范化 Unicode 空白并拒绝空标题

- 只改哪些文件：`title_tools.py`、`tests/test_title_tools.py`
- 要变绿的测试：`test_normalize_collapses_mixed_unicode_whitespace`、`test_normalize_preserves_chinese_punctuation_and_case`、`test_normalize_rejects_empty_and_whitespace_only`、`test_normalize_keeps_single_word`
- 实现要点：填写 1 个函数体 `normalize_title`，用 Python 标准库的空白定义去掉首尾空白并把内部连续空白合为一个 ASCII 空格；空结果抛出带说明的 `ValueError`。空字符串、ASCII 空格、全角空格和混合 Unicode 空白在预置测试中分别检查，不增加依赖。
- 做完能观察到什么：启用本任务四项测试后运行两条完整门禁；包含全角首尾空白及不换行空格、制表符、换行的输入得到 `AbC 你好，世界！`，空白输入全部拒绝。
- 保留的验收要求：规格 1、2；规格 8 的标准库及不联网限制；规格 9 的两条门禁；规格 10 的任务独立提交和 `Task: T01` trailer。通过事实仅由独立验证追加。

## T02 按行提取首个严格匹配的一级标题

- 只改哪些文件：`title_tools.py`、`tests/test_title_tools.py`
- 要变绿的测试：`test_extract_ignores_nonmatching_heading_prefixes`、`test_extract_normalizes_first_heading`、`test_extract_chooses_first_matching_heading`、`test_extract_rejects_missing_heading`、`test_extract_rejects_empty_first_heading_without_fallback`
- 实现要点：依赖 T01，填写 1 个函数体 `extract_title`，按行顺序查找 `# ` 前缀，规范其内容后立即返回；没有匹配时抛出带说明的 `ValueError`。首个匹配内容为空时传播拒绝，不跳到后续标题；不接受前导缩进、二级标题或 `#` 后缺空格，不解析语法上下文。
- 做完能观察到什么：启用本任务五项测试后运行两条完整门禁；规格中的二级、缩进、缺空格行被忽略，首个匹配中的连续制表符合为一个 ASCII 空格，后续有效标题不影响结果。
- 保留的验收要求：规格 3、4；规格 8 的标准库及不联网限制；规格 9 的两条门禁；规格 10 的独立提交和 `Task: T02` trailer。

## T03 提供只读 UTF-8 文件提取与两个命令行子命令

- 只改哪些文件：`title_tools.py`、`tests/test_title_tools.py`
- 要变绿的测试：`test_cli_normalize_prints_one_line`、`test_cli_extract_uses_explicit_utf8_file_and_preserves_bytes`、`test_cli_normalize_rejects_whitespace`、`test_cli_extract_rejects_missing_heading`、`test_cli_extract_rejects_empty_first_heading`、`test_cli_extract_rejects_non_utf8_file`、`test_cli_extract_rejects_missing_file`、`test_cli_extract_reports_unreadable_file`、`test_cli_rejects_missing_required_arguments`、`test_cli_rejects_unknown_subcommand`、`test_cli_runs_without_site_packages`、`test_imports_are_standard_library_only`
- 实现要点：依赖 T01、T02，填写 3 个函数体 `read_markdown`、`build_parser`、`main`，显式使用 UTF-8 只读文件，normalize 和 extract 各接受一个位置参数。成功 stdout 只有标题与一个换行且 stderr 为空；捕获规范化、读取和解码失败，stderr 有原因、stdout 为空、退出 2；参数错误遵循 argparse 的退出 2，所有已有输入文件在成功和失败前后按字节核对。
- 做完能观察到什么：启用本任务十二项测试后运行两条完整门禁；子进程实际执行 `python3 -m title_tools normalize`、`python3 -m title_tools extract` 的成功及全部错误用例，核 stdout、stderr、退出状态和原文件字节。额外以 `python3 -S -m title_tools` 覆盖两子命令的成功与失败，核项目无第三方声明及导入；独立验收另保留禁止联网和不可读文件的真实宿主证据。
- 保留的验收要求：规格 5、6、7 全部；规格 8 的无第三方、禁止联网环境及成功失败行为；规格 9 的两条门禁；规格 10 的独立提交和 `Task: T03` trailer。无法证明文件确实不可读或环境禁止联网时，对应验收不得标通过。

## T04 收尾使用说明与验收交接

- 只改哪些文件：`README.md`
- 要变绿的测试：纯文档任务，无新增或停用测试；人工逐项检查下述说明与需求一致，并运行两条完整门禁。
- 实现要点：依赖 T01—T03，不填函数体。写两个函数及两个子命令的示例、UTF-8 文件参数、首个严格 `# ` 前缀和首个空标题拒绝规则，说明 Unicode 空白、汉字标点大小写保留、只读文件、成功输出和错误退出 2；保留标准库、不联网、门禁命令及 Task trailer 约定，不记录没有证据的验证通过。
- 做完能观察到什么：打开 README，首次读者能按示例运行两个子命令并理解所有失败边界；逐项比对规格 1—10 的说明及 T01—T03 的测试映射，执行两条门禁均成功后独立提交。需将验收 8 的真实环境证据和验收 10 的真实用户确认记录交接给独立验证者；缺失事实原样标未完成。
- 保留的验收要求：规格 1—9 的完整行为、限制及验证入口；规格 10 的至少三个小任务、每任务 `Task: TNN` trailer，以及人工审批、一次条件和改方案前的真实用户明确确认。计划没有提供这些确认，实施者不可自行补造；当前“一次条件”名称和结果待真实用户明确。

## 骨架与验证交接约束

- 骨架为 T01—T03 预写全部五个函数签名、任务占位体和二十一项测试，按以上归属禁用尚未实施的测试；实现时只启用当前任务的预置测试，每次都跑 README 的两条完整门禁。
- 每项提交后记录任务基线、候选提交和门禁真实 argv、stdout、stderr、退出状态；保留现有输入文件的前后字节证据。任务自报或提交存在不向本清单的已验证表追加行。
- 未绑定任何 decision 或旧验证，不存在继承事实。真实用户批准方案或要求改方案后，协调者按 Workbook 转交实际确认材料；“一次条件”未经明确确认时停在对应动作，不自行决定其名称或结果。
