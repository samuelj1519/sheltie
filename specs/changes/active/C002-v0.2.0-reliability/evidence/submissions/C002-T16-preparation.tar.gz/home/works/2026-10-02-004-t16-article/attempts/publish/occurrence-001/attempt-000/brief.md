# 任务书：定稿

Work: 2026-10-02-004-t16-article（t16-article）
节点: publish#1，第 0 次尝试
来自: review#1（main 边）
执行者: human

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| article | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-004-t16-article/attempts/draft/occurrence-001/attempt-000/outputs/article.md | e271c307a132e146c649120e5e957a5fb1a6da7cc412dd2688b9292db541c2a4 |
| review | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-004-t16-article/attempts/review/occurrence-001/attempt-000/outputs/review.md | 9a51fc8d1c2f780f0b894e5c112a96e6e64540b43c0df17811f5ca55ebe4ff57 |

## 说明

阅读审查通过的文章，确认可以发布。把最终版复制到 final.md。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| final | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-004-t16-article/attempts/publish/occurrence-001/attempt-000/outputs/final.md | 是 | 1 MiB |

写完输出文件后，在终端运行：

    sheltie attempt submit 2026-10-02-004-t16-article --attempt publish#1.0 --summary "<一句话结论>"
