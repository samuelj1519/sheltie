# 任务书：列提纲

Work: 2026-10-02-001-t16-two-step（t16-two-step）
节点: outline#1，第 0 次尝试
来自: 入口
执行者: agent（standard）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| topic | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-001-t16-two-step/start-inputs/topic | 5f8f5b88dff5e2820de92f6976302064d009b8cdf672d7e707b8d2d985dcefdc |

## 说明

读 `topic`，围绕它列一份提纲。

- 三到六个一级要点，每个要点下一到三个子点。
- 每个要点一句话说清要讲什么，不展开。
- 用简体中文，Markdown 列表。

把提纲写到任务书「输出要求」里 `outline` 对应的路径。回复协调者时说一句：几个要点，主线是什么。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| outline | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-001-t16-two-step/attempts/outline/occurrence-001/attempt-000/outputs/outline.md | 是 | 64 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
