# 任务书：生成发布说明

Work: 2026-10-02-002-t16-gate（t16-gate）
节点: notes#1，第 0 次尝试
来自: 入口
执行者: agent（standard）

## 输入

| 名称 | 路径 | sha256 |
| --- | --- | --- |
| version | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-002-t16-gate/start-inputs/version | f1b5b86521a920535516851c9ce9230bec178eaace4a094ad69db1369ff1ed01 |

## 说明

读 `version`，为这个版本写一份发布说明。

- 标题写版本号。
- 分「新增」「修复」「已知问题」三节，没有内容的一节写「无」。
- 每条一行，面向使用者，不写实现细节。

写到 `notes` 对应的路径。这一步有门槛：你提交后，人会读这份说明并批准，之后流程才继续。回复协调者时说一句：三节各几条。

## 输出要求

| 名称 | 写到 | 必需 | 上限 |
| --- | --- | --- | --- |
| notes | /private/tmp/sheltie-c002-t16-82c6c55/home/works/2026-10-02-002-t16-gate/attempts/notes/occurrence-001/attempt-000/outputs/notes.md | 是 | 64 KiB |

完成后不要自己修改输入文件。回复协调者时用几句话说明结论，并列出你写了哪些输出文件。
