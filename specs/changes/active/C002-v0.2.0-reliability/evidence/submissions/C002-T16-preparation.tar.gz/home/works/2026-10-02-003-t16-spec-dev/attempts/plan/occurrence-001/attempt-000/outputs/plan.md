# 技术方案：规范化标题并提取 Markdown 首个一级标题

## 现状

- 项目根目录为 `/private/tmp/sheltie-c002-t16-82c6c55/project`，绑定的 `start-inputs/project` 文件记录此路径。
- `README.md` 声明使用 Python 标准库、不联网，并规定 unittest 与 compileall 两条验证命令。
- `tests/.gitkeep` 仅保留测试目录，目前没有业务代码、测试实现、AGENTS.md、构建配置或 CI 工作流。
- 新增单文件模块 `title_tools.py` 后，通过 `python3 -m title_tools` 提供命令行入口。
- 本次为首次规划，未绑定旧方案、旧任务、变更或验证记录，尚无已验证任务。

## 改法

- 骨架阶段新增 `title_tools.py`，预写 `normalize_title(text: str) -> str`、`extract_title(markdown: str) -> str`、`read_markdown(path: str) -> str`、`build_parser() -> argparse.ArgumentParser`、`main(argv: list[str] | None = None) -> int` 的签名和任务占位体；模块入口调用 `SystemExit(main())`。预写 `tests/test_title_tools.py` 的全部测试，使用函数和测试附近的 `Task: TNN` 注释标记归属；各任务只启用自己的预置测试，不关闭既有已启用测试。
- T01 在 `title_tools.py` 填写 `normalize_title`，以标准库 Unicode 空白定义拆分并用一个 ASCII 空格连接，拒绝空结果；汉字、标点与大小写原样保留。
- T02 在 `title_tools.py` 填写 `extract_title`，按原文行顺序找首个严格以 `# ` 开头的行，将井号和一个空格之后的内容交给 `normalize_title`；没有匹配或首个匹配为空时立即拒绝。不解析 Markdown 上下文，不接受缩进、二级标题或缺空格的井号行。
- T03 在 `title_tools.py` 填写 `read_markdown`、`build_parser`、`main`：文件显式按 UTF-8 只读；argparse 提供 normalize 的标题参数和 extract 的文件名参数。成功只写规范标题及一个行尾换行到 stdout；输入、读取或解码错误只在 stderr 说明原因并返回 2，缺参数和未知子命令使用 argparse 的错误处理。
- T04 修改 `README.md`，记录两个函数、两个子命令的用法、Unicode 空白规则、提取边界、退出码、标准库及不联网限制，并保留现有两条门禁命令和 Task trailer 约定。
- 每个任务独立通过全部门禁并提交，提交保留对应 `Task: TNN` trailer；逐任务候选、自报和真实用户确认均不能替代后续独立验证。需求验收 1—10 全部保留，覆盖映射见 tasks；所有任务当前待实施。

## 门禁

每个任务做完都要全部通过。命令取自项目 README，在项目根目录运行；本次仅规划，未执行这些门禁。

```bash
python3 -m unittest discover -s tests -v
python3 -m compileall -q title_tools.py tests
```

## 基线

原始基线（Work 开始时的 `git rev-parse HEAD`；改方案从上一版原样抄这一行，不重设）：`2f88d59b0d214967b64b285e96d764f26bc71c30`

## 风险

- 需求中的“一次条件”名称及本次结果尚未确定。任何人工审批、一次条件或改方案动作必须先取得真实用户明确确认并记录；本方案不是批准记录。对应动作无确认时停止，由协调者请求真实用户确认后恢复，不猜测条件或代签。
- “无法读取”的文件用例在高权限宿主中可能绕过文件权限。测试应在可证明拒绝读取的条件下运行并保留结果；无法形成该条件时停止该项验收并交接缺口，不能将其标为通过。
- 仅 `# ` 前缀符合规格；首个匹配为空、代码围栏中的匹配或 Unicode 空白均不得自行改成另一种 Markdown 解析语义。验收出现歧义时停在当前候选，交回真实用户决定是否改方案。
- “禁止联网且未安装第三方包”的环境需独立验证时证明，T03 用 `python3 -S` 运行子命令可排除 site-packages，但这本身不证明网络被禁止；需保留宿主禁止联网的实际证据。缺证据时验收 8 不通过，不宣称宿主资格。
- 白名单或任务大小不足以容纳实现时停止并报告具体新增文件或接口需求，不能悄悄扩范围。恢复仅保留或修正本任务白名单内的候选，不改输入 Markdown，也不撤销他人编辑；必要时由真实用户确认改方案。

## 修订记录

- 2026-10-02 初版；依据绑定 spec、模板、任务规则和项目 README 规划四项待实施任务，记录完整原始基线；未记录人工批准、门禁通过或任务完成。

## 已验证任务

继承来源: 无

保留已独立验证的原始行；实现者的自报不算验证。首次为空表。

| 任务 | 任务基线 | 候选提交 | 审批来源 | 验证报告 | 原始证据 |
| --- | --- | --- | --- | --- | --- |

## 需重验事项

无。首次规划，全部验收仍待实施及独立验证。
