import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/Users/shushu/orca/workspaces/sheltie/codex');out=Path('/private/tmp/sheltie-t39-evidence/gates');out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(PATH=str(root/'target/t31-validation/tools')+':'+env['PATH'],CARGO_TARGET_DIR='/private/tmp/sheltie-simplify-t38-target',RUSTC_WRAPPER='',CARGO_NET_OFFLINE='true',NEXTEST_TEST_THREADS='2')
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','deny.toml','.config','examples','workbooks','skills','scripts','.github'],cwd=root,text=True).splitlines()
inputs={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if (root/p).is_file()}
(out/'input-files.json').write_text(json.dumps(inputs,indent=2)+'\n')
commands=[('fmt',['cargo','fmt','--all','--','--check']),('check',['cargo','check','--all-targets','--all-features']),('clippy',['cargo','clippy','--all-targets','--all-features','--','-D','warnings']),('nextest',['cargo','nextest','run','--all-features','--no-tests=pass']),('deny',['cargo','deny','--offline','--config','/private/tmp/sheltie-t38-gates/deny.toml','check']),('docs',['scripts/check-docs.sh']),('specs',['scripts/check-specs.sh']),('core-vocab',['scripts/check-core-vocab.sh']),('tests',['scripts/check-tests.sh']),('skill',['scripts/check-skill.sh']),('msrv',['cargo','+1.85.0','check','--workspace','--all-targets','--all-features','--locked']),('dist',['/Users/shushu/.cargo/bin/dist','plan'])]
results=[]
for name,argv in commands:
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
 record={'name':name,'argv':argv,'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3)}
 for channel in ['stdout','stderr']:
  record[channel]=str(out/(name+'.'+channel));record[channel+'_sha256']=hashlib.sha256(Path(record[channel]).read_bytes()).hexdigest()
 results.append(record)
 (out/'results.json').write_text(json.dumps({'HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'env':{k:env[k] for k in ['CARGO_TARGET_DIR','RUSTC_WRAPPER','CARGO_NET_OFFLINE','NEXTEST_TEST_THREADS']},'nextest':'0.9.146','input_sha256':hashlib.sha256((out/'input-files.json').read_bytes()).hexdigest(),'results':results},indent=2)+'\n')
 print(name,'exit='+str(result.returncode),str(record['seconds'])+'s',flush=True)
 if result.returncode:
  print(Path(record['stderr']).read_text()[-8000:],flush=True);break
