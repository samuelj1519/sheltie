# C002-T39 F38-03 局部实施与验证

Owner：/root/fix_flow_ids；仅改 `crates/sheltie-runtime/src/workbook_repo.rs`，新建 `crates/sheltie-cli/tests/flow_identity.rs`。未提交、未改 specs/依赖、保留既有 T38 和其他 agent 改动，已停止编辑。

依据：Workbook 合同 §3 Flow id 在 Workbook 内唯一；§4 规则 1 所有 ID 合规唯一；protocol §7 FLOW_INVALID 带 detail.path/detail.rule，提交前无 Workbook 行或最终目录，允许私有未提交 pending。

生产修改仅 8 行：完整最终副本的 load_tree 在 parse_flow 后通过 BTreeSet 校验跨文件 Flow id，重复返回 FlowInvalid(rule="1", path="flows/second.toml.id", reason含重复ID)。add 在 COMMIT 前调用此入口；public load_dir/load_managed_dir 共享该规则。有效 Workbook 不改变 I/O、编译、摘要或响应顺序。既有 load_checked_request 的严格 snapshot.flows 唯一性校验保留；不迁移清理既有坏 Store。

新测 4 项：不同 id 的两图可 add/show/start；仅改第二 id 的重复图准确拒绝且全业务/request/audit/sequence零行和final不存在，随后无关合法 add 与同 request-id 修源重试成功；public load_dir 同样拒绝/接受；历史坏已提交 snapshot 保持拒绝，原 reply_json/effects_json/published 原值保留，不登记被阻断请求，不自动修复清库。

环境：`RUSTC_WRAPPER=`、`CARGO_TARGET_DIR=/private/tmp/sheltie-f39-flow-target`、`CARGO_NET_OFFLINE=true`、`PATH=$PWD/target/t31-validation/tools:$PATH`；所有 CLI/runtime 使用独立临时根。HEAD `4b86279a863f941cc282fa6cb772f7359fda585a`；Cargo.lock sha256 `76621d1d7ec8056f3817c3e647dd5f34fca13f6c14345353ce550f7b4dc6de19`。

完整输出与命令（cargo 前缀为上面 env）：

- `/private/tmp/sheltie-t39-flow-red.log`：`cargo test -p sheltie-cli --all-features --test flow_identity -- --nocapture`，exit 101，首 3 项 1 PASS/2 FAIL；真实 add EFFECT_PENDING 与 public load_dir 误接受重复 ID。首次装入 fixture 的路径别名问题先修为规范管理路径后，保存此有效红输出。
- `/private/tmp/sheltie-t39-flow-green.log`：同命令，exit 0，最终 4/4 PASS。
- `/private/tmp/sheltie-t39-flow-cli-regression.log`：`cargo test -p sheltie-cli --all-features --test flow_identity --test workbook --test replay --test scenario_workbook_lifecycle`，exit 0；首 3 新例与 29 原有例共 32/32 PASS；新增历史 guard 第4例由最终 green 验证。
- `/private/tmp/sheltie-t39-flow-runtime-regression.log`：`cargo test -p sheltie-runtime --all-features --test workbook_repo --test workbook_txn --test workbook_identity`，exit 0；各组摘要见完整输出。
- `git diff --check` 与 owned files `rustfmt --edition 2024 --check`，exit 0。

冻结 owned 文件 sha256：`workbook_repo.rs` = `2588020821335bed785257afbc9d3246664dfa23d53e3da6355ae7f98ed6558c`；`flow_identity.rs` = `deaead3758f38c53c38a1b2cd8d53c177cad2ca930753690083a1357cb506dfa`。全仓 gate 和独立 review 由父 agent 统一执行；不把历史 M1/变异通过推给本候选。
