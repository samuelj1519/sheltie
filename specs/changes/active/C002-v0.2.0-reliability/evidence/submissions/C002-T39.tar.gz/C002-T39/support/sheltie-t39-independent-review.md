# C002-T39 三项修复独立审查

结论：**通过**。F38-03、F38-02、F38-01 的本次增量均无未关闭的阻断 finding。

Reviewer：`/root/review_repairs`。未参与生产代码、测试或仓库文档编写；仅只读审查及写本临时报告，未运行全仓门禁、未提交。Owner 按审查建议补的目录替换用例已复核。

范围以 HEAD `4b86279a863f941cc282fa6cb772f7359fda585a`、`/private/tmp/sheltie-t39-evidence/input-hashes.json`、`input-worktree.patch` 区分已有 T38 简化与 T39 新增；T38 保持行为的既有 diff 不冒充本次修复。依据为当前 CONTEXT、specs 入口、engineering §2.2/§3/§5、Workbook 合同 §3/§4、storage §1.2/§3.3、protocol §5/§7，以及 D-037。

## 逐项结论

| 缺口 | 结论 | 源码与真实调用链 | 独立正反例及拒绝边界 |
| --- | --- | --- | --- |
| F38-03 重复 Flow id | 通过 | `WorkbookRepo::load_tree` 在 parse 后跨文件校验 id，给 `FLOW_INVALID` rule=1 与重复字段路径；`add` 只装入最终私有副本，并在其后 COMMIT。`load_dir` / `load_managed_dir` 共用规则；`load_checked_request` 的历史 snapshot 唯一性校验仍保留 | `flow_identity.rs` 用两份不同路径、仅改变第二 id 的真实 CLI 对照；重复拒绝后 workbooks/works/requests/audit/work_sequence 均零行，final 不存在，无关合法 add 与修源后的同 request-id 重试成功。两图合法 add/show/start 可用。历史坏 snapshot 仍 EFFECT_PENDING，不改 reply_json/effects_json/published，不登记被阻断的新请求，不自动迁移或清库 |
| F38-02 嵌套未知字段 | 通过 | `AttemptId` 与全部 `WorkStatus` 形状增加 `deny_unknown_fields`，合法 Serialize 形状未改。Store `decode_row`、完整 `PersistedResponse` / Reply / NextOp 与 `Command` audit 装入真实入口均使用该严格类型；成功 original 构造晚于完整元数据与 audit 校验 | Core 单元覆盖未知字段首/中/末位置、各合法 status 与 blocked reason、乱序合法字段及精确序列化。`strict_state.rs` 真实 CLI 覆盖 state 外层/AttemptId、四种 WorkStatus、历史 Reply/NextOp 与 submit/fail audit 的单字段反例；合法历史快照在 Work 后续取消后仍原样重放。拒绝报告 STORE_CORRUPT 或 EFFECT_PENDING/cause=STORE_CORRUPT，不放成功 original/pending_original，全业务表及 workbooks/works/pending 文件内容保持原值 |
| F38-01 tmp 过期维护 | 通过 | CLI `dispatch` 在业务输出后只对成功 Work/Workbook/self 写调用 `Home::cleanup_tmp`；只读、self version、失败不调用。Home 只获取既有管理根写锁；root/.lock 在获锁后复核，维护不创建 root/.lock/tmp。`ManagedFs::cleanup_expired_tmp` 只枚举 tmp 直接子项，验证锁/root/tmp，以 dev/inode 比对文件/目录观察与打开对象，再核 mtime；目录依自己的 mtime 判断并按句柄遍历；叶链接只 NOFOLLOW stat 与 unlink 本身。`tmp_entry_expired` 纳秒精度严格 >24h。异常项、硬链接及身份变化保留并转 stderr，outcome/退出码/快照不改 | 真实 CLI 覆盖 stale file/完整 abandoned store-init 树删除、recent/future 保留、pending 保留、读/失败不清、self 写触发、hardlink 告警下成功历史响应精确重放、叶/嵌套链接根外字节权限保持、FIFO 不阻塞保留。私有删除原语覆盖 future/exact24h/+1ns 的实际文件与目录删除。新增第7例复用 `delete_before_root_unlink(tmp-cleanup)`：将旧打开目录移名并放替代哨兵树，释放后业务仍成功且回复仅 replayed 不同，stderr 告警、替代哨兵原字节保留、旧空目录未误 unlink |

## 证据核对

审查者已读取完整局部红绿原文；失败为运行时行为，非编译失败。只读取 Owner 已运行日志，未自行重跑测试。

- Flow：`/private/tmp/sheltie-t39-flow-red.log` 为 1 PASS / 2 FAIL，明确真实 add 先提交后返回 EFFECT_PENDING、load_dir 误收重复 id；`/private/tmp/sheltie-t39-flow-green.log` 最终 4/4 PASS。
- 严格解码：`/private/tmp/sheltie-f39-decode-core-red.log` 两项运行失败、`/private/tmp/sheltie-f39-decode-core-green.log` 2/2 PASS；`/private/tmp/sheltie-f39-decode-cli-red.log` 四项因坏嵌套字段仍成功而失败，`/private/tmp/sheltie-f39-decode-cli-green.log` 4/4 PASS。
- tmp：`/private/tmp/sheltie-t39-evidence/tmp-red.log` 为 1 PASS / 3 FAIL，缺失实际删除和维护诊断；`/private/tmp/sheltie-t39-evidence/tmp-green-reviewed.log` 最终 7/7 PASS；`/private/tmp/sheltie-t39-evidence/tmp-exact.log` 唯一目标单元 1/1 PASS，其他 binary 的 filtered 0 不算用例。
- `git diff --check` 审查时通过。

## 冻结输入

| 文件 | SHA-256 |
| --- | --- |
| crates/sheltie-runtime/src/workbook_repo.rs | 2588020821335bed785257afbc9d3246664dfa23d53e3da6355ae7f98ed6558c |
| crates/sheltie-core/src/ids.rs | c90367c5b163f416ab61fd6df22a68150e44c2879c9625d83261214d904bd1e0 |
| crates/sheltie-core/src/work/state.rs | 31f045f1a9213e62ca6ee0b31d48e30c3c89e7a4b6e4fbe0ce3306c1a4f996e7 |
| crates/sheltie-runtime/src/fsx.rs | e34cbfbe986e6f12f1de8a6cc0f0ad119cfcd2f23d5b1453715eba1db8c9ad71 |
| crates/sheltie-runtime/src/home.rs | ceb85d8c5ea3ebac066b7288070f88dfcadfc626512268d77c034b2c6027cd3e |
| crates/sheltie-cli/src/commands/mod.rs | b3be3b2657836fb1ba9552b01e52d10c7b378ce1aad56f738bc2b11af866d72f |
| crates/sheltie-cli/tests/flow_identity.rs | deaead3758f38c53c38a1b2cd8d53c177cad2ca930753690083a1357cb506dfa |
| crates/sheltie-cli/tests/strict_state.rs | 10f3f211f02ff1046bddb555b5dbd2e61d087c8f6a10656b05f2c797d5889ca2 |
| crates/sheltie-cli/tests/tmp_cleanup.rs | 2fea640a83cf207f6bd17f8210dc276380263cdde91bda28ebd9f381491c316b |

此结论只覆盖本候选的三项修复、所列调用链和局部证据。普通全仓门禁由父 agent 单独记录；不将局部修复或旧候选验证扩大为本候选的完整变异、M1、Linux、Host 或发布结论。D-037 明定不声称阻止同 OS 账户任意移动整个目录，本审查不添加用户隔离保证。不改写 plan 既有里程碑/豁免边界。
