# C002-T17 单平台发布前独立核验

Reviewer：`Codex /root/t16_reopen_review`。未参与候选修改、CI 操作、artifact oracle 或安装操作；只读核实际 API 结果文件、quality 原文、301 项源输入、完整 manifest、压缩包和 fresh CLI。仅写本文，不改源码、档案、状态或其它报告，不重跑 700 项、不网络写或发布。

结论：**发布前条件通过，可以按用户已给单平台许可，以候选 `8455aed2bcd9ac1739852be3987091a0975e7ac3` 执行 v0.2.0 tag/release。** 许可只覆盖本版 macOS aarch64。必须让 tag 指向该候选，保留实际发布流程的同 SHA quality/asset gate，发布后再核真实远端、结果字节与生命周期；本报告不预称 Release 成功或 T17 done。

## 实际 CI 与同 SHA 质量

实际 `ci/37036267252-final.json` 为 [Release run 37036267252](https://github.com/samuelj1519/sheltie/actions/runs/37036267252)，event pull_request、headSha 为 8455aed 完整候选、status completed、conclusion success。quality、plan、唯一 ARM local artifacts、global artifacts 均 success；host/announce 均 skipped，符合 PR 不发布。没有用两个 skipped 发布 job 冒充已发布。

`37036267369-final.json` 为 [build run 37036267369](https://github.com/samuelj1519/sheltie/actions/runs/37036267369)，相同 headSha、success；docs、MSRV、build-rust(macos-14) 均实际 success。source 尚未漂移：当前 HEAD 正是该候选，工作区干净。

quality asset 的 candidate.txt 同时给出 candidate/checkout 两份完整相同 SHA、run ID 37036267252、attempt 1，commit.txt 也定位该候选，result.txt 为 quality_result=success。tools.txt 实际 host=aarch64-apple-darwin、rustc/cargo 1.99.0、MSRV Cargo 1.85.0、Nextest 0.9.146、deny 0.20.2；不是 Linux native 或旧 T16 0.1.0 质量记录。

Reviewer 核全部 quality step conclusion 都 success，docs/specs/skill/core-vocab/test-governance、fmt、check、Clippy、deny、Nextest、MSRV 的实际原文齐全。fmt.log 为空，由实际对应 step success证明退出；check/Clippy/MSRV 原文均正常 Finished，deny 原文 advisories/bans/licenses/sources ok。Nextest summary 实际为 **700/700、0 skipped、209.038 秒**。这是新的 native Mac run，与此前本机 165 秒运行分开；不扩为完整安全或变异。

`source-sha256.json` 的 301 个唯一 tracked 路径与当前 Git tracked 集合完全一致，每个实际文件 SHA256 逐项匹配，零缺失、零漂移。checked out commit 与源码清单共同支持本候选输入闭包；软链 LICENSE 的摘要依既有记录口径跟随到内容，不单独冒充 Git mode 证明。

## 实物、摘要和完整 manifest

实际 local artifact 只有 `sheltie-cli-aarch64-apple-darwin.tar.xz`，**1779920 bytes**，Reviewer 独立 hashlib 结果为 `7a80f8b1e6c4334a102f7bbf3b9ee3eda12a74ec9179cf7e95dd3a2b88811033`。该值同时匹配独立 .sha256 文件、global sha256.sum、完整 local manifest 和 global manifest。

local 完整 manifest SHA256 为 `81764e7e32b8e5a656b69e5fec8ab19aa2ef9e1349628a0d51504dcd0895d493`；release app_version=0.2.0，artifact target_triples 只有 aarch64-apple-darwin，checksum 引用准确。plan/local/global 的 release artifact 清单一致，仅有 ARM tar/checksum和通用 installer/source/总摘要；没有 Intel/Linux tar。source.tar.gz SHA256 为 `e66ab9763ccea6c10f7d9b2542b7042c2315d7a94b5a72859278e4a6f7f1e94b`，与自身 checksum、global manifest 一致；Git archive 的 pax comment 明确为同一完整候选 SHA，298 个普通文件逐字匹配，3 个 crate LICENSE 软链均保留根内相对目标。

Reviewer 在内存中读取包，成员只含根目录、sheltie、LICENSE-MIT、README、CHANGELOG；没有链接或逃逸路径。binary 实际 SHA256 为 `a220309ab437a5de52202acb8b8f933370a45969e2027c55964930818e315130`；独立解析 Mach-O magic `0xfeedfacf`、CPU type `16777228`（ARM64）、executable file type 2。三个文档与候选当前字节相同，README/CHANGELOG 的平台范围没有回退。

generated installer 和 release manifest 只选择 ARM 包。quality-8455 及 cargo-dist-cache 独立 workflow artifacts 不混入发布资产；announce 仅下载本 run 的 artifacts-*，仍受 tag push/publishing、host/quality success门槛，不因此次审查放宽权限或追加其它平台。

## Fresh 实际安装

CI 包 binary 与 `delivery/final-ci-sheltie`、`final-ci-install-home/bin/sheltie` 三份实际字节完全相同，均为上述 a220309a 摘要。`commands/final-ci-self-install` 在独立新 home 实际 exit 0、already_installed=false；`final-ci-self-version` 实际 exit 0、version 0.2.0/schema 2/platform aarch64-apple-darwin。argv 与 stdout/stderr SHA256 均独立匹配 result.json，没有拿此前本机构建 c0b509 或历史 T16 bytes 替代 CI 实物。

## 许可与后续完成边界

用户主动原话「可以仅发布 macOS aarch64 。其余平台以后有需求再增加」和执行条件在 `ci/single-platform-authorization.json`；前阶段报告已经独立核其范围。现在同 SHA quality/实际 ARM 包/fresh 安装条件齐全，可以在该许可内执行本候选 tag/release，无需重复请求相同批准。核验时本地 v0.2.0 tag 仍未存在；Owner 的远端只读 404 检查与本次尚未发布的阶段范围一致。

发布 job 的实际成功及上传后的包/manifest/checksum/skill/source 清单还须继续核；tag CI 若重新构建产生不同实际摘要，应使用该 tag run 的真实结果重新比对，不能套用本 PR run 的值。真正远端固定版本 update/rollback、schema1 原字节与新 schema2边界、实际 release record和 C002 lifecycle 在发布后补核，再判断 T17 完成。

后续 updater 起点若使用 T16 的 0.1.0 identity/schema2，只能称同 schema 旧候选→新发布包的下载/替换/rollback演练；它不是已发布 schema1 v0.1.0 无迁移升级。旧发布 schema1拒绝与真实字节保存仍由对应独立反例证据支持，不能混为一条结果。

Linux 编译/Clippy FAIL、Intel/四平台历史事实及本版 excluded_by_user保留，不能把授权披露 PASS写成其它平台执行 PASS。M1/SK01/SK02、215 项额外变异/最终 Spec批准缺失、usage=null、T16历史0.1.0和手动 skill/Host边界都不扩大。本报告只批准已经实测的 macOS aarch64发布前闭包，不声称完整安全/变异或全 Host资格。
