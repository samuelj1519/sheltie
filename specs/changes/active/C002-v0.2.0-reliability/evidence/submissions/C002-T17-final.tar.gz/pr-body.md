## Summary

C002 修复请求重放、Store/文件边界和事务恢复，并固定 v0.2.0 发布输入。

```diff
- schema 1 / cli-result/v1 / 旧 Attempt 布局
+ schema 2 / cli-result/v2 / workbook-digest/v2 / 当前 WorkLayout
- PR 只 plan，默认 merge SHA
+ PR head SHA → macOS aarch64 构建 + 同 SHA 原生 Mac quality → 保存原文；不发布
```

候选 `8455aed2bcd9ac1739852be3987091a0975e7ac3`。本草稿仅验证候选，T17 保持 doing；用户已明确允许本版仅发布 macOS aarch64，实物与同 SHA 质量独立核验后发布，再完成远端验证与生命周期。

## Evidence

- **Before:** 旧 completed checker 误读历史事实表；首修又放行空字段、多列藏 PASS，四条独立反例真实为红。
  **After:** 精确非空六列表拒绝反例，22/22 治理测试通过；候选完整 Nextest 700/700、零跳过，doctest 5/5 和工程门禁通过。
- 首次真实 Linux 构建因三处 permission mode 的平台位宽不匹配而失败；保留原 constructor，仅按目标类型无损转换。本机新 700/700、5/5 与独立审查通过，用户随后明确本版本可忽略 Linux，既有失败保留为 excluded_by_user；当前仅发布 macOS aarch64，其他平台按用户决定排除。原失败与修复原文见 C002-T17-linux-mode.tar.gz。
- 本地准备阶段的隔离安装、完整 manifest 镜像更新/rollback 和已发布旧 schema 反例见 C002-T17-preparation.tar.gz；最终Mac aarch64 实物和真实远端仍待当前候选实际验证。
- 历史 M1 的 SK01/SK02、215 项额外执行、Linux 原运行和 usage 缺失保留，不记完整安全或变异 PASS。

## Merge Danger

**Door:** two-way

代码可回退；schema 1 与 schema 2 管理根必须分开，binary rollback 不转换 Store。本 PR 不合并、不发布，不改真实用户 home。

**Blast Radius:** Store

新版本拒绝旧格式并保留原数据；现有 CLI 消费者需采用 cli-result/v2。
