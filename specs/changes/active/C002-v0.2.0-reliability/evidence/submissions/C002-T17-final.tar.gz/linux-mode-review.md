# C002-T17 Linux 权限参数修复独立审查

Reviewer：`Codex /root/t16_reopen_review`。未参与修复或 CI 操作；只读核锁定 rustix 1.1.4 的实际源码、三处 caller、worker 最终 diff 和初次真实 CI 错误。仅写本文，不改源码、之前报告或流程状态，不重复 Owner 的完整门禁。

结论：**修复内容通过。** 三个 `u16` 权限参数显式转换为目标平台的 `RawMode`，macOS 恒等、Linux 无损扩展，保留原构造器与权限位语义。没有观察到行为、句柄、持久化顺序或公开 API 改变。该结论是源码和 API 语义审查，不是新的 Linux CI 通过；新候选仍须实际构建与测试。

## 根因与依赖事实

Cargo.lock 锁定 `rustix = 1.1.4`，本次不改锁或依赖。缓存中该精确版本的 `backend/linux_raw/fs/types.rs:77/830` 定义 `Mode: RawMode`、`RawMode = ffi::c_uint`，Linux CI 实际要求 `u32`；`backend/libc/fs/types.rs:110/1114` 使用 `RawMode = c::mode_t`，本机锁定 libc 的 Apple mode_t 为 `u16`。因此相同的私有 `u16` 实参在 macOS 编译通过，Linux 不能隐式转换。

两 backend 的 `from_raw_mode` 都先去除 `S_IFMT`，再 `from_bits_truncate`（linux_raw 行 132—133；libc 行 196—197）。修复继续调用此构造器，保留类型位过滤与已知权限位处理；没有换成直接 `from_bits_truncate`、统一 `u32` 或绕过 rustix 类型。该版本的公开 API 同样要求 `RawMode`，参见 [rustix 1.1.4 Mode 文档](https://docs.rs/rustix/1.1.4/rustix/fs/struct.Mode.html#method.from_raw_mode)。依赖源码中的平台别名是本次宽度判断的直接依据。

## 三处实际改动及 caller

| 位置 | 输入与实际 caller | 等价依据 |
| --- | --- | --- |
| `SafeFile::set_mode`，fsx.rs:2775 | `mode: u16`；ManagedFs 的封存为 0444、可执行为 0755 | `Mode::from_raw_mode(mode as _)` 将目标类型推断为 RawMode；Mac u16→u16，Linux u16→u32，没有符号扩展或截断 |
| `set_dir_tree_mode` 目录分支，fsx.rs:3178 | `directory_mode: u16`；恢复可写为 0755、封存为 0555 | 原数值及全部置位保持；递归传递同参数，constructor 原过滤不变 |
| 同函数文件分支，fsx.rs:3206 | `file_mode: u16`；恢复可写为 0644、封存为 0444 | 原数值及全部置位保持；不新增权限、文件类型位或特殊分支 |

整个 `u16` 的范围 0—65535 都可无损容纳于这两个目标类型，当前 caller 更只使用上述九位权限常量。数字转换在 Mac/Linux 都不改变任何已有 bit；调用原构造器后，原有去类型位和 truncate 的结果相同。没有新 `cfg` 层、兼容函数、fallback、测试专用路径或不同权限规则。

Reviewer 以当前 HEAD 的原 fsx.rs 为基准独立重建预期文本，只替换上述三个构造器实参；结果与当前文件逐字相同。当前 fsx.rs SHA256 为 `a2d1efce26f523cb1838327fb40ce48e4f2b81251a4114f13541b94d4e64f83a`；Cargo.lock 仍为 `44388bef2167384fdd12d08fc90cb3fee270d2ad8043a8029cc524c49202beaa`。这比仅看行数能直接约束全部其余代码保持原字节。

## 文件安全与持久化顺序

SafeFile 保留同一已打开文件句柄；ManagedFs 仍先核根锁、归属、fstat 身份，置权限后重开原路径核同一对象。`SafeFile::set_mode` 仍为 fchmod→fsync，原错误映射及传播不变。

目录分支仍拒软链、NOFOLLOW 打开、核 stat/fstat 身份、先递归，再对相同 child 句柄 fchmod，随后原 failpoint 和 fsync。文件分支仍核普通文件/单链接等原规则、NOFOLLOW/NONBLOCK 打开、复核身份，再对相同 file 句柄 fchmod→原 failpoint→fsync。没有改变文件观察、树遍历、根目录处理、syscall 或同步先后，也未触及公开函数签名、Store/schema/协议。

## 验证与状态范围

初次失败原文 `ci/37029608597-failed.log`、`ci/37029608698-failed.log` 均保留，实际 E0308 点名三处 `expected u32, found u16`，其中 MSRV 与 Linux check 同样失败。原 700/700、5/5 和本机安装只能证明其 macOS 候选输入；两 Mac 资产成功不能推成 Linux 成功或整体 CI 通过。

本报告没有重复跑完整测试，没有预判新 Linux job、quality、MSRV 或四平台资产。Owner 应固定这三个源码改动后的新候选，按实际影响链执行本地门禁，并从新 CI 的原始 run/checkout SHA、构建与测试结果补核；源码修复内容通过不替代执行结果。此前 M1/SK01/SK02、Linux 历史缺失、usage、远端更新和发布授权保持原边界，T17 不据本文标 done。

## 本机辅助门禁原文补核

worker 提供 `/private/tmp/c002-t17-mode-verification.json`，记录 Darwin arm64 上实际 fmt、全 targets/features Clippy `-D warnings`、全 targets/features check、MSRV 1.85 workspace/all targets/features/locked，四项 exit 0。Reviewer 逐项读取元数据对应 stdout/stderr，独立 SHA256 全匹配，三个 fsx/Cargo 输入 hash 与当前文件一致。`as _` 在本机严格 Clippy 下没有新增 lint；不需要为此添加许可属性或平台分支。

这些实际通过只限本机编译、格式和 lint；没有重复完整测试，也不代替后续 Linux CI、完整新候选门禁或四平台实物。原失败 run 与原 700/700 的平台、输入和结论均保持历史字节，不改写成修复后已全通过。
