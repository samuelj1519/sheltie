# C002-T17 macOS aarch64 单平台独立审查

Reviewer：`Codex /root/t16_reopen_review`。未参与本轮目标、CI 或文案修改；只读核相对 `6bb8b5a` 的实际 7 文件 diff、用户授权、当前单平台 plan/governance 原文及既有 Mac 验证。仅写本文，不改其他文件、状态、旧报告或档案，不复跑完整 700 测试，不进行网络写。

结论：**当前单平台源码配置与范围记录通过。** 本版本只发布 `aarch64-apple-darwin`，其余平台按用户决定排除，完整本平台质量/MSRV与实物/远端验证不被放宽。用户主动表示「可以仅发布 macOS aarch64」，在之前要求完成 C002 的上下文中，足以授权按该范围在实际质量和独立实物核验后发布；不必再次请求相同许可。本文不是新实际 CI/资产的通过结论。

## 已授权范围

`ci/single-platform-authorization.json` 保存用户直接原话「可以仅发布 macOS aarch64 。其余平台以后有需求再增加」、唯一 target、其它平台 `excluded_by_user`、同 SHA 原生完整质量/MSRV、单平台包/manifest/checksum及发布前独立核验条件。root 已明确向用户解释此执行边界，不能把许可等同于已完成材料或已发布。

plan、progress 当前入口、validation 最终单平台段、README 顶部与安装段、CHANGELOG 均使用单一 aarch64 范围。原两 Mac、四平台及未授权记录保持各自时点事实，后面明确本轮覆盖；不会为了满足旧矩阵重启其它平台修复，也不把其它平台历史成功/FAIL/not_run 改为新候选 PASS。新增平台需要之后的实际需求，不自行恢复矩阵。

## 源码配置

Cargo dist targets 恰为一个 `aarch64-apple-darwin`；build-rust 矩阵恰为 macos-14。release quality 和 MSRV 同样保持 macos-14，对当前公开 runner 是原生 arm64，先前 macOS 范围审查的官方 runner 来源及 SHA 接线仍适用。

本次 Cargo.toml 独立结构比较只改变 dist targets：依赖、版本、features、MSRV、profile及其他 metadata 均不变；Cargo.lock 完全不变。相对当前已提交两 Mac 候选，所有修改只限两个 target/matrix 位置和版本范围文案，Rust src/tests、fixture、skill、合同及运行时行为无新增改动。fsx 仍为已核三处 Mode 转换的 `a2d1efce…f83a`，不继续 Linux 四个 lint cast 修复，不新增 cfg、许可或兼容层。

release.yml 与前一范围候选逐字相同：候选 HEAD 验证、各 checkout 的同 SHA、tag push/publishing、announce 的 quality/host/plan 成功门槛和单独质量证据资产均保留。没有混入历史其它平台包的额外上传路径；新 CI 应核本 run 的实际 asset 清单，只上传当前 target 和必需通用源/installer/manifest/checksum/skill，而不是复用旧 run 的 Intel/Linux 包。

## 本地原文与影响链

`commands/single-platform-plan` 实际 argv 为 `dist plan --tag=v0.2.0 --output-format=json`，exit 0，stdout/stderr SHA256 与 result.json 独立一致。生成 manifest 的 local CI 矩阵只有 macos-14/host `aarch64-apple-darwin`，`--target` 也只有该 target；release artifact 列表只有 ARM tar/checksum和 source/installer/总摘要等通用资产。没有 Intel 或 Linux tar，plan 成功不证明包已实际构建。

`single-platform-governance` 实际执行 `cargo test -p sheltie-cli --test release_governance --all-features --locked`，22/22、0 ignored、0 filtered、exit 0，原 argv/输出 hash 均独立匹配。它重新通过实际 workflow/checker consumer，原质量双负控制与精确验证表不被修改。

前一 `macos-scope-nextest` 原文为 700/700、零 skip、165.985 秒；同阶段 doctest 实际 5 个 compile-fail、exit 0，两个输出 hash已独立核。此 run 与更早三 Mode 修复后 165.194 秒的 run 分开保留。当前 Rust、测试、依赖、lock/features仍是这份 Mac run 的相同闭包；本轮改动影响 dist/CI矩阵和文案，已另核真实新 plan 与 governance。不能把配置变化说成整个历史输入完全没变，也不能把保留的本机结果冒充新提交同 SHA 的 GitHub CI PASS；新源码配置须固定提交后取得实际 native quality/MSRV和单平台实物。

## 验收与发布约束

当前仅通过单平台范围、候选配置及本地影响链，T17 不据本文标 done。实际下一阶段应核唯一 ARM 包的 CPU/版本/schema、实际 sha256 与 manifest/checksum一致、同一 candidate/checkout SHA 的完整原生 Mac quality/MSRV、安装及真实远端指定 update/rollback，失败保存 FAIL并处理；达成这些已授权条件后才发布并写最终生命周期。

Linux 首次三处编译失败、33b08bc 的四平台构建成功但 Linux lint FAIL、Intel 历史产物及原 M1/SK01/SK02、215 项额外执行/最终 Spec 批准缺失全部保留。排除披露或授权核实的 PASS只说明范围/记录完整，不能代表其它平台执行 PASS、全平台原生资格或完整安全/变异验证。T16历史0.1.0、本机 Host范围、usage null与未验证自动发现亦不扩大。

当前主要输入 SHA256：Cargo.toml `fb7e8e18c3e7f0b4daf9de64e9dea6ba2c9562c742ae0dc6bfc4973581efe602`；build.yml `d503b9fc5f52c0c81f9010eed85c8f9726e41b08447c081e9a60d012ad60d2c6`；release.yml `7f447eee0e482e5b6e28b465f7cb6773d923f7d46a28cc11748668808ddcfffe`；README `3d5d9e7254332555f42b5a608f8a4ae34774e7de64683b803f21379de0027845`。新的单平台 CI 结果与实物仍待后续独立补核，没有在本文预记绿色或发布成功。

Owner 另保存 `single-platform-input-closure.json`，Reviewer 已读并独立执行同一只读 Git 边界比较，`git diff --quiet 6bb8b5a -- crates Cargo.lock rust-toolchain.toml .config` 实际 exit 0。准备阶段 11 文件档案生成时未包含本文，其范围应保留这一说明；后续最终 CI 档案再纳入本文，不能预称前档案已有独立报告。
