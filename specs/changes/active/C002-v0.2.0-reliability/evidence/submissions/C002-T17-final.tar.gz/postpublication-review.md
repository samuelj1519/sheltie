# C002-T17 正式发布与远端更新独立审查

Reviewer：`Codex /root/t16_reopen_review`。未参与发布、下载、安装、更新或 oracle 记录；只读核公开下载字节、实际 API 结果/CLI 原文、tag quality、源输入、self 生命周期与既有范围。仅写本文，不改状态、代码、档案或旧报告，不网络写、不重跑完整测试。

结论：**产品发布、公开实物、同 SHA 质量与真实远端 update/rollback限定通过；T17 产品执行必需项已齐，可以进入完成状态和生命周期记录收尾。** 当前没有观察到尚缺的产品/发布动作。最终 release record、C002 completed 记录、证据封存及 staged scope/gate 仍待后续实际核验，不以本结论预称已提交或全部治理闭环完成。

## 已发布事实和实际质量

`ci/published-release.json` 实际 tagName=v0.2.0，isDraft=false、isPrerelease=false，publishedAt=`2026-10-02T17:03:04Z`，targetCommitish=`8455aed2bcd9ac1739852be3987091a0975e7ac3`。本地 tag 解引用也为同一候选。[v0.2.0 公共 Release](https://github.com/samuelj1519/sheltie/releases/tag/v0.2.0)的来源、版本及单平台范围符合用户主动许可，不使用此前仍为 PR 的阶段结论代替发布。

[Release tag run 37037558064](https://github.com/samuelj1519/sheltie/actions/runs/37037558064)实际 event push、headSha为同一完整候选、success；quality、plan、唯一 ARM local artifacts、global artifacts、host、announce 六 job 均 success。[build tag run 37037558052](https://github.com/samuelj1519/sheltie/actions/runs/37037558052)同 SHA、completed/success，docs、MSRV、build-rust(macos-14) 均 success。

published-quality 的 candidate/checkout/commit 均为8455aed，run ID 37037558064、attempt 1、event push、quality_result=success。tools 实际 host=aarch64-apple-darwin，所有 quality step success；fmt/check/Clippy/deny、docs/specs/skill/core-vocab/test-governance、MSRV原文齐全，MSRV 1.85 locked实际 Finished，deny advisories/bans/licenses/sources ok。该 tag run 新 Nextest 为 **700/700、0 skipped、156.541秒**，不是拿 PR 的209.038秒或本机165秒运行改写。

Reviewer 从 Git候选本身在内存取得冻结源字节，published-quality 的301个唯一 tracked 路径全部匹配，未用正在准备的后续治理工作树代替发布源码。3个 LICENSE软链依原记录口径核其目标内容，普通文件直接核字节；源 tar 的 pax comment也为同一完整候选，298普通文件逐字匹配、3根内 LICENSE相对链接保留。

## 实际公开资产重新核验

公开下载目录含且只含Release列出的8个资产：dist-manifest.json、sha256.sum、ARM tar/独立checksum、installer、skill、source tar/独立checksum。Reviewer逐一独立核实际大小与GitHub asset size、hashlib SHA256与GitHub digest；8项全部一致，没有Intel/Linux资产。

正式ARM包为 **1779600bytes**，SHA256 `fc63c9d0c7132796cdacd050be102ed5501f637f2db0f19b279da6b4744899e4`。该摘要同时匹配独立 `.sha256`、公开sha256.sum和完整dist-manifest。公开manifest实际SHA256为 `8540728b9db73a31a74e7f762128bebed90210ecfb2ec24845786db02a02354b`，release version=0.2.0，target_triples只有aarch64-apple-darwin，checksum名称/引用一致。

正式包摘要与PR包7a80f8不同，不能复用旧包oracle。本文重新读取正式tar，成员只有目录、sheltie、LICENSE-MIT、README、CHANGELOG，无链接/逃逸路径；binary独立SHA256为 `a220309ab437a5de52202acb8b8f933370a45969e2027c55964930818e315130`，与PR执行文件逐字相同。Mach-O magic 0xfeedfacf、CPU type16777228（ARM64）、executable type2，权限0755。

source.tar.gz 的独立checksum/global sum/完整manifest一致，SHA256 `e66ab9763ccea6c10f7d9b2542b7042c2315d7a94b5a72859278e4a6f7f1e94b`；源内容与该candidate对应。generated installer只选择ARM包，未提供本版Intel/Linux下载路径。PR/quality临时资产没有混成正式发布资产。

## 公开 skill 自包含与来源

sheltie-skill.tar.gz 实际SHA256为 `32af975008679e7a191ce57474413d5a6cdb15a7df7b92ebeac80358fe0f52cb`。包只含 `sheltie/SKILL.md` 与 `references/protocol.md`、`references/workbook.md`三份普通文本，无链接或逃逸成员。

Reviewer不用发布oracle生成期望，而从source8455取对应SKILL和两份权威合同，在内存按既有交付规则重绑两份references、去掉交付外本地链接；三份预期与公开文本逐字相同。另独立遍历残留本地引用，全部能在交付包内解析，零dangling。没有安装宿主或把自包含打包当自动skill发现/Host资格。

## Fresh安装和真实远端更新/回滚

`published-self-install`实际exit0、already_installed=false；`published-self-version`实际exit0、version0.2.0/schema2/platformaarch64。argv和stdout/stderr摘要独立匹配。公开包binary、delivery/published-sheltie、published-install-home/bin/sheltie三份实际字节均为a220309a摘要，Reviewer另只读核新home数据库user_version=2。

`remote-prepare-install`以T16的0.1.0显示身份/schema2 updater建立独立remote-update-home。`remote-pinned-update`实际argv包含 `env -u SHELTIE_RELEASE_BASE`，指定版本0.2.0、默认真实GitHub来源，exit0、from0.1.0→to0.2.0、up_to_date=false；`remote-updated-version`实际确认0.2.0/schema2。没有把本地mirror或published schema1旧binary当此调用的起点。

更新时保留的remote-update-after oracle记录新binary等于公开字节、prev等于原T16binary、Store与before一致；这是当时中间截面的记录，回滚后不能假称再次观察到更新中的路径。`remote-rollback`实际exit0、rolled_back=true；`remote-rollback-version`确认0.1.0/schema2。Reviewer事后独立hash当前binary为原T16的 `eba587d3a6e84578317bd5a0c0b6f677e6632a54924ae06891f86dd92095752d`，bin目录只有sheltie、prev已消失，Store现有文件与before全字节摘要一致，main为 `e7dfbd0c6ced39b6e9e6c3816e8da0f4898f9ca89943a46b4fe8fa6274ec18ee`，逻辑schema仍2。

上述7个public/remote CLI的实际argv、UTC、exit0、stdout/stderr hash均核，更新/回滚和公开下载后installed bytes分开记录。此远端链证明同schema旧候选下载/摘要/替换/prev/回滚闭环，**不是历史发布schema1 v0.1.0原地迁移**。旧发布schema1由旧CLI生成、拒绝/主库不变和D-039控制文件边界仍按既有独立证据保留；本版不迁移、不清库、不操作真实用户home。

## 最终限定完成资格

用户明确的单ARM许可、发布前独立核验、真实tag/publicRelease、同SHA完整Mac质量/MSRV、正式实物/skill/source、fresh安装、真实默认远端固定版本update/rollback均已完成，结合原T16及schema保留证据，未发现其它必需产品动作阻断T17限定完成。Owner可记录done，并把实际release record和C002生命周期提交闭环交独立scope/gate核验。

Linux原E0308/Clippy FAIL、Intel与四平台历史结果及本版excluded_by_user保持原事实；它们不因本次发布变为PASS。M1/SK01/SK02、215项额外变异/最终Spec批准、完整安全与变异缺失、usage null、T16历史0.1.0和手动skill/Host边界都不扩大。单平台T17完成仅按用户授权范围，不代表全平台或完整安全验证通过；发布之后的治理记录仍不得重写历史FAIL或将本报告当最终staged提交成功。
