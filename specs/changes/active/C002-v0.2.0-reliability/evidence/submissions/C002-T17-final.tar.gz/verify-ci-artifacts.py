from pathlib import Path
import json,hashlib,tarfile,sys,struct,re
root=Path(sys.argv[1]);candidate=sys.argv[2];quality=root/('quality-'+candidate)
assert quality.is_dir(),quality
facts=dict(line.split('=',1) for line in (quality/'candidate.txt').read_text().splitlines())
assert facts['candidate_sha']==candidate and facts['checkout_sha']==candidate,facts
result=dict(line.split('=',1) for line in (quality/'result.txt').read_text().splitlines())
assert result['candidate_sha']==candidate and result['quality_result']=='success',result
for name in ['nextest','docs','specs','fmt','check','clippy','deny','msrv']:
 assert (quality/(name+'.log')).is_file(),name
summary=next(line for line in (quality/'nextest.log').read_text().splitlines() if 'Summary' in line and 'tests run:' in line)
counts=re.search(r'(\d+) tests run: (\d+) passed.*?, (\d+) skipped',summary);assert counts and int(counts[1])>0 and counts[1]==counts[2] and counts[3]=='0',summary
expected={'aarch64-apple-darwin':('macho',0x100000c)}
assets={}
for target,(kind,machine) in expected.items():
 name='sheltie-cli-'+target+'.tar.xz';matches=list(root.rglob(name));assert len(matches)==1,(name,matches);p=matches[0];b=p.read_bytes();digest=hashlib.sha256(b).hexdigest()
 sums=list(root.rglob(name+'.sha256'));assert len(sums)==1;assert sums[0].read_text().split()[0]==digest
 with tarfile.open(p,'r:xz') as tar:
  items=tar.getmembers();assert all(not x.name.startswith('/') and '..' not in Path(x.name).parts for x in items)
  bins=[x for x in items if x.isfile() and Path(x.name).name=='sheltie'];assert len(bins)==1;binary=tar.extractfile(bins[0]).read()
 if kind=='macho':assert binary[:4]==b'\xcf\xfa\xed\xfe' and struct.unpack_from('<I',binary,4)[0]==machine
 else:assert binary[:4]==b'\x7fELF' and binary[4:6]==b'\x02\x01' and struct.unpack_from('<H',binary,18)[0]==machine
 assets[target]={'name':name,'bytes':len(b),'sha256':digest,'binary_sha256':hashlib.sha256(binary).hexdigest(),'header_machine':machine,'path':str(p)}
manifest_candidates=list(root.rglob('*dist-manifest.json'));full=[]
for p in manifest_candidates:
 try:m=json.loads(p.read_text())
 except ValueError:continue
 if all(a['name'] in m.get('artifacts',{}) and m['artifacts'][a['name']].get('checksums',{}).get('sha256')==a['sha256'] for a in assets.values()):full.append((p,m))
assert full,'没有与Mac aarch64实际包sha匹配的完整manifest'
p,m=full[0];assert m['announcement_tag']=='v0.2.0';assert all(r['app_version']=='0.2.0' for r in m['releases'])
out={'candidate_sha':candidate,'quality':result,'native_nextest_summary':summary,'run_id':facts['run_id'],'run_attempt':facts['run_attempt'],'assets':assets,'manifest':str(p),'manifest_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'oracle':'Python hashlib/包checksum/完整manifest/独立Mach-O和ELF machine核对；不是执行所有平台业务测试'}
(root.parent/'ci-artifact-oracle.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
