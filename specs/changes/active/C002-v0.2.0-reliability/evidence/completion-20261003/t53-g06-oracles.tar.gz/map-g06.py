from pathlib import Path
import json,subprocess,difflib,hashlib,os
r=Path('/private/tmp/sheltie-completion-20261003');paths=['crates/sheltie-runtime/src/fsx.rs','crates/sheltie-runtime/src/workbook_digest.rs'];source={n:Path(n).read_bytes() for n in paths};env=os.environ.copy();env['RUSTC_WRAPPER']='';env['CARGO_TARGET_DIR']='target';p=subprocess.run(['cargo','mutants','-p','sheltie-runtime','--all-features','--list','--json'],env=env,capture_output=True,check=True);assert all(Path(n).read_bytes()==b for n,b in source.items());(r/'t53-current-mutants.json').write_bytes(p.stdout);current=json.loads(p.stdout);old=json.loads((r/'current-runtime-mutants.json').read_text());by={x['name']:x for x in old};line_maps={}
for n,b in source.items():
 oldsource=subprocess.check_output(['git','show','63b05ca:'+n],text=True).splitlines();newsource=b.decode().splitlines();line_maps[n]={}
 for a,c,count in difflib.SequenceMatcher(None,oldsource,newsource,autojunk=False).get_matching_blocks():
  for k in range(count):line_maps[n][a+k+1]=c+k+1
prep=json.loads((r/'g06-oracle-directions.json').read_text());rows=[]
for group,items in prep['groups'].items():
 for item in items:
  o=by[item['current_id']];f=o['file'];span=o['span']['start'];line=line_maps[f][span['line']];choices=[x for x in current if x['file']==f and x['genre']==o['genre'] and x['replacement']==o['replacement'] and x['span']['start']=={'line':line,'column':span['column']} and x.get('function',{}).get('function_name')==o.get('function',{}).get('function_name')];assert len(choices)==1,(item['old_id'],choices);c=choices[0];x=item.copy();x.update(previous_current_id=item['current_id'],current_id=c['name'],current_diff_sha256=hashlib.sha256(c['diff'].encode()).hexdigest(),current_source_sha256=hashlib.sha256(source[f]).hexdigest(),group=group,mapping='equal source-line block from 63b05ca; exact file/column/function/genre/replacement',execution='not_run_by_mapping');rows.append(x)
assert len(rows)==8 and len({x['current_id'] for x in rows})==8
(r/'t53-g06-mapping.json').write_text(json.dumps({'items':rows},indent=2)+'\n');print('8 current IDs uniquely mapped')
