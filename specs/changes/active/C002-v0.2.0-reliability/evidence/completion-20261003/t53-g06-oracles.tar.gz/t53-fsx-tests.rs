
#[cfg(all(test, feature = "failpoint"))]
mod external_read_contract_tests {
    use super::controlled_object_tests::observe_change;
    use super::*;

    fn abs(path: &std::path::Path) -> AbsPath {
        AbsPath::new(path.to_str().unwrap().to_owned()).unwrap()
    }

    // Task: C002-T53
    #[test]
    fn final_tree_validation_rejects_changes_to_either_files_or_directories_alone() {
        for addition in ["file", "directory"] {
            let directory = tempfile::tempdir().unwrap();
            let original = directory.path().join("data");
            std::fs::write(&original, b"unchanged original bytes").unwrap();
            let before = std::fs::metadata(&original).unwrap();
            let tree = ExternalReadTree::open(&abs(directory.path())).unwrap();
            tree.validate_unchanged().unwrap();
            if addition == "file" {
                std::fs::write(directory.path().join("late-file"), b"new late bytes").unwrap();
            } else {
                std::fs::create_dir(directory.path().join("late-directory")).unwrap();
            }
            let Error::InvalidRequest { reason } = tree.validate_unchanged().unwrap_err() else {
                panic!("a single changed inventory must invalidate the original tree")
            };
            assert!(reason.contains("读取期间目录项或对象身份改变"), "{reason}");
            assert_eq!(std::fs::read(&original).unwrap(), b"unchanged original bytes");
            let after = std::fs::metadata(&original).unwrap();
            assert_eq!((after.dev(), after.ino(), after.mode(), after.nlink()), (before.dev(), before.ino(), before.mode(), before.nlink()));
        }
    }

    // Task: C002-T53
    #[test]
    fn external_open_refuses_same_inode_growth_or_same_length_replacement_after_stat() {
        for change in ["growth", "replacement"] {
            let directory = tempfile::tempdir().unwrap();
            let original = directory.path().join("data");
            std::fs::write(&original, b"data").unwrap();
            let before = std::fs::metadata(&original).unwrap();
            let tree = ExternalReadTree::open(&abs(directory.path())).unwrap();
            let entry = tree.files()[0].clone();
            let scope = format!("{}/data", tree.root);
            let retained = directory.path().join("retained-original");
            let result = observe_change(
                "external_tree_after_stat", &scope,
                move || tree.open_file(&entry),
                || {
                    if change == "growth" {
                        let mut file = std::fs::OpenOptions::new().append(true).open(&original).unwrap();
                        file.write_all(b"+").unwrap();
                        assert_eq!(std::fs::metadata(&original).unwrap().ino(), before.ino());
                    } else {
                        std::fs::rename(&original, &retained).unwrap();
                        std::fs::write(&original, b"late").unwrap();
                        let replacement = std::fs::metadata(&original).unwrap();
                        assert_eq!(replacement.dev(), before.dev());
                        assert_ne!(replacement.ino(), before.ino());
                        assert_eq!(replacement.len(), before.len());
                    }
                },
            );
            let Error::InvalidRequest { reason } = result.unwrap_err() else {
                panic!("opened facts must independently match the captured entry")
            };
            assert!(reason.contains("打开期间被替换或改变"), "{reason}");
            if change == "growth" {
                assert_eq!(std::fs::read(&original).unwrap(), b"data+");
            } else {
                assert_eq!(std::fs::read(&original).unwrap(), b"late");
                assert_eq!(std::fs::read(&retained).unwrap(), b"data");
                let preserved = std::fs::metadata(&retained).unwrap();
                assert_eq!((preserved.dev(), preserved.ino(), preserved.mode(), preserved.nlink()), (before.dev(), before.ino(), before.mode(), before.nlink()));
            }
        }
    }

    // Task: C002-T53
    #[test]
    fn an_extra_byte_after_open_validation_cannot_be_silently_truncated_to_the_read_cap() {
        let directory = tempfile::tempdir().unwrap();
        let original = directory.path().join("data");
        std::fs::write(&original, b"data").unwrap();
        let tree = ExternalReadTree::open(&abs(directory.path())).unwrap();
        assert_eq!(tree.read_file(&RelPath::new("data").unwrap(), 4).unwrap(), b"data");
        let scope = format!("{}/data", tree.root);
        let result = observe_change(
            "external_tree_after_open_validation", &scope,
            move || tree.read_file(&RelPath::new("data").unwrap(), 4),
            || {
                std::fs::OpenOptions::new().append(true).open(&original).unwrap().write_all(b"+").unwrap();
            },
        );
        let Error::InvalidRequest { reason } = result.unwrap_err() else {
            panic!("reading one byte beyond the cap must invalidate the captured file")
        };
        assert!(reason.contains("读取期间改变"), "{reason}");
        assert_eq!(std::fs::read(&original).unwrap(), b"data+");
    }

    // Task: C002-T53
    #[test]
    fn copy_detects_growth_past_the_actual_file_limit_before_creating_a_truncated_target() {
        let directory = tempfile::tempdir().unwrap();
        let source = directory.path().join("source");
        std::fs::create_dir(&source).unwrap();
        let original = source.join("data");
        let file = std::fs::File::create(&original).unwrap();
        file.set_len(MAX_FILE_BYTES).unwrap();
        let before = file.metadata().unwrap();
        let root = directory.path().join("home");
        let home = crate::Home::resolve(Some(root.to_str().unwrap())).unwrap();
        let lock = home.acquire_lock().unwrap();
        let destination = home.rel("copy").unwrap();
        let source_abs = abs(&source);
        let tree = ExternalReadTree::open(&source_abs).unwrap();
        let scope = format!("{}/data", tree.root);
        drop(tree);
        let worker_home = home.clone();
        let worker_destination = destination.clone();
        let result = observe_change(
            "external_tree_after_open_validation", &scope,
            move || copy_tree_confined(&worker_home, &lock, &source_abs, &worker_destination),
            || {
                std::fs::OpenOptions::new().append(true).open(&original).unwrap().write_all(b"+").unwrap();
            },
        );
        assert!(!destination.as_path().join("data").exists(), "a growth refusal must precede writing a silently truncated target");
        let Error::InvalidRequest { reason } = result.unwrap_err() else {
            panic!("copy must reject growth at its bounded read")
        };
        assert!(reason.contains("复制期间改变"), "{reason}");
        let after = std::fs::metadata(&original).unwrap();
        assert_eq!(after.len(), MAX_FILE_BYTES + 1);
        assert_eq!((after.dev(), after.ino(), after.mode(), after.nlink()), (before.dev(), before.ino(), before.mode(), before.nlink()));
        let mut reader = std::fs::File::open(&original).unwrap();
        reader.seek(std::io::SeekFrom::End(-1)).unwrap();
        let mut tail = [0u8; 1];
        reader.read_exact(&mut tail).unwrap();
        assert_eq!(tail, [b'+']);
        assert!(!home.store_path().as_path().exists());
    }

    // Task: C002-T53
    #[test]
    fn an_open_observation_failure_returns_io_without_reading_or_creating_business_files() {
        let _serial = crate::failpoint::RENDEZVOUS_TEST_LOCK.lock().unwrap();
        let directory = tempfile::tempdir().unwrap();
        let source = directory.path().join("source");
        std::fs::create_dir(&source).unwrap();
        let original = source.join("data");
        std::fs::write(&original, b"retain original bytes").unwrap();
        let before = std::fs::metadata(&original).unwrap();
        let tree = ExternalReadTree::open(&abs(&source)).unwrap();
        let scope = format!("{}/data", tree.root);
        let carrier = directory.path().join("invalid-sync-directory");
        std::fs::write(&carrier, b"retain carrier").unwrap();
        crate::failpoint::arm_rendezvous("external_tree_after_open_validation", &scope, &carrier).unwrap();
        let result = tree.read_file(&RelPath::new("data").unwrap(), 32);
        crate::failpoint::disarm_rendezvous().unwrap();
        let Error::Io { path, .. } = result.unwrap_err() else {
            panic!("the failed marker must not be a successful body read")
        };
        assert_eq!(path, scope);
        assert_eq!(std::fs::read(&original).unwrap(), b"retain original bytes");
        let after = std::fs::metadata(&original).unwrap();
        assert_eq!((after.dev(), after.ino(), after.mode(), after.nlink()), (before.dev(), before.ino(), before.mode(), before.nlink()));
        assert_eq!(std::fs::read(&carrier).unwrap(), b"retain carrier");
        assert_eq!(std::fs::read_dir(&source).unwrap().count(), 1);
    }
}
