import os,subprocess,time,json,hashlib
from pathlib import Path
root=Path('/private/tmp/sheltie-completion-20261003')
ev=Path.cwd()/'specs/changes/active/C002-v0.2.0-reliability/evidence/completion-20261003'
env=os.environ.copy();env['RUSTC_WRAPPER']='';env['CARGO_TARGET_DIR']='/private/tmp/sheltie-c006-target';env['PATH']=str(root/'tools/nextest')+os.pathsep+env['PATH']
env['SHELTIE_TEST_ENGINE_BINARY']='/private/tmp/sheltie-completion-20261003/t53-frozen-binaries/sheltie'
env['SHELTIE_TEST_EXPORT_BINARY']='/private/tmp/sheltie-completion-20261003/t53-frozen-binaries/sheltie-export'
files=[p for p in Path('crates').rglob('*') if p.is_file() and p.suffix in ('.rs','.toml')]+[Path('Cargo.toml'),Path('Cargo.lock'),Path('.config/nextest.toml')]
inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
records=[]
for name,cmd in [('fmt',['cargo','fmt','--all','--','--check']),('check',['cargo','check','--all-targets','--all-features','--locked']),('clippy',['cargo','clippy','--all-targets','--all-features','--locked','--','-D','warnings']),('nextest',['cargo','nextest','run','--all-features','--locked','--no-tests=fail','--no-fail-fast']),('doctest',['cargo','test','--doc','--all-features','--locked'])]:
 start=time.monotonic();print('START',name,flush=True)
 with (ev/f't53-final-{name}.txt').open('wb') as f:
  try: code=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=720).returncode
  except subprocess.TimeoutExpired: code='timeout'
 record={'name':name,'argv':cmd,'exit_code':code,'elapsed_seconds':round(time.monotonic()-start,3),'output_sha256':hashlib.sha256((ev/f't53-final-{name}.txt').read_bytes()).hexdigest()}
 records.append(record);(ev/'t53-final-gates.json').write_text(json.dumps({'base':'ed9b5da08efadac41e9e3f9ead1f3c4c2e00442c','inputs':inputs,'env':{k:env[k] for k in ['RUSTC_WRAPPER','CARGO_TARGET_DIR','SHELTIE_TEST_ENGINE_BINARY','SHELTIE_TEST_EXPORT_BINARY']},'frozen_binaries':json.loads((root/'t53-frozen-binaries.json').read_text())['artifacts'],'results':records,'source_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in inputs.items())},indent=2)+'\n');print('FINISH',record,flush=True)
 if code!=0:break
