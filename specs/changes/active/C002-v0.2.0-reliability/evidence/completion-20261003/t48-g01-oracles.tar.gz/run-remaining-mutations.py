import json,subprocess,os,re,time,hashlib,collections
from pathlib import Path
root=Path('/private/tmp/sheltie-completion-20261003')
plan=json.loads((root/'remaining-mutation-plan.json').read_text())
env=os.environ.copy();env['RUSTC_WRAPPER']='';env['CARGO_TARGET_DIR']='target';env['CARGO_BUILD_JOBS']='2';env['PATH']=str(root/'tools/nextest')+os.pathsep+env['PATH']
inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('crates').rglob('*.rs')}
results=[]
for group in plan['remaining']:
 output=root/'mutation-remaining'/group['group'];output.mkdir(parents=True,exist_ok=True)
 group['candidate']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();group['source_sha256']=inputs
 (output/'selection.json').write_text(json.dumps(group,indent=2)+'\n')
 regex='^(?:'+'|'.join(re.escape(i['current_id']) for i in group['items'])+')$'
 cmd=['cargo','mutants','-p','sheltie-runtime','--test-package','sheltie-runtime','--test-package','sheltie-cli','--test-tool','nextest','--all-features','--cargo-arg=--locked','--cargo-arg=--package=sheltie-cli','--timeout','120','--build-timeout','240','--jobs','2','--output',str(output),'--re',regex,'--cargo-test-arg=-E','--cargo-test-arg='+group['filter'],'--cargo-test-arg=--test-threads=4']
 start=time.monotonic();print('START',group['group'],group['count'],flush=True)
 with (output/'console.txt').open('wb') as f:
  try:code=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=720).returncode
  except subprocess.TimeoutExpired:code='group_timeout'
 record={'group':group['group'],'argv':cmd,'exit_code':code,'elapsed_seconds':round(time.monotonic()-start,3),'source_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in inputs.items())}
 raw=output/'mutants.out/outcomes.json'
 if raw.exists():
  x=json.loads(raw.read_text());record['counts']=dict(collections.Counter(o['summary'] for o in x['outcomes']))
  baseline=next((o for o in x['outcomes'] if o['scenario']=='Baseline'),None)
  if baseline:
   text=(output/'mutants.out'/baseline['log_path']).read_text();n=re.search(r'(\d+) tests run:',text);record['baseline_tests']=int(n.group(1)) if n else None
 results.append(record);(root/'mutation-remaining/results.json').write_text(json.dumps(results,indent=2)+'\n');print('FINISH',json.dumps(record),flush=True)
 if code not in (0,2) or not record['source_unchanged'] or not record.get('baseline_tests'):break
