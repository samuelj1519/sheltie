from pathlib import Path
import json,subprocess,os,re,time,hashlib,collections
root=Path('/private/tmp/sheltie-completion-20261003');output=root/'mutation-g01-final';output.mkdir(exist_ok=True)
ids=[]
for o in json.loads((root/'mutation-remaining/G01/mutants.out/outcomes.json').read_text())['outcomes']:
 if o['summary']=='MissedMutant':
  name=o['scenario']['Mutant']['name']
  ids.append(name)
assert len(ids)==19
filter='binary(snapshot_qualification) | test(request_metadata_keeps_immutable) | test(committed_start_publication_binds) | test(genuine_attempts_keep_namespace)'
cmd=['cargo','mutants','-p','sheltie-runtime','--test-package','sheltie-runtime','--test-package','sheltie-cli','--test-tool','nextest','--all-features','--cargo-arg=--locked','--cargo-arg=--package=sheltie-cli','--timeout','120','--build-timeout','240','--jobs','2','--output',str(output),'--re','^(?:'+'|'.join(re.escape(i) for i in ids)+')$','--cargo-test-arg=-E','--cargo-test-arg='+filter,'--cargo-test-arg=--test-threads=4']
env=os.environ.copy();env['RUSTC_WRAPPER']='';env['CARGO_TARGET_DIR']='target';env['CARGO_BUILD_JOBS']='2';env['PATH']=str(root/'tools/nextest')+os.pathsep+env['PATH']
inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('crates').rglob('*.rs')}
(output/'selection.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'items':ids,'filter':filter,'source_sha256':inputs},indent=2)+'\n')
start=time.monotonic()
with (output/'console.txt').open('wb') as f:code=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=720).returncode
x=json.loads((output/'mutants.out/outcomes.json').read_text());record={'argv':cmd,'exit_code':code,'elapsed_seconds':round(time.monotonic()-start,3),'counts':dict(collections.Counter(o['summary'] for o in x['outcomes'])),'source_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in inputs.items())}
(output/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
