# G13 独立期望准备（5 个精确对应 ID）

范围为只读准备：未改 tracked、未写或运行 oracle，全部5项仍未执行，不给动态PASS。仅 macOS aarch64。准确旧/当前ID、原diff SHA和当前来源SHA见JSON；HEAD与源码来源固定在报告输入。两个归档函数名 `rendezvous` 的对应表达式现在位于 `rendezvous_payload`：观察路径/载荷共用该函数，不能仅按原函数名或漂移行号选mutation。

| 组 | 数量 | 能力与真实消费者 |
|---|---:|---|
| X1 解除配置生命周期 | 2 | public arm/disarm→实际 ManagedFs/Work/Workbook callbacks；RendezvousWorker/SyncGuard |
| X2 子进程 rendezvous 作用域 | 2 | CLI env fallback→Store::commit 的 before_commit 同步点 |
| X3 清理故障边界 | 1 | cleanup_selected四个调用点→业务成功维护或同rid未提交准备 |

这5项均为 failpoint辅助能力：测试/注入正确性不能宣称额外产品安全或物理持久性。默认关闭feature的条件证明见末尾；本轮all-features输入下仍需实际判据。没有必要新增observer或通用harness。

## X1：解除尚未消费的配置

上下游类型：`arm_rendezvous(&str,&str,&Path)`、`arm_sync_error(&str,&str)`都是public API，保存owned String/PathBuf到进程内Mutex<Option<…>>；参数没有限制为“必定马上命中”的业务enum。`disarm_*`语义是删除仍然有效的配置，不是只在已用完时返回Ok。

完整callee闭包：RENDEZVOUS被arm写Some、disarm置None，rendezvous_payload只clone而不消费；SYNC_ERROR被arm写Some、disarm置None，sync_error仅在同root且同name命中时置None并返回一次IO，其他调用保留原配置。进程内配置优先于env fallback。`lib.rs`公开failpoint模块，所以当前仓库测试caller习惯不构成接口输入域的完整约束。

已有 SyncGuard/disarm大多放在命中并已消费错误之后，单次“同步错误→retry成功”很容易测不到 disarm→Ok突变；已有 RendezvousWorker.finish/Drop写release后才disarm，后续arm又会覆盖残留配置，可能同样掩盖。不能把这些使用方式静态处分为等价。

**rendezvous共享能力判据。** 在真实受管普通文件上复用 `regular_open_after_stat`（scope=实际绝对path），arm后实际open_regular必须建立精确payload reached并停住，release后正常读到手写原字节。保持release存在，删除旧reached，disarm，然后再次实际打开同一文件：原实现不得重建旧reached，mutant残留配置会重建。也可直接arm后尚未命中便disarm，再操作；保留release使错误激活不会导致测试无限等待。核正常文件字节/dev/inode未改，不只断言disarm返回Ok。显式测试无配置/重复disarm不会制造事件。

**sync共享能力判据。** 创建两个独立Home/真实锁A和B，arm A的现有 `managed_file_parent_sync`，先执行B的一次实际 NOREPLACE原子写入，确认异根不消费配置；disarm后执行A对应实际写入，必须成功且精确内容正常。mutant残留配置在A实际必需同步边界返回IO。正例另从arm A到A操作命中一次错误，核rename后原件存在/正确，再操作不同新目标成功，证明一次性消费；不要先消费再测试disarm，也不要在disarm后又arm覆盖状态。可改用已存在Work/Workbook原件sync消费者，但需要相同独立成功/故障原件关系。

failpoint全局状态须使用现有serial guard或专属测试子进程；scope独立并不允许其他测试覆盖全局Some。优先复用既有public API/真实方法，不引入私有state getter、镜像Option断言或unsafe OS机制。bounded worker必须在失败时release/join或kill/wait，超时本身不能记caught。

## X2：必须验证 env fallback，而非 in-process优先分支

上下游边界：env三键是任意字符串/PathBuf；没有类型校验把name或id匹配关系预先证明。`Process::spawn`对每个新CLI子进程先清SHELTIE_FAILPOINT及三个SHELTIE_TEST_RENDEZVOUS键，后显式设置它们。新进程的in-process RENDEZVOUS为空，因此确实走 `.or_else` env路径；只用arm_rendezvous的测试会完全绕过本组两个表达式。

选一个真实合法 CLI写请求，复用 `Store::commit→maybe_exit("before_commit")`，这里传name与id都为before_commit。当前点在SQLite BEGIN之前；核目标request/audit/本次业务行尚未登记，不声称整个管理根或预先分配事实零变化。

一份真实场景覆盖三种独立配置：

- name/id都精确：新child必须暂停，reached内容为手写 `before_commit`，当前rid业务登记尚无；release后命令成功、恰好一份请求/审计，正常输出内容与源Workbook关系成立。
- name仅改为另一名字，id仍before_commit：原实现不产生reached，正常完成；name != mutant会在目标point错误激活。
- name仍before_commit，id仅改为另一个id：原实现不产生reached，正常完成；id != mutant会错误激活。

两个不匹配例各用独立tempdir，预先建立release，再等child有界完成；这样错误匹配留下reached而不会变成timeout。只有匹配正例才用等待reached→核未提交→release协议。核实际child stdout/exit、rid/审计和checkpoint artifact；不照抄 guard返回bool，不借共享进程环境变量，也不用mock“configured一定匹配”。其他同期observer的name/id可能不同，目标前后阶段必须用实际payload判别。

该group不需要新point。现有Process.raii会release/kill/wait，复用它；错误source/filter/未到指定阶段时停止，保存原文，不将“等待没消息”自动计为正确拒绝或caught。

## X3：外部清理故障必须穿过业务停止点

`maybe_fail_cleanup`只有 cleanup_selected四个callsite，全部字面量 `pending_cleanup_before_remove`：已完成空container删除、合法未提交孤儿删除、owner侧车删除、deleted marker删除。它转换 `cleanup_error`的外部故障为Error::Io；callee feature启用时读取SHELTIE_FAILPOINT匹配，未启用时Ok。四个caller不能给“名称不会匹配”静态证明，因为既有CLI子进程明确配置该名字。

复用两种现有独立能力，不为wrapper补一条镜像is_err单元测试：

1. 成功业务的维护失败：实际Workbook add完成，child设置cleanup故障。请求已经成功提交/发布，JSON和exit仍成功且原snapshot不变；stderr必须有pending维护warning，含实际request_id/object/reason；待清metadata/原件按正确停止位置保存。取消故障后同请求replay与cleanup正常完成，Store/audit不能追加第二次。入口可直接复用 CLI workbook 的 cleanup_warning_goes_to_stderr…现有场景。
2. 新请求准备门槛：实际start/add在 pending_owner_synced_before_payload 或 before_commit中断，保留同rid未提交原件；同rid重试配置相同故障，须IO、request/audit仍未登记、旧原件字节保持、不得新建另一container后提交。解除故障后仅提交一次且旧残留安全清掉。现有 reliability_crash 的 same_request_retry_stops…包含这份完整关系，可与G09 prepare_new_request消费同一oracle。

正例无故障或不匹配名字时安全清理已归属metadata，不碰外部sentinel或未完成原件；重复cleanup应安静。不要将孤儿权限在进入故障前被合法放开当作零修改违约；完整inventory核实际承诺的字节/身份/提交边界。故障env只在专属child生效，避免在runtime并行进程修改全局环境。此实验证明注入边界被业务正确消费，不宣称所有真实OS删除错误或断电持久性。

## 静态范围：仅禁用feature的条件证明，all-features无等价候选

这5个 ID在 `cfg(not(feature="failpoint"))` 闭包可作有限无影响证明，适用于所有当前caller，不依赖请求或env：

- 两个disarm的Mutex块均编译移除，原与mutant都只返回Ok。
- 两个env匹配表达式整个feature块移除，rendezvous_payload仅忽略参数并返回Ok。
- maybe_fail_cleanup调用的cleanup_error在该配置下恒Ok，map_err无错误可转换；原与mutant都Ok。

上述只证明feature关闭的产品配置。当前授权补验/原mutation过滤采用all-features，五项仍open；启用feature时String/PathBuf/public API以及env输入允许未消费配置、失配和重放，不能由类型或测试惯例排除。报告不将默认build静态无影响换算为旧ID的equivalent/PASS，也不把新增harness验证算产品业务覆盖。

作者执行前按实际nextest JSON列表固定filter和至少一个正例，原G13同时包含CLI/runtime binary，不能把runtime内没有os_process文件误解成整个队列无此binary。保留准确patch SHA及所有raw，源漂移/零测试/错误分支/observer未到/超时均停止并保留未执行。
