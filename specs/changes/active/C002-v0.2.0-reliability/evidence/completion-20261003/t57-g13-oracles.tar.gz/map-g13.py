from pathlib import Path
import json,subprocess,difflib,hashlib,os
r=Path('/private/tmp/sheltie-completion-20261003');paths=['crates/sheltie-runtime/src/failpoint.rs','crates/sheltie-runtime/src/pending.rs'];source={n:Path(n).read_bytes() for n in paths};e=os.environ.copy();e['RUSTC_WRAPPER']='';e['CARGO_TARGET_DIR']='target'
p=subprocess.run(['cargo','mutants','-p','sheltie-runtime','--all-features','--list','--json'],env=e,capture_output=True,check=True);assert all(Path(n).read_bytes()==b for n,b in source.items());(r/'t57-current-mutants.json').write_bytes(p.stdout);current=json.loads(p.stdout);old={x['name']:x for x in json.loads((r/'current-runtime-mutants.json').read_text())};line_maps={}
for n,b in source.items():
 oldsource=subprocess.check_output(['git','show','63b05ca:'+n],text=True).splitlines();newsource=b.decode().splitlines();line_maps[n]={}
 for a,c,count in difflib.SequenceMatcher(None,oldsource,newsource,autojunk=False).get_matching_blocks():
  for k in range(count):line_maps[n][a+k+1]=c+k+1
rows=[]
for item in json.loads((r/'t57-implementation-directions.json').read_text())['targets']:
 o=old[item['old_id']];f=o['file'];sp=o['span']['start'];line=line_maps[f][sp['line']];fn=o['function']['function_name'];expected='rendezvous_payload' if fn=='rendezvous' else fn
 choices=[x for x in current if x['file']==f and x['genre']==o['genre'] and x['replacement']==o['replacement'] and x['span']['start']=={'line':line,'column':sp['column']} and x['function']['function_name']==expected];assert len(choices)==1,(item,choices)
 c=choices[0];row=item.copy();row.update(current_id=c['name'],current_diff_sha256=hashlib.sha256(c['diff'].encode()).hexdigest(),current_source_sha256=hashlib.sha256(source[f]).hexdigest(),mapping='equal source line/column/genre/replacement from63b05ca; rendezvous env expression moved to shared rendezvous_payload, other functions unchanged',execution='not_run_by_mapping');rows.append(row)
assert len(rows)==len({x['current_id'] for x in rows})==5
(r/'t57-g13-mapping.json').write_text(json.dumps({'items':rows},indent=2)+'\n');print('Five exact unique current targets mapped')
