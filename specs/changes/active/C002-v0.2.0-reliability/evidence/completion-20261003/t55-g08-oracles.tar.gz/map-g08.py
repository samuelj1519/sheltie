from pathlib import Path
import json,subprocess,difflib,hashlib,os
r=Path('/private/tmp/sheltie-completion-20261003');paths=['crates/sheltie-runtime/src/fsx.rs','crates/sheltie-runtime/src/effects.rs','crates/sheltie-runtime/src/pending.rs'];source={n:Path(n).read_bytes() for n in paths};env=os.environ.copy();env['RUSTC_WRAPPER']='';env['CARGO_TARGET_DIR']='target';p=subprocess.run(['cargo','mutants','-p','sheltie-runtime','--all-features','--list','--json'],env=env,capture_output=True,check=True);assert all(Path(n).read_bytes()==b for n,b in source.items());(r/'t55-current-mutants.json').write_bytes(p.stdout);current=json.loads(p.stdout);old=json.loads((r/'current-runtime-mutants.json').read_text());by={x['name']:x for x in old};line_maps={}
for n,b in source.items():
 oldsource=subprocess.check_output(['git','show','63b05ca:'+n],text=True).splitlines();newsource=b.decode().splitlines();line_maps[n]={}
 for a,c,count in difflib.SequenceMatcher(None,oldsource,newsource,autojunk=False).get_matching_blocks():
  for k in range(count):line_maps[n][a+k+1]=c+k+1
prep=json.loads((r/'g08-oracle-directions.json').read_text());rows=[]
structural={
'crates/sheltie-runtime/src/fsx.rs:576:13: replace || with && in ManagedFs::verify_tree_at',
'crates/sheltie-runtime/src/fsx.rs:575:13: replace || with && in ManagedFs::verify_tree_at',
'crates/sheltie-runtime/src/fsx.rs:617:13: replace || with && in ManagedFs::rename_tree_new',
'crates/sheltie-runtime/src/fsx.rs:616:13: replace || with && in ManagedFs::rename_tree_new',
'crates/sheltie-runtime/src/fsx.rs:1594:9: replace || with && in verify_tree_entry_at',
'crates/sheltie-runtime/src/pending.rs:211:27: replace && with || in locate_publish_dir',
'crates/sheltie-runtime/src/pending.rs:214:30: replace && with || in locate_publish_dir',
'crates/sheltie-runtime/src/pending.rs:218:28: replace && with || in locate_publish_dir',
'crates/sheltie-runtime/src/pending.rs:221:31: replace && with || in locate_publish_dir'}
for group,items in prep['groups'].items():
 for item in items:
  x=item.copy();x['group']=group
  if item['old_id'] in structural:
   x['previous_candidate_current_id']=item['current_id'];x['previous_candidate_current_diff_sha256']=x.pop('current_diff_sha256');x.update(current_id=None,mapping='old connector replaced by shared pure directory_has_identity or sole_directory_exists; pending full structural verification',execution='old_native_not_run',disposition='open_structural_replacement_candidate');rows.append(x);continue
  o=by[item['current_id']];f=o['file'];span=o['span']['start'];line=line_maps[f][span['line']];choices=[x for x in current if x['file']==f and x['genre']==o['genre'] and x['replacement']==o['replacement'] and x['span']['start']=={'line':line,'column':span['column']} and (x.get('function') or {}).get('function_name')==(o.get('function') or {}).get('function_name')];assert len(choices)==1,(item['old_id'],choices);c=choices[0];x.update(previous_current_id=item['current_id'],current_id=c['name'],current_diff_sha256=hashlib.sha256(c['diff'].encode()).hexdigest(),current_source_sha256=hashlib.sha256(source[f]).hexdigest(),mapping='equal source-line block from 63b05ca; exact file/column/function/genre/replacement',execution='not_run_by_mapping');rows.append(x)
assert len(rows)==33 and len({x['old_id'] for x in rows})==33;assert sum(x['current_id'] is None for x in rows)==9
extra=[x for x in current if (x.get('function') or {}).get('function_name')in ['directory_has_identity','sole_directory_exists']];assert extra
(r/'t55-g08-mapping.json').write_text(json.dumps({'items':rows,'new_shared_module_mutants':extra},indent=2)+'\n');print('33 exact old IDs:24 direct/9 structural candidates;',len(extra),'new pure-module mutants')
