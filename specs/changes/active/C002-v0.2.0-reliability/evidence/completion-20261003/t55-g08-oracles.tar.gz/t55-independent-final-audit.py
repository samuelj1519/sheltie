from pathlib import Path
import json,hashlib,re,subprocess,collections,difflib
b=Path('/private/tmp/sheltie-completion-20261003');p=Path('specs/changes/active/C002-v0.2.0-reliability/evidence/completion-20261003');load=lambda q:json.loads(Path(q).read_text());h=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest()
d=load(p/'t55-g08-dispositions.json');g=load(p/'t55-final-gates.json');m=load(b/'t55-g08-mapping.json');entries=[];broad=[];pure=[];closures=[]
def scan(q,rows,expected,baseline,pure_filter=False):
 s=load(q/'selection.json');r=load(q/'result.json');o=load(q/'mutants.out/outcomes.json')['outcomes'];closures.append(s['source_sha256']);assert r['exit_code']==0 and r['source_unchanged'] and r['counts']=={'Success':1,'CaughtMutant':expected};assert len(o)==expected+1;assert o[0]['summary']=='Success' and o[0]['scenario']=='Baseline';assert f'{baseline} tests run: {baseline} passed' in (q/'mutants.out'/o[0]['log_path']).read_text();out=[]
 for a in o[1:]:
  name=a['scenario']['Mutant']['name'];item=next(x for x in rows if x['current_id']==name);assert a['summary']=='CaughtMutant' and a['phase_results']==item['phase_results'];assert a['phase_results'][0]['process_status']=='Success' and a['phase_results'][1]['process_status']=={'Failure':100};assert h(q/'mutants.out'/a['log_path'])==item['log_sha256'];diff=h(q/'mutants.out'/a['diff_path']);assert not item.get('current_diff_sha256') or diff==item['current_diff_sha256'];txt=(q/'mutants.out'/a['log_path']).read_text();assert not re.search(r'TIMEOUT|LEAK|target object observation was not reached',txt)
  ps=re.findall(r"thread '([^']+)'[^\n]*panicked at[^\n]*\n(.*?)(?=\n\s*(?:note:|failures:|test result:|thread ')|\Z)",txt,re.S);assert ps and set(x[0] for x in ps)==set(x.split()[-1] for x in item['failing_tests'])
  if pure_filter:assert len(ps)==1 and any(t in ps[0][0] for t in ['directory_identity_requires','only_one_existing_directory_qualifies']);assert 'assertion `left == right` failed' in ps[0][1]
  out.append({'current_id':name,'old_id':item.get('old_id'),'build_success':True,'test_failure':100,'raw_panics':[{'test':t,'panic':x.strip()[:1700]} for t,x in ps],'log_sha256':item['log_sha256'],'diff_sha256':diff})
 return out
for batch,n in [('A',11),('B',9)]:entries+=scan(b/'mutation-g08-final'/batch,d['items'],n,22)
broad=scan(b/'mutation-g08-final/C',d['new_shared_mechanism_results'],9,22)
pure_rows=d['new_shared_pure_interface_results'];pure=scan(b/'mutation-g08-final-pure',pure_rows,9,2,True)
assert all(x==closures[0] for x in closures);assert all(h(k)==v for k,v in closures[0].items());assert all(closures[0].get(k)==v and h(k)==v for k,v in g['inputs'].items());assert len(entries)==len({x['current_id'] for x in entries})==20;assert {x['current_id'] for x in broad}=={x['current_id'] for x in pure}=={x['name'] for x in m['new_shared_module_mutants']}
archive='specs/changes/active/C002-v0.2.0-reliability/evidence/m1-2026-10-01/mutants/adaptive-validation-2026-10-02/SK02-missing-execution-map.json';old=json.loads(subprocess.check_output(['git','show','e54dcd41d8f1e186007b62b47583063cb19a4b66:'+archive]));oldrows=[x for x in old['items'] if x['group_id']=='G08'];assert len(d['items'])==len({x['old_id'] for x in d['items']})==33;assert {x['id'] for x in oldrows}=={x['old_id'] for x in d['items']};assert all(x['old_stage1_formal_summary']=='MissedMutant' for x in d['items'])
struct=[x for x in d['items'] if x.get('current_id') is None];static=[x for x in d['items'] if x.get('static_boundary')];assert len(struct)==9 and len(static)==4 and len([x for x in struct if '/fsx.rs:' in x['old_id']])==5 and len([x for x in struct if '/pending.rs:' in x['old_id']])==4
for x in struct:assert x['caught'] is False and x['execution']=='old_native_not_run' and 'current_diff_sha256' not in x and x['previous_candidate_current_id'] and x['previous_candidate_current_diff_sha256']
oldinv={x['name']:x for x in load(b/'current-runtime-mutants.json')};curinv={x['name']:x for x in load(b/'t55-current-mutants.json')};maps={}
for path in {curinv[x['current_id']]['file'] for x in d['items'] if x.get('current_id')}:
 oldsrc=subprocess.check_output(['git','show','63b05ca:'+path],text=True).splitlines();cur=Path(path).read_text().splitlines();lm={}
 for x,y,n in difflib.SequenceMatcher(None,oldsrc,cur,autojunk=False).get_matching_blocks():
  for k in range(n):lm[x+k+1]=y+k+1
 maps[path]=lm
for row in d['items']:
 assert row['old_diff_sha256']==next(x['diff_sha256'] for x in oldrows if x['id']==row['old_id'])
 if not row.get('current_id'):continue
 a=oldinv[row['previous_current_id']];c=curinv[row['current_id']];assert c['span']['start']['line']==maps[c['file']][a['span']['start']['line']];assert c['span']['start']['column']==a['span']['start']['column'] and c['genre']==a['genre'] and c['replacement']==a['replacement'] and c['function']['function_name']==a['function']['function_name'];assert hashlib.sha256(c['diff'].encode()).hexdigest()==row['current_diff_sha256'];assert row['current_source_sha256']==h(c['file'])
for row in pure:
 c=curinv[row['current_id']];assert hashlib.sha256(c['diff'].encode()).hexdigest()==row['diff_sha256']
sp=load(p/'t55-static-review.json');assert len(sp['items'])==4 and {x['old_id'] for x in sp['items']}=={x['old_id'] for x in static};assert all(h(k)==v for k,v in sp['source_sha256'].items())
src=load(p/'t55-source-review.json');assert src['required_source_changes']==[] and all(h(k)==v for k,v in src['source_sha256'].items())
for r in g['results']:assert r['exit_code']==0 and h(p/('t55-final-'+r['name']+'.txt'))==r['output_sha256'];assert g['source_unchanged']
for r in load(p/'t55-supplemental-gates.json'):assert r['exit_code']==0 and h(p/('t55-'+r['name']+'.txt'))==r['sha256']
text=(p/'t55-final-nextest.txt').read_text();assert 'b062be43-16ad-4137-8760-805efe524d21' in text;assert re.search(r'935 tests run: 935 passed(?: \(\d+ slow\))?, 0 skipped',text);assert not re.search(r'LEAK|TIMEOUT',text);assert '5 passed; 0 failed' in (p/'t55-final-doctest.txt').read_text()
bins=load(p/'t55-frozen-binaries.json');resolvers=[json.loads(x) for x in (p/'t55-binary-build.jsonl').read_text().splitlines()]
for name,a in bins['artifacts'].items():assert a==g['frozen_binaries'][name];assert h(a['original'])==h(a['frozen'])==a['sha256'];assert len([x for x in resolvers if x.get('reason')=='compiler-artifact' and x.get('executable')==a['original'] and x['target']['name']==name])==1
for e in entries:
 id=e['current_id'];body=' '.join(x['panic'] for x in e['raw_panics']);cls=''
 if 'classify_committed_path_error' in id:cls='cause_code_diagnostic';assert 'left: Io' in body and 'right: StoreCorrupt' in body
 elif 'verify_publish_final_state' in id or 'verify_owned_digest' in id:cls='private_integrity_check_returned_Ok';assert 'unwrap_err()' in body and 'Ok' in body
 elif 'delete_dir' in id:
  if 'false completion marker' in body:cls='completion_marker_created_before_late_refusal'
  elif 'marker同步期间' in body:cls='first_marker_qualification_diagnostic'
  else:cls='late_endpoint_result_not_StoreCorrupt_source_success_inference';assert 'matches!(result' in body
 elif 'verify_tree_at' in id or 'check_tree_root' in id or 'verify_managed_tree_at' in id:cls='old_root_epoch_binding_returned_Ok';assert 'unwrap_err()' in body and 'Ok' in body
 elif 'validate_publish_reference' in id:cls='corrupt_global_registration_returned_list';assert 'WorkbookListItem' in body
 elif 'preflight_remove_at' in id:
  if 'leaf-alias 是特殊文件' in body:cls='valid_symlink_purge_refused'
  else:cls='preflight_side_effect_before_refusal';assert 'whole-root preflight must precede' in body
 elif 'remove_at' in id or 'set_dir_tree_mode' in id:cls='replaced_object_recursive_operation_returned_Ok';assert 'result.is_err()' in body
 elif 'locate_publish_dir' in id:cls='temporary_IO_misclassified_as_absence';assert 'temporary IO, not false absence' in body
 assert cls,id;e['classification']=cls
out={'result':'PASS_scoped_T55_G08_pending_governance_final_readback','reviewer':'independent read-only; no implementation/oracle author','source_sha256':src['source_sha256'],'input_count':len(closures[0]),'gate_input_count':len(g['inputs']),'source_unchanged_verified':True,'original33_unique_exact_set':True,'counts':{'old_direct_dynamic_caught':20,'old_scoped_static':4,'old_structural_current_candidate_qualified':9,'old_native_executed_by_structural_path':0,'new_shared_broad_caught':9,'new_shared_pure_caught':9,'timeout':0,'compile_caught':0,'missing_current_G08':0},'direct_classification_counts':dict(collections.Counter(x['classification'] for x in entries)),'old_history_preserved':True,'old1595_outside215':'stage1Missed + original later focusedCLI caught, no newG08old obligation','full_engineering':{'tests':935,'passed':935,'skip':0,'leak':0,'run':'b062be43-16ad-4137-8760-805efe524d21','compilefail':5,'fmt_check_clippy_msrv_default':0},'direct_entries':entries,'new_shared_broad_entries':broad,'new_shared_pure_entries':pure,'structural_items':struct,'scoped_static_items':sp['items'],'frozen_binaries':bins['artifacts'],'boundaries':['current-candidate structural qualification, no old native perturbation execution/Caught/equivalence','pure nine witnessed independentInterface relations; broadC nine includes legal producer setup failures distinct from integrity acceptance','private integrity checks/standalone delete controls are not full request published1/original qualification','some late marker raw only mismatched expectedStoreCorrupt; source confirms weakened terminal check canreturnOk, raw not separately printed','three static diagnostics differ; shape static resource/clone/OOM not equivalent','previous sources/failures/samples preserved, current935 only stated closure']}
(b/'t55-final-review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['direct_entries','new_shared_broad_entries','new_shared_pure_entries','structural_items','scoped_static_items','frozen_binaries']},ensure_ascii=False,indent=2))
