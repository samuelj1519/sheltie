from pathlib import Path
import json,subprocess,hashlib,difflib,os
r=Path('/private/tmp/sheltie-completion-20261003');path='crates/sheltie-runtime/src/fsx.rs';before=Path(path).read_bytes();env=os.environ.copy();env['RUSTC_WRAPPER']='';env['CARGO_TARGET_DIR']='target'
p=subprocess.run(['cargo','mutants','-p','sheltie-runtime','--all-features','--list','--json'],env=env,capture_output=True,check=True);assert Path(path).read_bytes()==before
(r/'t52-current-mutants.json').write_bytes(p.stdout);current=json.loads(p.stdout);old=json.loads((r/'current-runtime-mutants.json').read_text());by={x['name']:x for x in old}
oldsource=subprocess.check_output(['git','show','63b05ca:'+path],text=True).splitlines();newsource=before.decode().splitlines();line_map={}
for a,b,n in difflib.SequenceMatcher(None,oldsource,newsource,autojunk=False).get_matching_blocks():
 for k in range(n):line_map[a+k+1]=b+k+1
prep=json.loads((r/'g05-oracle-directions.json').read_text());rows=[]
for group,items in prep['groups'].items():
 for item in items:
  o=by[item['current_id']];span=o['span']['start'];line=line_map[span['line']]
  choices=[x for x in current if x['file']==o['file'] and x['genre']==o['genre'] and x['replacement']==o['replacement'] and x['span']['start']=={'line':line,'column':span['column']} and x.get('function',{}).get('function_name')==o.get('function',{}).get('function_name')]
  assert len(choices)==1,(item['old_id'],choices);c=choices[0];x=item.copy();x.update(previous_current_id=item['current_id'],current_id=c['name'],current_diff_sha256=hashlib.sha256(c['diff'].encode()).hexdigest(),current_source_sha256=hashlib.sha256(before).hexdigest(),group=group,mapping='equal source-line matching block from 63b05ca, same column/function/genre/replacement',execution='not_run_by_mapping');rows.append(x)
assert len(rows)==16 and len({x['current_id'] for x in rows})==16
(r/'t52-g05-mapping.json').write_text(json.dumps({'items':rows},indent=2)+'\n');print('16 unique exact current mappings verified')
