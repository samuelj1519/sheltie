import pathlib,json,hashlib,subprocess,re,collections
b=pathlib.Path('/private/tmp/sheltie-completion-20261003');p=pathlib.Path('specs/changes/active/C002-v0.2.0-reliability/evidence/completion-20261003'); h=lambda q:hashlib.sha256(pathlib.Path(q).read_bytes()).hexdigest();load=lambda q:json.loads(pathlib.Path(q).read_text())
g=load(p/'t51-final-gates.json');d=load(p/'t51-g04-dispositions.json');mapping=load(b/'t51-final-mapping.json')['items']; sets=[]; entries=[]
for batch in 'ABC':
 q=b/'mutation-g04-final'/batch;s=load(q/'selection.json');r=load(q/'result.json');o=load(q/'mutants.out/outcomes.json')['outcomes'];sets.append(s['source_sha256']);assert r['exit_code']==0 and r['source_unchanged'];assert len(o)==len(s['items'])+1
 assert o[0]['scenario']=='Baseline' and o[0]['summary']=='Success';txt=(q/'mutants.out'/o[0]['log_path']).read_text();assert re.search(r'14 tests run: 14 passed',txt)
 for a in o[1:]:
  name=a['scenario']['Mutant']['name'];item=next(x for x in d['items'] if x['current_id']==name);assert a['summary']=='CaughtMutant';assert a['phase_results'][0]['process_status']=='Success' and a['phase_results'][1]['process_status']=={'Failure':100};assert item['phase_results']==a['phase_results']
  assert h(q/'mutants.out'/a['log_path'])==item['log_sha256'];assert h(q/'mutants.out'/a['diff_path'])==item['current_diff_sha256'];txt=(q/'mutants.out'/a['log_path']).read_text();assert not re.search(r'TIMEOUT|LEAK|failed to reach observation point',txt)
  panics=re.findall(r"thread '([^']+)'[^\n]*panicked at[^\n]*\n(.*?)(?=\n\s*(?:note:|failures:|test result:|thread ')|\Z)",txt,re.S);assert panics;assert set(item['failing_tests'])==set(x[0] for x in panics)
  c=item['detection_class'];evidence=[]
  for t,body in panics:
   if (c=='actual_exec_inheritance_mechanism' and ('live constrained FD leaked into exec' in body or ('right: []' in body and 'left: [' in body))) or (c=='kernel_fd_flags_mechanism' and ('status.contains' in body or 'descriptor.contains' in body or 'right: 2' in body)) or (c=='exclusive_creation_rejection' and ('temporary collision' in body or 'write_new' in body)) or (c=='actual_fifo_open_mechanism' and 'opened a FIFO' in body) or c in ['name_alias_or_invalid_type_rejection','constrained_open_error_diagnostic','same_inode_alias_actual_acceptance']:evidence.append({'test':t,'panic':body.strip()[:500]})
  assert evidence, name
  refined=c
  if c=='name_alias_or_invalid_type_rejection':
   refined='constrained_open_error_diagnostic' if item['function']=='ManagedFs::ensure_dir_unlocked' else 'same_inode_alias_accepted'
  entries.append({'old_id':item['old_id'],'current_id':name,'ledger_classification':c,'reviewer_classification':refined,'evidence':evidence,'log_sha256':item['log_sha256'],'diff_sha256':item['current_diff_sha256'],'build_success':True,'test_failure':100})
print('logs_checked')
assert sets[0]==sets[1]==sets[2];drift=[k for k,v in sets[0].items() if h(k)!=v];assert not drift
assert all(sets[0].get(k)==v for k,v in g['inputs'].items());assert all(h(k)==v for k,v in g['inputs'].items())
assert len(entries)==len({x['old_id'] for x in entries})==len({x['current_id'] for x in entries})==27
assert {x['current_id'] for x in mapping}=={x['current_id'] for x in entries};assert {x['old_id'] for x in mapping}=={x['old_id'] for x in entries}
archive='specs/changes/active/C002-v0.2.0-reliability/evidence/m1-2026-10-01/mutants/adaptive-validation-2026-10-02/SK02-missing-execution-map.json';old=json.loads(subprocess.check_output(['git','show','e54dcd41d8f1e186007b62b47583063cb19a4b66:'+archive]));assert {x['id'] for x in old['items'] if x['group_id']=='G04'}=={x['old_id'] for x in entries};assert all(x['old_stage1_formal_summary']=='MissedMutant' for x in d['items'])
print('closure_mapping_checked')
for r in g['results']:assert r['exit_code']==0 and h(p/('t51-final-'+r['name']+'.txt'))==r['output_sha256'],r['name']
for name in ['t51-msrv.json','t51-default-gates.json','t51-task-gates.json']:
 a=load(p/name);a=a if isinstance(a,list) else [a]
 for r in a:
  raw=r.get('output_file') or ('t51-'+({'task':'task','default-check':'default-check'}.get(r.get('name'),'msrv'))+'.txt');assert h(p/raw)==r['output_sha256'],raw
nextest=(p/'t51-final-nextest.txt').read_text();assert '720db473-4ee4-40e6-b620-866743570264' in nextest;assert re.search(r'894 tests run: 894 passed(?: \(2 slow\))?, 0 skipped',nextest);assert not re.search(r'LEAK|TIMEOUT',nextest)
doc=(p/'t51-final-doctest.txt').read_text();assert '5 passed; 0 failed' in doc
print('gates_checked')
binaries=load(p/'t51-frozen-binaries.json');resolver=[json.loads(x) for x in (p/'t51-binary-resolver.jsonl').read_text().splitlines()]
for name,a in binaries['artifacts'].items():
 assert h(a['frozen'])==h(a['original'])==a['sha256'];assert a==g['frozen_binaries'][name]
 arts=[x for x in resolver if x.get('reason')=='compiler-artifact' and x.get('executable')==a['original']];assert len(arts)==1 and arts[0]['fresh'];assert binaries['cargo_artifact_resolution']['artifacts'][name]['cargo_executable']==a['original']
print('binaries_checked')
audit={'result':'PASS_scoped_T51_G04','reviewer':'independent oracle reviewer; no implementation/oracle authorship','input_count':len(sets[0]),'gate_input_count':len(g['inputs']),'source_drift':drift,'source_sha256':{k:h(k) for k in ['crates/sheltie-runtime/src/fsx.rs','crates/sheltie-runtime/src/failpoint.rs']},'ledger_counts':dict(collections.Counter(x['ledger_classification'] for x in entries)),'reviewer_counts':dict(collections.Counter(x['reviewer_classification'] for x in entries)),'dynamic_caught':27,'static':0,'missed':0,'timeout':0,'compile_only':0,'old_ids_exact_G04':True,'mapping_bijective':True,'old_stage1_results_preserved':True,'full_engineering':{'nextest':894,'passed':894,'skipped':0,'leak':0,'doctests':5,'run_id':'720db473-4ee4-40e6-b620-866743570264','fmt_check_clippy_msrv_default':0,'fixed_binary_traceability':True},'task_gate':{'task':0,'check_task':'precompletion doing guard exit1; required after done'},'entries':entries}
(b/'t51-final-review.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in audit.items() if k!='entries'},ensure_ascii=False,indent=2))
