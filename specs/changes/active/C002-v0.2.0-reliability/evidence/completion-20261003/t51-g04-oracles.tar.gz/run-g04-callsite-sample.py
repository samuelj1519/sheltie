from pathlib import Path
import subprocess,json,time
root=Path('/private/tmp/sheltie-completion-20261003')
records=[]
for name in ['A','B']:
 print('START',name,flush=True)
 with (root/f'g04-callsite-{name}-driver.txt').open('wb') as output:
  code=subprocess.run(['python3',str(root/f'check-g04-callsite-{name}.py')],stdout=output,stderr=subprocess.STDOUT).returncode
 result=root/'mutation-g04-callsite'/name/'result.json'
 record=json.loads(result.read_text()) if result.exists() else {'status':'incomplete','driver_exit':code}
 records.append({'batch':name,'result':record})
 (root/'g04-callsite-batches.json').write_text(json.dumps(records,indent=2)+'\n')
 print('FINISH',name,{key:record.get(key) for key in ['exit_code','elapsed_seconds','counts','source_unchanged','status']},flush=True)
 if code!=0 or record.get('exit_code')!=0 or record.get('source_unchanged') is not True: break
