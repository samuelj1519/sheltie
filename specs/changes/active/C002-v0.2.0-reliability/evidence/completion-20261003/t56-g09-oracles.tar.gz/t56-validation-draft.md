

## C002-T56 pending 资格、失败补偿与恢复分派

依据 [G09 独立准备](evidence/completion-20261003/g09-oracle-directions.md)，准确15旧ID分13动态和2限定静态证明。新增10项、复用1项既有未提交同请求清理门槛测试；修后11/11针对性基线通过。真实CREATE|EXCL对象在write后模型化sync错误进入失败补偿，合法补偿移除本次A，换名竞争者B及保留A的字节、设备/inode/权限/链接数均不变。清理观察自身I/O失败保留原件并RecoveryRequired；直接stage_pending三操作核owner已写、父目录sync失败时container/payload尚未创建。不称真实磁盘故障、断电或整个业务事务验证。

真实登记的全局pending路径单项损坏先拒索引，合法未提交邻居原件不被清理；coupled owner/container非UUID只告未知并保全。missing root用真实未发布A与完成B，告警关系仅A，并比较保存树的完整路径/字节/dev/inode/mode/nlink与五表原始值。独立审查首次发现只核is_dir不足，补完整保全断言后增量通过；原needs-changes和编译错误保留，不声称SQLite物理文件或timestamp全部不变。

CLI由真实completed B和真实COMMIT后exit70未完成A产生缓存分派场景。健康A先恢复再重放B；坏A拒EFFECT_PENDING，顶层当前请求B、手写原B、detail原A/cause、五表与实际A树均保留。已清完成delete配置专属清理故障后重放仍无不存在marker告警；既有同rid未提交场景验证故障时未登记、解除后仅一次提交。fixture API/wire探索失败原文保留，不写成产品错误或通过。

静态证明仅处分两个精确位置：同局部None/None组合已early continue的不可达分支，以及纯索引装入前置digest资格/末尾同invocation重复关联拒绝。后者保留首诊断、处理顺序、克隆/解析/分配成本差异；均动态not_run，不记旧Caught或完整资源/JSON等价。
