import json,subprocess,os,re,time,hashlib,collections
from pathlib import Path
root=Path('/private/tmp/sheltie-completion-20261003')
correspondence={x['old_id']:x for x in json.loads((root/'independent-sk02-mapping.json').read_text())['all_correspondences']}
missing=json.loads((root/'sk02-map.json').read_text())['items']
filters={
 'G10':'package(sheltie-runtime) & test(/schema|column|user_version|store.*valid|revision|conflict|constraint/)',
 'G11':'package(sheltie-runtime) & (binary(selfmgmt) | test(/^selfmgmt::/))',
 'G12':'package(sheltie-runtime) & (binary(selfmgmt) | test(/^selfmgmt::/))',
}
completed={o['scenario']['Mutant']['name'] for o in json.loads((root/'mutation-sample/mutants.out/outcomes.json').read_text())['outcomes'] if isinstance(o['scenario'],dict) and o['summary']=='CaughtMutant'}
env=os.environ.copy();env['RUSTC_WRAPPER']='';env['CARGO_TARGET_DIR']='target';env['CARGO_BUILD_JOBS']='2';env['PATH']=str(root/'tools/nextest')+os.pathsep+env['PATH']
input_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('crates').rglob('*.rs')}
records=[]
for group in ['G10','G11','G12']:
 items=[{'old_id':i['id'],'current_id':correspondence[i['id']]['current_id']} for i in missing if i['group_id']==group and correspondence[i['id']]['current_id'] not in completed]
 if not items:continue
 output=root/'mutation-groups'/group;output.mkdir(parents=True,exist_ok=True)
 (output/'selection.json').write_text(json.dumps({'candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'items':items,'filter':filters[group],'source_sha256':input_hashes},indent=2)+'\n')
 regex='^(?:'+'|'.join(re.escape(i['current_id']) for i in items)+')$'
 cmd=['cargo','mutants','-p','sheltie-runtime','--test-package','sheltie-runtime','--test-package','sheltie-cli','--test-tool','nextest','--all-features','--cargo-arg=--locked','--cargo-arg=--package=sheltie-cli','--timeout','120','--build-timeout','240','--jobs','2','--output',str(output),'--re',regex,'--cargo-test-arg=-E','--cargo-test-arg='+filters[group],'--cargo-test-arg=--test-threads=4']
 start=time.monotonic();print('START',group,len(items),flush=True)
 with (output/'console.txt').open('wb') as f:
  try:code=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=720).returncode
  except subprocess.TimeoutExpired:code='group_timeout'
 result={'group':group,'argv':cmd,'exit_code':code,'elapsed_seconds':round(time.monotonic()-start,3),'source_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in input_hashes.items())}
 raw=output/'mutants.out/outcomes.json'
 if raw.exists():
  outcomes=json.loads(raw.read_text());result['counts']=dict(collections.Counter(o['summary'] for o in outcomes['outcomes']))
  baseline=next((o for o in outcomes['outcomes'] if o['scenario']=='Baseline'),None)
  if baseline:
   text=(output/'mutants.out'/baseline['log_path']).read_text();n=re.search(r'([0-9]+) tests run:',text)
   result['baseline_tests']=int(n.group(1)) if n else None
 records.append(result);(root/'mutation-groups/results.json').write_text(json.dumps(records,indent=2)+'\n');print('FINISH',result,flush=True)
 if code not in (0,2) or not result['source_unchanged'] or not result.get('baseline_tests'):break
